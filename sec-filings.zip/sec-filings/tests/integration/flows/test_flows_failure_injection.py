"""Failure injection (PLAN 8.3): break the data or the inputs, assert the right check fires."""

from __future__ import annotations

import json
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

import pytest
from flow_helpers import (
    GOLDEN_QUERIES,
    REPO,
    RUN_KW,
    TODAY,
    execute,
    fixture_bytes,
    patched_client,
    query,
    scalar,
)

from sec_filings import flows
from sec_filings.edgar.daily_index import daily_index_url, full_index_url
from sec_filings.edgar.submissions import submissions_url
from sec_filings.edgar.tickers import TICKERS_URL
from sec_filings.errors import ChecksRed, EdgarHTTPError
from sec_filings.models import CheckReport

pytestmark = pytest.mark.db

LONDON = ZoneInfo("Europe/London")
INDEX_FIXTURE = "www.sec.gov/Archives/edgar/daily-index/2026/QTR4/form.20261102.idx"


def run_check(settings, **kw) -> CheckReport:
    """flows.check, whether or not it raises (the golden data has genuine reds)."""
    kw.setdefault("today", TODAY)
    kw.setdefault("now", RUN_KW["now"])
    try:
        return flows.check(settings, **kw)
    except ChecksRed as exc:
        return exc.report


def statuses(report: CheckReport, check_id: str) -> list[str]:
    return [r.status for r in report.results if r.check_id == check_id]


def only_aapl(tmp_path):
    csv = tmp_path / "aapl.csv"
    csv.write_text("ticker\nAAPL\n", encoding="utf-8")
    return csv


def test_deleted_filing_row_turns_c6_red_on_the_next_check(clone):
    url, settings = clone()
    assert statuses(run_check(settings), "C6") == ["green"]
    accession = scalar(
        url,
        "SELECT accession_number FROM filing WHERE company_id = 'TM' "
        "AND form_family = 'foreign_current_report' ORDER BY accession_number LIMIT 1",
    )
    execute(url, "DELETE FROM filing WHERE accession_number = %s", (accession,))
    report = run_check(settings)
    assert statuses(report, "C6") == ["red"]
    (c6,) = [r for r in report.results if r.check_id == "C6"]
    assert "TM|foreign_current_report" in c6.message or "TM foreign_current_report" in c6.message
    # A second check must not "accept" the drop: the baseline stays where the sync left it.
    assert statuses(run_check(settings), "C6") == ["red"]


def test_changed_ticker_mapping_turns_c4_red(clone):
    url, settings = clone()
    tickers = json.loads(fixture_bytes("www.sec.gov/files/company_tickers.json"))
    for entry in tickers.values():
        if entry["ticker"] == "XOM":
            entry["cik_str"] = 9_999_999  # the next "XOM moved" event
    client = patched_client(settings, {TICKERS_URL: (200, json.dumps(tickers).encode())})
    run = flows.sync(settings, tickers=["XOM"], client=client, **RUN_KW)
    assert run.status == "success"
    c4 = [r for r in flows.read_results(settings, run.run_id) if r.check_id == "C4"]
    assert [(r.status, r.company_id) for r in c4] == [("red", "XOM")]
    assert "9999999" in c4[0].message
    # The job did not silently follow the new CIK.
    assert [r[0] for r in query(url, "SELECT cik FROM company_cik WHERE company_id = 'XOM'")] == [
        34088,
        2115436,
    ]


def test_missing_daily_index_day_is_amber_and_retried(clone):
    url, settings = clone()
    morning = datetime(2026, 11, 4, 6, 5, tzinfo=LONDON)
    next_day = {**RUN_KW, "today": date(2026, 11, 4), "now": morning}
    # The fixtures hold no index for 2026-11-03, exactly like an index not yet published.
    run = flows.sync(settings, **next_day)
    assert run.status == "success"
    days = query(url, "SELECT index_date, status FROM daily_index_reconciliation ORDER BY 1")
    assert days == [(date(2026, 11, 2), "ok"), (date(2026, 11, 3), "not_published")]
    c3 = [r for r in flows.read_results(settings, run.run_id) if r.check_id == "C3"]
    assert [r.status for r in c3] == ["amber"]
    # Once the index appears, the next run reconciles it (the 11-02 file stands in for it).
    published = {daily_index_url(date(2026, 11, 3)): (200, fixture_bytes(INDEX_FIXTURE))}
    later = flows.sync(settings, client=patched_client(settings, published), **next_day)
    assert query(
        url,
        "SELECT status FROM daily_index_reconciliation WHERE index_date = %s",
        (date(2026, 11, 3),),
    ) == [("ok",)]
    c3 = [r for r in flows.read_results(settings, later.run_id) if r.check_id == "C3"]
    assert [r.status for r in c3] == ["green"]


def test_daily_index_filing_we_lack_turns_c3_red(fresh_db, tmp_path):
    url, settings = fresh_db(only_aapl(tmp_path))
    unknown = "0000320193-26-999999"
    pad = " " * 40
    extra = f"10-Q             Apple Inc.{pad}320193       20261102    "
    extra += f"edgar/data/320193/{unknown}.txt"
    body = fixture_bytes(INDEX_FIXTURE).rstrip(b"\r\n") + b"\n" + extra.encode() + b"\n"
    client = patched_client(settings, {daily_index_url(date(2026, 11, 2)): (200, body)})
    run = flows.sync(settings, client=client, **RUN_KW)
    (c3,) = [r for r in flows.read_results(settings, run.run_id) if r.check_id == "C3"]
    assert c3.status == "red" and unknown in c3.message
    assert query(url, "SELECT status, missing FROM daily_index_reconciliation") == [
        ("missing_filings", [unknown])
    ]


def test_no_run_by_the_deadline_turns_the_heartbeat_red(clone):
    _, settings = clone()
    late = datetime(2026, 11, 4, 8, 0, tzinfo=LONDON)  # the next morning, past 07:00, no sync ran
    report = run_check(settings, today=date(2026, 11, 4), now=late)
    assert statuses(report, "C1") == ["red"]


def test_page_count_mismatch_turns_c5_red(clone):
    url, settings = clone()
    execute(url, "UPDATE history_page SET filing_count = filing_count + 5 WHERE cik = 320193")
    assert statuses(run_check(settings), "C5") == ["red"]


def test_broken_golden_query_turns_c11_red(clone, tmp_path):
    _, settings = clone()
    text = GOLDEN_QUERIES.read_text(encoding="utf-8").replace(
        "0001193125-10-012091", "0001193125-09-214859"
    )
    broken = tmp_path / "queries.yml"
    broken.write_text(text, encoding="utf-8")
    report = run_check(settings, golden_queries_path=broken)
    assert statuses(report, "C11") == ["red"]
    (c11,) = [r for r in report.results if r.check_id == "C11"]
    assert "aapl-fy2009-10ka" in c11.message


# --------------------------------------------------------------------------- round 2

MONDAY = date(2026, 11, 9)
MONDAY_RUN = {**RUN_KW, "today": MONDAY, "now": datetime(2026, 11, 9, 6, 5, tzinfo=LONDON)}
MASTER = REPO / "tests" / "fixtures" / "derived" / "master_2026Q4_excerpt.idx"
MASTER_URL = full_index_url(2026, 4)
XOM_Q3 = "0002115436-26-000020"  # a 10-Q filed 2026-11-02 under the new Exxon CIK
FAKE = "0000320193-26-999998"


def master_without(*accessions: str, extra: str = "") -> bytes:
    lines = MASTER.read_text(encoding="utf-8").splitlines()
    kept = [ln for ln in lines if not any(a in ln for a in accessions)]
    return ("\n".join(kept + ([extra] if extra else [])) + "\n").encode("utf-8")


def error_summary(url, run_id):
    return scalar(url, "SELECT error_summary FROM run WHERE run_id = %s", (str(run_id),)) or ""


def test_monday_master_index_marks_a_vanished_filing_stale_and_reports_it(clone):
    url, settings = clone()
    sql = "SELECT is_stale FROM filing WHERE accession_number = %s"
    assert scalar(url, sql, (XOM_Q3,)) is False
    before = scalar(url, "SELECT count(*) FROM filing")
    client = patched_client(settings, {MASTER_URL: (200, master_without(XOM_Q3))})
    run = flows.sync(settings, client=client, **MONDAY_RUN)
    assert run.status == "success"
    assert query(
        url, "SELECT is_stale, stale_run_id FROM filing WHERE accession_number = %s", (XOM_Q3,)
    ) == [(True, run.run_id)]
    assert scalar(url, "SELECT count(*) FROM filing") == before  # never deleted (D-07)
    assert XOM_Q3 in error_summary(url, run.run_id)
    results = flows.read_results(settings, run.run_id)
    (x1,) = [r for r in results if r.check_id == "X1"]
    assert (x1.status, x1.tier) == ("amber", "extended") and XOM_Q3 in x1.message
    assert [r.status for r in results if r.check_id == "C6"] == ["green"]  # counts include stale


def test_monday_master_index_unchanged_marks_nothing_and_other_days_do_not_fetch_it(clone):
    url, settings = clone()
    client = patched_client(settings, {MASTER_URL: (200, MASTER.read_bytes())})
    run = flows.sync(settings, client=client, **MONDAY_RUN)
    assert scalar(url, "SELECT count(*) FROM filing WHERE is_stale") == 0
    assert "master index" not in error_summary(url, run.run_id)
    # A Tuesday never fetches it: a garbage body would otherwise be reported.
    tuesday = {**MONDAY_RUN, "today": date(2026, 11, 10)}
    client = patched_client(settings, {MASTER_URL: (200, b"garbage")})
    run = flows.sync(settings, client=client, **tuesday)
    assert "master index" not in error_summary(url, run.run_id)
    # And a backfill does not either.
    client = patched_client(settings, {MASTER_URL: (200, b"garbage")})
    run = flows.backfill(settings, tickers=["AAPL"], client=client, **MONDAY_RUN)
    assert "master index" not in error_summary(url, run.run_id)


def test_monday_master_entry_missing_from_the_table_turns_c3_red(clone):
    url, settings = clone()
    extra = f"320193|Apple Inc.|10-Q|2026-11-02|edgar/data/320193/{FAKE}.txt"
    client = patched_client(settings, {MASTER_URL: (200, master_without(extra=extra))})
    run = flows.sync(settings, client=client, **MONDAY_RUN)
    assert query(
        url,
        "SELECT status, missing FROM daily_index_reconciliation WHERE index_date = %s",
        (date(2026, 11, 2),),
    ) == [("missing_filings", [FAKE])]
    c3 = [r for r in flows.read_results(settings, run.run_id) if r.check_id == "C3"]
    assert [r for r in c3 if r.status == "red" and FAKE in r.message]
    assert FAKE in error_summary(url, run.run_id)


def test_missing_day_is_rechecked_every_run_until_it_turns_ok(clone):
    url, settings = clone()
    present = scalar(url, "SELECT accession_number FROM filing WHERE company_id = 'AAPL' LIMIT 1")
    execute(
        url,
        "UPDATE daily_index_reconciliation SET status = 'missing_filings', entries_for_us = 2, "
        "missing = %s WHERE index_date = %s",
        ([present, FAKE], date(2026, 11, 2)),
    )
    run = flows.sync(settings, **RUN_KW)
    assert query(
        url,
        "SELECT status, missing FROM daily_index_reconciliation WHERE index_date = %s",
        (date(2026, 11, 2),),
    ) == [("missing_filings", [FAKE])]  # one arrived, one is still missing
    assert [r.status for r in flows.read_results(settings, run.run_id) if r.check_id == "C3"] == [
        "red"
    ]
    execute(
        url,
        "UPDATE daily_index_reconciliation SET missing = %s WHERE index_date = %s",
        ([present], date(2026, 11, 2)),
    )
    run = flows.sync(settings, **RUN_KW)
    assert query(
        url,
        "SELECT status, missing FROM daily_index_reconciliation WHERE index_date = %s",
        (date(2026, 11, 2),),
    ) == [("ok", [])]
    assert [r.status for r in flows.read_results(settings, run.run_id) if r.check_id == "C3"] == [
        "green"
    ]


def test_daily_index_http_error_is_recorded_not_published_and_never_fails_the_run(clone):
    url, settings = clone()
    day = daily_index_url(date(2026, 11, 3))

    class Flaky(type(patched_client(settings, {}))):
        def get(self, u):
            if u == day:
                raise EdgarHTTPError("HTTP 500 from daily index after 4 attempts")
            return super().get(u)

    client = Flaky(
        settings.user_agent, fixtures_dir=settings.fixtures_dir, request_budget=6000, overrides={}
    )
    run = flows.sync(settings, client=client, **{**RUN_KW, "today": date(2026, 11, 4)})
    assert run.status == "success"
    assert query(
        url,
        "SELECT status FROM daily_index_reconciliation WHERE index_date = %s",
        (date(2026, 11, 3),),
    ) == [("not_published",)]
    assert "HTTP 500" in error_summary(url, run.run_id)


def test_two_hour_old_running_run_turns_c2_red_in_a_check(clone):
    url, settings = clone()
    execute(
        url,
        "INSERT INTO run (run_id, started_at, mode, status) "
        "VALUES (gen_random_uuid(), now(), 'sync', 'running')",
    )
    later = datetime.now(LONDON) + timedelta(hours=3)
    c2 = [r for r in run_check(settings, now=later).results if r.check_id == "C2"]
    assert [r.status for r in c2] == ["red"] and "run died" in c2[0].message


def test_check_honours_expect_run_by(clone):
    from datetime import time

    _, settings = clone()
    now = datetime(2026, 11, 4, 8, 0, tzinfo=LONDON)  # no sync ran on the 4th
    day = date(2026, 11, 4)
    assert statuses(run_check(settings, today=day, now=now), "C1") == ["red"]
    assert statuses(run_check(settings, today=day, now=now, expect_run_by=time(9, 0)), "C1") == [
        "green"
    ]


def test_heartbeat_pings_ok_on_success_and_fail_url_on_partial(clone, monkeypatch):
    from dataclasses import replace

    _, settings = clone()
    settings = replace(settings, heartbeat_url="https://hc.example/ping/abc")
    pings: list[tuple[str, bool]] = []
    monkeypatch.setattr(
        flows, "ping_heartbeat", lambda url, failed=False, **kw: pings.append((url, failed))
    )
    flows.sync(settings, **RUN_KW)
    assert pings == [("https://hc.example/ping/abc", False)]
    client = patched_client(settings, {submissions_url(789019): (500, b"")})
    run = flows.sync(settings, client=client, **RUN_KW)
    assert run.status == "partial"
    assert pings[-1] == ("https://hc.example/ping/abc", True)
