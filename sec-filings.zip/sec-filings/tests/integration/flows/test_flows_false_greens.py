"""Second review: situations in which the morning check showed green or amber wrongly."""

from __future__ import annotations

from dataclasses import replace
from datetime import date, datetime
from zoneinfo import ZoneInfo

import psycopg
import pytest
from flow_helpers import (
    GOLDEN_QUERIES,
    RUN_KW,
    TODAY,
    execute,
    fixture_bytes,
    patched_client,
    query,
    scalar,
)

from sec_filings import flows
from sec_filings.edgar.daily_index import daily_index_url
from sec_filings.edgar.tickers import TICKERS_URL
from sec_filings.errors import ChecksRed, EdgarHTTPError, RunFailed

pytestmark = pytest.mark.db

LONDON = ZoneInfo("Europe/London")
INDEX_FIXTURE = "www.sec.gov/Archives/edgar/daily-index/2026/QTR4/form.20261102.idx"
HB = "https://hc.example/ping/abc"


def aapl_csv(tmp_path):
    csv = tmp_path / "aapl.csv"
    csv.write_text("ticker\nAAPL\n", encoding="utf-8")
    return csv


def empty_golden(tmp_path):
    path = tmp_path / "golden_empty.yml"
    path.write_text("[]\n", encoding="utf-8")
    return path


def broken_golden(tmp_path):
    text = GOLDEN_QUERIES.read_text(encoding="utf-8").replace(
        "0001193125-10-012091", "0001193125-09-214859"
    )
    path = tmp_path / "golden_broken.yml"
    path.write_text(text, encoding="utf-8")
    return path


def kw(**over):
    return {**RUN_KW, **over}


# ---------------------------------------------------------------- 2. run scope


def test_runs_limited_to_tickers_are_recorded_as_subset(fresh_db, tmp_path):
    url, settings = fresh_db(aapl_csv(tmp_path))
    flows.backfill(settings, tickers=["AAPL"], **RUN_KW)
    flows.sync(settings, **RUN_KW)
    flows.sync(settings, tickers=["AAPL"], **RUN_KW)
    assert query(url, "SELECT mode, scope FROM run ORDER BY started_at") == [
        ("backfill", "subset"),
        ("sync", "all"),
        ("sync", "subset"),
    ]


def test_failed_morning_sync_stays_red_after_a_successful_single_ticker_backfill(
    fresh_db, tmp_path
):
    url, settings = fresh_db(aapl_csv(tmp_path))
    # 06:05 the morning sync failed ...
    flows.backfill(settings, tickers=["AAPL"], **RUN_KW)
    execute(
        url,
        "INSERT INTO run (run_id, started_at, finished_at, mode, status, scope, error_summary) "
        "VALUES (gen_random_uuid(), now() - interval '1 minute', now(), 'sync', 'failed', "
        "'all', 'boom')",
    )
    # ... `backfill -t AAPL` succeeded at 10:00, and the check ran at 10:05
    late = datetime(2026, 11, 3, 10, 5, tzinfo=LONDON)
    try:
        report = flows.check(settings, today=TODAY, now=late)
    except ChecksRed as exc:
        report = exc.report
    by_id = {r.check_id: r for r in report.results}
    assert by_id["C1"].status == "red"
    assert by_id["C2"].status == "red" and "boom" in by_id["C2"].message
    assert report.exit_code == 2


# ---------------------------------------------------------------- 3. report write crash


def test_check_still_raises_checks_red_when_the_report_cannot_be_written(fresh_db, tmp_path):
    url, settings = fresh_db(aapl_csv(tmp_path))
    flows.sync(settings, **kw(golden_queries_path=empty_golden(tmp_path)))
    blocker = tmp_path / "not_a_directory"
    blocker.write_text("x", encoding="utf-8")
    broken = replace(settings, reports_dir=blocker / "reports")  # mkdir under a file fails
    late = datetime(2026, 11, 4, 8, 0, tzinfo=LONDON)  # no sync today: C1 is red
    with pytest.raises(ChecksRed) as excinfo:
        flows.check(broken, today=date(2026, 11, 4), now=late)
    assert any(r.status == "red" for r in excinfo.value.report.results)
    assert "could not be written" in excinfo.value.report.markdown


def test_sync_reports_run_failed_even_when_the_report_cannot_be_written(fresh_db, tmp_path):
    url, settings = fresh_db(aapl_csv(tmp_path))
    blocker = tmp_path / "not_a_directory"
    blocker.write_text("x", encoding="utf-8")
    broken = replace(settings, reports_dir=blocker / "reports")
    with pytest.raises(RunFailed) as excinfo:
        flows.sync(broken, client=patched_client(broken, {}, budget=3), **RUN_KW)
    assert excinfo.value.result.status == "failed"
    # and a healthy run is not turned into a crash by the report either
    assert flows.sync(broken, **kw(golden_queries_path=empty_golden(tmp_path))).status == "success"


# ---------------------------------------------------------------- raise_on_red


def test_sync_raise_on_red_raises_after_the_report_is_written(fresh_db, tmp_path):
    url, settings = fresh_db(aapl_csv(tmp_path))
    golden = broken_golden(tmp_path)
    run = flows.sync(settings, **kw(golden_queries_path=golden))  # default: returns
    assert run.status == "success"
    assert any(r.status == "red" for r in flows.read_results(settings, run.run_id))
    with pytest.raises(ChecksRed) as excinfo:
        flows.sync(settings, raise_on_red=True, **kw(golden_queries_path=golden))
    assert any(r.check_id == "C11" and r.status == "red" for r in excinfo.value.report.results)
    assert (settings.reports_dir / "morning_check_2026-11-03.md").is_file()
    # the run itself stays 'success': red checks are not a failed run
    assert query(url, "SELECT status FROM run ORDER BY started_at DESC LIMIT 1") == [("success",)]


def test_sync_raise_on_red_still_raises_run_failed_for_a_failed_run(fresh_db, tmp_path):
    _, settings = fresh_db(aapl_csv(tmp_path))
    with pytest.raises(RunFailed):
        flows.sync(
            settings, raise_on_red=True, client=patched_client(settings, {}, budget=3), **RUN_KW
        )


def test_sync_raise_on_red_does_not_raise_when_nothing_is_red(fresh_db, tmp_path):
    _, settings = fresh_db(aapl_csv(tmp_path))
    run = flows.sync(settings, raise_on_red=True, **kw(golden_queries_path=empty_golden(tmp_path)))
    assert run.status == "success"


# ---------------------------------------------------------------- 7. ticker file outage


def _client_without_ticker_file(settings):
    base = patched_client(settings, {})

    class Outage(type(base)):
        def get(self, u):
            if u == TICKERS_URL:
                raise EdgarHTTPError("HTTP 503 from the ticker file after 4 attempts")
            return super().get(u)

    return Outage(
        settings.user_agent, fixtures_dir=settings.fixtures_dir, request_budget=6000, overrides={}
    )


def test_ticker_file_outage_does_not_fail_the_run_and_c4_is_amber(fresh_db, tmp_path):
    url, settings = fresh_db(aapl_csv(tmp_path))
    run = flows.sync(
        settings,
        client=_client_without_ticker_file(settings),
        **kw(golden_queries_path=empty_golden(tmp_path)),
    )
    assert run.status == "success", run.error_summary
    assert "ticker file unavailable" in (run.error_summary or "")
    assert scalar(url, "SELECT count(*) FROM filing WHERE company_id = 'AAPL'") > 100
    c4 = [r for r in flows.read_results(settings, run.run_id) if r.check_id == "C4"]
    assert [r.status for r in c4] == ["amber"] and "ticker map unavailable" in c4[0].message


# ---------------------------------------------------------------- 9. lost connection


def test_a_run_that_dies_after_start_is_marked_failed_and_pings_fail(
    fresh_db, tmp_path, monkeypatch
):
    url, settings = fresh_db(aapl_csv(tmp_path))
    settings = replace(settings, heartbeat_url=HB)
    pings: list[tuple[str, bool]] = []
    monkeypatch.setattr(
        flows, "ping_heartbeat", lambda u, failed=False, **k: pings.append((u, failed))
    )

    def dead(*a, **k):
        raise psycopg.OperationalError("server closed the connection unexpectedly")

    monkeypatch.setattr(flows, "_run_body", dead)
    with pytest.raises(psycopg.OperationalError):
        flows.sync(settings, **RUN_KW)
    (status, summary, finished) = query(url, "SELECT status, error_summary, finished_at FROM run")[
        0
    ]
    assert status == "failed" and "OperationalError" in summary and finished is not None
    assert pings == [(HB, True)]


def test_a_crash_after_the_run_row_was_finished_still_ends_failed(fresh_db, tmp_path, monkeypatch):
    url, settings = fresh_db(aapl_csv(tmp_path))
    monkeypatch.setattr(flows, "run_core_checks", lambda *a, **k: 1 / 0)
    with pytest.raises(ZeroDivisionError):
        flows.sync(settings, **RUN_KW)
    assert query(url, "SELECT status FROM run") == [("failed",)]


# ---------------------------------------------------------------- 10. heartbeat honesty


def test_heartbeat_pings_ok_only_when_the_run_succeeded_and_nothing_is_red(
    fresh_db, tmp_path, monkeypatch
):
    _, settings = fresh_db(aapl_csv(tmp_path))
    settings = replace(settings, heartbeat_url=HB)
    pings: list[tuple[str, bool]] = []
    monkeypatch.setattr(
        flows, "ping_heartbeat", lambda u, failed=False, **k: pings.append((u, failed))
    )
    flows.sync(settings, **kw(golden_queries_path=broken_golden(tmp_path)))  # success, C11 red
    assert pings == [(HB, True)]
    flows.sync(settings, **kw(golden_queries_path=empty_golden(tmp_path)))  # success, none red
    assert pings[-1] == (HB, False)
    # a run limited to some tickers never vouches for the morning job
    pings.clear()
    flows.sync(settings, tickers=["AAPL"], **kw(golden_queries_path=empty_golden(tmp_path)))
    assert pings == []


# ---------------------------------------------------------------- 5. retry the whole window


def test_an_unpublished_day_is_retried_for_the_whole_30_day_window(fresh_db, tmp_path):
    url, settings = fresh_db(aapl_csv(tmp_path))
    flows.sync(settings, **kw(golden_queries_path=empty_golden(tmp_path)))  # reconciles 11-02
    old = date(2026, 10, 15)  # 19 days before the last due day
    execute(
        url,
        "INSERT INTO daily_index_reconciliation (index_date, status, entries_for_us, missing, "
        "run_id, checked_at) SELECT %s, 'not_published', 0, '{}', run_id, now() FROM run LIMIT 1",
        (old,),
    )
    published = {daily_index_url(old): (200, fixture_bytes(INDEX_FIXTURE))}
    flows.sync(
        settings,
        client=patched_client(settings, published),
        **kw(golden_queries_path=empty_golden(tmp_path)),
    )
    assert query(
        url, "SELECT status FROM daily_index_reconciliation WHERE index_date = %s", (old,)
    ) == [("ok",)]
