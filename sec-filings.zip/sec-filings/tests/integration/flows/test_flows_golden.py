"""An offline backfill of the 12 golden companies, asserted against facts checked by hand."""

from __future__ import annotations

import csv
from datetime import date

import pytest
import yaml
from flow_helpers import GOLDEN_CSV, GOLDEN_QUERIES, query, scalar

from sec_filings import flows
from sec_filings.errors import ChecksRed

pytestmark = pytest.mark.db

APPLE_10K = "0001193125-09-214859"
APPLE_10KA = "0001193125-10-012091"
XOM_Q2 = "0000034088-26-000093"
XOM_Q3 = "0002115436-26-000020"
PLUG_8K = "0001104659-21-037184"
PLUG_ORIGINAL = "0001558370-21-007147"
PLUG_10KA_2022 = "0001558370-22-003577"
LUCID_SHELL_10KA = "0001104659-21-067004"
LUCID_SHELL_8K = "0001104659-21-066993"
GE_FY2014 = "0000040545-15-000030"
WMT_FY2009 = "0000104169-09-000006"
WMT_FY2009_OTHER = "0001193125-10-071652"  # filed 2010-03-30, period 2010-01-31
WMT_FY2014 = "0000104169-14-000019"
TM_FY2021 = "0001193125-21-197902"
TM_FY2021_AMENDMENT_2024 = "0001193125-24-024808"
TM_FY2017 = "0001193125-17-211041"
SHEL_FY2023 = "0001306965-24-000026"
SHEL_FY2024 = "0001306965-25-000007"

_BY_ACCESSION = "SELECT {} FROM filing WHERE accession_number = %s"


def test_run_succeeded_for_every_company(golden):
    assert golden.first.mode == "backfill"
    assert golden.first.status == "success", golden.first.error_summary
    assert golden.first.companies_failed == []
    assert len(golden.first.companies_ok) == 12
    assert golden.first.rows_inserted > 5000 and golden.first.rows_updated == 0


def test_apple_fy2009_canonical_is_the_accounting_change_amendment(golden):
    rows = query(
        golden.url,
        "SELECT accession, form, was_amended, canonical_amendment_kind, amendment_kinds, "
        "original_accession FROM v_annual_reports WHERE company_id = 'AAPL' AND fiscal_year = 2009",
    )
    assert len(rows) == 1
    accession, form, amended, kind, kinds, original = rows[0]
    assert (accession, form, amended, kind) == (APPLE_10KA, "10-K/A", True, "accounting_change")
    assert kinds == ["accounting_change"]
    assert original == APPLE_10K
    assert scalar(golden.url, _BY_ACCESSION.format("form"), (APPLE_10K,)) == "10-K"


def test_exxon_joint_filing_is_stored_once_with_both_ciks(golden):
    q2 = scalar(golden.url, "SELECT count(*) FROM filing WHERE accession_number = %s", (XOM_Q2,))
    assert q2 == 1
    aliases = query(
        golden.url,
        "SELECT cik FROM filing_cik_alias WHERE accession_number = %s ORDER BY cik",
        (XOM_Q2,),
    )
    assert [a[0] for a in aliases] == [34088, 2115436]
    # The Q3 10-Q exists only under the new CIK.
    assert scalar(golden.url, _BY_ACCESSION.format("cik"), (XOM_Q3,)) == 2115436
    no_alias = "SELECT count(*) FROM filing_cik_alias WHERE accession_number = %s"
    assert scalar(golden.url, no_alias, (XOM_Q3,)) == 0


def test_plug_non_reliance_event_links_the_original_not_the_amendment(golden):
    linked, confidence = query(
        golden.url,
        "SELECT corrected_in_accessions, link_confidence FROM correction_event "
        "WHERE source_accession = %s",
        (PLUG_8K,),
    )[0]
    assert PLUG_ORIGINAL in linked
    assert PLUG_10KA_2022 not in linked
    assert confidence == "medium"
    # ...so the full-scope 2022 amendment is not called a restatement.
    kind = scalar(golden.url, _BY_ACCESSION.format("amendment_kind"), (PLUG_10KA_2022,))
    assert kind != "restatement"


def test_lucid_shell_amendment_is_flagged_pre_merger(golden):
    assert scalar(golden.url, _BY_ACCESSION.format("pre_merger_shell"), (LUCID_SHELL_10KA,))
    rows = query(
        golden.url,
        "SELECT pre_merger_shell, link_confidence FROM v_correction_events "
        "WHERE company_id = 'LCID' AND source_accession = %s",
        (LUCID_SHELL_8K,),
    )
    assert rows == [(True, "high")]


def test_wrong_report_dates_are_labelled_with_the_corrected_fiscal_year(golden):
    cols = "fiscal_year, fiscal_period, period_of_report"
    ge = query(golden.url, _BY_ACCESSION.format(cols), (GE_FY2014,))[0]
    assert ge == (2014, "FY", date(2015, 2, 27))  # the raw reportDate is kept, the label is not
    wmt = query(golden.url, _BY_ACCESSION.format(cols), (WMT_FY2009,))[0]
    assert wmt == (2009, "FY", date(2009, 4, 1))


def test_toyota_has_no_quarterly_reports(golden):
    n_quarterly = "SELECT count(*) FROM v_quarterly_reports WHERE company_id = 'TM'"
    assert scalar(golden.url, n_quarterly) == 0
    assert scalar(golden.url, "SELECT count(*) FROM v_annual_reports WHERE company_id = 'TM'") > 5
    sixk = "SELECT count(*), count(fiscal_year) FROM filing WHERE company_id = 'TM' "
    sixk += "AND form_family = 'foreign_current_report'"
    kept, labelled = query(golden.url, sixk)[0]
    assert kept > 100 and labelled == 0  # kept, but never labelled as a periodic report


def test_daily_index_of_2026_11_02_reconciles_cleanly(golden):
    status, entries, missing = query(
        golden.url,
        "SELECT status, entries_for_us, missing FROM daily_index_reconciliation "
        "WHERE index_date = '2026-11-02'",
    )[0]
    assert (status, missing) == ("ok", [])
    assert entries >= 1


def _expected_golden_query_count() -> int:
    """Golden queries for the companies in the golden CSV, counted from the queries file."""
    with open(GOLDEN_CSV, newline="", encoding="utf-8") as fh:
        tickers = {r["ticker"].strip().upper() for r in csv.DictReader(fh)}
    queries = yaml.safe_load(GOLDEN_QUERIES.read_text(encoding="utf-8"))
    return sum(1 for q in queries if str(q["company_id"]).upper() in tickers)


def test_golden_queries_are_green(golden):
    results = query(
        golden.url,
        "SELECT status, message FROM check_result WHERE run_id = %s AND check_id = 'C11'",
        (golden.first.run_id,),
    )
    assert results == [("green", f"{_expected_golden_query_count()} golden queries match")]


def test_second_sync_with_the_same_inputs_changes_nothing(golden):
    second = golden.second
    assert second.mode == "sync" and second.status == "success"
    assert second.rows_inserted == 0
    assert second.rows_updated == 0
    assert second.rows_unchanged == golden.first.rows_inserted
    # The ticker file and the 13 submissions files; nothing else is fetched again.
    assert second.http_requests == 14
    assert scalar(golden.url, "SELECT count(*) FROM daily_index_reconciliation") == 1


def test_run_ledger_and_reports(golden):
    modes = [r[0] for r in query(golden.url, "SELECT mode FROM run ORDER BY started_at")]
    assert modes == ["backfill", "sync"]
    reports = sorted(p.name for p in golden.settings.reports_dir.iterdir())
    assert reports == ["morning_check_2026-11-03.json", "morning_check_2026-11-03.md"]
    assert scalar(golden.url, "SELECT count(*) FROM raw_payload") > 50


def test_views_answer_the_analyst_questions(golden):
    ciks = "SELECT ciks FROM v_company_coverage WHERE company_id = 'XOM'"
    assert scalar(golden.url, ciks) == [34088, 2115436]
    amendment = (
        "SELECT count(*) FROM v_amendments WHERE company_id = 'AAPL' AND accession_number = %s "
        "AND scope = 'full' AND kind = 'accounting_change'"
    )
    assert scalar(golden.url, amendment, (APPLE_10KA,)) == 1
    order = [r[0] for r in query(golden.url, "SELECT status FROM v_morning_check")]
    assert order and order == sorted(order, key=["red", "amber", "green"].index)  # red first


def test_check_command_runs_against_stored_state(golden):
    try:
        report = flows.check(golden.settings, today=date(2026, 11, 3), now=golden.first.finished_at)
    except ChecksRed as exc:  # the golden data legitimately has reds, see the report
        report = exc.report
    by_id = {r.check_id: r.status for r in report.results}
    assert by_id["C1"] == "green"
    assert by_id["C6"] == "green"
    assert by_id["C11"] == "green"


def _annual(url, company, year):
    return query(
        url,
        "SELECT accession, form, period_of_report, filing_date, canonical_amendment_kind "
        "FROM v_annual_reports WHERE company_id = %s AND fiscal_year = %s",
        (company, year),
    )


def test_walmart_fiscal_year_names_follow_the_period_end(golden):
    (fy14,) = _annual(golden.url, "WMT", 2014)
    assert fy14[:3] == (WMT_FY2014, "10-K", date(2014, 1, 31))
    (fy09,) = _annual(golden.url, "WMT", 2009)
    assert (fy09[0], fy09[1], fy09[2], fy09[3]) == (
        WMT_FY2009,
        "10-K",
        date(2009, 4, 1),
        date(2009, 4, 1),  # raw reportDate is wrong
    )
    assert fy09[0] != WMT_FY2009_OTHER  # the 10-K filed 2010-03-30 is fiscal 2010
    other = "SELECT fiscal_year, declared_fiscal_year FROM filing WHERE accession_number = %s"
    assert query(golden.url, other, (WMT_FY2009_OTHER,)) == [(2010, 2009)]


def test_toyota_original_20f_stays_canonical_and_late_amendment_keeps_its_year(golden):
    (fy21,) = _annual(golden.url, "TM", 2021)
    assert fy21[0] == TM_FY2021 and fy21[1] == "20-F"
    (fy17,) = _annual(golden.url, "TM", 2017)
    assert fy17[0] == TM_FY2017
    label = "SELECT fiscal_year, is_canonical FROM filing WHERE accession_number = %s"
    assert query(golden.url, label, (TM_FY2021_AMENDMENT_2024,)) == [(2021, False)]


def test_shell_original_20fs_stay_canonical_over_the_reviewed_partial_amendments(golden):
    assert _annual(golden.url, "SHEL", 2023)[0][0] == SHEL_FY2023
    assert _annual(golden.url, "SHEL", 2024)[0][0] == SHEL_FY2024
    kinds = query(
        golden.url,
        "SELECT amendment_scope, amendment_kind FROM filing WHERE accession_number = ANY(%s)",
        (["0001306965-25-000025", "0001306965-25-000027"],),
    )
    assert kinds == [("partial", "administrative")] * 2


def test_plug_fy2020_canonical_is_the_administrative_full_amendment(golden):
    (row,) = _annual(golden.url, "PLUG", 2020)
    assert row[0] == PLUG_10KA_2022 and row[4] == "administrative"
    linked = scalar(
        golden.url,
        "SELECT corrected_in_accessions FROM correction_event WHERE source_accession = %s",
        (PLUG_8K,),
    )
    assert linked == [PLUG_ORIGINAL]


def test_checks_c7_not_red_and_c8_informs_on_declared_label_disagreements(golden):
    # D-24: the deliberate declared-vs-convention differences are information (green), so a
    # normal morning is not amber; they are still listed per company.
    rows = query(
        golden.url,
        "SELECT check_id, status, company_id, message FROM check_result WHERE run_id = %s "
        "AND check_id IN ('C7', 'C8') ORDER BY check_id, company_id",
        (golden.first.run_id,),
    )
    assert any(r[0] == "C7" and r[1] == "green" and r[2] is None for r in rows)
    assert not [r for r in rows if r[1] == "red"]
    c8_info = {r[2] for r in rows if r[0] == "C8" and r[1] == "green" and "info:" in r[3]}
    assert {"WMT", "TM"} <= c8_info


def test_every_fetch_is_logged_with_its_url_and_stored_404s_read_as_missing(golden):
    n_fetch = scalar(golden.url, "SELECT count(*) FROM raw_fetch")
    n_urls = scalar(golden.url, "SELECT count(DISTINCT url) FROM raw_fetch")
    assert n_fetch >= n_urls > 50
    # Every stored 404 shares the one empty body, yet each URL keeps its own fetch row.
    gone = scalar(golden.url, "SELECT count(DISTINCT url) FROM raw_fetch WHERE http_status = 404")
    assert gone > 1
