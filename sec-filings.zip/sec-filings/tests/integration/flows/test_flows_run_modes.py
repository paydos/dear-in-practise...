"""Run-level behaviour: overlap, partial failure, budget, empty database, unreviewed tickers."""

from __future__ import annotations

import json

import pytest
from flow_helpers import RUN_KW, fixture_bytes, patched_client, query, scalar

from sec_filings import flows
from sec_filings.db.repo import DEFAULT_LOCK_KEY
from sec_filings.edgar.submissions import submissions_url
from sec_filings.edgar.tickers import TICKERS_URL
from sec_filings.errors import RunFailed

pytestmark = pytest.mark.db


def csv_of(tmp_path, *tickers):
    path = tmp_path / "companies.csv"
    path.write_text("ticker\n" + "\n".join(tickers) + "\n", encoding="utf-8")
    return path


def test_sync_on_an_empty_database_runs_as_a_backfill_and_says_so(fresh_db, tmp_path):
    url, settings = fresh_db(csv_of(tmp_path, "AAPL"))
    run = flows.sync(settings, **RUN_KW)
    assert run.mode == "backfill"
    assert "empty" in (run.error_summary or "")
    assert query(url, "SELECT mode, status FROM run") == [("backfill", "success")]
    # With data present the same command is an ordinary sync.
    assert flows.sync(settings, **RUN_KW).mode == "sync"


def test_overlapping_run_is_skipped_not_run(fresh_db, tmp_path):
    import psycopg

    url, settings = fresh_db(csv_of(tmp_path, "AAPL"))
    with psycopg.connect(url, autocommit=True) as holder:
        flows.sync(settings, tickers=["AAPL"], **RUN_KW)  # migrate, then take the lock by hand
        holder.execute("SELECT pg_advisory_lock(%s)", (DEFAULT_LOCK_KEY,))
        before = scalar(url, "SELECT count(*) FROM filing")
        run = flows.sync(settings, **RUN_KW)
        holder.execute("SELECT pg_advisory_unlock(%s)", (DEFAULT_LOCK_KEY,))
    assert run.status == "skipped_locked"
    assert scalar(url, "SELECT count(*) FROM filing") == before
    assert query(url, "SELECT status FROM run ORDER BY started_at")[-1] == ("skipped_locked",)


def test_one_failing_company_makes_the_run_partial_not_dead(fresh_db, tmp_path):
    url, settings = fresh_db(csv_of(tmp_path, "AAPL", "MSFT"))
    client = patched_client(settings, {submissions_url(789019): (500, b"")})
    run = flows.sync(settings, client=client, **RUN_KW)
    assert run.status == "partial"
    assert (run.companies_ok, run.companies_failed) == (["AAPL"], ["MSFT"])
    assert "MSFT" in (run.error_summary or "")
    assert scalar(url, "SELECT count(*) FROM filing WHERE company_id = 'AAPL'") > 100
    assert scalar(url, "SELECT count(*) FROM company WHERE company_id = 'MSFT'") == 0  # rolled back
    c2 = [r for r in flows.read_results(settings, run.run_id) if r.check_id == "C2"]
    assert [r.status for r in c2] == ["red"]


def test_request_budget_exhaustion_fails_the_run_loudly(fresh_db, tmp_path):
    url, settings = fresh_db(csv_of(tmp_path, "AAPL", "MSFT"))
    client = patched_client(settings, {}, budget=5)
    with pytest.raises(RunFailed) as excinfo:
        flows.sync(settings, client=client, **RUN_KW)
    run = excinfo.value.result
    assert run.status == "failed" and "budget" in run.error_summary
    assert query(url, "SELECT status FROM run") == [("failed",)]
    c2 = [r for r in flows.read_results(settings, run.run_id) if r.check_id == "C2"]
    assert [r.status for r in c2] == ["red"]
    assert (settings.reports_dir / "morning_check_2026-11-03.md").is_file()


def test_unreviewed_ticker_is_ingested_and_flagged_amber(fresh_db, tmp_path):
    empty_yml = tmp_path / "companies.yml"
    empty_yml.write_text("{}\n", encoding="utf-8")
    url, settings = fresh_db(csv_of(tmp_path, "AAPL"), empty_yml)
    run = flows.sync(settings, **RUN_KW)
    assert run.status == "success"
    assert query(url, "SELECT reviewed, is_foreign_private_issuer FROM company") == [(False, False)]
    assert scalar(url, "SELECT cik FROM company_cik WHERE company_id = 'AAPL'") == 320193
    c4 = [r for r in flows.read_results(settings, run.run_id) if r.check_id == "C4"]
    assert [(r.status, r.company_id) for r in c4] == [("amber", "AAPL")]
    # Without the reviewed override Apple's 10-K/A scope still comes from the filing's own signals.
    assert (
        scalar(
            url,
            "SELECT amendment_scope FROM filing WHERE accession_number = '0001193125-10-012091'",
        )
        == "full"
    )


def test_foreign_filer_is_detected_when_not_reviewed(fresh_db, tmp_path):
    empty_yml = tmp_path / "companies.yml"
    empty_yml.write_text("{}\n", encoding="utf-8")
    url, settings = fresh_db(csv_of(tmp_path, "SHEL"), empty_yml)
    run = flows.sync(settings, **RUN_KW)
    assert run.status == "success", run.error_summary
    assert scalar(url, "SELECT is_foreign_private_issuer FROM company WHERE company_id = 'SHEL'")


def test_unreviewed_ticker_is_resolved_from_the_ticker_file_only_once(fresh_db, tmp_path):
    empty_yml = tmp_path / "companies.yml"
    empty_yml.write_text("{}\n", encoding="utf-8")
    url, settings = fresh_db(csv_of(tmp_path, "AAPL"), empty_yml)
    assert flows.sync(settings, **RUN_KW).status == "success"
    assert query(url, "SELECT cik FROM company_cik WHERE company_id = 'AAPL'") == [(320193,)]
    # The ticker file now says AAPL is a different CIK: it is not added, C4 goes red (D-08).
    tickers = json.loads(fixture_bytes("www.sec.gov/files/company_tickers.json"))
    for entry in tickers.values():
        if entry["ticker"] == "AAPL":
            entry["cik_str"] = 9_999_999
    client = patched_client(settings, {TICKERS_URL: (200, json.dumps(tickers).encode())})
    run = flows.sync(settings, client=client, **RUN_KW)
    assert run.status == "success", run.error_summary  # stored CIKs stand; no ticker lookup
    assert query(url, "SELECT cik FROM company_cik WHERE company_id = 'AAPL'") == [(320193,)]
    c4 = [r for r in flows.read_results(settings, run.run_id) if r.check_id == "C4"]
    assert ("red", "AAPL") in [(r.status, r.company_id) for r in c4]
    assert "9999999" in " ".join(r.message for r in c4)
