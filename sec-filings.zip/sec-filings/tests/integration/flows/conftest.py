"""Fixtures for the offline flow tests: a golden database built once per module and cloned (as a
Postgres template) for the failure-injection tests."""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path

import pytest
from flow_helpers import (
    GOLDEN_CSV,
    REPO,
    RUN_KW,
    Golden,
    create_database,
    drop_database,
    make_settings,
)

from sec_filings import flows
from sec_filings.config import Settings


@pytest.fixture(scope="module")
def golden(pg_server_uri: str, tmp_path_factory: pytest.TempPathFactory):
    """Offline backfill of the 12 golden companies, then a second sync with the same inputs."""
    name, url = create_database(pg_server_uri)
    settings = make_settings(url, tmp_path_factory.mktemp("reports"))
    first = flows.backfill(settings, **RUN_KW)
    second = flows.sync(settings, **RUN_KW)
    yield Golden(pg_server_uri, name, url, settings, first, second)
    drop_database(pg_server_uri, name)


@pytest.fixture
def clone(golden: Golden, tmp_path: Path) -> Callable[[], tuple[str, Settings]]:
    """Factory: a private copy of the golden database, dropped at teardown."""
    made: list[str] = []

    def make() -> tuple[str, Settings]:
        name, url = create_database(golden.admin_uri, template=golden.name)
        made.append(name)
        return url, make_settings(url, tmp_path)

    yield make
    for name in made:
        drop_database(golden.admin_uri, name)


@pytest.fixture
def fresh_db(pg_server_uri: str, tmp_path: Path):
    """Factory: an empty database and settings for it (AAPL-only runs are fast)."""
    made: list[str] = []

    def make(csv: Path = GOLDEN_CSV, yml: Path = REPO / "companies.yml") -> tuple[str, Settings]:
        name, url = create_database(pg_server_uri)
        made.append(name)
        return url, make_settings(url, tmp_path, csv, yml)

    yield make
    for name in made:
        drop_database(pg_server_uri, name)
