"""Helpers for the offline flow tests (imported by conftest.py and the test modules)."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import psycopg
from psycopg import sql

from sec_filings.config import Settings
from sec_filings.edgar.client import EdgarClient
from sec_filings.models import RunResult

REPO = Path(__file__).resolve().parents[3]
FIXTURES = REPO / "tests" / "fixtures" / "edgar"
GOLDEN_CSV = REPO / "tests" / "fixtures" / "companies_golden.csv"
GOLDEN_QUERIES = REPO / "src" / "sec_filings" / "golden_queries.yml"
TODAY = date(2026, 11, 3)
NOW = datetime(2026, 11, 3, 6, 5, tzinfo=ZoneInfo("Europe/London"))
RUN_KW = {"today": TODAY, "now": NOW, "golden_queries_path": GOLDEN_QUERIES}


def _with_dbname(uri: str, dbname: str) -> str:
    info = psycopg.conninfo.conninfo_to_dict(uri)
    info["dbname"] = dbname
    return psycopg.conninfo.make_conninfo(**info)


def create_database(admin_uri: str, template: str | None = None) -> tuple[str, str]:
    """Create a database (optionally cloned from a template); returns (name, url)."""
    name = f"f_{uuid.uuid4().hex[:12]}"
    stmt = sql.SQL("CREATE DATABASE {}").format(sql.Identifier(name))
    if template:
        stmt += sql.SQL(" TEMPLATE {}").format(sql.Identifier(template))
    with psycopg.connect(admin_uri, autocommit=True) as admin:
        admin.execute(stmt)
    return name, _with_dbname(admin_uri, name)


def drop_database(admin_uri: str, name: str) -> None:
    drop = sql.SQL("DROP DATABASE IF EXISTS {} WITH (FORCE)").format(sql.Identifier(name))
    with psycopg.connect(admin_uri, autocommit=True) as admin:
        admin.execute(drop)


def make_settings(
    url: str, reports_dir: Path, csv: Path = GOLDEN_CSV, yml: Path = REPO / "companies.yml"
) -> Settings:
    return Settings(
        database_url=url,
        fixtures_dir=FIXTURES,
        companies_csv=csv,
        companies_yml=yml,
        reports_dir=reports_dir,
    )


def query(url: str, statement: str, params: tuple = ()) -> list[tuple]:
    """One short-lived connection per query, so a database can still be used as a template."""
    with psycopg.connect(url) as conn:
        return conn.execute(statement, params).fetchall()


def scalar(url: str, statement: str, params: tuple = ()):
    rows = query(url, statement, params)
    return rows[0][0] if rows else None


def execute(url: str, statement: str, params: tuple = ()) -> None:
    with psycopg.connect(url, autocommit=True) as conn:
        conn.execute(statement, params)


class PatchedClient(EdgarClient):
    """The offline client, except for URLs in `overrides` ({url: (status, body)})."""

    def __init__(self, *args, overrides: dict[str, tuple[int, bytes]] | None = None, **kw):
        super().__init__(*args, **kw)
        self.overrides = overrides or {}

    def get(self, url: str):
        if url in self.overrides:
            self._spend_budget(url)
            status, body = self.overrides[url]
            return self._finish(self._make_response(url, status, body, True))
        return super().get(url)


def patched_client(
    settings: Settings, overrides: dict[str, tuple[int, bytes]], budget: int = 6000
) -> PatchedClient:
    return PatchedClient(
        settings.user_agent,
        fixtures_dir=settings.fixtures_dir,
        request_budget=budget,
        overrides=overrides,
    )


def fixture_bytes(url_path: str) -> bytes:
    """Bytes of a recorded fixture, e.g. 'www.sec.gov/files/company_tickers.json'."""
    import gzip

    path = FIXTURES / url_path
    if path.is_file():
        return path.read_bytes()
    return gzip.decompress(path.with_name(path.name + ".gz").read_bytes())


@dataclass
class Golden:
    admin_uri: str
    name: str
    url: str
    settings: Settings
    first: RunResult
    second: RunResult
