"""Parsers and the offline client against the recorded SEC fixtures (no network)."""
# ruff: noqa: E501

from __future__ import annotations

import json
from datetime import UTC, date, datetime
from pathlib import Path

import pytest

from sec_filings.edgar.client import EdgarClient
from sec_filings.edgar.cover_tags import (
    cover_page_url,
    filing_index_url,
    instance_url,
    parse_cover_page,
    parse_cover_tags,
    parse_filing_index,
    pick_instance,
)
from sec_filings.edgar.daily_index import (
    daily_index_url,
    parse_form_index,
    parse_master_index,
)
from sec_filings.edgar.submissions import (
    history_page_url,
    parse_history_page,
    parse_submissions,
    submissions_url,
)
from sec_filings.edgar.tickers import TICKERS_URL, parse_company_tickers
from sec_filings.edgar.xbrl_concepts import (
    company_concept_url,
    parse_concept_labels,
    parse_public_float,
)

UA = "integration-test contact@example.com"

GOLDEN_CIKS = [
    34088, 40545, 104169, 320193, 353278, 789019, 1093691, 1094517,
    1306965, 1326380, 1577552, 1811210, 2115436,
]  # fmt: skip
ALL_CIKS = GOLDEN_CIKS  # the manifest records these 13 main files


@pytest.fixture
def client(fixtures_dir: Path) -> EdgarClient:
    return EdgarClient(UA, fixtures_dir=fixtures_dir, request_budget=10_000)


def fetch(client: EdgarClient, url: str) -> bytes:
    resp = client.get(url)
    assert resp.status == 200, f"fixture missing for {url}"
    return resp.body


# ------------------------------------------------------------------ tickers


def test_tickers(client):
    tickers = parse_company_tickers(fetch(client, TICKERS_URL))
    assert tickers["AAPL"][0] == 320193
    assert tickers["XOM"][0] == 2115436
    assert tickers["AAPL"][1] == "Apple Inc."
    assert len(tickers) > 5000


# -------------------------------------------------------------- submissions


def test_apple_main_page(client):
    doc = parse_submissions(fetch(client, submissions_url(320193)))
    assert doc.meta.cik == 320193 and doc.meta.name == "Apple Inc."
    assert doc.meta.tickers == ("AAPL",)
    assert doc.meta.fiscal_year_end_mmdd == "0926"
    assert doc.meta.filer_category == "Large accelerated filer"
    assert [(p.name, p.filing_count) for p in doc.pages] == [
        ("CIK0000320193-submissions-001.json", 1271)
    ]
    assert doc.pages[0].filing_from == date(1994, 1, 26)
    assert doc.pages[0].filing_to == date(2015, 10, 3)
    assert any(fn.name == "APPLE COMPUTER INC" for fn in doc.meta.former_names)
    assert len(doc.filings) > 100
    assert all(f.cik == 320193 for f in doc.filings)


def test_apple_history_page_has_fy2009_filings(client):
    rows = parse_history_page(
        fetch(client, history_page_url("CIK0000320193-submissions-001.json")), 320193
    )
    by_acc = {r.accession_number: r for r in rows}
    k = by_acc["0001193125-09-214859"]
    ka = by_acc["0001193125-10-012091"]
    assert (k.form, k.filing_date, k.period_of_report) == (
        "10-K",
        date(2009, 10, 27),
        date(2009, 9, 26),
    )
    assert (ka.form, ka.filing_date, ka.period_of_report) == (
        "10-K/A",
        date(2010, 1, 25),
        date(2009, 9, 26),
    )
    assert k.primary_document == "d10k.htm" and k.size_bytes == 3638340
    assert ka.primary_document == "d10ka.htm" and ka.size_bytes == 5066790
    assert k.is_xbrl and ka.is_xbrl
    assert k.acceptance_datetime is not None and k.acceptance_datetime.tzinfo is not None


def test_apple_recent_rows_empty_strings_and_items(client):
    doc = parse_submissions(fetch(client, submissions_url(320193)))
    k2025 = next(f for f in doc.filings if f.accession_number == "0000320193-25-000079")
    assert k2025.form == "10-K" and k2025.filing_date == date(2025, 10, 31)
    assert k2025.items == ()
    assert k2025.is_inline_xbrl and k2025.primary_document == "aapl-20250927.htm"
    eight_ks = [f for f in doc.filings if f.form == "8-K" and f.items]
    assert eight_ks and all(
        isinstance(i, str) and i and "," not in i for f in eight_ks for i in f.items
    )
    # every empty-string column is None, never ''
    for f in doc.filings:
        for value in (f.primary_document, f.primary_doc_description, f.file_number, f.film_number):
            assert value != ""


def test_acceptance_is_utc_aware(client):
    doc = parse_submissions(fetch(client, submissions_url(320193)))
    row = next(f for f in doc.filings if f.accession_number == "0000320193-26-000026")
    assert row.acceptance_datetime == datetime(2026, 11, 3, 13, 5, 15, tzinfo=UTC)


def test_exxon_joint_accession_in_both_ciks(client):
    old = parse_submissions(fetch(client, submissions_url(34088)))
    new = parse_submissions(fetch(client, submissions_url(2115436)))
    acc = "0000034088-26-000093"
    old_rows = {f.accession_number: f for f in old.filings}
    new_rows = {f.accession_number: f for f in new.filings}
    # The old CIK's recent array may have rolled the accession onto a page; look there too.
    assert acc in new_rows
    assert new_rows[acc].cik == 2115436
    if acc not in old_rows:
        for page in old.pages:
            rows = parse_history_page(fetch(client, history_page_url(page.name)), 34088)
            old_rows.update({r.accession_number: r for r in rows})
    assert acc in old_rows and old_rows[acc].cik == 34088
    assert old_rows[acc].form == new_rows[acc].form == "10-Q"
    assert old_rows[acc].filing_date == new_rows[acc].filing_date == date(2026, 8, 3)
    assert "0002115436-26-000020" in new_rows and new_rows["0002115436-26-000020"].form == "10-Q"


def test_foreign_filer_toyota(client):
    doc = parse_submissions(fetch(client, submissions_url(1094517)))
    assert doc.meta.fiscal_year_end_mmdd == "0331"
    pages = [
        parse_history_page(fetch(client, history_page_url(p.name)), 1094517) for p in doc.pages
    ]
    twenty_f = [r for rows in [doc.filings, *pages] for r in rows if r.form == "20-F"]
    twenty_f_a = [r for rows in [doc.filings, *pages] for r in rows if r.form == "20-F/A"]
    assert len(twenty_f_a) == 18  # spike A11
    assert any(r.accession_number == "0001193125-26-264811" and r.filing_date == date(2026, 6, 10)
               for r in twenty_f)  # fmt: skip
    assert any(r.accession_number == "0001193125-24-024814" for r in twenty_f_a)


@pytest.mark.parametrize("cik", ALL_CIKS)
def test_every_history_page_yields_its_stated_filing_count(client, cik):
    doc = parse_submissions(fetch(client, submissions_url(cik)))
    for page in doc.pages:
        rows = parse_history_page(fetch(client, history_page_url(page.name)), cik)
        assert len(rows) == page.filing_count, page.name
        # filingFrom/filingTo are NOT exact row bounds (GameStop's page says 2013-09-22, its
        # latest row is 2013-09-16), so only the count is asserted.
        assert len({r.accession_number for r in rows}) == len(rows)


def test_history_pages_cover_every_recorded_page(fixtures_dir):
    """Every recorded history page file is reachable from some main file (nothing orphaned)."""
    recorded = {
        p.name for p in (fixtures_dir / "data.sec.gov" / "submissions").glob("*-submissions-*.json")
    }
    referenced = set()
    for cik in ALL_CIKS:
        path = fixtures_dir / "data.sec.gov" / "submissions" / f"CIK{cik:010d}.json"
        referenced |= {p.name for p in parse_submissions(path.read_bytes()).pages}
    assert recorded == {n for n in referenced if n in recorded}
    assert len(recorded) == 14


# -------------------------------------------------------------- pick_instance


def _golden_with_index(golden, fixture_exists):
    out = []
    for f in golden:
        rel = (
            f"www.sec.gov/Archives/edgar/data/{f['cik']}/"
            f"{f['accession_number'].replace('-', '')}/index.json"
        )
        if fixture_exists(rel):
            out.append((f, rel))
    return out


def test_pick_instance_matches_golden_on_every_recorded_index(golden, read_fixture, fixture_exists):
    checked = _golden_with_index(golden, fixture_exists)
    assert len(checked) >= 20
    for f, rel in checked:
        expected = f["cover"]["instance_file"] if f.get("cover") else None
        assert pick_instance(read_fixture(rel)) == expected, f["id"]


def test_pick_instance_on_all_recorded_indexes_never_returns_a_non_instance(
    fixtures_dir, read_fixture
):
    seen = 0
    for path in (fixtures_dir / "www.sec.gov" / "Archives" / "edgar" / "data").glob(
        "*/*/index.json"
    ):
        names = {n for n, _ in parse_filing_index(path.read_bytes()).files}
        picked = pick_instance(path.read_bytes())
        seen += 1
        if picked is None:
            # no inline file, and no xml sharing a stem with the xsd
            assert not any(n.endswith("_htm.xml") for n in names), path
            continue
        assert picked in names
        low = picked.lower()
        assert low.endswith(".xml")
        assert not low.endswith(("_cal.xml", "_def.xml", "_lab.xml", "_pre.xml"))
        assert low not in ("defnref.xml", "filingsummary.xml")
        assert not (low.startswith("r") and low[1:-4].isdigit())
    assert seen >= 30


def test_pick_instance_named_cases(read_fixture):
    base = "www.sec.gov/Archives/edgar/data"
    cases = {
        "320193/000119312509214859": "aapl-20090926.xml",  # defnref.xml and R<n>.xml present
        "320193/000032019325000079": "aapl-20250927_htm.xml",
        "1094517/000119312526264811": "d101983d20f_htm.xml",  # name differs from the xsd stem
        "1094517/000119312519178062": "tm-20190331.xml",
        "1094517/000119312512281223": "tm-20120331.xml",
        "1094517/000119312516630645": "tm-20160331.xml",
        "1811210/000110465921067004": "cciv-20200331.xml",  # stem does not match the period
        "353278/000162828022001639": "nvo-20211231_htm.xml",
        "40545/000004054515000030": "ge-20141231.xml",
        "104169/000010416909000006": None,  # Walmart 2009: no XBRL
        "1094517/000119312524024814": None,  # Toyota 20-F/A: no XBRL
        "353278/000117184315000625": None,  # Novo 2015: no XBRL
    }
    for folder, expected in cases.items():
        assert pick_instance(read_fixture(f"{base}/{folder}/index.json")) == expected, folder


def test_filing_index_report_counts(read_fixture):
    base = "www.sec.gov/Archives/edgar/data"
    apple_2025 = parse_filing_index(read_fixture(f"{base}/320193/000032019325000079/index.json"))
    assert apple_2025.report_file_count == 70
    plug_cover_only = parse_filing_index(
        read_fixture(f"{base}/1093691/000110465923054310/index.json")
    )
    assert plug_cover_only.report_file_count == 1  # Part III only amendment: cover report only
    walmart_2009 = parse_filing_index(read_fixture(f"{base}/104169/000010416909000006/index.json"))
    assert walmart_2009.report_file_count == 0
    assert any(name == "FilingSummary.xml" for name, _ in apple_2025.files)
    assert dict(apple_2025.files)["aapl-20250927_htm.xml"] is not None


def test_urls_round_trip_through_fixture_client(client):
    assert client.get(filing_index_url(320193, "0001193125-10-012091")).status == 200
    assert (
        client.get(instance_url(320193, "0001193125-10-012091", "aapl-20090926.xml")).status == 200
    )
    assert client.get(cover_page_url(320193, "0000320193-25-000079")).status == 200
    assert client.get(filing_index_url(320193, "0000000000-00-000000")).status == 404


# ------------------------------------------------------------ cover tags (instance)


def _expect(cover: dict, tags) -> None:
    assert tags.fiscal_year == cover["fiscal_year"]
    assert tags.fiscal_period == cover["fiscal_period"]
    assert tags.filer_category == cover["filer_category"]
    assert tags.amendment_flag == cover["amendment_flag"]
    assert tags.error_correction_flag == cover["error_correction_flag"]
    assert tags.document_type == cover["document_type"]


def test_parse_cover_tags_matches_every_golden_cover_block(golden, read_fixture):
    n = 0
    for f in golden:
        cover = f.get("cover")
        if not cover:
            continue
        rel = (
            f"www.sec.gov/Archives/edgar/data/{f['cik']}/"
            f"{f['accession_number'].replace('-', '')}/{cover['instance_file']}"
        )
        _expect(cover, parse_cover_tags(read_fixture(rel)))
        n += 1
    assert n >= 20


def test_named_cover_cases(read_fixture):
    base = "www.sec.gov/Archives/edgar/data"
    toyota = parse_cover_tags(
        read_fixture(f"{base}/1094517/000119312526264811/d101983d20f_htm.xml")
    )
    assert (toyota.document_type, toyota.fiscal_year, toyota.fiscal_period) == ("20-F", 2026, "FY")
    assert toyota.period_end_date == date(2026, 3, 31)
    novo = parse_cover_tags(read_fixture(f"{base}/353278/000162828022001639/nvo-20211231_htm.xml"))
    assert (novo.document_type, novo.fiscal_year, novo.fiscal_period) == ("20-F", 2021, "FY")
    assert novo.period_end_date == date(2021, 12, 31)
    apple = parse_cover_tags(
        read_fixture(f"{base}/320193/000032019325000079/aapl-20250927_htm.xml")
    )
    assert apple.fiscal_year == 2025 and apple.error_correction_flag is False
    assert apple.non_dei_fact_count > 100
    apple_2009 = parse_cover_tags(
        read_fixture(f"{base}/320193/000119312509214859/aapl-20090926.xml")
    )
    assert apple_2009.fiscal_year is None and apple_2009.fiscal_period is None  # no DEI focus tags
    assert apple_2009.filer_category == "Large Accelerated Filer"
    ge = parse_cover_tags(read_fixture(f"{base}/40545/000004054515000030/ge-20141231.xml"))
    assert (ge.fiscal_year, ge.fiscal_period) == (2014, "Q4")  # GE tagged its 10-K as Q4
    plug_part3 = parse_cover_tags(
        read_fixture(f"{base}/1093691/000110465923054310/tm232164d4_10ka_htm.xml")
    )
    assert plug_part3.non_dei_fact_count == 0  # cover-only amendment
    aapl_amend = parse_cover_tags(
        read_fixture(f"{base}/320193/000119312510012091/aapl-20090926.xml")
    )
    assert aapl_amend.amendment_flag is True and aapl_amend.document_type == "10-K"


# --------------------------------------------------- rendered cover (R1.htm)


def test_parse_cover_page_agrees_with_instance_wherever_both_are_recorded(
    golden, read_fixture, fixture_exists
):
    n = 0
    for f in golden:
        cover = f.get("cover")
        if not cover:
            continue
        folder = (
            f"www.sec.gov/Archives/edgar/data/{f['cik']}/{f['accession_number'].replace('-', '')}"
        )
        if not fixture_exists(f"{folder}/R1.htm"):
            continue
        rendered = parse_cover_page(read_fixture(f"{folder}/R1.htm"))
        instance = parse_cover_tags(read_fixture(f"{folder}/{cover['instance_file']}"))
        for attr in ("fiscal_year", "fiscal_period", "document_type", "period_end_date",
                     "filer_category", "amendment_flag", "error_correction_flag"):  # fmt: skip
            assert getattr(rendered, attr) == getattr(instance, attr), (f["id"], attr)
        assert rendered.non_dei_fact_count == -1
        n += 1
    assert n >= 15


def test_cover_page_amendment_description_and_status(read_fixture):
    base = "www.sec.gov/Archives/edgar/data"
    shell_a = parse_cover_page(read_fixture(f"{base}/1306965/000130696525000025/R1.htm"))
    assert shell_a.amendment_flag is True and shell_a.document_type == "20-F/A"
    assert shell_a.amendment_description and shell_a.amendment_description.startswith("Shell plc")
    lucid = parse_cover_page(read_fixture(f"{base}/1811210/000110465921067004/R1.htm"))
    assert lucid.filer_category == "Non-accelerated Filer"
    assert lucid.amendment_flag is True and lucid.amendment_description
    apple = parse_cover_page(read_fixture(f"{base}/320193/000032019325000079/R1.htm"))
    assert apple.current_reporting_status == "Yes"
    assert apple.error_correction_flag is False  # label has no brackets here, brackets elsewhere
    plug = parse_cover_page(read_fixture(f"{base}/1093691/000155837022003577/R1.htm"))
    assert plug.amendment_flag is False  # Plug's amendments carry AmendmentFlag false
    assert plug.document_type == "10-K/A"


# ------------------------------------------------------------ company concepts


def concept_cases(fixtures_dir: Path):
    for d in sorted((fixtures_dir / "data.sec.gov" / "api" / "xbrl" / "companyconcept").iterdir()):
        yield int(d.name[3:])


def test_concept_labels_apple(client):
    labels = parse_concept_labels(
        fetch(client, company_concept_url(320193, "EntityCommonStockSharesOutstanding"))
    )
    k = labels["0001193125-09-214859"]
    assert (k.form, k.filed, k.fiscal_year, k.fiscal_period) == (
        "10-K",
        date(2009, 10, 27),
        2009,
        "FY",
    )
    assert labels["0001193125-10-012091"].form == "10-K/A"
    assert labels["0000320193-25-000079"].fiscal_year == 2025


def test_concept_labels_ge_q4_and_gme_start_year(client):
    ge = parse_concept_labels(
        fetch(client, company_concept_url(40545, "EntityCommonStockSharesOutstanding"))
    )["0000040545-15-000030"]
    assert (ge.fiscal_year, ge.fiscal_period, ge.form) == (2014, "Q4", "10-K")
    gme = parse_concept_labels(
        fetch(client, company_concept_url(1326380, "EntityCommonStockSharesOutstanding"))
    )["0001326380-26-000013"]
    assert (gme.fiscal_year, gme.fiscal_period) == (2025, "FY")  # period ends 2026-01-31


def test_every_recorded_concept_file_parses_and_agrees_with_instances(client, fixtures_dir, golden):
    parsed = 0
    for cik in concept_cases(fixtures_dir):
        shares = parse_concept_labels(
            fetch(client, company_concept_url(cik, "EntityCommonStockSharesOutstanding"))
        )
        assert shares and all(isinstance(k, str) for k in shares)
        float_path = (
            fixtures_dir / "data.sec.gov" / "api" / "xbrl" / "companyconcept"
            / f"CIK{cik:010d}" / "dei" / "EntityPublicFloat.json"
        )  # fmt: skip
        if float_path.exists():
            floats = parse_public_float(float_path.read_bytes())
            assert all(v > 0 and isinstance(d, date) for v, d in floats.values())
        parsed += 1
    assert parsed >= 10
    # Golden labels from the instance covers must match the concept API where both exist.
    compared = 0
    for f in golden:
        cover = f.get("cover")
        if not cover or cover["fiscal_year"] is None:
            continue
        path = (
            fixtures_dir / "data.sec.gov" / "api" / "xbrl" / "companyconcept"
            / f"CIK{f['cik']:010d}" / "dei" / "EntityCommonStockSharesOutstanding.json"
        )  # fmt: skip
        if not path.exists():
            continue
        label = parse_concept_labels(path.read_bytes()).get(f["accession_number"])
        if label is None:
            continue  # the concept API is per CIK, and some facts sit under the other Exxon CIK
        assert (label.fiscal_year, label.fiscal_period) == (
            cover["fiscal_year"],
            cover["fiscal_period"],
        ), f["id"]
        compared += 1
    assert compared >= 8


def test_public_float_apple(client):
    floats = parse_public_float(fetch(client, company_concept_url(320193, "EntityPublicFloat")))
    assert floats["0001193125-09-214859"] == (94593000000.0, date(2009, 3, 28))


def test_concept_json_is_plain_json(client):
    body = fetch(client, company_concept_url(320193, "EntityPublicFloat"))
    assert json.loads(body)["taxonomy"] == "dei"


# ------------------------------------------------------------- daily indexes


def test_form_index_20261102(client):
    rows = parse_form_index(fetch(client, daily_index_url(date(2026, 11, 2))))
    assert len(rows) == 5353
    xom = [r for r in rows if r.accession_number == "0002115436-26-000020"]
    assert len(xom) == 1
    assert (xom[0].form, xom[0].cik, xom[0].date_filed) == ("10-Q", 2115436, date(2026, 11, 2))
    assert "NT 10-Q" in {r.form for r in rows}
    assert all(len(r.accession_number) == 20 for r in rows)


def test_form_index_20261109_keeps_rows_dated_other_than_file_date(client):
    rows = parse_form_index(fetch(client, daily_index_url(date(2026, 11, 9))))
    assert len(rows) == 4891
    off_date = [r for r in rows if r.date_filed != date(2026, 11, 9)]
    assert off_date, "spike B9: the file holds rows with older filing dates"
    assert any(r.date_filed == date(2025, 12, 11) for r in off_date)
    assert {r.form for r in rows if " " in r.form} >= {"NT 10-Q", "DEF 14A"}


def test_form_index_rows_match_line_count(client):
    body = fetch(client, daily_index_url(date(2026, 11, 2)))
    lines = body.decode("latin-1").splitlines()
    sep = next(i for i, ln in enumerate(lines) if ln.startswith("-----"))
    data_lines = [ln for ln in lines[sep + 1 :] if ln.strip()]
    assert len(parse_form_index(body)) == len(data_lines)


def test_master_index_excerpt(derived_dir):
    rows = parse_master_index((derived_dir / "master_2026Q4_excerpt.idx").read_bytes())
    assert len(rows) == 3201
    xom = [r for r in rows if r.accession_number == "0002115436-26-000020"]
    assert len(xom) == 1 and xom[0].form == "10-Q" and xom[0].cik == 2115436
    assert xom[0].date_filed == date(2026, 11, 2)
    sap = rows[0]
    assert (sap.cik, sap.company_name, sap.form) == (1000184, "SAP SE", "6-K")
    assert 1 < len({r.cik for r in rows}) <= 25
