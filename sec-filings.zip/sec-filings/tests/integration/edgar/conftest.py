"""Shared helpers for the EDGAR tests: recorded fixtures and the golden facts."""

from __future__ import annotations

import gzip
from collections.abc import Callable
from pathlib import Path

import pytest
import yaml

REPO = Path(__file__).resolve().parents[3]
FIXTURES = REPO / "tests" / "fixtures" / "edgar"
DERIVED = REPO / "tests" / "fixtures" / "derived"
GOLDEN = REPO / "tests" / "golden" / "filings.yml"


def _read(relative: str) -> bytes:
    path = FIXTURES / relative
    if path.is_file():
        return path.read_bytes()
    return gzip.decompress(Path(str(path) + ".gz").read_bytes())


def _exists(relative: str) -> bool:
    path = FIXTURES / relative
    return path.is_file() or Path(str(path) + ".gz").is_file()


@pytest.fixture(scope="session")
def read_fixture() -> Callable[[str], bytes]:
    """Bytes of a recorded fixture by its path under tests/fixtures/edgar (reads .gz too)."""
    return _read


@pytest.fixture(scope="session")
def fixture_exists() -> Callable[[str], bool]:
    return _exists


@pytest.fixture(scope="session")
def fixtures_dir() -> Path:
    return FIXTURES


@pytest.fixture(scope="session")
def derived_dir() -> Path:
    return DERIVED


@pytest.fixture(scope="session")
def golden() -> list[dict]:
    return yaml.safe_load(GOLDEN.read_text(encoding="utf-8"))
