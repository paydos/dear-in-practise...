import psycopg
import pytest

from sec_filings.db.migrate import apply_migrations

pytestmark = pytest.mark.db

TABLES = {
    "schema_migrations",
    "company",
    "company_cik",
    "company_name_history",
    "run",
    "raw_payload",
    "filing",
    "filing_cik_alias",
    "history_page",
    "report_period",
    "correction_event",
    "expected_filing",
    "daily_index_reconciliation",
    "check_result",
    "raw_fetch",
}


def test_migrations_apply_and_are_idempotent(db_conn):
    versions = [r[0] for r in db_conn.execute("SELECT version FROM schema_migrations")]
    assert versions[:5] == [
        "001_init",
        "002_views",
        "003_fetch_log_and_declared",
        "004_original_report_and_float_source",
        "005_run_scope_and_acks",
    ]
    assert versions == sorted(versions)  # later migrations only append
    assert apply_migrations(db_conn) == []


def test_all_tables_exist(db_conn):
    rows = db_conn.execute(
        "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'"
    ).fetchall()
    assert TABLES <= {r[0] for r in rows}


def test_migration_003_columns_and_index(db_conn):
    cols = {
        r[0]: r[1]
        for r in db_conn.execute(
            "SELECT column_name, data_type FROM information_schema.columns "
            "WHERE table_name = 'raw_fetch'"
        )
    }
    assert cols == {
        "url": "text",
        "sha256": "text",
        "fetched_at": "timestamp with time zone",
        "run_id": "uuid",
        "http_status": "integer",
    }
    declared = {
        r[0]: r[1]
        for r in db_conn.execute(
            "SELECT column_name, data_type FROM information_schema.columns "
            "WHERE table_name = 'filing' AND column_name LIKE 'declared_%'"
        )
    }
    assert declared == {"declared_fiscal_year": "integer", "declared_fiscal_period": "text"}
    index = db_conn.execute(
        "SELECT indexdef FROM pg_indexes WHERE tablename = 'raw_fetch'"
    ).fetchone()[0]
    assert "(url, fetched_at DESC)" in index


def test_migration_003_backfills_raw_fetch_from_existing_payloads(pg_server_uri):
    """003 is forward-only and keeps payloads stored before it reachable by URL."""
    import uuid

    from psycopg import sql

    from sec_filings.db.connection import connect
    from sec_filings.db.migrate import _migration_files

    name = f"m_{uuid.uuid4().hex[:12]}"
    with psycopg.connect(pg_server_uri, autocommit=True) as admin:
        admin.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(name)))
    try:
        info = psycopg.conninfo.conninfo_to_dict(pg_server_uri)
        info["dbname"] = name
        conn = connect(psycopg.conninfo.make_conninfo(**info))
        files = dict(_migration_files())
        conn.execute(files["001_init"])
        conn.execute(files["002_views"])
        conn.execute(
            "INSERT INTO raw_payload VALUES "
            "('abc', 'https://x/a', now(), now(), NULL, 200, '\\x00')"
        )
        conn.execute(files["003_fetch_log_and_declared"])
        assert conn.execute("SELECT url, sha256, http_status FROM raw_fetch").fetchall() == [
            ("https://x/a", "abc", 200)
        ]
        conn.close()
    finally:
        with psycopg.connect(pg_server_uri, autocommit=True) as admin:
            admin.execute(
                sql.SQL("DROP DATABASE IF EXISTS {} WITH (FORCE)").format(sql.Identifier(name))
            )


def _insert_annual(conn, accession: str, canonical: bool = True):
    conn.execute(
        "INSERT INTO filing (accession_number, cik, company_id, form, form_family, filing_date,"
        " fiscal_year, fiscal_period, label_source, is_canonical)"
        " VALUES (%s, 1, 'AAPL', '10-K', 'annual', '2025-10-31', 2025, 'FY', 'rule', %s)",
        (accession, canonical),
    )


def test_one_canonical_annual_per_company_year(db_conn):
    db_conn.execute("INSERT INTO company (company_id) VALUES ('AAPL')")
    _insert_annual(db_conn, "0000000001-25-000001")
    _insert_annual(db_conn, "0000000001-25-000002", canonical=False)  # non-canonical is fine
    with pytest.raises(psycopg.errors.UniqueViolation):
        _insert_annual(db_conn, "0000000001-25-000003")
    db_conn.rollback()
