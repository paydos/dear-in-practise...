"""The MCP tool functions, called directly, against the offline golden database."""

from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

import psycopg
import pytest
import yaml

sys.path.insert(0, str(Path(__file__).parent / "flows"))

from flow_helpers import (  # noqa: E402
    GOLDEN_CSV,
    GOLDEN_QUERIES,
    RUN_KW,
    create_database,
    drop_database,
    make_settings,
)

from sec_filings import flows, mcp_server  # noqa: E402

pytestmark = pytest.mark.db


@pytest.fixture(scope="module")
def golden_url(pg_server_uri: str, tmp_path_factory: pytest.TempPathFactory):
    name, url = create_database(pg_server_uri)
    flows.backfill(make_settings(url, tmp_path_factory.mktemp("reports")), **RUN_KW)
    yield url
    drop_database(pg_server_uri, name)


@pytest.fixture(autouse=True)
def _server_db(golden_url: str, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.setenv("MCP_DATABASE_URL", golden_url)


def _golden_queries() -> list[dict]:
    with open(GOLDEN_CSV, newline="", encoding="utf-8") as fh:
        tickers = {r["ticker"].strip().upper() for r in csv.DictReader(fh)}
    queries = yaml.safe_load(GOLDEN_QUERIES.read_text(encoding="utf-8"))
    return [q for q in queries if q["company_id"].upper() in tickers]


_QUERIES = _golden_queries()


def test_golden_queries_are_loaded():
    assert len(_QUERIES) >= 10


@pytest.mark.parametrize("query", _QUERIES, ids=lambda q: q["id"])
def test_golden_query_is_answered_through_the_tools(query):
    year = query["fiscal_year"]
    if query["report_kind"] == "annual":
        res = mcp_server.get_annual_report(query["company_id"], year)
    else:
        res = mcp_server.get_quarterly_report(
            query["company_id"], year, int(query["fiscal_period"].removeprefix("Q"))
        )
    assert res["status"] == "found", res
    assert res["answer"]["accession"] == query["expected_canonical_accession"]
    assert res["answer"]["form"] == query["form"]


def test_apple_fy2009_shows_the_original_as_another_version():
    res = mcp_server.get_annual_report("aapl", 2009)
    assert res["answer"]["form"] == "10-K/A"
    assert res["answer"]["amendment_kind"] == "accounting_change"
    assert [v["form"] for v in res["other_versions"]] == ["10-K"]
    assert res["expected"]["status"] == "received"


def test_toyota_quarterly_gives_the_d01_message():
    res = mcp_server.get_quarterly_report("TM", 2026, 1)
    assert res["status"] == "foreign_no_quarterly"
    assert "no periodic quarterly report is filed with the SEC" in res["message"]
    assert "D-01" in res["message"]


def test_unknown_company_and_missing_year_are_answers_not_errors():
    assert mcp_server.get_annual_report("NOPE", 2020)["status"] == "unknown_company"
    res = mcp_server.get_annual_report("AAPL", 1900)
    assert res["status"] == "nothing_on_file"
    assert 2009 in res["years_on_file"]
    assert mcp_server.get_quarterly_report("AAPL", 2020, 5)["status"] == "error"


def test_list_filings_defaults_to_periodic_reports_newest_first():
    res = mcp_server.list_filings("TM", limit=5)
    assert res["status"] == "ok" and res["count"] == 5 and res["truncated"] is True
    dates = [f["filing_date"] for f in res["filings"]]
    assert dates == sorted(dates, reverse=True)
    assert {f["form_family"] for f in res["filings"]} <= set(mcp_server._PERIODIC)
    since = mcp_server.list_filings("AAPL", family="annual", since="2025-01-01")
    assert since["filings"] and {f["form"] for f in since["filings"]} == {"10-K"}
    assert all(f["filing_date"] >= "2025-01-01" for f in since["filings"])
    assert mcp_server.list_filings("AAPL", family="bogus")["status"] == "error"
    assert mcp_server.list_filings("AAPL", since="yesterday")["status"] == "error"


def test_morning_check_lists_red_first():
    res = mcp_server.morning_check()
    assert res["status"] == "ok"
    order = {"red": 0, "amber": 1, "green": 2}
    ranks = [order[c["status"]] for c in res["checks"]]
    assert ranks == sorted(ranks)
    assert mcp_server.morning_check("2000-01-01")["status"] == "no_results"


def test_explain_label_for_an_amendment():
    res = mcp_server.explain_label("0001193125-10-012091")
    assert res["status"] == "ok"
    assert res["label"]["source"] and res["label"]["confidence"]
    assert res["label"]["fiscal_year"] == 2009
    assert res["amendment"]["scope"] == "full"
    assert res["amendment"]["kind"] == "accounting_change"
    assert res["amendment"]["amends_accession"] == "0001193125-09-214859"
    assert mcp_server.explain_label("000119312510012091")["accession"] == "0001193125-10-012091"
    assert mcp_server.explain_label("0000000000-00-000000")["status"] == "not_found"
    assert mcp_server.explain_label("x; DROP TABLE filing")["status"] == "error"


def test_the_servers_connection_cannot_write():
    with mcp_server.connect_readonly() as conn:
        row = conn.execute("SHOW default_transaction_read_only").fetchone()
        assert row["default_transaction_read_only"] == "on"
        assert conn.execute("SHOW statement_timeout").fetchone()["statement_timeout"] == "5s"
        with pytest.raises(psycopg.errors.ReadOnlySqlTransaction):
            conn.execute("UPDATE company SET name = 'x'")
        with pytest.raises(psycopg.errors.ReadOnlySqlTransaction):
            conn.execute("CREATE TABLE scratch (a int)")
        with pytest.raises(psycopg.errors.ReadOnlySqlTransaction):
            conn.execute("DELETE FROM filing")


def test_statement_timeout_stops_a_slow_query():
    with mcp_server.connect_readonly() as conn:
        conn.execute("SET statement_timeout = 100")
        with pytest.raises(psycopg.errors.QueryCanceled):
            conn.execute("SELECT pg_sleep(2)")


def test_a_database_error_comes_back_as_an_error_dict(monkeypatch):
    monkeypatch.setenv("MCP_DATABASE_URL", "postgresql://127.0.0.1:1/none?connect_timeout=1")
    res = mcp_server.get_annual_report("AAPL", 2009)
    assert res["status"] == "error"


def test_the_server_registers_exactly_five_tools():
    pytest.importorskip("mcp")
    import asyncio

    server = mcp_server.build_server()
    names = sorted(t.name for t in asyncio.run(server.list_tools()))
    assert names == [
        "explain_label",
        "get_annual_report",
        "get_quarterly_report",
        "list_filings",
        "morning_check",
    ]
    assert "D-04" in (server.instructions or "")


def test_mcp_json_passes_the_reader_url_with_database_url_as_fallback():
    cfg = json.loads((Path(__file__).parents[2] / ".mcp.json").read_text(encoding="utf-8"))
    env = cfg["mcpServers"]["sec-filings"]["env"]
    assert env["MCP_DATABASE_URL"].startswith("${MCP_DATABASE_URL")
    assert env["DATABASE_URL"].startswith("${DATABASE_URL")


def test_database_url_prefers_the_reader_url_and_falls_back(monkeypatch):
    monkeypatch.setenv("DATABASE_URL", "postgresql://owner/db")
    monkeypatch.setenv("MCP_DATABASE_URL", "postgresql://reader/db")
    assert mcp_server.database_url() == "postgresql://reader/db"
    monkeypatch.setenv("MCP_DATABASE_URL", "")  # what .mcp.json passes when it is unset
    assert mcp_server.database_url() == "postgresql://owner/db"
    monkeypatch.delenv("MCP_DATABASE_URL")
    assert mcp_server.database_url() == "postgresql://owner/db"


def test_annual_report_gives_both_period_ends_and_late_confidence():
    res = mcp_server.get_annual_report("WMT", 2009)
    assert res["period_end_sec"] == "2009-04-01"
    assert res["period_end"] != res["period_end_sec"]
    assert "SEC lists 2009-04-01" in res["period_end_note"]
    exp = res["expected"]
    if exp:
        assert "late_confidence" in exp


def test_a_52_53_week_year_end_is_shown_as_the_sec_gives_it():
    # Apple's fiscal 2009 ended Saturday 2009-09-26. Snapping to month end is for labels only;
    # the answer must not claim a "correction" to 2009-09-30 (found on the final live run).
    res = mcp_server.get_annual_report("AAPL", 2009)
    assert res["period_end"] == "2009-09-26"
    assert res["period_end_sec"] == "2009-09-26"
    assert res["period_end_note"] is None
