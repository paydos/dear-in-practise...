from __future__ import annotations

import gzip
import hashlib
from dataclasses import replace
from datetime import UTC, date, datetime, timedelta

import psycopg
import pytest

from sec_filings.db import repo
from sec_filings.db.repo import FilingRecord
from sec_filings.domain.corrections import CorrectionEventDraft
from sec_filings.domain.expected import ExpectedFiling
from sec_filings.models import (
    CanonicalChoice,
    CheckResult,
    FetchedResponse,
    FormerName,
    PageRef,
    RunResult,
)

pytestmark = pytest.mark.db


def mk_company(conn, cid="AAPL"):
    repo.upsert_company(
        conn,
        company_id=cid,
        name=cid + " Inc",
        is_foreign_private_issuer=False,
        fiscal_year_end_mmdd="0926",
        filer_category_current="Large accelerated filer",
    )


def rec(acc, **kw):
    base = dict(
        accession_number=acc,
        cik=320193,
        company_id="AAPL",
        form="10-K",
        form_family="annual",
        filing_date=date(2025, 11, 1),
        period_of_report=date(2025, 9, 27),
        fiscal_year=2025,
        fiscal_period="FY",
        label_source="filing_dei",
        label_confidence="high",
        items=("2.02",),
    )
    base.update(kw)
    return FilingRecord(**base)


def test_company_and_cik_upsert(db_conn):
    mk_company(db_conn)
    repo.upsert_company(
        db_conn,
        company_id="AAPL",
        name="Apple",
        is_foreign_private_issuer=True,
        fiscal_year_end_mmdd="0927",
        filer_category_current="x",
        fy_naming_convention="ends_in",
        pre_merger_until=date(2020, 1, 1),
        reviewed=True,
        notes="n",
    )
    row = db_conn.execute(
        "SELECT name, is_foreign_private_issuer, reviewed, fy_naming_convention, notes FROM company"
    ).fetchall()
    assert row == [("Apple", True, True, "ends_in", "n")]
    repo.upsert_company_cik(
        db_conn, company_id="AAPL", cik=320193, valid_from=None, valid_to=None, source="ticker_file"
    )
    repo.upsert_company_cik(
        db_conn,
        company_id="AAPL",
        cik=320193,
        valid_from=date(2000, 1, 1),
        valid_to=None,
        source="manual",
        note="x",
    )
    assert db_conn.execute("SELECT source, note, valid_from FROM company_cik").fetchall() == [
        ("manual", "x", date(2000, 1, 1))
    ]
    assert repo.known_ciks(db_conn) == {320193: "AAPL"}


def test_cik_owned_by_other_company_is_rejected(db_conn):
    mk_company(db_conn, "A")
    mk_company(db_conn, "B")
    repo.upsert_company_cik(
        db_conn, company_id="A", cik=1, valid_from=None, valid_to=None, source="manual"
    )
    with pytest.raises(psycopg.errors.UniqueViolation):
        repo.upsert_company_cik(
            db_conn, company_id="B", cik=1, valid_from=None, valid_to=None, source="manual"
        )


def test_replace_name_history(db_conn):
    names = [FormerName("Old Co", None, date(2010, 1, 1)), FormerName("Older", None, None)]
    repo.replace_name_history(db_conn, 5, names)
    repo.replace_name_history(db_conn, 5, names[:1] + [FormerName("Old Co", None, None)])
    assert db_conn.execute("SELECT name FROM company_name_history WHERE cik=5").fetchall() == [
        ("Old Co",)
    ]
    repo.replace_name_history(db_conn, 5, [])
    assert db_conn.execute("SELECT count(*) FROM company_name_history").fetchone()[0] == 0


def test_run_lifecycle(db_conn):
    assert repo.last_run(db_conn) is None
    rid = repo.start_run(db_conn, "sync", "abc123")
    row = repo.last_run(db_conn)
    assert row["run_id"] == rid and row["status"] == "running" and row["git_sha"] == "abc123"
    start = datetime(2026, 11, 10, 5, 0, tzinfo=UTC)
    repo.finish_run(
        db_conn,
        RunResult(
            rid,
            "sync",
            "partial",
            start,
            start + timedelta(minutes=3),
            12,
            4,
            5,
            6,
            ["A"],
            ["B"],
            "boom",
        ),
    )
    row = repo.last_run(db_conn, status="partial", mode="sync")
    assert row["finished_at"] == start + timedelta(minutes=3)
    assert (row["rows_inserted"], row["rows_updated"], row["rows_unchanged"]) == (4, 5, 6)
    assert row["companies_ok"] == ["A"] and row["companies_failed"] == ["B"]
    assert row["error_summary"] == "boom"
    assert repo.last_run(db_conn, status="success") is None
    assert repo.last_run(db_conn, mode="backfill") is None
    r2 = repo.start_run(db_conn, "check")
    assert repo.last_run(db_conn)["run_id"] == r2


def test_advisory_lock_is_exclusive_across_sessions(db_conn):
    other = psycopg.connect(db_conn.info.dsn, password=db_conn.info.password)
    try:
        assert repo.try_advisory_lock(db_conn) is True
        assert repo.try_advisory_lock(other) is False
        repo.release_advisory_lock(db_conn)
        assert repo.try_advisory_lock(other) is True
        repo.release_advisory_lock(other)
    finally:
        other.close()


def resp(body=b'{"a":1}', url="https://data.sec.gov/submissions/CIK1.json", at=None):
    return FetchedResponse(
        url,
        200,
        body,
        hashlib.sha256(body).hexdigest(),
        at or datetime(2026, 11, 10, 5, 0, tzinfo=UTC),
        False,
    )


def test_raw_payload_roundtrip_and_dedupe(db_conn):
    rid = repo.start_run(db_conn, "sync")
    r1 = resp()
    assert repo.store_raw_payload(db_conn, r1, rid) == r1.sha256
    later = datetime(2026, 11, 11, 5, 0, tzinfo=UTC)
    repo.store_raw_payload(db_conn, resp(at=later), rid)
    first, last, blob = db_conn.execute(
        "SELECT first_fetched_at, last_fetched_at, body_gzip FROM raw_payload"
    ).fetchone()
    assert first == r1.fetched_at and last == later
    assert gzip.decompress(bytes(blob)) == r1.body
    assert repo.latest_raw_payload(db_conn, r1.url) == r1.body
    assert repo.latest_raw_payload(db_conn, "https://nope") is None
    newer = resp(b'{"a":2}', at=later + timedelta(hours=1))
    repo.store_raw_payload(db_conn, newer, rid)
    assert repo.latest_raw_payload(db_conn, r1.url) == b'{"a":2}'


def test_raw_fetch_logged_per_url_even_for_identical_bodies(db_conn):
    rid = repo.start_run(db_conn, "sync")
    a, b = "https://data.sec.gov/a.json", "https://data.sec.gov/b.json"
    t0 = datetime(2026, 11, 10, 5, 0, tzinfo=UTC)
    repo.store_raw_payload(db_conn, resp(b"same", a, t0), rid)
    repo.store_raw_payload(db_conn, resp(b"same", b, t0 + timedelta(minutes=1)), rid)
    assert db_conn.execute("SELECT count(*) FROM raw_payload").fetchone()[0] == 1  # one body
    assert db_conn.execute("SELECT count(*) FROM raw_fetch").fetchone()[0] == 2  # two fetches
    assert repo.latest_raw_payload(db_conn, a) == b"same"
    assert repo.latest_raw_payload(db_conn, b) == b"same"
    row = db_conn.execute(
        "SELECT sha256, fetched_at, run_id, http_status FROM raw_fetch WHERE url = %s", (b,)
    ).fetchone()
    assert row == (hashlib.sha256(b"same").hexdigest(), t0 + timedelta(minutes=1), rid, 200)


def test_stored_404_reads_as_none_and_hides_an_older_200(db_conn):
    rid = repo.start_run(db_conn, "sync")
    url = "https://data.sec.gov/c.json"
    t0 = datetime(2026, 11, 10, 5, 0, tzinfo=UTC)
    gone = FetchedResponse(url, 404, b"", hashlib.sha256(b"").hexdigest(), t0, False)
    other = FetchedResponse("https://x/other", 404, b"", gone.sha256, t0, False)
    repo.store_raw_payload(db_conn, other, rid)  # same empty body under another URL first
    repo.store_raw_payload(db_conn, gone, rid)
    assert repo.latest_raw_payload(db_conn, url) is None
    repo.store_raw_payload(db_conn, resp(b'{"x":1}', url, t0 + timedelta(hours=1)), rid)
    assert repo.latest_raw_payload(db_conn, url) == b'{"x":1}'
    later = FetchedResponse(url, 404, b"", gone.sha256, t0 + timedelta(hours=2), False)
    repo.store_raw_payload(db_conn, later, rid)
    assert repo.latest_raw_payload(db_conn, url) is None


def test_declared_fiscal_label_is_stored_and_changes_are_updates(db_conn):
    mk_company(db_conn)
    r1 = repo.start_run(db_conn, "sync")
    a = rec("0000320193-25-000001")
    assert a.declared_fiscal_year is None and a.declared_fiscal_period is None  # defaults
    assert repo.upsert_filings(db_conn, [a], r1) == (1, 0, 0)
    declared = replace(a, declared_fiscal_year=2024, declared_fiscal_period="FY")
    r2 = repo.start_run(db_conn, "sync")
    assert repo.upsert_filings(db_conn, [declared], r2) == (0, 1, 0)
    assert db_conn.execute(
        "SELECT fiscal_year, declared_fiscal_year, declared_fiscal_period FROM filing"
    ).fetchone() == (2025, 2024, "FY")
    assert repo.upsert_filings(db_conn, [declared], r2) == (0, 0, 1)


def test_upsert_filings_insert_then_noop_then_update(db_conn):
    mk_company(db_conn)
    r1, r2 = repo.start_run(db_conn, "sync"), None
    recs = [
        rec("0000320193-25-000001"),
        rec("0000320193-25-000002", form="10-Q", form_family="quarterly", fiscal_period="Q1"),
    ]
    assert repo.upsert_filings(db_conn, recs, r1) == (2, 0, 0)
    r2 = repo.start_run(db_conn, "sync")
    assert repo.upsert_filings(db_conn, recs, r2) == (0, 0, 2)
    row = db_conn.execute(
        "SELECT first_seen_run_id, last_seen_run_id, is_stale, last_seen_at IS NOT NULL "
        "FROM filing WHERE accession_number = '0000320193-25-000001'"
    ).fetchone()
    assert row == (r1, r2, False, True)
    changed = [replace(recs[0], primary_document="a.htm", items=("2.02", "9.01")), recs[1]]
    r3 = repo.start_run(db_conn, "sync")
    assert repo.upsert_filings(db_conn, changed, r3) == (0, 1, 1)
    assert db_conn.execute(
        "SELECT primary_document, items, first_seen_run_id FROM filing "
        "WHERE accession_number = '0000320193-25-000001'"
    ).fetchone() == ("a.htm", ["2.02", "9.01"], r1)
    assert repo.upsert_filings(db_conn, [], r3) == (0, 0, 0)


def test_upsert_resurrects_stale_and_keeps_canonical(db_conn):
    mk_company(db_conn)
    rid = repo.start_run(db_conn, "sync")
    a = rec("0000320193-25-000001")
    repo.upsert_filings(db_conn, [a], rid)
    repo.write_canonical(
        db_conn,
        "AAPL",
        [
            (
                "annual",
                2025,
                "FY",
                CanonicalChoice(a.accession_number, a.accession_number, a.accession_number, 1),
            )
        ],
    )
    assert repo.mark_stale(db_conn, cik=320193, seen_accessions=set()) == 1
    assert repo.upsert_filings(db_conn, [a], rid) == (0, 0, 1)
    assert db_conn.execute("SELECT is_stale, is_canonical FROM filing").fetchone() == (False, True)


def test_upsert_orders_amendments_after_targets(db_conn):
    mk_company(db_conn)
    rid = repo.start_run(db_conn, "sync")
    orig = rec("0000320193-25-000001")
    amend = rec(
        "0000320193-25-000002",
        form="10-K/A",
        form_family="annual_amendment",
        amends_accession=orig.accession_number,
        amendment_scope="full",
        amendment_kind="restatement",
    )
    assert repo.upsert_filings(db_conn, [amend, orig], rid) == (2, 0, 0)
    assert repo.upsert_filings(db_conn, [amend, orig], rid) == (0, 0, 2)


def test_mark_stale_counts_only_newly_stale_and_scopes_to_cik(db_conn):
    mk_company(db_conn)
    rid = repo.start_run(db_conn, "sync")
    a, b = rec("0000320193-25-000001"), rec("0000320193-25-000002")
    other = rec("0000999999-25-000001", cik=999)
    repo.upsert_filings(db_conn, [a, b, other], rid)
    assert repo.mark_stale(db_conn, cik=320193, seen_accessions={a.accession_number}) == 1
    assert repo.mark_stale(db_conn, cik=320193, seen_accessions={a.accession_number}) == 0
    stale = dict(db_conn.execute("SELECT accession_number, is_stale FROM filing").fetchall())
    assert stale == {
        a.accession_number: False,
        b.accession_number: True,
        other.accession_number: False,
    }


def test_cik_alias_idempotent(db_conn):
    mk_company(db_conn)
    rid = repo.start_run(db_conn, "sync")
    repo.upsert_filings(db_conn, [rec("0000320193-25-000001")], rid)
    repo.add_cik_alias(db_conn, "0000320193-25-000001", 34088)
    repo.add_cik_alias(db_conn, "0000320193-25-000001", 34088)
    assert db_conn.execute("SELECT count(*) FROM filing_cik_alias").fetchone()[0] == 1


def test_history_page_upsert(db_conn):
    rid = repo.start_run(db_conn, "sync")
    sha = repo.store_raw_payload(db_conn, resp(), rid)
    page = PageRef("CIK1-submissions-001.json", 10, date(2001, 1, 1), date(2010, 1, 1))
    repo.record_history_page(db_conn, cik=1, page=page, rows_in_payload=None, payload_sha256=None)
    repo.record_history_page(db_conn, cik=1, page=page, rows_in_payload=10, payload_sha256=sha)
    assert db_conn.execute(
        "SELECT filing_count, rows_in_payload, payload_sha256, filing_to FROM history_page"
    ).fetchall() == [(10, 10, sha, date(2010, 1, 1))]


def test_write_canonical_replaces_everything(db_conn):
    mk_company(db_conn)
    rid = repo.start_run(db_conn, "sync")
    a = rec("0000320193-25-000001")
    am = rec(
        "0000320193-25-000002",
        form="10-K/A",
        form_family="annual_amendment",
        amends_accession=a.accession_number,
    )
    repo.upsert_filings(db_conn, [a, am], rid)
    first = CanonicalChoice(a.accession_number, am.accession_number, a.accession_number, 2)
    repo.write_canonical(db_conn, "AAPL", [("annual", 2025, "FY", first)])
    assert dict(
        db_conn.execute("SELECT accession_number, is_canonical FROM filing").fetchall()
    ) == {a.accession_number: True, am.accession_number: False}
    # flip canonical to the amendment: no unique-index clash, report_period replaced
    second = CanonicalChoice(am.accession_number, am.accession_number, a.accession_number, 2)
    repo.write_canonical(db_conn, "AAPL", [("annual", 2025, "FY", second)])
    assert dict(
        db_conn.execute("SELECT accession_number, is_canonical FROM filing").fetchall()
    ) == {a.accession_number: False, am.accession_number: True}
    assert db_conn.execute(
        "SELECT canonical_accession, latest_filed_accession, version_count FROM report_period"
    ).fetchall() == [(am.accession_number, am.accession_number, 2)]
    repo.write_canonical(db_conn, "AAPL", [])
    assert db_conn.execute("SELECT count(*) FROM report_period").fetchone()[0] == 0
    assert db_conn.execute("SELECT count(*) FROM filing WHERE is_canonical").fetchone()[0] == 0


def test_two_canonical_rows_are_impossible(db_conn):
    mk_company(db_conn)
    rid = repo.start_run(db_conn, "sync")
    repo.upsert_filings(db_conn, [rec("0000320193-25-000001", is_canonical=True)], rid)
    with pytest.raises(psycopg.errors.UniqueViolation):
        repo.upsert_filings(db_conn, [rec("0000320193-25-000002", is_canonical=True)], rid)


def test_replace_expected_and_corrections(db_conn):
    mk_company(db_conn)
    rid = repo.start_run(db_conn, "sync")
    a = rec("0000320193-25-000001")
    nr = rec(
        "0000320193-25-000003",
        form="8-K",
        form_family="non_reliance_8k",
        fiscal_year=None,
        fiscal_period=None,
        label_source="none",
        label_confidence=None,
    )
    repo.upsert_filings(db_conn, [a, nr], rid)
    exp = ExpectedFiling(
        "AAPL",
        "annual",
        2025,
        "FY",
        date(2025, 9, 27),
        "large_accelerated",
        "cover",
        date(2025, 11, 26),
        date(2025, 12, 11),
        "received",
        a.accession_number,
        None,
    )
    repo.replace_expected(db_conn, "AAPL", [exp])
    repo.replace_expected(
        db_conn,
        "AAPL",
        [exp, replace(exp, fiscal_year=2026, status="pending", matched_accession=None)],
    )
    assert db_conn.execute("SELECT count(*) FROM expected_filing").fetchone()[0] == 2
    repo.replace_expected(db_conn, "AAPL", [])
    assert db_conn.execute("SELECT count(*) FROM expected_filing").fetchone()[0] == 0

    ev = CorrectionEventDraft(
        "AAPL",
        "non_reliance_8k",
        nr.accession_number,
        date(2025, 3, 1),
        (a.accession_number,),
        "medium",
        False,
    )
    repo.replace_correction_events(db_conn, "AAPL", [ev])
    repo.replace_correction_events(db_conn, "AAPL", [ev])
    assert db_conn.execute(
        "SELECT corrected_in_accessions, link_confidence FROM correction_event"
    ).fetchall() == [([a.accession_number], "medium")]
    repo.replace_correction_events(db_conn, "AAPL", [])
    assert db_conn.execute("SELECT count(*) FROM correction_event").fetchone()[0] == 0


def test_reconciliation(db_conn):
    rid = repo.start_run(db_conn, "sync")
    assert repo.last_reconciled_date(db_conn) is None
    repo.record_reconciliation(
        db_conn, index_date=date(2026, 11, 3), status="ok", entries_for_us=2, missing=[], run_id=rid
    )
    repo.record_reconciliation(
        db_conn,
        index_date=date(2026, 11, 4),
        status="missing_filings",
        entries_for_us=1,
        missing=["0000320193-26-000001"],
        run_id=rid,
    )
    repo.record_reconciliation(
        db_conn,
        index_date=date(2026, 11, 5),
        status="not_published",
        entries_for_us=0,
        missing=[],
        run_id=rid,
    )
    assert repo.last_reconciled_date(db_conn) == date(2026, 11, 4)
    repo.record_reconciliation(
        db_conn, index_date=date(2026, 11, 4), status="ok", entries_for_us=1, missing=[], run_id=rid
    )
    assert db_conn.execute(
        "SELECT status, missing FROM daily_index_reconciliation WHERE index_date='2026-11-04'"
    ).fetchone() == ("ok", [])


def test_write_check_results_and_company_filings(db_conn):
    mk_company(db_conn)
    rid = repo.start_run(db_conn, "check")
    repo.write_check_results(
        db_conn,
        rid,
        [
            CheckResult("C2", "Run status", "core", "green", "ok"),
            CheckResult("C9", "Expected but overdue", "core", "red", "late", "1", "0", "AAPL"),
        ],
    )
    assert db_conn.execute(
        "SELECT check_id, status, observed, company_id FROM check_result ORDER BY check_id"
    ).fetchall() == [("C2", "green", None, None), ("C9", "red", "1", "AAPL")]

    repo.upsert_filings(
        db_conn,
        [
            rec("0000320193-25-000002", filing_date=date(2025, 5, 1)),
            rec("0000320193-25-000001", filing_date=date(2024, 11, 1)),
        ],
        rid,
    )
    got = repo.company_filings(db_conn, "AAPL")
    assert [g["accession_number"] for g in got] == ["0000320193-25-000001", "0000320193-25-000002"]
    assert got[0]["items"] == ["2.02"]
    assert repo.company_filings(db_conn, "NOPE") == []
