"""Analyst views: the first-filed report and lateness claims (T-12, round 2)."""

from __future__ import annotations

from datetime import date

import pytest

from sec_filings.db import repo
from sec_filings.db.repo import FilingRecord
from sec_filings.domain.expected import ExpectedFiling
from sec_filings.models import CanonicalChoice, RunResult

pytestmark = pytest.mark.db

ORIG = "0000000001-21-000001"
AMEND = "0000000001-22-000002"
Q1 = "0000000001-21-000003"


def _rec(acc, form, family, filed, period, fy, fp, **kw):
    return FilingRecord(
        accession_number=acc,
        cik=1,
        company_id="PLUG",
        form=form,
        form_family=family,
        filing_date=filed,
        period_of_report=period,
        fiscal_year=fy,
        fiscal_period=fp,
        label_source="filing_dei",
        label_confidence="high",
        **kw,
    )


def _expected(kind, fy, fp, end, due, status, matched, source):
    return ExpectedFiling(
        "PLUG", kind, fy, fp, end, "large_accelerated", source, due, due, status, matched, None
    )


@pytest.fixture
def seeded(db_conn):
    repo.upsert_company(
        db_conn,
        company_id="PLUG",
        name="Plug",
        is_foreign_private_issuer=False,
        fiscal_year_end_mmdd="1231",
        filer_category_current="Large accelerated filer",
    )
    rid = repo.start_run(db_conn, "sync")
    repo.finish_run(
        db_conn,
        RunResult(rid, "sync", "success", None, None, 0, 0, 0, 0, [], [], None),  # type: ignore[arg-type]
    )
    repo.upsert_filings(
        db_conn,
        [
            _rec(ORIG, "10-K", "annual", date(2021, 5, 14), date(2020, 12, 31), 2020, "FY"),
            _rec(
                AMEND,
                "10-K/A",
                "annual_amendment",
                date(2022, 3, 14),
                date(2020, 12, 31),
                2020,
                "FY",
                amends_accession=ORIG,
                amendment_scope="full",
                amendment_kind="restatement",
            ),
            _rec(Q1, "10-Q", "quarterly", date(2021, 6, 22), date(2021, 3, 31), 2021, "Q1"),
        ],
        rid,
    )
    repo.write_canonical(
        db_conn,
        "PLUG",
        [
            ("annual", 2020, "FY", CanonicalChoice(AMEND, AMEND, ORIG, 2)),
            ("quarterly", 2021, "Q1", CanonicalChoice(Q1, Q1, Q1, 1)),
        ],
    )
    return db_conn


def test_annual_view_names_the_original_and_judges_it(seeded):
    repo.replace_expected(
        seeded,
        "PLUG",
        [
            _expected(
                "annual",
                2020,
                "FY",
                date(2020, 12, 31),
                date(2021, 3, 1),
                "received_late",
                ORIG,
                "cover",
            ),
            _expected(
                "quarterly",
                2021,
                "Q1",
                date(2021, 3, 31),
                date(2021, 5, 10),
                "received_late",
                Q1,
                "current",
            ),
        ],
    )
    row = seeded.execute(
        "SELECT accession, original_accession, original_filing_date, filing_date, filed_late, "
        "days_after_period_end, category_source FROM v_annual_reports WHERE fiscal_year = 2020"
    ).fetchone()
    # the canonical row is the 2022 amendment; lateness and the original are the 2021 filing
    assert row == (AMEND, ORIG, date(2021, 5, 14), date(2022, 3, 14), True, 134, "cover")


def test_filed_late_is_not_claimed_when_the_category_is_todays(seeded):
    repo.replace_expected(
        seeded,
        "PLUG",
        [
            _expected(
                "quarterly",
                2021,
                "Q1",
                date(2021, 3, 31),
                date(2021, 5, 10),
                "received_late",
                Q1,
                "current",
            ),
        ],
    )
    row = seeded.execute(
        "SELECT status, filed_late, category_source, original_accession, original_filing_date "
        "FROM v_quarterly_reports WHERE fiscal_period = 'Q1'"
    ).fetchone()
    assert row == ("received_late", False, "current", Q1, date(2021, 6, 22))
    for source in ("cover", "public_float", "previous_cover", "previous_public_float", "none"):
        repo.replace_expected(
            seeded,
            "PLUG",
            [
                _expected(
                    "quarterly",
                    2021,
                    "Q1",
                    date(2021, 3, 31),
                    date(2021, 5, 10),
                    "received_late",
                    Q1,
                    source,
                )
            ],
        )
        late = seeded.execute("SELECT filed_late FROM v_quarterly_reports").fetchone()[0]
        assert late is True, source
