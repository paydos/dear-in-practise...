from __future__ import annotations

from datetime import UTC, date, datetime, time, timedelta
from pathlib import Path

import pytest

from sec_filings.checks import core
from sec_filings.checks.core import CheckContext
from sec_filings.db import repo
from sec_filings.db.repo import FilingRecord
from sec_filings.domain.expected import ExpectedFiling
from sec_filings.models import CanonicalChoice, CheckResult, PageRef, RunResult

pytestmark = pytest.mark.db

TODAY = date(2026, 11, 10)
NOW = datetime(2026, 11, 10, 6, 0, tzinfo=UTC)  # 06:00 London (GMT in November)
A1 = "0000320193-25-000001"
A2 = "0000320193-25-000002"


def mk_company(conn, cid="AAPL", reviewed=True):
    repo.upsert_company(
        conn,
        company_id=cid,
        name=cid,
        is_foreign_private_issuer=False,
        fiscal_year_end_mmdd="0926",
        filer_category_current="x",
        reviewed=reviewed,
    )


def rec(acc=A1, **kw):
    base = dict(
        accession_number=acc,
        cik=320193,
        company_id="AAPL",
        form="10-K",
        form_family="annual",
        filing_date=date(2025, 11, 1),
        period_of_report=date(2025, 9, 27),
        fiscal_year=2025,
        fiscal_period="FY",
        label_source="filing_dei",
        label_confidence="high",
    )
    base.update(kw)
    return FilingRecord(**base)


def finish(
    conn,
    status="success",
    mode="sync",
    error=None,
    failed=(),
    at=NOW,
    scope="all",
    sec_denied=False,
    started=None,
):
    rid = repo.start_run(conn, mode, None, scope)
    repo.finish_run(
        conn,
        RunResult(rid, mode, status, at, at, 0, 0, 0, 0, [], list(failed), error),
        sec_denied=sec_denied,
    )
    if started is not None:
        conn.execute("UPDATE run SET started_at = %s WHERE run_id = %s", (started, rid))
    return rid


def reconcile_days(conn, rid, start, end, status="ok"):
    """Record every US business day from start to end (the way a healthy daily job would)."""
    d = start
    while d <= end:
        if core.is_business_day(d):
            repo.record_reconciliation(
                conn, index_date=d, status=status, entries_for_us=0, missing=[], run_id=rid
            )
        d += timedelta(days=1)


def ctx_for(rid, tmp_path, **kw):
    base = dict(
        run_id=rid,
        today=TODAY,
        now=NOW,
        ticker_map={},
        tickers_in_csv=[],
        golden_queries_path=tmp_path / "golden.yml",
    )
    base.update(kw)
    return CheckContext(**base)


def statuses(results):
    return {r.status for r in results}


def test_every_check_has_id_and_name_and_green_on_empty_db(db_conn, tmp_path):
    rid = finish(db_conn)
    now = datetime.now(UTC)
    mk_company(db_conn, "AAPL")
    repo.upsert_company_cik(
        db_conn, company_id="AAPL", cik=320193, valid_from=None, valid_to=None, source="ticker_file"
    )
    repo.record_reconciliation(
        db_conn,
        index_date=TODAY - timedelta(days=1),
        status="ok",
        entries_for_us=0,
        missing=[],
        run_id=rid,
    )
    (tmp_path / "golden.yml").write_text("[]")
    ctx = ctx_for(rid, tmp_path, now=now, tickers_in_csv=["AAPL"], ticker_map={"AAPL": 320193})
    results = core.run_core_checks(db_conn, ctx)
    assert [r.check_id for r in results] == [*(f"C{i}" for i in range(2, 13)), "X1"]
    assert [r.check_name for r in results] == [
        "Run status",
        "Daily index reconcile",
        "Company mapping",
        "Coverage drift",
        "Row count never falls",
        "One canonical per period",
        "Labels present and plausible",
        "Expected but overdue",
        "Amendments resolved",
        "Golden queries",
        "Unknown periodic form",
        "Stale rows",
    ]
    assert statuses(results) == {"green"}
    assert [r.tier for r in results] == ["core"] * 11 + ["extended"]


# ---------------------------------------------------------------- C1


def test_c1_heartbeat(db_conn):
    late_now = datetime(2026, 11, 10, 8, 0, tzinfo=UTC)
    # nothing at all, after the deadline: red
    r = core.heartbeat_check(db_conn, now=late_now)
    assert (r.check_id, r.check_name, r.status) == ("C1", "Heartbeat", "red")
    # before the 06:30 deadline nothing is due yet: green, even with no run at all
    assert core.heartbeat_check(db_conn, now=NOW).status == "green"
    # yesterday's run does not satisfy today's deadline
    finish(db_conn, at=datetime(2026, 11, 9, 5, 30, tzinfo=UTC))
    assert core.heartbeat_check(db_conn, now=late_now).status == "red"
    # a partial run is not a success
    finish(db_conn, status="partial", at=datetime(2026, 11, 10, 5, 30, tzinfo=UTC))
    assert core.heartbeat_check(db_conn, now=late_now).status == "red"
    # today's successful run before now: green
    finish(db_conn, at=datetime(2026, 11, 10, 5, 45, tzinfo=UTC))
    assert core.heartbeat_check(db_conn, now=late_now).status == "green"


def test_c1_expect_run_by_default_is_0630_london_and_is_configurable(db_conn):
    finish(db_conn, at=datetime(2026, 11, 10, 7, 0, tzinfo=UTC))  # finished 07:00
    assert core.heartbeat_check(db_conn, now=datetime(2026, 11, 10, 6, 29, tzinfo=UTC)).status == (
        "green"
    )  # before the deadline
    assert core.heartbeat_check(db_conn, now=datetime(2026, 11, 10, 6, 30, tzinfo=UTC)).status == (
        "red"
    )  # at the deadline, the run has not finished yet
    assert core.heartbeat_check(db_conn, now=datetime(2026, 11, 10, 7, 0, tzinfo=UTC)).status == (
        "green"
    )  # finished at 07:00, which is before or at now
    late = datetime(2026, 11, 10, 9, 0, tzinfo=UTC)
    # a custom deadline of 06:45 is missed when nothing has finished by then
    assert (
        core.heartbeat_check(
            db_conn, now=datetime(2026, 11, 10, 6, 45, tzinfo=UTC), deadline_local=time(6, 45)
        ).status
        == "red"
    )
    assert core.heartbeat_check(db_conn, now=late, deadline_local=time(9, 0)).status == "green"


def test_c1_failed_run_and_check_mode_do_not_count(db_conn):
    finish(db_conn, status="failed", at=datetime(2026, 11, 10, 5, 0, tzinfo=UTC))
    finish(db_conn, mode="check", at=datetime(2026, 11, 10, 5, 0, tzinfo=UTC))
    finish(db_conn, status="skipped_locked", at=datetime(2026, 11, 10, 5, 0, tzinfo=UTC))
    late_now = datetime(2026, 11, 10, 9, 0, tzinfo=UTC)
    assert core.heartbeat_check(db_conn, now=late_now).status == "red"


def test_c1_a_run_finishing_after_now_does_not_count(db_conn):
    finish(db_conn, at=datetime(2026, 11, 10, 8, 30, tzinfo=UTC))
    r = core.heartbeat_check(db_conn, now=datetime(2026, 11, 10, 7, 0, tzinfo=UTC))
    assert r.status == "red" and "expected one by 06:30" in r.message


def test_c1_uses_london_local_time_in_summer(db_conn):
    # The London date matters: a run at 23:30 UTC on 30 June is 00:30 BST on 1 July, so it counts
    # as today's run for a check at 09:00 BST, but not for a check that reads dates in UTC.
    finish(db_conn, at=datetime(2026, 6, 30, 23, 30, tzinfo=UTC))
    now = datetime(2026, 7, 1, 8, 0, tzinfo=UTC)  # 09:00 BST
    assert core.heartbeat_check(db_conn, now=now).status == "green"
    assert core.heartbeat_check(db_conn, now=now, tz="UTC").status == "red"  # a different day


# ---------------------------------------------------------------- C2


def test_c2_variants(db_conn, tmp_path):
    ok = finish(db_conn)
    assert core.check_run_status(db_conn, ctx_for(ok, tmp_path))[0].status == "green"
    bad = finish(db_conn, status="failed", error="kaboom")
    r = core.check_run_status(db_conn, ctx_for(bad, tmp_path))
    assert [x.status for x in r] == ["red"] and "kaboom" in r[0].message
    part = finish(db_conn, status="partial", failed=["XOM", "KO"])
    r = core.check_run_status(db_conn, ctx_for(part, tmp_path))
    assert r[0].status == "red" and "XOM" in r[0].message and "KO" in r[0].message
    denied = finish(db_conn, status="success", error="stopped", sec_denied=True)
    r = core.check_run_status(db_conn, ctx_for(denied, tmp_path))
    assert r[0].status == "red" and "403" in r[0].message
    running = repo.start_run(db_conn, "sync")
    assert core.check_run_status(db_conn, ctx_for(running, tmp_path))[0].status == "green"
    import uuid

    assert core.check_run_status(db_conn, ctx_for(uuid.uuid4(), tmp_path))[0].status == "red"


def test_c2_running_for_over_two_hours_is_a_dead_run(db_conn, tmp_path):
    running = repo.start_run(db_conn, "sync")
    db_conn.execute(
        "UPDATE run SET started_at = %s WHERE run_id = %s",
        (NOW - timedelta(hours=3), running),
    )
    r = core.check_run_status(db_conn, ctx_for(running, tmp_path))
    assert [x.status for x in r] == ["red"] and "run died" in r[0].message
    db_conn.execute(
        "UPDATE run SET started_at = %s WHERE run_id = %s", (NOW - timedelta(hours=1), running)
    )
    assert core.check_run_status(db_conn, ctx_for(running, tmp_path))[0].status == "green"


def test_c2_c4_judge_the_latest_run_that_was_not_skipped(db_conn, tmp_path):
    finish(db_conn, status="partial", failed=["XOM"], at=NOW - timedelta(hours=2))
    finish(db_conn, status="skipped_locked", at=NOW)
    chk = repo.start_run(db_conn, "check")
    r = core.check_run_status(db_conn, ctx_for(chk, tmp_path))
    assert r[0].status == "red" and "XOM" in r[0].message  # not the skipped run's amber
    mk_company(db_conn, "XOM")
    c4 = core.check_company_mapping(db_conn, ctx_for(chk, tmp_path, tickers_in_csv=["XOM"]))
    assert "not resolved: company failed this run" in c4[0].message


def test_c2_standalone_check_run_judges_last_sync(db_conn, tmp_path):
    finish(db_conn, status="failed", error="boom")
    chk = repo.start_run(db_conn, "check")
    assert core.check_run_status(db_conn, ctx_for(chk, tmp_path))[0].status == "red"


def test_c2_standalone_check_run_judges_last_backfill_too(db_conn, tmp_path):
    finish(db_conn, status="success", mode="sync", at=NOW - timedelta(days=1))
    finish(db_conn, status="partial", mode="backfill", failed=["WMT"], at=NOW)
    chk = repo.start_run(db_conn, "check")
    r = core.check_run_status(db_conn, ctx_for(chk, tmp_path))
    assert r[0].status == "red" and "WMT" in r[0].message
    finish(db_conn, status="success", mode="backfill", at=NOW + timedelta(hours=1))
    assert core.check_run_status(db_conn, ctx_for(chk, tmp_path))[0].status == "green"


# ---------------------------------------------------------------- C3


def test_c3_missing_filings_red_with_accessions(db_conn, tmp_path):
    rid = finish(db_conn)
    repo.record_reconciliation(
        db_conn,
        index_date=TODAY - timedelta(days=2),
        status="missing_filings",
        entries_for_us=2,
        missing=["0000320193-26-000009"],
        run_id=rid,
    )
    r = core.check_daily_index_reconcile(db_conn, ctx_for(rid, tmp_path))
    assert r[0].status == "red" and "0000320193-26-000009" in r[0].message


def test_c3_missing_filings_never_decay_until_cleared_or_acknowledged(db_conn, tmp_path):
    rid = finish(db_conn)
    old = TODAY - timedelta(days=45)
    repo.record_reconciliation(
        db_conn,
        index_date=old,
        status="missing_filings",
        entries_for_us=1,
        missing=["0000320193-26-000001"],
        run_id=rid,
    )
    reconcile_days(db_conn, rid, old + timedelta(days=1), TODAY - timedelta(days=1))
    # 45 days later the gap is still red: nothing ages out
    r = core.check_daily_index_reconcile(db_conn, ctx_for(rid, tmp_path))
    assert [x.status for x in r] == ["red"] and "000001" in r[0].message
    # an acknowledgement turns it amber and carries the reason
    repo.acknowledge(db_conn, "C3", str(old), "SEC re-filed it under another CIK")
    r = core.check_daily_index_reconcile(db_conn, ctx_for(rid, tmp_path))
    assert [x.status for x in r] == ["amber"]
    assert "SEC re-filed it under another CIK" in r[0].message and "000001" in r[0].message
    # a different day is not covered by that acknowledgement
    other = TODAY - timedelta(days=3)
    repo.record_reconciliation(
        db_conn,
        index_date=other,
        status="missing_filings",
        entries_for_us=1,
        missing=["0000320193-26-000002"],
        run_id=rid,
    )
    r = core.check_daily_index_reconcile(db_conn, ctx_for(rid, tmp_path))
    assert sorted(x.status for x in r) == ["amber", "red"]
    # re-reconciling the day to ok (what _recheck_missing_days does) clears it for good
    repo.record_reconciliation(
        db_conn, index_date=other, status="ok", entries_for_us=1, missing=[], run_id=rid
    )
    repo.record_reconciliation(
        db_conn, index_date=old, status="ok", entries_for_us=1, missing=[], run_id=rid
    )
    assert core.check_daily_index_reconcile(db_conn, ctx_for(rid, tmp_path))[0].status == "green"


def test_c3_acknowledgement_needs_a_reason_and_can_be_replaced(db_conn):
    with pytest.raises(ValueError):
        repo.acknowledge(db_conn, "C3", "2026-11-06", "   ")
    repo.acknowledge(db_conn, "C3", "2026-11-06", "first")
    repo.acknowledge(db_conn, "C3", "2026-11-06", "second")
    assert repo.acknowledgements(db_conn, "C3") == {"2026-11-06": "second"}


def test_c3_business_days_without_a_row_are_amber_and_listed(db_conn, tmp_path):
    rid = finish(db_conn)
    # TODAY is Tue 2026-11-10, so the last due day is Mon 11-09. 11-04 and 11-05 are missing rows.
    reconcile_days(db_conn, rid, date(2026, 10, 20), date(2026, 11, 3))
    reconcile_days(db_conn, rid, date(2026, 11, 6), date(2026, 11, 9))
    r = core.check_daily_index_reconcile(db_conn, ctx_for(rid, tmp_path))
    assert [x.status for x in r] == ["amber"]
    assert "2026-11-04" in r[0].message and "2026-11-05" in r[0].message
    assert r[0].observed == "2"
    # a hole in the chain stays amber even when the newest day is fine; filling it clears it
    reconcile_days(db_conn, rid, date(2026, 11, 4), date(2026, 11, 5))
    assert core.check_daily_index_reconcile(db_conn, ctx_for(rid, tmp_path))[0].status == "green"
    # weekends and US holidays are never gaps: on Thu 11-12 the last due day is Tue 11-10
    # (Wed 11-11 is Veterans Day), and 11-10 is the last row filled below
    reconcile_days(db_conn, rid, date(2026, 11, 10), date(2026, 11, 10))
    r = core.check_daily_index_reconcile(db_conn, ctx_for(rid, tmp_path, today=date(2026, 11, 12)))
    assert r[0].status == "green"


def test_c3_not_published_latest_is_amber_and_filling_it_clears_it(db_conn, tmp_path):
    rid = finish(db_conn)
    reconcile_days(db_conn, rid, date(2026, 10, 20), date(2026, 11, 6))
    repo.record_reconciliation(
        db_conn,
        index_date=date(2026, 11, 9),
        status="not_published",
        entries_for_us=0,
        missing=[],
        run_id=rid,
    )
    r = core.check_daily_index_reconcile(db_conn, ctx_for(rid, tmp_path))
    assert [x.status for x in r] == ["amber"] and "2026-11-09" in r[0].message
    assert "not published" in r[0].message
    repo.record_reconciliation(
        db_conn,
        index_date=date(2026, 11, 9),
        status="ok",
        entries_for_us=0,
        missing=[],
        run_id=rid,
    )
    assert core.check_daily_index_reconcile(db_conn, ctx_for(rid, tmp_path))[0].status == "green"


def test_c3_only_not_published_days_is_amber_not_red(db_conn, tmp_path):
    rid = finish(db_conn)
    repo.record_reconciliation(
        db_conn,
        index_date=TODAY - timedelta(days=1),
        status="not_published",
        entries_for_us=0,
        missing=[],
        run_id=rid,
    )
    r = core.check_daily_index_reconcile(db_conn, ctx_for(rid, tmp_path))
    assert [x.status for x in r] == ["amber"]
    # A real gap (last reconciled day long ago) is still red next to the amber.
    repo.record_reconciliation(
        db_conn,
        index_date=TODAY - timedelta(days=40),
        status="ok",
        entries_for_us=0,
        missing=[],
        run_id=rid,
    )
    r = core.check_daily_index_reconcile(db_conn, ctx_for(rid, tmp_path))
    assert sorted(x.status for x in r) == ["amber", "red"]


def test_c3_gap_over_30_days_is_red_with_runbook(db_conn, tmp_path):
    rid = finish(db_conn)
    r = core.check_daily_index_reconcile(db_conn, ctx_for(rid, tmp_path))
    assert r[0].status == "red" and "backfill runbook" in r[0].message  # empty table
    repo.record_reconciliation(
        db_conn,
        index_date=TODAY - timedelta(days=31),
        status="ok",
        entries_for_us=0,
        missing=[],
        run_id=rid,
    )
    r = core.check_daily_index_reconcile(db_conn, ctx_for(rid, tmp_path))
    assert any(x.status == "red" and "backfill runbook" in x.message for x in r)
    reconcile_days(db_conn, rid, TODAY - timedelta(days=30), TODAY - timedelta(days=1))
    assert core.check_daily_index_reconcile(db_conn, ctx_for(rid, tmp_path))[0].status == "green"


# ---------------------------------------------------------------- C4


def test_c4_mapping_red_amber_green(db_conn, tmp_path):
    rid = finish(db_conn)
    mk_company(db_conn, "XOM", reviewed=True)
    repo.upsert_company_cik(
        db_conn, company_id="XOM", cik=34088, valid_from=None, valid_to=None, source="ticker_file"
    )
    ctx = ctx_for(rid, tmp_path, tickers_in_csv=["XOM"], ticker_map={"XOM": 34088})
    assert [r.status for r in core.check_company_mapping(db_conn, ctx)] == ["green"]
    ctx = ctx_for(rid, tmp_path, tickers_in_csv=["XOM"], ticker_map={"XOM": 2115436})
    r = core.check_company_mapping(db_conn, ctx)
    assert r[0].status == "red" and r[0].company_id == "XOM" and "2115436" in r[0].message
    # additional cik recorded for the company clears it
    repo.upsert_company_cik(
        db_conn,
        company_id="XOM",
        cik=2115436,
        valid_from=None,
        valid_to=None,
        source="successor_8k",
    )
    assert statuses(core.check_company_mapping(db_conn, ctx)) == {"green"}


def test_c4_unreviewed_and_unsynced_amber_and_no_ticker_map(db_conn, tmp_path):
    rid = finish(db_conn)
    mk_company(db_conn, "NEW", reviewed=False)
    ctx = ctx_for(rid, tmp_path, tickers_in_csv=["NEW", "GHOST"], ticker_map=None)
    r = core.check_company_mapping(db_conn, ctx)
    assert statuses(r) == {"amber"}
    msgs = " ".join(x.message for x in r)
    assert "NEW" in msgs and "GHOST" in msgs and "not fetched" in msgs


def test_c4_empty_ticker_list_is_red(db_conn, tmp_path):
    rid = finish(db_conn)
    for tm in ({}, None):
        ctx = ctx_for(rid, tmp_path, tickers_in_csv=[], ticker_map=tm)
        r = core.check_company_mapping(db_conn, ctx)
        assert [x.status for x in r] == ["red"] and "no tickers" in r[0].message


def test_c4_tracked_ticker_absent_from_the_sec_file_is_amber(db_conn, tmp_path):
    rid = finish(db_conn)
    mk_company(db_conn, "OLD", reviewed=True)
    repo.upsert_company_cik(
        db_conn, company_id="OLD", cik=111, valid_from=None, valid_to=None, source="ticker_file"
    )
    ctx = ctx_for(rid, tmp_path, tickers_in_csv=["OLD"], ticker_map={"OTHER": 5})
    r = core.check_company_mapping(db_conn, ctx)
    assert [(x.status, x.company_id) for x in r] == [("amber", "OLD")]
    assert "absent from the SEC ticker file" in r[0].message


def test_c4_unavailable_ticker_map_is_amber(db_conn, tmp_path):
    rid = finish(db_conn)
    mk_company(db_conn, "XOM", reviewed=True)
    repo.upsert_company_cik(
        db_conn, company_id="XOM", cik=34088, valid_from=None, valid_to=None, source="ticker_file"
    )
    ctx = ctx_for(rid, tmp_path, tickers_in_csv=["XOM"], ticker_map=None)
    r = core.check_company_mapping(db_conn, ctx)
    assert [x.status for x in r] == ["amber"] and "ticker map unavailable" in r[0].message


def test_c4_company_that_failed_this_run_is_amber_not_red(db_conn, tmp_path):
    mk_company(db_conn, "XOM", reviewed=True)
    repo.upsert_company_cik(
        db_conn, company_id="XOM", cik=34088, valid_from=None, valid_to=None, source="ticker_file"
    )
    rid = finish(db_conn, status="partial", failed=["XOM", "GHOST"])
    ctx = ctx_for(rid, tmp_path, tickers_in_csv=["XOM", "GHOST"], ticker_map={"XOM": 2115436})
    r = core.check_company_mapping(db_conn, ctx)
    assert [(x.status, x.company_id) for x in r] == [("amber", "XOM"), ("amber", "GHOST")]
    assert all("not resolved: company failed this run" in x.message for x in r)
    # The same data judged against a run where XOM did not fail is red again.
    ok = finish(db_conn)
    r = core.check_company_mapping(
        db_conn,
        ctx_for(ok, tmp_path, **{"tickers_in_csv": ["XOM"], "ticker_map": {"XOM": 2115436}}),
    )
    assert r[0].status == "red"
    # A standalone check run judges the latest sync or backfill run.
    chk = repo.start_run(db_conn, "check")
    bad = finish(db_conn, status="partial", mode="backfill", failed=["XOM"], at=NOW)
    assert bad
    r = core.check_company_mapping(
        db_conn, ctx_for(chk, tmp_path, tickers_in_csv=["XOM"], ticker_map={"XOM": 2115436})
    )
    assert [x.status for x in r] == ["amber"]


# ---------------------------------------------------------------- C5


def test_c5_coverage_drift(db_conn, tmp_path):
    rid = finish(db_conn)
    page = PageRef("CIK1-001.json", 10, None, None)
    repo.record_history_page(db_conn, cik=1, page=page, rows_in_payload=10, payload_sha256=None)
    assert core.check_coverage_drift(db_conn, ctx_for(rid, tmp_path))[0].status == "green"
    repo.record_history_page(db_conn, cik=1, page=page, rows_in_payload=9, payload_sha256=None)
    r = core.check_coverage_drift(db_conn, ctx_for(rid, tmp_path))
    assert r[0].status == "red" and "10" in r[0].message and "9" in r[0].message
    repo.record_history_page(db_conn, cik=1, page=page, rows_in_payload=None, payload_sha256=None)
    r = core.check_coverage_drift(db_conn, ctx_for(rid, tmp_path))
    assert r[0].status == "red" and "no stored copy" in r[0].message


# ---------------------------------------------------------------- C6


def test_c6_decrease_turns_red_and_baseline_is_stored(db_conn, tmp_path):
    mk_company(db_conn)
    run1 = finish(db_conn)
    repo.upsert_filings(db_conn, [rec(A1), rec(A2, form="10-K405")], run1)
    r1 = core.check_rowcount_monotonic(db_conn, ctx_for(run1, tmp_path))
    assert r1[0].status == "green" and '"AAPL|annual": 2' in r1[0].observed
    repo.write_check_results(db_conn, run1, r1)

    run2 = finish(db_conn)
    r2 = core.check_rowcount_monotonic(db_conn, ctx_for(run2, tmp_path))
    assert r2[0].status == "green"  # same counts
    repo.write_check_results(db_conn, run2, r2)

    # a row flagged stale is still a row: rows are never deleted, so counts do not fall
    db_conn.execute("UPDATE filing SET is_stale = true WHERE accession_number = %s", (A2,))
    run3 = finish(db_conn)
    r3 = core.check_rowcount_monotonic(db_conn, ctx_for(run3, tmp_path))
    assert r3[0].status == "green" and '"AAPL|annual": 2' in r3[0].observed
    repo.write_check_results(db_conn, run3, r3)

    # a row really deleted: red
    db_conn.execute("DELETE FROM filing WHERE accession_number = %s", (A2,))
    run4 = finish(db_conn)
    r4 = core.check_rowcount_monotonic(db_conn, ctx_for(run4, tmp_path))
    assert r4[0].status == "red" and "AAPL|annual 2 -> 1" in r4[0].message
    repo.write_check_results(db_conn, run4, r4)

    # the baseline is the last GREEN result: the drop stays red on the next run ...
    run5 = finish(db_conn)
    r5 = core.check_rowcount_monotonic(db_conn, ctx_for(run5, tmp_path))
    assert r5[0].status == "red" and "AAPL|annual 2 -> 1" in r5[0].message
    repo.write_check_results(db_conn, run5, r5)
    # ... until the rows are restored
    repo.upsert_filings(db_conn, [rec(A2, form="10-K405")], finish(db_conn))
    run6 = finish(db_conn)
    assert core.check_rowcount_monotonic(db_conn, ctx_for(run6, tmp_path))[0].status == "green"

    # a whole company/family disappearing is also a decrease
    repo.write_check_results(
        db_conn, run6, core.check_rowcount_monotonic(db_conn, ctx_for(run6, tmp_path))
    )
    db_conn.execute("DELETE FROM filing")
    run7 = finish(db_conn)
    r7 = core.check_rowcount_monotonic(db_conn, ctx_for(run7, tmp_path))
    assert r7[0].status == "red" and "AAPL|annual 2 -> 0" in r7[0].message


def test_c6_growth_is_green(db_conn, tmp_path):
    mk_company(db_conn)
    run1 = finish(db_conn)
    repo.upsert_filings(db_conn, [rec(A1)], run1)
    repo.write_check_results(
        db_conn, run1, core.check_rowcount_monotonic(db_conn, ctx_for(run1, tmp_path))
    )
    run2 = finish(db_conn)
    repo.upsert_filings(db_conn, [rec(A2, form="10-K405")], run2)
    assert core.check_rowcount_monotonic(db_conn, ctx_for(run2, tmp_path))[0].status == "green"


# ---------------------------------------------------------------- C7


def test_c7_one_canonical(db_conn, tmp_path):
    mk_company(db_conn)
    rid = finish(db_conn)
    repo.upsert_filings(db_conn, [rec(A1)], rid)
    # filings but no canonical: red
    r = core.check_one_canonical(db_conn, ctx_for(rid, tmp_path))
    assert r[0].status == "red" and "AAPL" in r[0].message and "FY2025" in r[0].message
    repo.write_canonical(db_conn, "AAPL", [("annual", 2025, "FY", CanonicalChoice(A1, A1, A1, 1))])
    assert core.check_one_canonical(db_conn, ctx_for(rid, tmp_path))[0].status == "green"


def test_c7_two_originals_in_one_period_is_red_even_with_one_canonical(db_conn, tmp_path):
    mk_company(db_conn)
    rid = finish(db_conn)
    repo.upsert_filings(
        db_conn,
        [rec(A1, filing_date=date(2025, 11, 1)), rec(A2, filing_date=date(2024, 11, 1))],
        rid,
    )
    repo.write_canonical(db_conn, "AAPL", [("annual", 2025, "FY", CanonicalChoice(A1, A1, A2, 2))])
    r = core.check_one_canonical(db_conn, ctx_for(rid, tmp_path))
    assert r[0].status == "red" and "2 original filings" in r[0].message
    assert "canonical)" not in r[0].message.replace("2 original", "")  # exactly one canonical
    # An original plus its amendment is the normal case and stays green.
    db_conn.execute(
        "UPDATE filing SET form = '10-K/A', form_family = 'annual_amendment', "
        "amends_accession = NULL WHERE accession_number = %s",
        (A2,),
    )
    assert core.check_one_canonical(db_conn, ctx_for(rid, tmp_path))[0].status == "green"


def test_c7_report_period_pointing_at_non_canonical_is_red(db_conn, tmp_path):
    mk_company(db_conn)
    rid = finish(db_conn)
    repo.upsert_filings(db_conn, [rec(A1, is_canonical=True)], rid)
    db_conn.execute(
        "INSERT INTO report_period VALUES ('AAPL','annual',2025,'FY', %s, %s, %s, 1)", (A1,) * 3
    )
    assert core.check_one_canonical(db_conn, ctx_for(rid, tmp_path))[0].status == "green"
    db_conn.execute("UPDATE filing SET is_canonical = false")
    assert core.check_one_canonical(db_conn, ctx_for(rid, tmp_path))[0].status == "red"


# ---------------------------------------------------------------- C8


def test_c8_labels(db_conn, tmp_path):
    mk_company(db_conn)
    rid = finish(db_conn)
    repo.upsert_filings(
        db_conn,
        [
            rec(A1),
            # pre-XBRL era unlabelled: ignored
            rec(
                "0000320193-05-000001",
                filing_date=date(2005, 11, 1),
                fiscal_year=None,
                fiscal_period=None,
                label_source="none",
                label_confidence=None,
            ),
            # off by one is plausible
            rec(
                "0000320193-25-000010",
                fiscal_year=2026,
                form="10-Q",
                form_family="quarterly",
                fiscal_period="Q1",
            ),
        ],
        rid,
    )
    assert core.check_labels(db_conn, ctx_for(rid, tmp_path))[0].status == "green"
    repo.upsert_filings(
        db_conn,
        [
            rec(
                "0000320193-25-000011",
                fiscal_year=None,
                fiscal_period=None,
                label_source="none",
                label_confidence=None,
            ),
            rec(
                "0000320193-25-000012",
                fiscal_year=2022,
                fiscal_period="Q2",
                form="10-Q",
                form_family="quarterly",
            ),
            # non-periodic family is not judged
            rec(
                "0000320193-25-000013",
                form="8-K",
                form_family="non_reliance_8k",
                fiscal_year=None,
                fiscal_period=None,
                label_source="none",
                label_confidence=None,
            ),
        ],
        rid,
    )
    r = core.check_labels(db_conn, ctx_for(rid, tmp_path))
    assert r[0].status == "red" and r[0].observed == "2"
    assert "000011" in r[0].message and "000012" in r[0].message and "000013" not in r[0].message


def test_c8_lists_at_most_ten(db_conn, tmp_path):
    mk_company(db_conn)
    rid = finish(db_conn)
    repo.upsert_filings(
        db_conn,
        [
            rec(
                f"0000320193-25-{i:06d}",
                fiscal_year=None,
                fiscal_period=None,
                label_source="none",
                label_confidence=None,
            )
            for i in range(1, 16)
        ],
        rid,
    )
    r = core.check_labels(db_conn, ctx_for(rid, tmp_path))[0]
    assert r.observed == "15" and "(+5 more)" in r.message


def test_c8_declared_label_disagreement_is_green_info_per_company(db_conn, tmp_path):
    mk_company(db_conn)
    mk_company(db_conn, "WMT")
    mk_company(db_conn, "TM")
    rid = finish(db_conn)
    wmt = [
        rec(
            f"0000104169-{14 + i}-{i:06d}",
            company_id="WMT",
            fiscal_year=2013 + i,
            declared_fiscal_year=2012 + i,
            declared_fiscal_period="FY",
            period_of_report=date(2014 + i, 1, 31),
            filing_date=date(2014 + i, 3, 30),
        )
        for i in range(1, 8)
    ]
    tm = rec(
        "0001094517-18-000001",
        company_id="TM",
        form="20-F",
        fiscal_year=2017,
        declared_fiscal_year=2016,
        declared_fiscal_period="FY",
        period_of_report=date(2018, 3, 31),
        filing_date=date(2018, 6, 27),
    )
    agree = rec(A1, declared_fiscal_year=2025, declared_fiscal_period="FY")
    undeclared = rec(A2, form="10-K405", fiscal_year=2024, filing_date=date(2024, 11, 1))
    repo.upsert_filings(db_conn, [*wmt, tm, agree, undeclared], rid)
    r = core.check_labels(db_conn, ctx_for(rid, tmp_path))
    assert sorted((x.status, x.company_id) for x in r) == [("green", "TM"), ("green", "WMT")]
    assert all("deliberate" in x.message for x in r)
    by = {x.company_id: x for x in r}
    assert by["WMT"].observed == "7" and "(+2 more)" in by["WMT"].message
    assert by["WMT"].message.count("0000104169-") == 5  # at most five examples
    assert by["TM"].observed == "1" and "declared FY2016, labelled FY2017" in by["TM"].message
    assert "AAPL" not in " ".join(x.message for x in r)
    # With a genuinely implausible label the red result comes first, the info results follow.
    repo.upsert_filings(
        db_conn,
        [rec("0000320193-25-000020", fiscal_year=2019, period_of_report=date(2025, 9, 27))],
        rid,
    )
    r = core.check_labels(db_conn, ctx_for(rid, tmp_path))
    assert [x.status for x in r] == ["red", "green", "green"]


# ---------------------------------------------------------------- C9


def test_c9_overdue(db_conn, tmp_path):
    mk_company(db_conn, "A")
    mk_company(db_conn, "B")
    rid = finish(db_conn)

    def exp(cid, status, fy):
        return ExpectedFiling(
            cid,
            "annual",
            fy,
            "FY",
            date(2025, 9, 27),
            None,
            "none",
            date(2025, 11, 26),
            date(2025, 12, 11),
            status,
            None,
            None,
        )

    repo.replace_expected(db_conn, "A", [exp("A", "pending", 2025), exp("A", "received", 2024)])
    assert core.check_expected_overdue(db_conn, ctx_for(rid, tmp_path))[0].status == "green"
    repo.replace_expected(db_conn, "A", [exp("A", "overdue", 2025), exp("A", "overdue", 2024)])
    repo.replace_expected(db_conn, "B", [exp("B", "overdue", 2025)])
    r = core.check_expected_overdue(db_conn, ctx_for(rid, tmp_path))
    assert [(x.status, x.company_id) for x in r] == [("red", "A"), ("red", "B")]


# ---------------------------------------------------------------- C10


def test_c10_amendments(db_conn, tmp_path):
    mk_company(db_conn)
    rid = finish(db_conn)
    repo.upsert_filings(
        db_conn,
        [
            rec(A1),
            rec(
                A2,
                form="10-K/A",
                form_family="annual_amendment",
                amends_accession=A1,
                amendment_scope="full",
                amendment_kind="restatement",
            ),
        ],
        rid,
    )
    assert core.check_amendments_resolved(db_conn, ctx_for(rid, tmp_path))[0].status == "green"
    repo.upsert_filings(
        db_conn,
        [
            rec(
                "0000320193-25-000003",
                form="10-K/A",
                form_family="annual_amendment",
                amendment_scope="full",
                amendment_kind="restatement",
            ),  # orphan
            rec(
                "0000320193-25-000004",
                form="10-K/A",
                form_family="annual_amendment",
                amends_accession=A1,
                amendment_scope="unknown",
                amendment_kind="restatement",
            ),
            rec(
                "0000320193-25-000005",
                form="10-Q/A",
                form_family="quarterly_amendment",
                amends_accession=A1,
                amendment_scope="partial",
                amendment_kind="unknown",
            ),
        ],
        rid,
    )
    r = core.check_amendments_resolved(db_conn, ctx_for(rid, tmp_path))
    assert r[0].status == "amber" and r[0].observed == "3"
    assert "orphan" in r[0].message and "scope unknown" in r[0].message
    assert "kind unknown" in r[0].message


def test_c10_does_not_assess_amendments_before_2009_06_15(db_conn, tmp_path):
    mk_company(db_conn)
    rid = finish(db_conn)
    old = dict(form="10-K/A", form_family="annual_amendment", amends_accession=None)
    repo.upsert_filings(
        db_conn,
        [
            rec("0000320193-09-000001", filing_date=date(2009, 6, 14), **old),
            rec("0000320193-95-000001", filing_date=date(1995, 3, 1), fiscal_year=1994, **old),
        ],
        rid,
    )
    assert core.check_amendments_resolved(db_conn, ctx_for(rid, tmp_path))[0].status == "green"
    new = rec("0000320193-09-000002", filing_date=date(2009, 6, 15), **old)
    repo.upsert_filings(db_conn, [new], rid)
    r = core.check_amendments_resolved(db_conn, ctx_for(rid, tmp_path))
    assert r[0].status == "amber" and r[0].observed == "1" and "000002" in r[0].message


# ---------------------------------------------------------------- C11


def golden(tmp_path, acc):
    p = tmp_path / "golden.yml"
    p.write_text(
        "- id: aapl-fy2025\n  company_id: AAPL\n  report_kind: annual\n  fiscal_year: 2025\n"
        f"  fiscal_period: FY\n  expected_canonical_accession: {acc}\n",
        encoding="utf-8",
    )
    return p


def test_c11_golden(db_conn, tmp_path):
    mk_company(db_conn)
    rid = finish(db_conn)
    repo.upsert_filings(db_conn, [rec(A1), rec(A2, form="10-K405")], rid)
    ctx = ctx_for(rid, tmp_path, golden_queries_path=golden(tmp_path, A1), tickers_in_csv=["AAPL"])
    # period missing entirely: red
    r = core.check_golden_queries(db_conn, ctx)
    assert r[0].status == "red" and "no report period" in r[0].message
    repo.write_canonical(db_conn, "AAPL", [("annual", 2025, "FY", CanonicalChoice(A1, A2, A1, 2))])
    assert core.check_golden_queries(db_conn, ctx)[0].status == "green"
    repo.write_canonical(db_conn, "AAPL", [("annual", 2025, "FY", CanonicalChoice(A2, A2, A1, 2))])
    r = core.check_golden_queries(db_conn, ctx)
    assert r[0].status == "red" and A2 in r[0].message and r[0].expected == A1


def test_c11_evaluates_only_queries_for_companies_in_the_csv(db_conn, tmp_path):
    mk_company(db_conn)
    rid = finish(db_conn)
    path = golden(tmp_path, A1)  # AAPL: no report period, so red when evaluated
    ctx = ctx_for(rid, tmp_path, golden_queries_path=path, tickers_in_csv=["MSFT"])
    r = core.check_golden_queries(db_conn, ctx)
    assert [x.status for x in r] == ["green"] and "0 golden queries" in r[0].message
    ctx = ctx_for(rid, tmp_path, golden_queries_path=path, tickers_in_csv=["aapl"])
    assert core.check_golden_queries(db_conn, ctx)[0].status == "red"


def test_c11_default_is_the_packaged_file_and_env_overrides_it(db_conn, tmp_path, monkeypatch):
    rid = finish(db_conn)
    monkeypatch.delenv("GOLDEN_QUERIES", raising=False)
    ctx = ctx_for(rid, tmp_path, golden_queries_path=None, tickers_in_csv=["AAPL"])
    packaged = core.load_golden_queries()
    assert {"aapl-fy2009-10ka", "aapl-fy2025-10k"} <= {q["id"] for q in packaged}
    r = core.check_golden_queries(db_conn, ctx)  # empty database: every AAPL query is red
    assert statuses(r) == {"red"} and all("no report period" in x.message for x in r)
    monkeypatch.setenv("GOLDEN_QUERIES", str(golden(tmp_path, A1)))
    assert [q["id"] for q in core.load_golden_queries()] == ["aapl-fy2025"]
    assert len(core.check_golden_queries(db_conn, ctx)) == 1


def test_c11_missing_or_broken_file_is_amber(db_conn, tmp_path):
    rid = finish(db_conn)
    assert core.check_golden_queries(db_conn, ctx_for(rid, tmp_path))[0].status == "amber"
    (tmp_path / "golden.yml").write_text("a: [unclosed", encoding="utf-8")
    assert core.check_golden_queries(db_conn, ctx_for(rid, tmp_path))[0].status == "amber"


# ---------------------------------------------------------------- C12


def test_c12_unknown_forms_from_sync_input(db_conn, tmp_path):
    rid = finish(db_conn)
    other = finish(db_conn)
    ctx = ctx_for(rid, tmp_path)
    assert core.check_unknown_periodic_form(db_conn, ctx)[0].status == "green"
    repo.write_check_results(
        db_conn,
        other,
        [CheckResult("C12-input", "Unknown periodic form input", "core", "amber", "10-KT/A")],
    )
    assert core.check_unknown_periodic_form(db_conn, ctx)[0].status == "green"  # other run
    repo.write_check_results(
        db_conn,
        rid,
        [
            CheckResult("C12-input", "Unknown periodic form input", "core", "amber", "10-K405T"),
            CheckResult("C12-input", "Unknown periodic form input", "core", "amber", "10-K405T"),
        ],
    )
    r = core.check_unknown_periodic_form(db_conn, ctx)
    assert [x.status for x in r] == ["amber"] and r[0].message.count("10-K405T") == 1


def test_results_can_be_persisted(db_conn, tmp_path):
    rid = finish(db_conn)
    (tmp_path / "golden.yml").write_text("[]")
    results = core.run_core_checks(db_conn, ctx_for(rid, tmp_path))
    repo.write_check_results(db_conn, rid, results)
    assert db_conn.execute("SELECT count(*) FROM check_result WHERE run_id=%s", (rid,)).fetchone()[
        0
    ] == len(results)
    assert Path(tmp_path / "golden.yml").exists()


# ---------------------------------------------------------------- X1


def test_x1_lists_rows_newly_flagged_stale_by_the_judged_run(db_conn, tmp_path):
    mk_company(db_conn)
    run1 = finish(db_conn)
    repo.upsert_filings(db_conn, [rec(A1), rec(A2, form="10-K405")], run1)
    r = core.check_stale_rows(db_conn, ctx_for(run1, tmp_path))
    assert [(x.check_id, x.tier, x.status) for x in r] == [("X1", "extended", "green")]
    run2 = finish(db_conn)
    assert repo.mark_stale(db_conn, cik=320193, seen_accessions={A1}, run_id=run2) == 1
    r = core.check_stale_rows(db_conn, ctx_for(run2, tmp_path))
    assert (r[0].status, r[0].tier, r[0].observed) == ("amber", "extended", "1")
    assert A2 in r[0].message and A1 not in r[0].message
    # the next run does not flag it again: not "newly" stale any more
    run3 = finish(db_conn)
    assert repo.mark_stale(db_conn, cik=320193, seen_accessions={A1}, run_id=run3) == 0
    assert core.check_stale_rows(db_conn, ctx_for(run3, tmp_path))[0].status == "green"
    # a standalone check run judges the latest sync run
    chk = repo.start_run(db_conn, "check")
    assert core.check_stale_rows(db_conn, ctx_for(chk, tmp_path))[0].status == "green"
    assert core.check_stale_rows(db_conn, ctx_for(chk, tmp_path))[0].tier == "extended"
    # seeing the filing again clears the flag
    repo.upsert_filings(db_conn, [rec(A2, form="10-K405")], finish(db_conn))
    assert db_conn.execute(
        "SELECT is_stale, stale_run_id FROM filing WHERE accession_number = %s", (A2,)
    ).fetchone() == (False, None)
