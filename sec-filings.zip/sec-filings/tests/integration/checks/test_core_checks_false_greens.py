"""Realistic situations in which the morning check used to show green or amber wrongly."""

from __future__ import annotations

from datetime import UTC, date, datetime, timedelta

import pytest
from test_core_checks import NOW, TODAY, ctx_for, finish, mk_company, reconcile_days

from sec_filings.checks import core
from sec_filings.db import repo

pytestmark = pytest.mark.db


# ---------------------------------------------------------------- 1. stale run


def test_c2_is_red_when_the_judged_run_started_over_26_hours_ago(db_conn, tmp_path):
    rid = finish(db_conn, started=NOW - timedelta(hours=27))
    chk = repo.start_run(db_conn, "check")
    r = core.check_run_status(db_conn, ctx_for(chk, tmp_path))
    assert [x.status for x in r] == ["red"] and "last run is 27 hours old" in r[0].message
    assert rid
    # 25 hours is a normal daily cadence
    db_conn.execute(
        "UPDATE run SET started_at = %s WHERE run_id = %s", (NOW - timedelta(hours=25), rid)
    )
    assert core.check_run_status(db_conn, ctx_for(chk, tmp_path))[0].status == "green"


# ---------------------------------------------------------------- 2. narrow runs


def test_a_successful_single_ticker_backfill_does_not_hide_a_failed_morning_sync(db_conn, tmp_path):
    # sync at 06:05 fails, `backfill -t AAPL` succeeds at 10:00, check at 10:05
    sync = finish(
        db_conn,
        status="failed",
        error="boom",
        at=datetime(2026, 11, 10, 6, 5, tzinfo=UTC),
        started=datetime(2026, 11, 10, 6, 5, tzinfo=UTC),
    )
    finish(
        db_conn,
        mode="backfill",
        scope="subset",
        at=datetime(2026, 11, 10, 10, 0, tzinfo=UTC),
        started=datetime(2026, 11, 10, 9, 58, tzinfo=UTC),
    )
    now = datetime(2026, 11, 10, 10, 5, tzinfo=UTC)
    assert core.heartbeat_check(db_conn, now=now).status == "red"
    chk = repo.start_run(db_conn, "check")
    r = core.check_run_status(db_conn, ctx_for(chk, tmp_path, now=now))
    assert r[0].status == "red" and str(sync) in r[0].message and "boom" in r[0].message
    # a whole-job success afterwards clears both
    finish(
        db_conn,
        at=datetime(2026, 11, 10, 10, 1, tzinfo=UTC),
        started=datetime(2026, 11, 10, 10, 0, tzinfo=UTC),
    )
    assert core.heartbeat_check(db_conn, now=now).status == "green"
    assert core.check_run_status(db_conn, ctx_for(chk, tmp_path, now=now))[0].status == "green"


def test_a_subset_run_that_judges_itself_still_looks_at_the_whole_job(db_conn, tmp_path):
    finish(db_conn, status="failed", error="boom", started=NOW - timedelta(hours=1))
    sub = finish(db_conn, mode="backfill", scope="subset", started=NOW)
    r = core.check_run_status(db_conn, ctx_for(sub, tmp_path))
    assert r[0].status == "red" and "boom" in r[0].message


# ---------------------------------------------------------------- 6. false 403


def test_c2_403_message_uses_only_the_flag(db_conn, tmp_path):
    mentions = finish(db_conn, error="company 4031 returned HTTP 4030 (not a denial)")
    assert core.check_run_status(db_conn, ctx_for(mentions, tmp_path))[0].status == "green"
    denied = finish(db_conn, status="failed", error="SecAccessDenied: stop", sec_denied=True)
    r = core.check_run_status(db_conn, ctx_for(denied, tmp_path))
    assert [x.status for x in r] == ["red"] and "403" in r[0].message


# ---------------------------------------------------------------- 3. golden query entries


def test_c11_entry_with_missing_keys_is_amber_for_that_entry_not_a_crash(db_conn, tmp_path):
    mk_company(db_conn)
    rid = finish(db_conn)
    path = tmp_path / "golden.yml"
    path.write_text(
        "- id: broken\n  company_id: AAPL\n  report_kind: annual\n"
        "- just a string\n"
        "- id: no-company\n  report_kind: annual\n"
        "- id: other\n  company_id: MSFT\n  report_kind: annual\n",
        encoding="utf-8",
    )
    ctx = ctx_for(rid, tmp_path, golden_queries_path=path, tickers_in_csv=["AAPL"])
    r = core.check_golden_queries(db_conn, ctx)
    assert [x.status for x in r] == ["amber", "amber", "amber"]
    assert "broken" in r[0].message and "fiscal_year" in r[0].message
    assert "not a mapping" in r[1].message and "no-company" in r[2].message
    # an unreadable value is amber too, and does not poison the caller's transaction
    path.write_text(
        "- id: bad\n  company_id: AAPL\n  report_kind: annual\n  fiscal_year: abc\n"
        "  fiscal_period: FY\n  expected_canonical_accession: X\n",
        encoding="utf-8",
    )
    r = core.check_golden_queries(db_conn, ctx)
    assert [x.status for x in r] == ["amber"]
    assert db_conn.execute("SELECT 1").fetchone() == (1,)


# ---------------------------------------------------------------- 5. helper


def test_unreconciled_business_days_window_starts_at_the_first_recorded_day(db_conn):
    rid = finish(db_conn)
    assert core.unreconciled_business_days(db_conn, TODAY) == []  # nothing recorded yet
    reconcile_days(db_conn, rid, date(2026, 11, 9), date(2026, 11, 9))
    assert core.unreconciled_business_days(db_conn, TODAY) == []  # days before install: no gap
    assert core.unreconciled_business_days(db_conn, date(2026, 11, 12)) == [date(2026, 11, 10)]
