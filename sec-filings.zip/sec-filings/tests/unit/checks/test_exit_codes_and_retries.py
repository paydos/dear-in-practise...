"""Unit-level fixes of the second review: exit codes, Retry-After dates, pre-2009 scope, CLI."""

from __future__ import annotations

import time
from datetime import date
from email.utils import formatdate

import httpx
import pytest
from typer.testing import CliRunner

from sec_filings import cli
from sec_filings.checks.report import exit_code
from sec_filings.domain.amendments import decide_scope
from sec_filings.edgar.client import EdgarClient
from sec_filings.models import CheckResult, ScopeSignals

URL = "https://data.sec.gov/submissions/CIK0000320193.json"


def result(status: str) -> CheckResult:
    return CheckResult("C2", "n", "core", status, "m")  # type: ignore[arg-type]


def test_exit_code_four_means_skipped_and_the_others_are_unchanged():
    assert exit_code([], False, run_skipped=True) == 4
    assert exit_code([result("red")], True, run_skipped=True) == 3  # a failed run wins
    assert [exit_code([result(s)], False) for s in ("green", "amber", "red")] == [0, 1, 2]
    assert exit_code([result("green")], True) == 3


# ---------------------------------------------------------------- 12. Retry-After as a date


def _client_with_retry_after(value: str):
    sleeps: list[float] = []
    calls = {"n": 0}

    def handler(req: httpx.Request) -> httpx.Response:
        calls["n"] += 1
        if calls["n"] == 1:
            return httpx.Response(429, headers={"Retry-After": value})
        return httpx.Response(200, content=b"{}")

    client = EdgarClient(
        "unit-test contact@example.com",
        transport=httpx.MockTransport(handler),
        sleep=sleeps.append,
        clock=lambda: 0.0,
    )
    return client, sleeps


def test_retry_after_as_an_http_date_is_honoured_and_capped():
    client, sleeps = _client_with_retry_after(formatdate(time.time() + 40, usegmt=True))
    assert client.get(URL).status == 200
    assert 35 <= max(sleeps) <= 41  # waited until that date, not the 0.5 s default backoff
    client, sleeps = _client_with_retry_after(formatdate(time.time() + 3600, usegmt=True))
    assert client.get(URL).status == 200
    assert max(sleeps) == 60.0  # capped
    client, sleeps = _client_with_retry_after(formatdate(time.time() - 3600, usegmt=True))
    client.get(URL)
    assert max(sleeps) < 1.0  # a date in the past means no extra wait
    client, sleeps = _client_with_retry_after("not a date or a number")
    client.get(URL)
    assert max(sleeps) < 1.0
    client, sleeps = _client_with_retry_after("20")
    client.get(URL)
    assert max(sleeps) == 20.0  # delta-seconds still work


# ---------------------------------------------------------------- 13. pre-2009 amendments


def test_amendments_before_2009_06_15_have_unknown_scope_even_when_small():
    small = ScopeSignals(None, None, None, None, primary_doc_bytes=40_000)
    assert decide_scope(small) == "partial"  # undated callers keep the old rule
    assert decide_scope(small, filing_date=date(2009, 6, 14)) == "unknown"
    assert decide_scope(small, filing_date=date(1999, 3, 1)) == "unknown"
    assert decide_scope(small, filing_date=date(2009, 6, 15)) == "partial"
    only_exhibits = ScopeSignals(None, None, None, None, partial_only_text=True)
    assert decide_scope(only_exhibits, filing_date=date(2005, 1, 1)) == "unknown"
    big = ScopeSignals(True, None, 1.0, True)
    assert decide_scope(big, filing_date=date(2008, 1, 1)) == "unknown"
    assert decide_scope(big, filing_date=date(2010, 1, 1)) == "full"


# ---------------------------------------------------------------- 3. CLI exit codes


def test_an_unexpected_exception_exits_3_never_1(monkeypatch):
    monkeypatch.setenv("DATABASE_URL", "postgresql://unused/unused")

    def boom(*a, **kw):
        raise KeyError("surprise")

    monkeypatch.setattr(cli.flows, "check", boom)
    res = CliRunner().invoke(cli.app, ["check"])
    assert res.exit_code == 3
    assert "KeyError" in res.output


def test_a_skipped_run_exits_4(monkeypatch):
    from datetime import UTC, datetime
    from uuid import uuid4

    from sec_filings.models import RunResult

    monkeypatch.setenv("DATABASE_URL", "postgresql://unused/unused")
    now = datetime(2026, 11, 10, 6, 0, tzinfo=UTC)
    skipped = RunResult(uuid4(), "sync", "skipped_locked", now, now, 0, 0, 0, 0, [], [], "locked")
    monkeypatch.setattr(cli.flows, "sync", lambda *a, **kw: skipped)
    res = CliRunner().invoke(cli.app, ["sync"])
    assert res.exit_code == 4 and "skipped" in res.output


@pytest.mark.parametrize(
    "bad",
    [
        ["ack", "C2", "2026-11-06", "--reason", "x"],
        ["ack", "C3", "yesterday", "--reason", "x"],
        ["ack", "C3", "2026-11-06", "--reason", "  "],
    ],
)
def test_ack_rejects_bad_input_with_exit_3(monkeypatch, bad):
    monkeypatch.setenv("DATABASE_URL", "postgresql://unused/unused")
    assert CliRunner().invoke(cli.app, bad).exit_code == 3
