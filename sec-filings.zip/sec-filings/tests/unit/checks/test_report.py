from __future__ import annotations

from datetime import UTC, date, datetime
from unittest.mock import patch
from uuid import uuid4

import httpx

from sec_filings.checks.report import exit_code, ping_heartbeat, render_markdown
from sec_filings.models import CheckResult, RunResult


def r(cid: str, status: str, msg: str = "m", company: str | None = None) -> CheckResult:
    return CheckResult(cid, f"Name {cid}", "core", status, msg, company_id=company)  # type: ignore[arg-type]


def run(status: str = "success") -> RunResult:
    now = datetime(2026, 11, 10, 6, 0, tzinfo=UTC)
    return RunResult(uuid4(), "sync", status, now, now, 10, 1, 2, 3, ["AAPL"], [], None)


def test_exit_codes():
    assert exit_code([r("C2", "green")], run_failed=False) == 0
    assert exit_code([r("C2", "green"), r("C3", "amber")], run_failed=False) == 1
    assert exit_code([r("C2", "amber"), r("C3", "red")], run_failed=False) == 2
    assert exit_code([r("C2", "green")], run_failed=True) == 3
    assert exit_code([r("C2", "red")], run_failed=True) == 3
    assert exit_code([], run_failed=False) == 0


def test_markdown_green():
    md = render_markdown([r("C2", "green"), r("C3", "green")], run(), date(2026, 11, 10))
    lines = md.splitlines()
    assert lines[0] == "# Morning check 2026-11-10: GREEN"
    assert "All 2 checks passed" in lines[2]
    assert "## Red" not in md and "## Amber" not in md
    assert "| C2 | Name C2 | green | m |" in md


def test_markdown_order_red_then_amber_then_table():
    results = [
        r("C2", "green"),
        r("C3", "amber", "slow"),
        r("C9", "red", "overdue\nfor X | y", company="X"),
    ]
    md = render_markdown(results, run(), date(2026, 11, 10))
    assert md.splitlines()[0] == "# Morning check 2026-11-10: RED"
    assert md.index("## Red") < md.index("## Amber") < md.index("## All checks")
    assert "C9 Name C9 [X]: overdue for X / y" in md
    # table keeps one row per result and no raw newlines inside a row
    table_rows = [
        ln for ln in md.splitlines() if ln.startswith("| C") and ln[2] == "C" and ln[3].isdigit()
    ]
    assert len(table_rows) == 3


def test_markdown_amber_only_and_failed_run():
    md = render_markdown([r("C3", "amber")], None, date(2026, 11, 10))
    assert md.startswith("# Morning check 2026-11-10: AMBER")
    md = render_markdown([r("C2", "green")], run("failed"), date(2026, 11, 10))
    assert md.startswith("# Morning check 2026-11-10: RED")


def test_markdown_truncates_long_messages_in_table():
    md = render_markdown([r("C8", "red", "x" * 500)], None, date(2026, 11, 10))
    row = next(ln for ln in md.splitlines() if ln.startswith("| C8"))
    assert len(row) < 200 and row.endswith("... |")


def test_ping_heartbeat_true_false_and_never_raises():
    ok = httpx.MockTransport(lambda req: httpx.Response(200))
    bad = httpx.MockTransport(lambda req: httpx.Response(500))

    def via(transport):
        def _get(url, **kw):
            with httpx.Client(transport=transport) as c:
                return c.get(url, **kw)

        return _get

    with patch("sec_filings.checks.report.httpx.get", via(ok)):
        assert ping_heartbeat("https://hc.example/ping") is True
    with patch("sec_filings.checks.report.httpx.get", via(bad)):
        assert ping_heartbeat("https://hc.example/ping") is False

    def boom(req):
        raise httpx.ConnectError("down")

    with patch("sec_filings.checks.report.httpx.get", via(httpx.MockTransport(boom))):
        assert ping_heartbeat("https://hc.example/ping") is False
    assert ping_heartbeat("not a url") is False


def test_ping_heartbeat_failed_run_pings_the_fail_url():
    """healthchecks.io convention: success pings the URL, partial or failed pings URL/fail."""
    seen: list[str] = []

    def record(url, **kw):
        seen.append(url)
        return httpx.Response(200, request=httpx.Request("GET", url))

    with patch("sec_filings.checks.report.httpx.get", record):
        assert ping_heartbeat("https://hc.example/ping/abc") is True
        assert ping_heartbeat("https://hc.example/ping/abc", failed=True) is True
        assert ping_heartbeat("https://hc.example/ping/abc/", failed=True) is True
    assert seen == [
        "https://hc.example/ping/abc",
        "https://hc.example/ping/abc/fail",
        "https://hc.example/ping/abc/fail",
    ]
