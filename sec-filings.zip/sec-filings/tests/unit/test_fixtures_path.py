from pathlib import PurePosixPath

from sec_filings.edgar.fixtures import url_to_fixture_path


def test_submissions():
    p = url_to_fixture_path("https://data.sec.gov/submissions/CIK0000320193.json")
    assert p == PurePosixPath("data.sec.gov/submissions/CIK0000320193.json")


def test_archive_index():
    url = "https://www.sec.gov/Archives/edgar/data/320193/000119312510012091/index.json"
    assert url_to_fixture_path(url) == PurePosixPath(
        "www.sec.gov/Archives/edgar/data/320193/000119312510012091/index.json"
    )


def test_trailing_segment_with_dashes():
    url = "https://www.sec.gov/Archives/edgar/data/2115436/0002115436-26-000020.txt"
    assert str(url_to_fixture_path(url)) == (
        "www.sec.gov/Archives/edgar/data/2115436/0002115436-26-000020.txt"
    )
