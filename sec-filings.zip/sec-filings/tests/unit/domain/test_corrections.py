from __future__ import annotations

from datetime import date

from sec_filings.domain.corrections import build_correction_events

D = date


def build(filings, scopes=None, pre=None):
    return build_correction_events(
        company_id="X", filings=filings, amendment_scopes=scopes or {}, pre_merger_until=pre
    )


def row(filing, label, acc, form, fam, filed, cov=None):
    return (filing(acc, form, filed), fam, label(None, None, "none"), cov)


def test_non_reliance_links_full_amendment(filing, label):
    fl = [
        row(filing, label, "8k", "8-K", "non_reliance_8k", D(2021, 3, 1)),
        row(filing, label, "a-partial", "10-K/A", "annual_amendment", D(2021, 4, 1)),
        row(
            filing, label, "a-full", "10-K/A", "annual_amendment", D(2022, 2, 28)
        ),  # 363 days (Plug)
        row(filing, label, "a-late", "10-K/A", "annual_amendment", D(2023, 6, 1)),  # > 730 days
        row(filing, label, "a-before", "10-K/A", "annual_amendment", D(2021, 2, 1)),
        row(filing, label, "k", "10-K", "annual", D(2022, 3, 1)),
    ]
    scopes = {"a-partial": "partial", "a-full": "full", "a-late": "full", "a-before": "full"}
    [ev] = build(fl, scopes)
    assert (ev.event_type, ev.source_accession, ev.event_date) == (
        "non_reliance_8k",
        "8k",
        D(2021, 3, 1),
    )
    assert ev.corrected_in_accessions == ("k",)  # amendment is 363 days later: not linked
    assert ev.link_confidence == "medium"
    assert ev.pre_merger_shell is False


def test_non_reliance_falls_back_to_next_original(filing, label):
    fl = [
        row(filing, label, "8k", "8-K", "non_reliance_8k", D(2021, 3, 1)),
        row(filing, label, "q", "10-Q", "quarterly", D(2021, 5, 1)),
        row(filing, label, "k2", "10-K", "annual", D(2022, 3, 1)),
        row(filing, label, "k1", "10-K", "annual", D(2021, 3, 15)),
        row(filing, label, "a", "10-K/A", "annual_amendment", D(2021, 4, 1)),
    ]
    [ev] = build(fl, {"a": "unknown"})
    assert ev.corrected_in_accessions == ("k1",)  # earliest original after the event
    assert ev.link_confidence == "medium"


def test_non_reliance_unlinked(filing, label):
    [ev] = build([row(filing, label, "8k", "8-K", "non_reliance_8k", D(2021, 3, 1))])
    assert ev.corrected_in_accessions == ()
    assert ev.link_confidence == "none"


def test_pre_merger_flag(filing, label):
    fl = [
        row(filing, label, "8k", "8-K", "non_reliance_8k", D(2021, 5, 1)),
        row(filing, label, "8k2", "8-K", "non_reliance_8k", D(2021, 8, 1)),
    ]
    evs = build(fl, pre=D(2021, 7, 23))
    assert [(e.source_accession, e.pre_merger_shell) for e in evs] == [("8k", True), ("8k2", False)]


def test_cover_error_flag(filing, label, cover):
    fl = [
        row(filing, label, "k", "10-K", "annual", D(2024, 2, 1), cover(error_flag=True)),
        row(filing, label, "q", "10-Q", "quarterly", D(2024, 5, 1), cover(error_flag=False)),
        row(
            filing, label, "a", "10-K/A", "annual_amendment", D(2024, 6, 1), cover(error_flag=True)
        ),
        row(filing, label, "n", "10-Q", "quarterly", D(2024, 8, 1), None),
        row(
            filing,
            label,
            "6",
            "6-K",
            "foreign_current_report",
            D(2024, 9, 1),
            cover(error_flag=True),
        ),
    ]
    evs = build(fl)
    assert [
        (e.event_type, e.source_accession, e.corrected_in_accessions, e.link_confidence)
        for e in evs
    ] == [
        ("cover_error_flag", "k", ("k",), "high"),
        ("cover_error_flag", "a", ("a",), "high"),
    ]


def test_no_events(filing, label):
    assert build([]) == []
    assert build([row(filing, label, "k", "10-K", "annual", D(2024, 2, 1))]) == []


def test_plug_case(filing, label):
    fl = [
        row(filing, label, "8k", "8-K", "non_reliance_8k", D(2021, 3, 16)),
        row(filing, label, "0001558370-21-007147", "10-K", "annual", D(2021, 5, 14)),
        row(filing, label, "0001558370-22-003577", "10-K/A", "annual_amendment", D(2022, 3, 14)),
    ]
    [ev] = build(fl, {"0001558370-22-003577": "full"})
    assert ev.corrected_in_accessions == ("0001558370-21-007147",)
    assert ev.link_confidence == "medium"


def test_lucid_shell_case(filing, label):
    fl = [
        row(filing, label, "8k", "8-K", "non_reliance_8k", D(2021, 5, 14)),
        row(filing, label, "ka", "10-K/A", "annual_amendment", D(2021, 5, 14)),
    ]
    [ev] = build(fl, {"ka": "full"}, pre=D(2021, 7, 23))
    assert ev.corrected_in_accessions == ("ka",)
    assert (ev.link_confidence, ev.pre_merger_shell) == ("high", True)


def test_amendment_and_original_both_linked(filing, label):
    fl = [
        row(filing, label, "8k", "8-K", "non_reliance_8k", D(2021, 3, 1)),
        row(filing, label, "a", "10-K/A", "annual_amendment", D(2021, 6, 29)),  # day 120
        row(filing, label, "a2", "10-K/A", "annual_amendment", D(2021, 6, 30)),  # day 121
        row(filing, label, "k", "10-K", "annual", D(2021, 4, 1)),
        row(filing, label, "far", "10-Q", "quarterly", D(2023, 6, 1)),
    ]
    [ev] = build(fl, {"a": "full", "a2": "full"})
    assert ev.corrected_in_accessions == ("a", "k")
    assert ev.link_confidence == "high"


def test_original_beyond_730_days_not_linked(filing, label):
    fl = [
        row(filing, label, "8k", "8-K", "non_reliance_8k", D(2021, 3, 1)),
        row(filing, label, "k", "10-K", "annual", D(2023, 3, 2)),
    ]
    [ev] = build(fl)
    assert (ev.corrected_in_accessions, ev.link_confidence) == ((), "none")


def test_jpm_style_next_original_is_a_10q(filing, label):
    fl = [
        row(filing, label, "8k", "8-K", "non_reliance_8k", D(2012, 7, 13)),
        row(filing, label, "q", "10-Q", "quarterly", D(2012, 8, 9)),
        row(filing, label, "k", "10-K", "annual", D(2013, 2, 28)),
    ]
    [ev] = build(fl)
    assert (ev.corrected_in_accessions, ev.link_confidence) == (("q",), "medium")
