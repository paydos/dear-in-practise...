from __future__ import annotations

from datetime import UTC, date, datetime

import pytest

from sec_filings.domain.amendments import (
    decide_kind,
    decide_scope,
    description_says_full,
    link_amendment,
    partial_only_text,
    select_canonical,
)
from sec_filings.models import Label, ScopeSignals, Version

D = date


@pytest.mark.parametrize(
    ("text", "expected"),
    [
        ("Restated financial statements", True),
        ("This amendment restates Item 8", True),
        ("Complete 10-K/A", True),
        ("amended in its entirety", True),
        ("Re-present Items 6 and 8", True),
        ("Full document", True),
        ("Part III information", False),
        ("Filed to add Exhibit 10.1", False),
        ("Corrects the signature page", False),
        ("Cover page fix", False),
        ("Part III and restated financial statements", True),  # full words win
        ("Something unrelated", None),
        ("", None),
        ("   ", None),
        (None, None),
    ],
)
def test_description_says_full(text, expected):
    assert description_says_full(text) is expected


def sig(f=None, d=None, s=None, t=None):
    return ScopeSignals(f, d, s, t)


@pytest.mark.parametrize(
    ("signals", "expected"),
    [
        (sig(True, True), "full"),
        (sig(True, None, 0.6), "full"),
        (sig(None, None, 0.5, True), "full"),
        (sig(True), "unknown"),
        (sig(None, True, 0.4), "unknown"),
        (sig(False, None, 0.1), "partial"),
        (sig(False, None, 0.25), "unknown"),
        (sig(False, None, None), "unknown"),
        (sig(None, None, 0.1), "unknown"),
        (sig(False, True, 0.9), "full"),  # two positives beat the partial test
        (sig(), "unknown"),
    ],
)
def test_decide_scope(signals, expected):
    assert decide_scope(signals) == expected


@pytest.mark.parametrize(
    ("kwargs", "kind", "needle"),
    [
        (
            dict(
                scope="full",
                linked_to_correction_event=True,
                cover_error_flag=None,
                manual_kind=None,
            ),
            "restatement",
            "correction event",
        ),
        (
            dict(
                scope="full",
                linked_to_correction_event=False,
                cover_error_flag=True,
                manual_kind=None,
            ),
            "restatement",
            "cover",
        ),
        (
            dict(
                scope="full",
                linked_to_correction_event=False,
                cover_error_flag=False,
                manual_kind=None,
            ),
            "unknown",
            "not claimed",
        ),
        (
            dict(
                scope="partial",
                linked_to_correction_event=True,
                cover_error_flag=True,
                manual_kind=None,
            ),
            "administrative",
            "partial",
        ),
        (
            dict(
                scope="unknown",
                linked_to_correction_event=True,
                cover_error_flag=True,
                manual_kind=None,
            ),
            "unknown",
            "unknown",
        ),
        (
            dict(
                scope="partial",
                linked_to_correction_event=False,
                cover_error_flag=None,
                manual_kind="accounting_change",
            ),
            "accounting_change",
            "manual:",
        ),
    ],
)
def test_decide_kind(kwargs, kind, needle):
    got_kind, evidence = decide_kind(**kwargs)
    assert got_kind == kind
    assert needle in evidence


def test_link_prefers_same_period(filing, label):
    o1 = filing("o1", filed=D(2020, 2, 1), period=D(2019, 12, 31))
    o2 = filing("o2", filed=D(2020, 3, 1), period=D(2019, 12, 31))  # later original, same period
    o3 = filing("o3", filed=D(2020, 4, 1), period=D(2019, 12, 31))  # after the amendment
    other = filing("o4", filed=D(2020, 3, 15), period=D(2018, 12, 31))
    amend = filing("a", "10-K/A", filed=D(2020, 3, 20), period=D(2019, 12, 31))
    lab = label(2019, "FY")
    got = link_amendment(amend, lab, [(o1, lab), (o2, lab), (o3, lab), (other, label(2018, "FY"))])
    assert got == "o2"


def test_link_falls_back_to_fiscal_label(filing, label):
    o = filing("o", filed=D(2020, 2, 1), period=D(2019, 12, 31))
    far = filing("far", filed=D(2020, 3, 1), period=D(2018, 12, 31))
    amend = filing("a", "10-K/A", filed=D(2020, 3, 20), period=D(2015, 2, 27))  # wrong raw period
    got = link_amendment(
        amend, label(2019, "FY"), [(o, label(2019, "FY")), (far, label(2018, "FY"))]
    )
    assert got == "o"


def test_link_falls_back_to_nearest_within_400_days(filing, label):
    old = filing("old", filed=D(2018, 1, 1), period=D(2017, 12, 31))
    near = filing("near", filed=D(2019, 6, 1), period=D(2018, 12, 31))
    amend = filing("a", "10-K/A", filed=D(2020, 3, 20), period=None)
    got = link_amendment(
        amend, label(None, None, "none"), [(old, label(2017, "FY")), (near, label(2018, "FY"))]
    )
    assert got == "near"


def test_link_none_when_no_original_within_400_days(filing, label):
    old = filing("old", filed=D(2018, 1, 1), period=D(2017, 12, 31))
    amend = filing("a", "10-K/A", filed=D(2020, 3, 20), period=None)
    assert link_amendment(amend, label(None, None, "none"), [(old, label(2017, "FY"))]) is None


def test_link_ignores_later_originals_and_empty(filing, label):
    later = filing("later", filed=D(2020, 5, 1), period=D(2019, 12, 31))
    amend = filing("a", "10-K/A", filed=D(2020, 3, 20), period=D(2019, 12, 31))
    assert link_amendment(amend, label(2019, "FY"), [(later, label(2019, "FY"))]) is None
    assert link_amendment(amend, label(2019, "FY"), []) is None


def v(acc, filed, amend=False, scope=None, accepted=None):
    return Version(acc, filed, accepted, amend, scope)


def test_canonical_latest_full_amendment_wins():
    c = select_canonical(
        [
            v("o", D(2020, 2, 1)),
            v("a1", D(2020, 3, 1), True, "partial"),
            v("a2", D(2020, 6, 1), True, "full"),
            v("a3", D(2020, 9, 1), True, "partial"),
        ]
    )
    assert (
        c.canonical_accession,
        c.latest_filed_accession,
        c.original_accession,
        c.version_count,
    ) == ("a2", "a3", "o", 4)


def test_canonical_stays_original_when_amendment_unknown_or_partial():
    c = select_canonical([v("o", D(2020, 2, 1)), v("a", D(2020, 3, 1), True, "unknown")])
    assert c.canonical_accession == "o"
    assert c.latest_filed_accession == "a"


def test_canonical_tie_breaks():
    t1 = datetime(2020, 3, 1, 10, tzinfo=UTC)
    t2 = datetime(2020, 3, 1, 15, tzinfo=UTC)
    c = select_canonical(
        [
            v("o", D(2020, 2, 1)),
            v("a1", D(2020, 3, 1), True, "full", t2),
            v("a2", D(2020, 3, 1), True, "full", t1),
        ]
    )
    assert c.canonical_accession == "a1"
    c = select_canonical(
        [
            v("o", D(2020, 2, 1)),
            v("b", D(2020, 3, 1), True, "full"),
            v("a", D(2020, 3, 1), True, "full"),
        ]
    )
    assert c.canonical_accession == "b"  # accession is the last resort
    c = select_canonical(
        [v("o", D(2020, 3, 1), False, None, t1), v("a", D(2020, 3, 1), True, "full", None)]
    )
    assert c.canonical_accession == "o"  # missing acceptance time sorts first


def test_canonical_without_original_and_single():
    c = select_canonical([v("a", D(2020, 3, 1), True, "partial")])
    assert (c.canonical_accession, c.original_accession, c.latest_filed_accession) == (
        None,
        None,
        "a",
    )
    c = select_canonical([v("o", D(2020, 3, 1))])
    assert (c.canonical_accession, c.version_count) == ("o", 1)


def test_canonical_empty_raises():
    with pytest.raises(ValueError):
        select_canonical([])


def test_label_unused_import_guard():
    assert Label(None, None, "none", None).source == "none"


# --- T-11: the description vetoes "full" ------------------------------------------------------


@pytest.mark.parametrize(
    ("texts", "expected"),
    [
        (("to furnish detail-tagged footnotes in Exhibit 101", "10-K/A"), True),
        (("The sole purpose is to furnish the correct versions of Exhibits 32.1", None), True),
        ((None, "Part III information"), True),
        (("Part III and restated financial statements", None), None),  # restated wins
        (("exhibit only", "complete document"), None),  # any full word in any text wins
        ((None, "10-K/A"), None),
        ((None, None), None),
    ],
)
def test_partial_only_text(texts, expected):
    assert partial_only_text(*texts) is expected


def test_partial_only_text_vetoes_full_even_with_two_positives():
    # More than 6 R files and a size ratio of 2: two positives, yet the cover says exhibits only.
    signals = ScopeSignals(True, None, 2.2, None, partial_only_text=True)
    assert decide_scope(signals) == "partial"
    assert decide_scope(ScopeSignals(True, None, 2.2, None)) == "full"  # before T-11 this was it


def test_small_primary_document_is_partial_unless_the_text_says_full():
    big = ScopeSignals(True, None, 5.4, None, primary_doc_bytes=29_914)  # Toyota 2011: XBRL only
    assert decide_scope(big) == "partial"
    assert decide_scope(ScopeSignals(True, None, 1.0, None, primary_doc_bytes=1_023_778)) == "full"
    restated = ScopeSignals(True, None, 1.0, True, primary_doc_bytes=60_000)
    assert decide_scope(restated) == "full"
