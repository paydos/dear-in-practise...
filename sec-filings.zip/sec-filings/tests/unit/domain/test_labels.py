from __future__ import annotations

from datetime import date

import pytest

from sec_filings.domain.labels import (
    effective_period_end,
    infer_fiscal_year_end,
    label_filing,
    learn_convention,
    normalize_fiscal_period,
    snap_to_month_end,
)
from sec_filings.models import Label

D = date

# (declared fiscal year, period end), from the recorded concept files.
WALMART = [(py - 1, D(py, 1, 31)) for py in range(2010, 2015)] + [
    (y, D(y, 1, 31)) for y in range(2015, 2027)
]
TOYOTA = [(y - 1, D(y, 3, 31)) for y in range(2012, 2018)] + [
    (y, D(y, 3, 31)) for y in range(2018, 2027)
]
GAMESTOP = [(2024, D(2025, 2, 1)), (2023, D(2024, 2, 3)), (2022, D(2023, 1, 28))]
SPLIT = [
    (2020, D(2020, 1, 31)),
    (2021, D(2021, 1, 31)),
    (2021, D(2022, 1, 31)),
    (2022, D(2023, 1, 31)),
]


@pytest.mark.parametrize(
    ("d", "expected"),
    [
        (D(2025, 2, 1), D(2025, 1, 31)),  # GameStop
        (D(2026, 1, 31), D(2026, 1, 31)),
        (D(2009, 9, 26), D(2009, 9, 30)),  # Apple 52/53 week
        (D(2012, 12, 29), D(2012, 12, 31)),
        (D(2024, 2, 3), D(2024, 1, 31)),
        (D(2024, 2, 28), D(2024, 2, 29)),  # leap year
        (D(2023, 2, 28), D(2023, 2, 28)),
        (D(2024, 3, 15), D(2024, 3, 15)),  # mid month stays
        (D(2024, 3, 8), D(2024, 3, 8)),
        (D(2024, 3, 7), D(2024, 2, 29)),  # exactly 7 days after month end
    ],
)
def test_snap(d, expected):
    assert snap_to_month_end(d) == expected


def test_snap_tolerance_parameter():
    assert snap_to_month_end(D(2024, 3, 25), tolerance_days=3) == D(2024, 3, 25)
    assert snap_to_month_end(D(2024, 3, 25), tolerance_days=6) == D(2024, 3, 31)


@pytest.mark.parametrize(
    ("ends", "expected"),
    [
        (
            [D(2022, 3, 31), D(2023, 3, 31), D(2024, 3, 31), D(2025, 3, 31), D(2026, 3, 31)],
            "0331",
        ),  # Alibaba
        ([D(2009, 9, 26), D(2010, 9, 25)], "0930"),
        ([D(2024, 2, 3), D(2025, 2, 1)], "0131"),
        ([D(2023, 12, 31), D(2022, 12, 31), D(2021, 3, 31)], "1231"),
        ([D(2023, 2, 28)], "0228"),
        ([], None),
    ],
)
def test_infer_fiscal_year_end(ends, expected):
    assert infer_fiscal_year_end(ends) == expected


@pytest.mark.parametrize(
    ("case", "family", "period", "filed", "fye", "expected"),
    [
        ("GE", "annual", D(2015, 2, 27), D(2015, 2, 27), "1231", (D(2014, 12, 31), True)),
        ("Walmart", "annual", D(2009, 4, 1), D(2009, 4, 1), "0131", (D(2009, 1, 31), True)),
        ("Novo", "annual", D(2014, 2, 10), D(2015, 2, 5), "1231", (D(2014, 12, 31), True)),
        ("Apple ok", "annual", D(2009, 9, 26), D(2009, 11, 5), "0926", (D(2009, 9, 30), False)),
        ("None period", "annual_amendment", None, D(2015, 2, 27), "1231", (D(2014, 12, 31), True)),
        ("No FYE", "annual", D(2015, 2, 27), D(2015, 2, 27), None, (D(2015, 2, 28), False)),
        ("No FYE no period", "annual", None, D(2015, 2, 27), None, (None, False)),
        (
            "Quarterly unchanged",
            "quarterly",
            D(2024, 6, 29),
            D(2024, 8, 1),
            "1231",
            (D(2024, 6, 29), False),
        ),
        ("Quarterly none", "quarterly", None, D(2024, 8, 1), "1231", (D(2024, 6, 30), True)),
        ("Quarterly none no FYE", "quarterly", None, D(2024, 8, 1), None, (None, False)),
        (
            "Toyota 20-F/A keeps FY2021",
            "annual_amendment",
            D(2021, 3, 31),
            D(2024, 2, 6),
            "0331",
            (D(2021, 3, 31), False),
        ),
        (
            "Apple 10-Q/A period is filing date",
            "quarterly_amendment",
            D(1997, 10, 7),
            D(1997, 10, 7),
            "0926",
            (D(1997, 6, 30), True),
        ),
        (
            "Quarterly off every quarter end",
            "quarterly",
            D(2024, 5, 10),
            D(2024, 8, 1),
            "1231",
            (D(2024, 6, 30), True),
        ),
        (
            "Amendment 60 days after period end",
            "annual_amendment",
            D(2014, 12, 31),
            D(2015, 3, 1),
            "1231",
            (D(2014, 12, 31), False),
        ),
        (
            "Amendment 13 days after period end",
            "annual_amendment",
            D(2014, 12, 31),
            D(2015, 1, 13),
            "1231",
            (D(2013, 12, 31), True),
        ),
        (
            "Period 14 days before filing is unreliable",
            "annual",
            D(2014, 12, 31),
            D(2015, 1, 14),
            "1231",
            (D(2013, 12, 31), True),
        ),
        (
            "Period 15 days before filing is reliable",
            "annual",
            D(2014, 12, 31),
            D(2015, 1, 15),
            "1231",
            (D(2014, 12, 31), False),
        ),
        (
            "Transition snaps",
            "transition_annual",
            D(2024, 6, 29),
            D(2024, 9, 1),
            "1231",
            (D(2024, 6, 30), False),
        ),
        (
            "30 days off ok",
            "annual",
            D(2020, 1, 31),
            D(2020, 3, 2),
            "1231",
            (D(2020, 1, 31), False),
        ),
    ],
)
def test_effective_period_end(case, family, period, filed, fye, expected):
    got = effective_period_end(
        family=family, period_of_report=period, filing_date=filed, fiscal_year_end_mmdd=fye
    )
    assert got == expected, case


@pytest.mark.parametrize(
    ("obs", "expected"),
    [
        ([(2023, D(2023, 1, 31)), (2024, D(2024, 2, 3)), (2025, D(2025, 2, 1))], "ends_in"),
        ([(2024, D(2025, 2, 1)), (2023, D(2024, 2, 3)), (2022, D(2023, 1, 28))], "starts_in"),
        ([(2024, D(2024, 1, 31)), (2025, D(2025, 1, 31)), (2026, D(2026, 1, 31))], "ends_in"),
        ([(2024, D(2024, 1, 31)), (2025, D(2025, 1, 31))], "unknown"),
        ([(2024, D(2024, 1, 31)), (2024, D(2025, 1, 31)), (2026, D(2026, 1, 31))], "ends_in"),
        ([(2024, D(2024, 1, 31)), (2024, D(2025, 1, 31)), (2024, D(2026, 1, 31))], "unknown"),
        (WALMART, "ends_in"),
        (TOYOTA, "ends_in"),
        (GAMESTOP, "starts_in"),
        (SPLIT, "unknown"),
        ([], "unknown"),
    ],
)
def test_learn_convention(obs, expected):
    assert learn_convention(obs) == expected


def test_learn_convention_accepts_iterator():
    assert (
        learn_convention(
            iter([(2020, D(2020, 9, 26)), (2021, D(2021, 9, 25)), (2022, D(2022, 9, 24))])
        )
        == "ends_in"
    )


@pytest.mark.parametrize(
    ("raw", "expected"),
    [
        ("FY", "FY"),
        ("fy", "FY"),
        (" q1 ", "Q1"),
        ("Q4", "Q4"),
        ("H1", "H1"),
        ("H2", "H2"),
        ("OTHER", "OTHER"),
        ("Q5", None),
        ("", None),
        (None, None),
        ("annual", None),
    ],
)
def test_normalize_fiscal_period(raw, expected):
    assert normalize_fiscal_period(raw) == expected


def lab(**kw):
    base = dict(
        family="annual",
        period_of_report=None,
        cover=None,
        convention="unknown",
        fiscal_year_end_mmdd=None,
    )
    base.update(kw)
    return label_filing(**base)


def test_walmart_ends_in(cover):
    got = lab(
        period_of_report=D(2026, 1, 31),
        cover=cover(2026, "FY"),
        convention="ends_in",
        fiscal_year_end_mmdd="0131",
    )
    assert got == Label(2026, "FY", "filing_dei", "high")
    got = lab(period_of_report=D(2026, 1, 31), convention="ends_in", fiscal_year_end_mmdd="0131")
    assert got == Label(2026, "FY", "convention", "medium")


@pytest.mark.parametrize(
    ("period", "fy"), [(D(2025, 2, 1), 2024), (D(2026, 1, 31), 2025), (D(2024, 2, 3), 2023)]
)
def test_gamestop_starts_in(period, fy):
    got = lab(period_of_report=period, convention="starts_in", fiscal_year_end_mmdd="0131")
    assert got == Label(fy, "FY", "convention", "medium")


def test_apple_2009():
    got = lab(period_of_report=D(2009, 9, 26), convention="ends_in", fiscal_year_end_mmdd="0926")
    assert (got.fiscal_year, got.fiscal_period) == (2009, "FY")


@pytest.mark.parametrize(
    ("period", "fye", "conv", "expected"),
    [
        (D(2025, 4, 30), "0131", "ends_in", (2026, "Q1")),  # Walmart Q1 FY26
        (D(2025, 7, 31), "0131", "ends_in", (2026, "Q2")),
        (D(2025, 10, 31), "0131", "ends_in", (2026, "Q3")),
        (D(2025, 5, 3), "0131", "starts_in", (2025, "Q1")),  # GameStop, 52/53 snapping
        (D(2025, 11, 1), "0131", "starts_in", (2025, "Q3")),
        (D(2024, 12, 28), "0930", "ends_in", (2025, "Q1")),  # Apple-like
        (D(2024, 3, 30), "0930", "ends_in", (2024, "Q2")),
        (D(2024, 6, 29), "0930", "ends_in", (2024, "Q3")),
        (D(2024, 3, 31), "1231", "ends_in", (2024, "Q1")),
        (D(2024, 9, 30), "1231", "ends_in", (2024, "Q3")),
    ],
)
def test_quarter_math(period, fye, conv, expected):
    got = lab(
        family="quarterly", period_of_report=period, convention=conv, fiscal_year_end_mmdd=fye
    )
    assert (got.fiscal_year, got.fiscal_period) == expected
    assert got.source == "convention"


def test_unknown_convention_is_tier3_rule_low():
    got = lab(
        family="quarterly",
        period_of_report=D(2010, 6, 30),
        convention="unknown",
        fiscal_year_end_mmdd="1231",
    )
    assert got == Label(2010, "Q2", "rule", "low")


def test_quarterly_without_fye_is_none():
    assert lab(family="quarterly", period_of_report=D(2010, 6, 30)) == Label(
        None, None, "none", None
    )


def test_annual_without_period_is_none():
    assert lab(period_of_report=None) == Label(None, None, "none", None)


def test_implausible_cover_falls_to_tier2(cover):
    got = lab(
        period_of_report=D(2015, 12, 31),
        cover=cover(2009, "FY"),
        convention="ends_in",
        fiscal_year_end_mmdd="1231",
    )
    assert got == Label(2015, "FY", "convention", "medium")


def test_off_by_one_cover_loses_to_known_convention(cover):
    got = lab(
        period_of_report=D(2015, 12, 31),
        cover=cover(2016, "FY"),
        convention="ends_in",
        fiscal_year_end_mmdd="1231",
    )
    assert got == Label(2015, "FY", "convention", "medium")


def test_plausible_off_by_one_cover_kept_when_convention_unknown(cover):
    got = lab(period_of_report=D(2015, 12, 31), cover=cover(2016, "FY"), convention="unknown")
    assert got == Label(2016, "FY", "filing_dei", "high")


def test_unknown_convention_uses_declared_label_5050(cover):
    assert learn_convention(SPLIT) == "unknown"
    got = lab(period_of_report=D(2022, 1, 31), cover=cover(2021, "FY"), convention="unknown")
    assert got == Label(2021, "FY", "filing_dei", "high")


def test_walmart_declared_start_year_overridden(cover):
    assert learn_convention(WALMART) == "ends_in"
    got = lab(
        period_of_report=D(2014, 1, 31),
        cover=cover(2013, "FY"),
        convention="ends_in",
        fiscal_year_end_mmdd="0131",
    )
    assert got == Label(2014, "FY", "convention", "medium")
    got = lab(
        period_of_report=D(2020, 1, 31),
        cover=cover(2020, "FY"),
        convention="ends_in",
        fiscal_year_end_mmdd="0131",
    )
    assert got == Label(2020, "FY", "filing_dei", "high")


def test_no_two_walmart_reports_share_a_label(cover):
    convention = learn_convention(WALMART)
    labels = [
        lab(
            period_of_report=period,
            cover=cover(fy, "FY"),
            convention=convention,
            fiscal_year_end_mmdd="0131",
        ).fiscal_year
        for fy, period in WALMART
    ]
    assert labels == list(range(2010, 2027))


def test_toyota_convention_and_label(cover):
    assert learn_convention(TOYOTA) == "ends_in"
    got = lab(
        period_of_report=D(2017, 3, 31),
        cover=cover(2016, "FY"),
        convention="ends_in",
        fiscal_year_end_mmdd="0331",
    )
    assert got == Label(2017, "FY", "convention", "medium")


def test_gamestop_convention_and_label():
    assert learn_convention(GAMESTOP) == "starts_in"
    got = lab(period_of_report=D(2025, 2, 1), convention="starts_in", fiscal_year_end_mmdd="0131")
    assert got.fiscal_year == 2024


def test_quarter_number_from_period_wins_over_declared(cover):
    got = lab(
        family="quarterly",
        period_of_report=D(2025, 7, 31),
        cover=cover(2026, "Q1"),
        convention="ends_in",
        fiscal_year_end_mmdd="0131",
    )
    assert got == Label(2026, "Q2", "convention", "medium")
    got = lab(
        family="quarterly",
        period_of_report=D(2025, 7, 31),
        cover=cover(2026, "Q2"),
        convention="ends_in",
        fiscal_year_end_mmdd="0131",
    )
    assert got == Label(2026, "Q2", "filing_dei", "high")


def test_cover_without_period_falls_through(cover):
    got = lab(
        family="quarterly",
        period_of_report=D(2015, 12, 31),
        cover=cover(2015, None),
        convention="ends_in",
        fiscal_year_end_mmdd="1231",
    )
    assert got.source == "convention"


def test_toyota_cover_fy2026(cover):
    got = lab(
        period_of_report=D(2026, 3, 31),
        cover=cover(2026, "FY"),
        convention="ends_in",
        fiscal_year_end_mmdd="0331",
    )
    assert got == Label(2026, "FY", "filing_dei", "high")


@pytest.mark.parametrize("family", ["foreign_current_report", "late_notice", "non_reliance_8k"])
def test_no_label_families(family, cover):
    got = lab(
        family=family,
        period_of_report=D(2020, 6, 30),
        cover=cover(2020, "FY"),
        convention="ends_in",
        fiscal_year_end_mmdd="1231",
    )
    assert got == Label(None, None, "none", None)


def test_manual_wins_even_for_no_label_family():
    manual = Label(2020, "FY", "manual", "high")
    assert lab(family="late_notice", manual=manual) is manual
    assert lab(period_of_report=D(2015, 12, 31), manual=manual) is manual


@pytest.mark.parametrize("family", ["transition_annual", "transition_quarterly"])
def test_transition_is_other(family, cover):
    tier1 = lab(
        family=family,
        period_of_report=D(2020, 6, 30),
        cover=cover(2020, "FY"),
        convention="ends_in",
        fiscal_year_end_mmdd="1231",
    )
    assert (tier1.fiscal_period, tier1.source) == ("OTHER", "filing_dei")
    tier2 = lab(
        family=family,
        period_of_report=D(2020, 6, 30),
        convention="ends_in",
        fiscal_year_end_mmdd="1231",
    )
    assert (tier2.fiscal_period, tier2.source) == ("OTHER", "convention")


def test_amendment_families_label_like_originals():
    a = lab(family="annual_amendment", period_of_report=D(2009, 9, 26), convention="ends_in")
    q = lab(
        family="quarterly_amendment",
        period_of_report=D(2024, 6, 30),
        convention="ends_in",
        fiscal_year_end_mmdd="1231",
    )
    assert (a.fiscal_year, a.fiscal_period) == (2009, "FY")
    assert (q.fiscal_year, q.fiscal_period) == (2024, "Q2")


def test_annual_cover_q4_is_fy(cover):
    for fam in ("annual", "annual_amendment"):
        got = lab(
            family=fam,
            period_of_report=D(2014, 12, 31),
            cover=cover(2014, "Q4"),
            convention="ends_in",
            fiscal_year_end_mmdd="1231",
        )
        assert got == Label(2014, "FY", "filing_dei", "high")
    got = lab(family="quarterly", period_of_report=D(2014, 9, 30), cover=cover(2014, "Q3"))
    assert got.fiscal_period == "Q3"


def test_amendment_filed_60_days_after_period_end_not_corrected():
    got = effective_period_end(
        family="annual_amendment",
        period_of_report=D(2014, 12, 31),
        filing_date=D(2015, 3, 1),
        fiscal_year_end_mmdd="1231",
    )
    assert got == (D(2014, 12, 31), False)


def test_sap_style_correction():
    got = effective_period_end(
        family="annual",
        period_of_report=D(2004, 3, 23),
        filing_date=D(2004, 3, 23),
        fiscal_year_end_mmdd="1231",
    )
    assert got == (D(2003, 12, 31), True)


def test_may_year_end_quarter_filed_within_14_days_not_corrected():
    # Oracle (May year end): 10-Q for 2020-11-30 filed 2020-12-11 is Q2 FY2021, not Q1.
    assert effective_period_end(
        family="quarterly",
        period_of_report=D(2020, 11, 30),
        filing_date=D(2020, 12, 11),
        fiscal_year_end_mmdd="0531",
    ) == (D(2020, 11, 30), False)
    assert effective_period_end(
        family="quarterly",
        period_of_report=D(2019, 8, 31),
        filing_date=D(2019, 9, 13),
        fiscal_year_end_mmdd="0531",
    ) == (D(2019, 8, 31), False)


def test_quarter_dated_on_its_filing_date_is_still_corrected():
    got = effective_period_end(
        family="quarterly",
        period_of_report=D(2020, 11, 30),
        filing_date=D(2020, 11, 30),
        fiscal_year_end_mmdd="0531",
    )
    assert got == (D(2020, 8, 31), True)
