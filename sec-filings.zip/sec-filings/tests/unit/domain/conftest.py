from __future__ import annotations

from datetime import UTC, date, datetime

import pytest

from sec_filings.models import CoverTags, Label, RawFiling


def make_filing(
    acc: str,
    form: str = "10-K",
    filed: date = date(2020, 1, 1),
    period: date | None = None,
    items: tuple[str, ...] = (),
    accepted: datetime | None = None,
) -> RawFiling:
    return RawFiling(
        accession_number=acc,
        cik=1,
        form=form,
        filing_date=filed,
        acceptance_datetime=accepted,
        period_of_report=period,
        items=items,
        primary_document=None,
        primary_doc_description=None,
        is_xbrl=False,
        is_inline_xbrl=False,
        size_bytes=None,
        file_number=None,
        film_number=None,
    )


def make_cover(
    fy: int | None = None,
    fp: str | None = None,
    category: str | None = None,
    error_flag: bool | None = None,
) -> CoverTags:
    return CoverTags(
        fiscal_year=fy,
        fiscal_period=fp,
        document_type=None,
        period_end_date=None,
        filer_category=category,
        amendment_flag=None,
        amendment_description=None,
        error_correction_flag=error_flag,
        current_reporting_status=None,
        non_dei_fact_count=0,
    )


def make_label(fy: int | None, fp: str | None, source: str = "filing_dei", conf="high") -> Label:
    return Label(fy, fp, source, conf if source != "none" else None)  # type: ignore[arg-type]


def utc(y: int, m: int, d: int, h: int = 12) -> datetime:
    return datetime(y, m, d, h, tzinfo=UTC)


@pytest.fixture
def filing():
    return make_filing


@pytest.fixture
def cover():
    return make_cover


@pytest.fixture
def label():
    return make_label
