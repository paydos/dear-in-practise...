from __future__ import annotations

from datetime import date

import pytest

from sec_filings.domain.expected import build_expected

D = date
LAF = "Large accelerated filer"


def run(filings, **kw):
    args = dict(
        company_id="X",
        is_foreign=False,
        fiscal_year_end_mmdd="1231",
        convention="ends_in",
        filings=filings,
        current_filer_category=None,
        pre_merger_until=None,
        today=D(2024, 3, 1),
    )
    args.update(kw)
    return build_expected(**args)


@pytest.fixture
def us_filings(filing, label, cover):
    def t(acc, form, fam, filed, period, fy, fp, cov=None, lab=True):
        return (
            filing(acc, form, filed, period),
            fam,
            label(fy, fp) if lab else label(None, None, "none"),
            cov,
        )

    return [
        t(
            "k22",
            "10-K",
            "annual",
            D(2023, 2, 15),
            D(2022, 12, 31),
            2022,
            "FY",
            cover(2022, "FY", LAF),
        ),
        t(
            "q1",
            "10-Q",
            "quarterly",
            D(2023, 5, 5),
            D(2023, 3, 31),
            2023,
            "Q1",
            cover(2023, "Q1", LAF),
        ),
        t(
            "q3",
            "10-Q",
            "quarterly",
            D(2023, 11, 2),
            D(2023, 9, 30),
            2023,
            "Q3",
            cover(2023, "Q3", LAF),
        ),
        t(
            "k23",
            "10-K",
            "annual",
            D(2024, 2, 20),
            D(2023, 12, 31),
            2023,
            "FY",
            cover(2023, "FY", LAF),
        ),
    ]


def test_gap_and_statuses(us_filings):
    rows = run(us_filings)
    got = {(r.fiscal_year, r.fiscal_period): r for r in rows}
    assert list(got) == [(2022, "FY"), (2023, "Q1"), (2023, "Q2"), (2023, "Q3"), (2023, "FY")]
    assert got[(2023, "Q2")].status == "overdue"
    assert got[(2023, "Q2")].matched_accession is None
    assert got[(2023, "Q2")].period_end_estimate == D(2023, 6, 30)
    assert got[(2023, "Q1")].matched_accession == "q1"
    assert got[(2023, "Q1")].status == "received"
    assert got[(2023, "FY")].due_date == D(2024, 2, 29)
    assert got[(2022, "FY")].category_source == "cover"
    assert got[(2022, "FY")].filer_category_used == "large_accelerated"
    # Q2 has no filing: previous annual cover is used
    assert got[(2023, "Q2")].category_source == "previous_cover"
    assert all(r.report_kind in ("annual", "quarterly") for r in rows)


def test_fy2023_received_on_time(us_filings):
    row = next(r for r in run(us_filings) if (r.fiscal_year, r.fiscal_period) == (2023, "FY"))
    assert row.status == "received"


def test_stops_at_due_date_horizon(us_filings):
    # Q1 2024 is due 2024-05-10. Not yet inside today + 7.
    assert (2024, "Q1") not in {(r.fiscal_year, r.fiscal_period) for r in run(us_filings)}
    rows = run(us_filings, today=D(2024, 5, 3))
    assert (2024, "Q1") in {(r.fiscal_year, r.fiscal_period) for r in rows}
    rows = run(us_filings, today=D(2024, 5, 2))
    assert (2024, "Q1") not in {(r.fiscal_year, r.fiscal_period) for r in rows}


def test_match_by_period_end_when_label_missing(filing, label):
    f = [
        (
            filing("k", "10-K", D(2023, 2, 15), D(2022, 12, 31)),
            "annual",
            label(None, None, "none"),
            None,
        ),
        (
            filing("q", "10-Q", D(2023, 5, 5), D(2023, 3, 29)),
            "quarterly",
            label(None, None, "none"),
            None,
        ),
    ]
    rows = {(r.fiscal_year, r.fiscal_period): r for r in run(f, today=D(2023, 6, 1))}
    assert rows[(2022, "FY")].matched_accession == "k"
    assert rows[(2023, "Q1")].matched_accession == "q"
    assert rows[(2023, "Q1")].period_end_estimate == D(2023, 3, 29)  # real period used for due date


def test_period_end_match_rejects_far_dates(filing, label):
    f = [
        (filing("k", "10-K", D(2023, 2, 15), D(2022, 12, 31)), "annual", label(2022, "FY"), None),
        (
            filing("q", "10-Q", D(2023, 5, 5), D(2023, 3, 1)),
            "quarterly",
            label(None, None, "none"),
            None,
        ),
    ]
    rows = {(r.fiscal_year, r.fiscal_period): r for r in run(f, today=D(2023, 6, 1))}
    assert rows[(2023, "Q1")].matched_accession is None


def test_late_notice_sets_extension(filing, label, cover):
    f = [
        (
            filing("k", "10-K", D(2023, 2, 15), D(2022, 12, 31)),
            "annual",
            label(2022, "FY"),
            cover(2022, "FY", LAF),
        ),
        (
            filing("nt", "NT 10-Q", D(2023, 5, 11), D(2023, 3, 31)),
            "late_notice",
            label(None, None, "none"),
            None,
        ),
    ]
    rows = {(r.fiscal_year, r.fiscal_period): r for r in run(f, today=D(2023, 5, 12))}
    q1 = rows[(2023, "Q1")]
    assert q1.nt_accession == "nt"
    assert q1.status == "nt_filed"
    assert rows[(2022, "FY")].nt_accession is None


def test_nt_for_wrong_kind_ignored(filing, label, cover):
    f = [
        (
            filing("k", "10-K", D(2023, 2, 15), D(2022, 12, 31)),
            "annual",
            label(2022, "FY"),
            cover(2022, "FY", LAF),
        ),
        (
            filing("nt", "NT 10-K", D(2023, 5, 11), D(2023, 3, 31)),
            "late_notice",
            label(None, None, "none"),
            None,
        ),
    ]
    rows = {(r.fiscal_year, r.fiscal_period): r for r in run(f, today=D(2023, 6, 12))}
    assert rows[(2023, "Q1")].nt_accession is None
    assert rows[(2023, "Q1")].status == "overdue"


def test_foreign_annual_only(filing, label):
    f = [
        (filing("a", "20-F", D(2025, 4, 10), D(2024, 12, 31)), "annual", label(2024, "FY"), None),
        (
            filing("k", "6-K", D(2025, 5, 10), D(2025, 3, 31)),
            "foreign_current_report",
            label(None, None, "none"),
            None,
        ),
    ]
    rows = run(f, is_foreign=True, today=D(2026, 5, 1))
    assert {r.report_kind for r in rows} == {"annual"}
    assert [(r.fiscal_year, r.matched_accession) for r in rows] == [(2024, "a"), (2025, None)]
    assert rows[0].due_date == D(2025, 4, 30)
    assert rows[1].status == "overdue"


def test_unmatched_with_no_category_is_non_accelerated(filing, label):
    f = [(filing("k", "10-K", D(2023, 2, 15), D(2022, 12, 31)), "annual", label(2022, "FY"), None)]
    rows = {(r.fiscal_year, r.fiscal_period): r for r in run(f, today=D(2023, 5, 1))}
    assert rows[(2022, "FY")].filer_category_used is None
    assert rows[(2022, "FY")].category_source == "none"
    assert rows[(2022, "FY")].due_date == D(2023, 3, 31)
    rows = {
        (r.fiscal_year, r.fiscal_period): r
        for r in run(f, today=D(2023, 5, 1), current_filer_category="Accelerated filer")
    }
    assert rows[(2022, "FY")].category_source == "current"
    assert rows[(2022, "FY")].filer_category_used == "accelerated"


def test_starts_at_first_filing_and_pre_merger(filing, label):
    shell = (filing("s", "10-K", D(2021, 3, 1), D(2020, 12, 31)), "annual", label(2020, "FY"), None)
    real = (
        filing("r", "10-Q", D(2021, 11, 10), D(2021, 9, 30)),
        "quarterly",
        label(2021, "Q3"),
        None,
    )
    rows = run([shell, real], today=D(2022, 1, 15))
    assert (rows[0].fiscal_year, rows[0].fiscal_period) == (2020, "FY")
    rows = run([shell, real], today=D(2022, 1, 15), pre_merger_until=D(2021, 7, 23))
    assert (rows[0].fiscal_year, rows[0].fiscal_period) == (2021, "Q3")
    assert rows[0].matched_accession == "r"
    assert len(rows) == 1  # FY2021 is not yet inside the horizon
    assert all(r.matched_accession != "s" for r in rows)


def test_starts_in_convention_labels(filing, label):
    f = [(filing("k", "10-K", D(2025, 3, 20), D(2025, 2, 1)), "annual", label(2024, "FY"), None)]
    rows = run(f, fiscal_year_end_mmdd="0131", convention="starts_in", today=D(2025, 8, 1))
    assert (rows[0].fiscal_year, rows[0].fiscal_period, rows[0].matched_accession) == (
        2024,
        "FY",
        "k",
    )
    assert [(r.fiscal_year, r.fiscal_period) for r in rows[1:]] == [(2025, "Q1")]
    assert rows[1].period_end_estimate == D(2025, 4, 30)


def test_corrected_period_filing_matches(filing, label):
    # GE style: raw period is the filing date; the effective period (2014-12-31) must match
    f = [
        (
            filing("g", "10-K", D(2015, 2, 27), D(2015, 2, 27)),
            "annual",
            label(None, None, "none"),
            None,
        )
    ]
    rows = run(f, today=D(2015, 4, 1))
    assert rows[0].matched_accession == "g"
    assert rows[0].period_end_estimate == D(2014, 12, 31)


def test_fye_inferred_when_missing(filing, label):
    f = [(filing("a", "20-F", D(2023, 6, 1), D(2023, 3, 31)), "annual", label(2023, "FY"), None)]
    rows = run(f, is_foreign=True, fiscal_year_end_mmdd=None, today=D(2024, 6, 1))
    assert rows[0].period_end_estimate == D(2023, 3, 31)


def test_empty_cases(filing, label):
    assert run([]) == []
    assert run([], fiscal_year_end_mmdd=None) == []
    nt_only = [
        (
            filing("nt", "NT 10-K", D(2023, 3, 1), D(2022, 12, 31)),
            "late_notice",
            label(None, None, "none"),
            None,
        )
    ]
    assert run(nt_only) == []


def test_no_rows_for_periods_ending_before_2009_06_15(filing, label):
    f = [
        (filing("k08", "10-K", D(2009, 2, 20), D(2008, 12, 31)), "annual", label(2008, "FY"), None),
        (filing("q1", "10-Q", D(2009, 5, 8), D(2009, 3, 31)), "quarterly", label(2009, "Q1"), None),
        (filing("q2", "10-Q", D(2009, 8, 7), D(2009, 6, 30)), "quarterly", label(2009, "Q2"), None),
    ]
    rows = run(f, today=D(2009, 9, 1))
    assert [(r.fiscal_year, r.fiscal_period) for r in rows] == [(2009, "Q2")]
    assert all(r.period_end_estimate >= D(2009, 6, 15) for r in rows)
    assert rows[0].matched_accession == "q2"


def test_period_ending_exactly_2009_06_15_is_kept(filing, label):
    f = [(filing("k", "10-K", D(2009, 8, 20), D(2009, 6, 15)), "annual", label(2009, "FY"), None)]
    rows = run(f, fiscal_year_end_mmdd="0615", today=D(2009, 9, 1))
    assert [(r.fiscal_year, r.fiscal_period) for r in rows] == [(2009, "FY")]


def _plug_like(filing, label, cover, *, covers=True):
    """FY2009 (non-accelerated per its float), two quarters of 2010, then FY2010."""
    return [
        (filing("k08", "10-K", D(2009, 3, 16), D(2008, 12, 31)), "annual", label(2008, "FY"), None),
        (filing("k09", "10-K", D(2010, 3, 16), D(2009, 12, 31)), "annual", label(2009, "FY"), None),
        (
            filing("q1", "10-Q", D(2010, 5, 14), D(2010, 3, 31)),
            "quarterly",
            label(2010, "Q1"),
            None,
        ),
        (
            filing("k10", "10-K", D(2011, 3, 31), D(2010, 12, 31)),
            "annual",
            label(2010, "FY"),
            cover(2010, "FY", "Non-accelerated Filer") if covers else None,
        ),
    ]


def test_category_chain_own_float_then_previous_annual_float_then_current(filing, label, cover):
    f = _plug_like(filing, label, cover, covers=False)
    rows = {
        (r.report_kind, r.fiscal_year, r.fiscal_period): r
        for r in run(
            f,
            today=D(2011, 6, 1),
            current_filer_category=LAF,
            float_categories={"k09": "accelerated", "k10": "non_accelerated"},
        )
    }
    fy09 = rows[("annual", 2009, "FY")]  # its own float estimate
    assert (fy09.filer_category_used, fy09.category_source) == ("accelerated", "public_float")
    assert fy09.due_date == D(2010, 3, 16)  # 75 days: filed on the due date, so on time
    assert fy09.status == "received"
    q1 = rows[("quarterly", 2010, "Q1")]  # no cover, no float: the previous annual's float
    assert (q1.filer_category_used, q1.category_source) == ("accelerated", "previous_public_float")
    fy10 = rows[("annual", 2010, "FY")]
    assert (fy10.filer_category_used, fy10.category_source) == ("non_accelerated", "public_float")
    assert fy10.status == "received"  # 90 days after 2010-12-31 is 2011-03-31


def test_category_chain_prefers_cover_over_float_and_previous_cover(filing, label, cover):
    f = _plug_like(filing, label, cover)
    rows = {
        (r.report_kind, r.fiscal_year, r.fiscal_period): r
        for r in run(f, today=D(2011, 6, 1), float_categories={"k10": "large_accelerated"})
    }
    fy10 = rows[("annual", 2010, "FY")]
    assert (fy10.filer_category_used, fy10.category_source) == ("non_accelerated", "cover")
    # FY2009 has no cover and no float, and nothing precedes it: today's category, if known
    fy09 = rows[("annual", 2009, "FY")]
    assert fy09.category_source == "none"


def test_today_category_is_the_last_resort_and_marked_current(filing, label, cover):
    f = _plug_like(filing, label, cover, covers=False)
    rows = {
        (r.report_kind, r.fiscal_year, r.fiscal_period): r
        for r in run(f, today=D(2011, 6, 1), current_filer_category=LAF)
    }
    assert {r.category_source for r in rows.values()} == {"current"}
    # judged as large accelerated (60 days), FY2009 looks late; the view will not claim it
    assert rows[("annual", 2009, "FY")].status == "received_late"


@pytest.mark.parametrize(
    ("filed", "status"), [(D(2020, 6, 9), "received"), (D(2020, 6, 26), "received_late")]
)
def test_covid_relief_makes_a_q1_2020_10q_within_45_days_not_late(
    filing, label, cover, filed, status
):
    f = [
        (
            filing("k19", "10-K", D(2020, 2, 20), D(2019, 12, 31)),
            "annual",
            label(2019, "FY"),
            cover(2019, "FY", LAF),
        ),
        (
            filing("q1", "10-Q", filed, D(2020, 3, 31)),
            "quarterly",
            label(2020, "Q1"),
            cover(2020, "Q1", LAF),
        ),
    ]
    rows = {(r.fiscal_year, r.fiscal_period): r for r in run(f, today=D(2020, 12, 1))}
    q1 = rows[(2020, "Q1")]
    assert q1.due_date == D(2020, 5, 11)  # 40 days is Sunday 05-10, rolled
    assert q1.status == status
