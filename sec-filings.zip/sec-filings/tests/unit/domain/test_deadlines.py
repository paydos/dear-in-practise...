from __future__ import annotations

from datetime import date

import pytest

from sec_filings.domain.deadlines import (
    covid_relief_applies,
    due_dates,
    normalize_filer_category,
    roll_forward,
    timeliness,
    us_federal_holidays,
)
from sec_filings.models import DueDates

D = date


@pytest.mark.parametrize(
    ("raw", "expected"),
    [
        ("Large accelerated filer", "large_accelerated"),
        ("Large Accelerated Filer", "large_accelerated"),
        ("Accelerated filer", "accelerated"),
        ("Accelerated Filer", "accelerated"),
        ("Non-accelerated filer", "non_accelerated"),
        ("Non-Accelerated Filer", "non_accelerated"),
        ("Smaller reporting company", "non_accelerated"),
        ("Accelerated filer | Smaller reporting company", "accelerated"),
        ("", None),
        (None, None),
        ("gibberish", None),
    ],
)
def test_normalize_filer_category(raw, expected):
    assert normalize_filer_category(raw) == expected


def test_2026_holidays():
    h = us_federal_holidays(2026)
    assert D(2026, 11, 26) in h  # Thanksgiving
    assert D(2026, 7, 3) in h  # July 4 is a Saturday: observed Friday
    assert D(2026, 6, 19) in h
    assert D(2026, 1, 1) in h
    assert D(2026, 1, 19) in h  # MLK
    assert D(2026, 2, 16) in h
    assert D(2026, 5, 25) in h
    assert D(2026, 9, 7) in h
    assert D(2026, 10, 12) in h
    assert D(2026, 11, 11) in h
    assert D(2026, 12, 25) in h
    assert len(h) == 11


def test_juneteenth_from_2021_only():
    assert D(2021, 6, 18) in us_federal_holidays(2021)  # Saturday -> Friday
    assert D(2021, 6, 19) not in us_federal_holidays(2021)
    assert not any(d.month == 6 for d in us_federal_holidays(2020))


@pytest.mark.parametrize(
    ("year", "observed"),
    [
        (2023, D(2023, 1, 2)),  # Sunday Jan 1 -> Monday
        (2022, D(2021, 12, 31)),  # Saturday Jan 1 2022 is observed in 2021
        (2021, D(2021, 12, 31)),
    ],
)
def test_new_year_observance(year, observed):
    assert observed in us_federal_holidays(observed.year)


def test_dec_31_2021_observed_and_2022_has_no_jan_1():
    assert D(2021, 12, 31) in us_federal_holidays(2021)
    assert D(2022, 1, 1) not in us_federal_holidays(2022)


@pytest.mark.parametrize(
    ("d", "expected"),
    [
        (D(2026, 11, 25), D(2026, 11, 25)),  # Wednesday stays
        (D(2026, 11, 7), D(2026, 11, 9)),  # Saturday -> Monday
        (D(2026, 11, 8), D(2026, 11, 9)),
        (D(2026, 11, 26), D(2026, 11, 27)),  # Thanksgiving
        (D(2021, 6, 18), D(2021, 6, 21)),  # Juneteenth observed Friday, then weekend
        (D(2026, 12, 24), D(2026, 12, 24)),
        (D(2026, 12, 25), D(2026, 12, 28)),  # Christmas Friday then weekend
        (D(2021, 12, 31), D(2022, 1, 3)),
    ],
)
def test_roll_forward(d, expected):
    assert roll_forward(d) == expected


@pytest.mark.parametrize(
    ("kind", "foreign", "cat", "end", "due", "ext", "first"),
    [
        (
            "annual",
            False,
            "large_accelerated",
            D(2026, 9, 26),
            D(2026, 11, 25),
            D(2026, 12, 10),
            False,
        ),  # Apple
        (
            "quarterly",
            False,
            "large_accelerated",
            D(2026, 9, 30),
            D(2026, 11, 9),
            D(2026, 11, 16),
            False,
        ),  # Exxon
        ("annual", True, None, D(2026, 3, 31), D(2026, 7, 31), D(2026, 8, 17), False),  # Toyota
        (
            "annual",
            True,
            None,
            D(2011, 12, 14),
            D(2012, 6, 14),
            D(2012, 6, 29),
            False,
        ),  # six months
        (
            "annual",
            True,
            None,
            D(2011, 12, 15),
            D(2012, 4, 16),
            D(2012, 5, 1),  # 15 days from the rolled due date (D-18)
            False,
        ),  # four months
        ("annual", True, None, D(2025, 10, 31), D(2026, 3, 2), D(2026, 3, 17), False),
        ("annual", True, None, D(2023, 12, 31), D(2024, 4, 30), D(2024, 5, 15), False),
        ("annual", False, "accelerated", D(2024, 12, 31), D(2025, 3, 17), D(2025, 4, 1), False),
        (
            "annual",
            False,
            "non_accelerated",
            D(2024, 12, 31),
            D(2025, 3, 31),
            D(2025, 4, 15),
            False,
        ),
        ("annual", False, None, D(2024, 12, 31), D(2025, 3, 31), D(2025, 4, 15), False),
        (
            "annual",
            False,
            "large_accelerated",
            D(2024, 12, 31),
            D(2025, 3, 31),
            D(2025, 4, 15),
            True,
        ),
        ("quarterly", False, "accelerated", D(2024, 3, 31), D(2024, 5, 10), D(2024, 5, 15), False),
        (
            "quarterly",
            False,
            "non_accelerated",
            D(2024, 3, 31),
            D(2024, 5, 15),
            D(2024, 5, 20),
            False,
        ),
        ("quarterly", False, None, D(2024, 3, 31), D(2024, 5, 15), D(2024, 5, 20), False),
    ],
)
def test_due_dates(kind, foreign, cat, end, due, ext, first):
    got = due_dates(
        report_kind=kind,
        is_foreign=foreign,
        category=cat,
        period_end=end,
        first_annual_after_listing=first,
    )
    assert (got.due, got.due_with_extension) == (due, ext)
    assert got.basis


def test_due_on_holiday_rolls():
    # 2026-09-30 + 40 days = 2026-11-09 (Mon); 2025-09-30 + 40 = 2025-11-09 (Sun) -> Mon 10th
    got = due_dates(
        report_kind="quarterly", is_foreign=False, category="accelerated", period_end=D(2025, 9, 30)
    )
    assert got.due == D(2025, 11, 10)
    # Landing exactly on a holiday: 2025-12-10 + 40 days = 2026-01-19, Martin Luther King Jr. Day
    got = due_dates(
        report_kind="quarterly",
        is_foreign=False,
        category="accelerated",
        period_end=D(2025, 12, 10),
    )
    assert got.due == D(2026, 1, 20)  # Monday 19 Jan is MLK day


def test_foreign_quarterly_rejected():
    with pytest.raises(ValueError):
        due_dates(
            report_kind="quarterly", is_foreign=True, category=None, period_end=D(2024, 3, 31)
        )


DUES = DueDates(due=D(2025, 3, 3), due_with_extension=D(2025, 3, 18), basis="x")


@pytest.mark.parametrize(
    ("filed", "nt", "today", "expected"),
    [
        (D(2025, 3, 3), False, D(2025, 6, 1), "received"),
        (D(2025, 2, 1), False, D(2025, 6, 1), "received"),
        (D(2025, 3, 4), False, D(2025, 6, 1), "received_late"),
        (D(2025, 3, 10), True, D(2025, 6, 1), "received"),  # inside the extension
        (D(2025, 3, 18), True, D(2025, 6, 1), "received"),
        (D(2025, 3, 19), True, D(2025, 6, 1), "received_late"),
        (None, True, D(2025, 3, 10), "nt_filed"),
        (None, True, D(2025, 3, 19), "overdue"),
        (None, False, D(2025, 3, 4), "overdue"),
        (None, False, D(2025, 3, 3), "due_soon"),
        (None, False, D(2025, 2, 24), "due_soon"),  # exactly 7 days out
        (None, False, D(2025, 2, 23), "pending"),
    ],
)
def test_timeliness(filed, nt, today, expected):
    assert timeliness(dates=DUES, filed=filed, nt_filed=nt, today=today) == expected


def test_extension_counts_from_the_rolled_due_date():
    """D-18 (lenient 12b-25 reading): Plug FY2014, 60 days after 2014-12-31 is Sunday 2015-03-01,
    rolled to Monday 03-02, and the 15 days run from there: 03-17, not 03-16."""
    got = due_dates(
        report_kind="annual",
        is_foreign=False,
        category="large_accelerated",
        period_end=D(2014, 12, 31),
    )
    assert (got.due, got.due_with_extension) == (D(2015, 3, 2), D(2015, 3, 17))
    q = due_dates(
        report_kind="quarterly",
        is_foreign=False,
        category="non_accelerated",
        period_end=D(2011, 6, 30),
    )  # 45 days is Sunday 2011-08-14, rolled to 08-15; plus 5 days is 08-20, a Saturday -> 08-22
    assert (q.due, q.due_with_extension) == (D(2011, 8, 15), D(2011, 8, 22))


COVID_DUES = DueDates(due=D(2020, 5, 11), due_with_extension=D(2020, 5, 18), basis="x")


@pytest.mark.parametrize(
    ("due", "filed", "expected"),
    [
        (D(2020, 5, 11), D(2020, 6, 9), "received"),  # AMC Q1 2020, 29 days late
        (D(2020, 5, 11), D(2020, 6, 25), "received"),  # exactly 45 days
        (D(2020, 5, 11), D(2020, 6, 26), "received_late"),  # 46 days
        (D(2020, 3, 1), D(2020, 4, 15), "received"),  # window start
        (D(2020, 7, 1), D(2020, 8, 15), "received"),  # window end
        (D(2020, 2, 28), D(2020, 3, 20), "received_late"),  # due before the window
        (D(2020, 7, 2), D(2020, 7, 20), "received_late"),  # due after the window
    ],
)
def test_covid_relief_window(due, filed, expected):
    dates = DueDates(due=due, due_with_extension=due, basis="x")
    got = timeliness(dates=dates, filed=filed, nt_filed=False, today=D(2021, 1, 1))
    assert got == expected


def test_covid_relief_helper_ignores_unfiled():
    assert covid_relief_applies(COVID_DUES.due, None) is False
    assert covid_relief_applies(COVID_DUES.due, D(2020, 6, 9)) is True
