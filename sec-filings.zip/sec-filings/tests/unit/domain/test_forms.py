from __future__ import annotations

import pytest

from sec_filings.domain.forms import (
    form_family,
    is_amendment,
    is_unknown_periodic_form,
    original_family,
    report_kind,
)


@pytest.mark.parametrize(
    ("form", "items", "expected"),
    [
        ("10-K", (), "annual"),
        ("10-K405", (), "annual"),
        ("10-KSB", (), "annual"),
        ("20-F", (), "annual"),
        ("40-F", (), "annual"),
        ("10-KT", (), "transition_annual"),
        ("10-KSBT", (), "transition_annual"),
        ("10-K/A", (), "annual_amendment"),
        ("10-K405/A", (), "annual_amendment"),
        ("10-KSB/A", (), "annual_amendment"),
        ("10-KT/A", (), "annual_amendment"),
        ("20-F/A", (), "annual_amendment"),
        ("40-F/A", (), "annual_amendment"),
        ("10-Q", (), "quarterly"),
        ("10-QSB", (), "quarterly"),
        ("10-QT", (), "transition_quarterly"),
        ("10-Q/A", (), "quarterly_amendment"),
        ("10-QSB/A", (), "quarterly_amendment"),
        ("10-QT/A", (), "quarterly_amendment"),
        ("6-K", (), "foreign_current_report"),
        ("6-K/A", (), "foreign_current_report"),
        ("NT 10-K", (), "late_notice"),
        ("NT 10-Q", (), "late_notice"),
        ("NT 20-F", (), "late_notice"),
        ("NT 10-K/A", (), "late_notice"),
        ("NT 10-KT", (), "late_notice"),
        ("NT 10-QT", (), "late_notice"),
        ("8-K", ("4.02",), "non_reliance_8k"),
        ("8-K", ("2.02", "4.02", "9.01"), "non_reliance_8k"),
        ("8-K", ("4.01",), None),
        ("8-K", ("4.020",), None),
        ("8-K", (), None),
        ("S-1", (), None),
        ("DEF 14A", (), None),
        ("NT 11-K", (), None),
        ("10-K405T", (), None),
    ],
)
def test_form_family(form, items, expected):
    assert form_family(form, items) == expected


@pytest.mark.parametrize(
    ("family", "kind", "amend", "orig"),
    [
        ("annual", "annual", False, "annual"),
        ("annual_amendment", "annual", True, "annual"),
        ("transition_annual", "annual", False, "transition_annual"),
        ("quarterly", "quarterly", False, "quarterly"),
        ("quarterly_amendment", "quarterly", True, "quarterly"),
        ("transition_quarterly", "quarterly", False, "transition_quarterly"),
        ("foreign_current_report", None, False, None),
        ("late_notice", None, False, None),
        ("non_reliance_8k", None, False, None),
    ],
)
def test_family_helpers(family, kind, amend, orig):
    assert report_kind(family) == kind
    assert is_amendment(family) is amend
    assert original_family(family) == orig


@pytest.mark.parametrize(
    ("form", "unknown"),
    [
        ("10-K", False),
        ("NT 10-K", False),
        ("6-K", False),
        ("NT 11-K", False),  # employee plans: not flagged (A5)
        ("S-1", False),
        ("8-K", False),
        ("10-K405T", True),
        ("10-Q/B", True),
        ("20-F/B", True),
        ("40-FR", True),
        ("6-KX", True),
        ("NT 10-D", True),
        ("NT 20-FX", True),
        ("NT 40-F/Z", True),
    ],
)
def test_is_unknown_periodic_form(form, unknown):
    assert is_unknown_periodic_form(form) is unknown
