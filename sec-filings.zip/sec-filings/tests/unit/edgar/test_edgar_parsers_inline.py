"""Parsers on small inline samples (shapes copied from the SEC formats) and URL builders."""
# ruff: noqa: E501

from __future__ import annotations

import json
from datetime import UTC, date, datetime

import pytest

from sec_filings.edgar.cover_tags import (
    cover_page_url,
    filing_index_url,
    instance_url,
    parse_cover_page,
    parse_cover_tags,
    parse_filing_index,
    pick_instance,
)
from sec_filings.edgar.daily_index import (
    daily_index_url,
    full_index_url,
    parse_form_index,
    parse_master_index,
)
from sec_filings.edgar.submissions import (
    history_page_url,
    parse_history_page,
    parse_submissions,
    submissions_url,
)
from sec_filings.edgar.tickers import parse_company_tickers
from sec_filings.edgar.xbrl_concepts import (
    company_concept_url,
    parse_concept_labels,
    parse_public_float,
)
from sec_filings.errors import ParseError


def test_url_builders():
    assert submissions_url(320193) == "https://data.sec.gov/submissions/CIK0000320193.json"
    assert history_page_url("CIK0000320193-submissions-001.json") == (
        "https://data.sec.gov/submissions/CIK0000320193-submissions-001.json"
    )
    assert filing_index_url(320193, "0001193125-10-012091") == (
        "https://www.sec.gov/Archives/edgar/data/320193/000119312510012091/index.json"
    )
    assert instance_url(320193, "0001193125-10-012091", "aapl-20090926.xml") == (
        "https://www.sec.gov/Archives/edgar/data/320193/000119312510012091/aapl-20090926.xml"
    )
    assert cover_page_url(34088, "0000034088-26-000093") == (
        "https://www.sec.gov/Archives/edgar/data/34088/000003408826000093/R1.htm"
    )
    assert daily_index_url(date(2026, 11, 2)) == (
        "https://www.sec.gov/Archives/edgar/daily-index/2026/QTR4/form.20261102.idx"
    )
    assert daily_index_url(date(2026, 3, 31)).endswith("/2026/QTR1/form.20260331.idx")
    assert daily_index_url(date(2026, 4, 1)).endswith("/2026/QTR2/form.20260401.idx")
    assert full_index_url(2026, 4) == (
        "https://www.sec.gov/Archives/edgar/full-index/2026/QTR4/master.idx"
    )
    with pytest.raises(ValueError):
        full_index_url(2026, 5)
    assert company_concept_url(320193, "EntityPublicFloat") == (
        "https://data.sec.gov/api/xbrl/companyconcept/CIK0000320193/dei/EntityPublicFloat.json"
    )
    assert company_concept_url(1, "Assets", "us-gaap").endswith(
        "/CIK0000000001/us-gaap/Assets.json"
    )


# ------------------------------------------------------------------ tickers


def test_tickers_basic_and_duplicates():
    body = json.dumps(
        {
            "0": {"cik_str": 320193, "ticker": "AAPL", "title": "Apple Inc."},
            "1": {"cik_str": 1, "ticker": "AAPL", "title": "Impostor"},
            "2": {"cik_str": 863064, "ticker": "RIO", "title": "Rio Tinto plc"},
        }
    ).encode()
    assert parse_company_tickers(body) == {
        "AAPL": (320193, "Apple Inc."),
        "RIO": (863064, "Rio Tinto plc"),
    }


def test_tickers_garbage():
    with pytest.raises(ParseError):
        parse_company_tickers(b"not json")
    with pytest.raises(ParseError):
        parse_company_tickers(b'{"0": {"ticker": "X"}}')


# ------------------------------------------------------------- submissions


def _submission(**overrides):
    recent = {
        "accessionNumber": ["0000000001-26-000001", "0000000001-26-000002"],
        "filingDate": ["2026-11-03", "2026-10-01"],
        "reportDate": ["2026-09-26", ""],
        "acceptanceDateTime": ["2026-11-03T18:01:36.000Z", ""],
        "form": ["10-K", "8-K"],
        "fileNumber": ["001-36743", ""],
        "filmNumber": ["", ""],
        "items": ["", "2.02,9.01"],
        "size": [100, 0],
        "isXBRL": [1, 0],
        "isInlineXBRL": [1, 0],
        "primaryDocument": ["a.htm", ""],
        "primaryDocDescription": ["10-K", ""],
    }
    doc = {
        "cik": "0000000001",
        "name": "Test Co",
        "tickers": ["TST"],
        "category": "",
        "fiscalYearEnd": "",
        "formerNames": [{"name": "OLD CO", "from": "2007-01-10T00:00:00.000Z", "to": None}],
        "filings": {
            "recent": recent,
            "files": [
                {
                    "name": "CIK0000000001-submissions-001.json",
                    "filingCount": 12,
                    "filingFrom": "1994-01-26",
                    "filingTo": "2015-10-03",
                }
            ],
        },
    }
    doc.update(overrides)
    return doc


def test_submissions_empty_strings_become_none_and_items_split():
    doc = parse_submissions(json.dumps(_submission()).encode())
    assert doc.meta.cik == 1 and doc.meta.name == "Test Co"
    assert doc.meta.filer_category is None and doc.meta.fiscal_year_end_mmdd is None
    assert doc.meta.former_names[0].valid_from == date(2007, 1, 10)
    assert doc.meta.former_names[0].valid_to is None
    ten_k, eight_k = doc.filings
    assert ten_k.items == () and eight_k.items == ("2.02", "9.01")
    assert ten_k.film_number is None and ten_k.file_number == "001-36743"
    assert eight_k.period_of_report is None and eight_k.acceptance_datetime is None
    assert eight_k.primary_document is None and eight_k.primary_doc_description is None
    assert ten_k.is_xbrl is True and ten_k.is_inline_xbrl is True and eight_k.is_xbrl is False
    assert ten_k.acceptance_datetime == datetime(2026, 11, 3, 18, 1, 36, tzinfo=UTC)
    assert ten_k.acceptance_datetime.utcoffset().total_seconds() == 0
    assert doc.pages[0].filing_count == 12 and doc.pages[0].filing_from == date(1994, 1, 26)


def test_history_page_uses_given_cik():
    arrays = _submission()["filings"]["recent"]
    rows = parse_history_page(json.dumps(arrays).encode(), 777)
    assert [r.cik for r in rows] == [777, 777]
    assert rows[1].form == "8-K"


def test_submissions_ragged_columns_rejected():
    bad = _submission()
    bad["filings"]["recent"]["form"] = ["10-K"]
    with pytest.raises(ParseError):
        parse_submissions(json.dumps(bad).encode())
    with pytest.raises(ParseError):
        parse_submissions(b"[]")
    with pytest.raises(ParseError):
        parse_history_page(b"{}", 1)


# ------------------------------------------------------------- daily index

FORM_IDX = """Description:           Daily Index of EDGAR Dissemination Feed by Form Type
Last Data Received:    Nov 9, 2026
Comments:              webmaster@sec.gov
Anonymous FTP:         ftp://ftp.sec.gov/edgar/




Form Type   Company Name                                                  CIK         Date Filed  File Name
---------------------------------------------------------------------------------------------------------------------------------------------
10-Q             ExxonMobil Holdings Corp                                      2115436     20261102    edgar/data/2115436/0002115436-26-000020.txt
NT 10-Q          Some   Spaced  Co 3M                                         1234        20261102    edgar/data/1234/0001234567-26-000001.txt
1-A/A            Elektros, Inc.                                                1852616     20251211    edgar/data/1852616/0001852616-25-000004.txt
"""


def test_form_index_inline():
    rows = parse_form_index(FORM_IDX.encode())
    assert [r.form for r in rows] == ["10-Q", "NT 10-Q", "1-A/A"]
    assert rows[0].cik == 2115436 and rows[0].accession_number == "0002115436-26-000020"
    assert rows[0].company_name == "ExxonMobil Holdings Corp"
    assert rows[1].company_name == "Some   Spaced  Co 3M"
    assert rows[2].date_filed == date(2025, 12, 11)  # differs from the file date: kept


def test_form_index_bad_row_is_an_error():
    with pytest.raises(ParseError):
        parse_form_index((FORM_IDX + "garbage line without columns\n").encode())
    with pytest.raises(ParseError):
        parse_form_index(b"no header at all\n")


def test_form_index_empty_body_after_header():
    header_only = FORM_IDX.split("10-Q ")[0]
    assert parse_form_index(header_only.encode()) == ()


MASTER_IDX = """Description:           Master Index of EDGAR Dissemination Feed
Last Data Received:    November 9, 2026

CIK|Company Name|Form Type|Date Filed|Filename
--------------------------------------------------------------------------------
2115436|ExxonMobil Holdings Corp|10-Q|2026-11-02|edgar/data/2115436/0002115436-26-000020.txt
99|Odd | Name|NT 10-Q|2026-10-01|edgar/data/99/0000000099-26-000005.txt
"""


def test_master_index_inline():
    rows = parse_master_index(MASTER_IDX.encode("latin-1"))
    assert len(rows) == 2
    assert rows[0].accession_number == "0002115436-26-000020"
    assert rows[0].date_filed == date(2026, 11, 2)
    assert rows[1].company_name == "Odd | Name" and rows[1].form == "NT 10-Q"


def test_master_index_latin1_name():
    body = MASTER_IDX.replace("Odd | Name", "Soci\u00e9t\u00e9").encode("latin-1")
    assert parse_master_index(body)[1].company_name == "Soci\u00e9t\u00e9"


def test_master_index_bad_row():
    with pytest.raises(ParseError):
        parse_master_index((MASTER_IDX + "1|x|10-K|2026-01-01|edgar/data/1/nofile\n").encode())


# ------------------------------------------------------------ filing index


def _index(*files: tuple[str, str]) -> bytes:
    return json.dumps(
        {"directory": {"item": [{"name": n, "size": s, "type": "x"} for n, s in files]}}
    ).encode()


def test_filing_index_counts_report_files_and_sizes():
    idx = parse_filing_index(
        _index(("R1.htm", "6000"), ("R2.htm", ""), ("R3.xml", "10"), ("FilingSummary.xml", "5"),
               ("a.htm", "1"), ("R1x.htm", "1"))
    )  # fmt: skip
    assert idx.report_file_count == 3
    assert ("R2.htm", None) in idx.files and ("R1.htm", 6000) in idx.files


def test_filing_index_garbage():
    with pytest.raises(ParseError):
        parse_filing_index(b'{"directory": 3}')


@pytest.mark.parametrize(
    ("files", "expected"),
    [
        # inline XBRL wins even when other xml files exist
        (
            ["a_htm.xml", "a.xsd", "a_cal.xml", "a_lab.xml", "FilingSummary.xml", "R1.xml"],
            "a_htm.xml",
        ),
        # pre-inline: stem equal to the single xsd
        (
            [
                "aapl-20090926.xml",
                "aapl-20090926.xsd",
                "aapl-20090926_cal.xml",
                "defnref.xml",
                "FilingSummary.xml",
                "R1.xml",
                "R2.xml",
            ],
            "aapl-20090926.xml",
        ),
        # never R<n>.xml, defnref, FilingSummary
        (["defnref.xml", "FilingSummary.xml", "R1.xml", "x.xsd"], None),
        # no XBRL at all
        (["d10k.htm", "0001-index.html"], None),
        # xml that does not share the xsd stem is not an instance
        (["other.xml", "tm-20190331.xsd"], None),
        # linkbases only
        (["x_cal.xml", "x_def.xml", "x_lab.xml", "x_pre.xml", "x.xsd"], None),
        # exhibit schema next to the real one: only the stem that has a matching xml counts
        (["ex.xsd", "tm-20190331.xsd", "tm-20190331.xml"], "tm-20190331.xml"),
        # case-insensitive extension
        (["A_HTM.XML"], "A_HTM.XML"),
    ],
)
def test_pick_instance_rule(files, expected):
    assert pick_instance(_index(*[(f, "1") for f in files])) == expected


def test_pick_instance_ambiguous_old_style_is_none():
    files = ["a.xml", "b.xml", "a.xsd", "b.xsd"]
    assert pick_instance(_index(*[(f, "1") for f in files])) is None


# ----------------------------------------------------------------- instance

INSTANCE = b"""<?xml version="1.0"?>
<xbrli:xbrl xmlns:xbrli="http://www.xbrl.org/2003/instance"
  xmlns:dei="http://xbrl.sec.gov/dei/2014-01-31" xmlns:us-gaap="http://fasb.org/us-gaap/2014-01-31"
  xmlns:ex="http://example.com/ns">
  <xbrli:context id="c1"/>
  <dei:DocumentType contextRef="c1">10-K</dei:DocumentType>
  <dei:DocumentFiscalYearFocus contextRef="c1">2014</dei:DocumentFiscalYearFocus>
  <dei:DocumentFiscalPeriodFocus contextRef="c1">Q4</dei:DocumentFiscalPeriodFocus>
  <dei:DocumentPeriodEndDate contextRef="c1">2014-12-31</dei:DocumentPeriodEndDate>
  <dei:EntityFilerCategory contextRef="c1">Large Accelerated Filer</dei:EntityFilerCategory>
  <dei:AmendmentFlag contextRef="c1">true</dei:AmendmentFlag>
  <dei:AmendmentDescription contextRef="c1">Why we amend</dei:AmendmentDescription>
  <dei:DocumentFinStmtErrorCorrectionFlag contextRef="c1">false</dei:DocumentFinStmtErrorCorrectionFlag>
  <us-gaap:Assets contextRef="c1" unitRef="usd">5</us-gaap:Assets>
  <us-gaap:Liabilities contextRef="c1" unitRef="usd">3</us-gaap:Liabilities>
  <ex:Custom contextRef="c1">x</ex:Custom>
  <dei:EntityCommonStockSharesOutstanding contextRef="c1" unitRef="s">7</dei:EntityCommonStockSharesOutstanding>
</xbrli:xbrl>"""


def test_parse_cover_tags_inline_sample():
    t = parse_cover_tags(INSTANCE)
    assert t.fiscal_year == 2014 and t.fiscal_period == "Q4" and t.document_type == "10-K"
    assert t.period_end_date == date(2014, 12, 31)
    assert t.filer_category == "Large Accelerated Filer"
    assert t.amendment_flag is True and t.amendment_description == "Why we amend"
    assert t.error_correction_flag is False
    assert t.current_reporting_status is None
    assert t.non_dei_fact_count == 3  # two us-gaap plus one custom; dei facts excluded


def test_parse_cover_tags_other_dei_year_and_absent_tags():
    xml = (
        b'<xbrl xmlns="http://www.xbrl.org/2003/instance" '
        b'xmlns:dei="http://xbrl.sec.gov/dei/2025"><dei:DocumentType contextRef="c">20-F'
        b"</dei:DocumentType></xbrl>"
    )
    t = parse_cover_tags(xml)
    assert t.document_type == "20-F" and t.fiscal_year is None and t.amendment_flag is None
    assert t.non_dei_fact_count == 0


def test_parse_cover_tags_2009_era_xbrl_us_dei_namespace():
    xml = (
        b'<xbrl xmlns="http://www.xbrl.org/2003/instance" xmlns:dei="http://xbrl.us/dei/2009-01-31"'
        b' xmlns:dei-ent="http://xbrl.us/dei-ent/2009-01-31">'
        b'<dei:EntityFilerCategory contextRef="c">Large Accelerated Filer</dei:EntityFilerCategory>'
        b'<dei:AmendmentFlag contextRef="c">false</dei:AmendmentFlag>'
        b'<dei-ent:Other contextRef="c">x</dei-ent:Other></xbrl>'
    )
    t = parse_cover_tags(xml)
    assert t.filer_category == "Large Accelerated Filer" and t.amendment_flag is False
    assert t.non_dei_fact_count == 1  # dei-ent is not dei


def test_parse_cover_tags_malformed():
    with pytest.raises(ParseError):
        parse_cover_tags(b"<xbrl><unclosed>")


# ------------------------------------------------------------- rendered cover


def _cover_html(rows: list[tuple[str, str]]) -> bytes:
    body = "".join(
        f'<tr class="re"><td class="pl"><a class="a" href="javascript:void(0);">{label}</a></td>'
        f'<td class="text">{value}<span></span></td><td class="text">&#160;<span></span></td></tr>'
        for label, value in rows
    )
    return (
        '<html><body><table class="report"><tr><th class="tl" rowspan="2">Cover Page - USD ($)'
        '</th><th class="th">12 Months Ended</th></tr>'
        f"{body}</table></body></html>"
    ).encode()


def test_parse_cover_page_labels_and_values():
    html = _cover_html(
        [
            ("Cover [Abstract]", ""),
            ("DOCUMENT TYPE", "10-K/A"),
            ("Document Fiscal Year Focus", "2020"),
            ("Document Fiscal Period Focus", "FY"),
            ("Document Period End Date", "Dec. 31,  2020"),
            ("Entity Filer Category [Fake]", "Large Accelerated Filer"),
            ("Amendment Flag", "true"),
            ("Amendment Description", "Amendment No 1 &amp; more"),
            ("Document Financial Statement Error Correction [Flag]", "false"),
            ("Entity Current Reporting Status", "Yes"),
        ]
    )
    t = parse_cover_page(html)
    assert t.document_type == "10-K/A" and t.fiscal_year == 2020 and t.fiscal_period == "FY"
    assert t.period_end_date == date(2020, 12, 31)
    assert t.filer_category == "Large Accelerated Filer"
    assert t.amendment_flag is True and t.amendment_description == "Amendment No 1 & more"
    assert t.error_correction_flag is False
    assert t.current_reporting_status == "Yes"
    assert t.non_dei_fact_count == -1


def test_parse_cover_page_label_without_brackets_and_missing_rows():
    html = _cover_html(
        [
            ("Document Type", "10-K"),
            ("Document Financial Statement Error Correction Flag", "true"),
            ("Document Period End Date", "May 31, 2025"),
        ]
    )
    t = parse_cover_page(html)
    assert t.error_correction_flag is True
    assert t.period_end_date == date(2025, 5, 31)
    assert t.fiscal_year is None and t.amendment_flag is None and t.filer_category is None


def test_parse_cover_page_not_a_cover():
    with pytest.raises(ParseError):
        parse_cover_page(b"<html><body><table><tr><td>Balance</td><td>1</td></tr></table></html>")
    with pytest.raises(ParseError):
        parse_cover_page(b"")


# --------------------------------------------------------------- concepts


def _concept(units: dict) -> bytes:
    return json.dumps({"cik": 1, "units": units}).encode()


def test_concept_labels_mode_and_consistency():
    f = lambda accn, fy, fp, form="10-K", filed="2026-03-01": {  # noqa: E731
        "end": "2025-12-31", "val": 1, "accn": accn, "fy": fy, "fp": fp, "form": form,
        "filed": filed,
    }  # fmt: skip
    body = _concept(
        {
            "shares": [f("A-1", 2025, "FY"), f("A-1", 2025, "FY"), f("A-1", 2024, "Q4")],
            "pure": [f("B-1", 2025, "Q1", "10-Q", "2026-05-01")],
        }
    )
    labels = parse_concept_labels(body)
    a, b = labels["A-1"], labels["B-1"]
    assert (a.fiscal_year, a.fiscal_period, a.consistent) == (2025, "FY", False)
    assert a.form == "10-K" and a.filed == date(2026, 3, 1)
    assert (b.fiscal_year, b.fiscal_period, b.consistent, b.form) == (2025, "Q1", True, "10-Q")


def test_concept_labels_missing_fy_is_none():
    body = _concept({"shares": [{"end": "2009-01-01", "val": 1, "accn": "X", "form": "10-K",
                                 "filed": "2009-02-01"}]})  # fmt: skip
    label = parse_concept_labels(body)["X"]
    assert label.fiscal_year is None and label.fiscal_period is None and label.consistent


def test_concept_garbage():
    with pytest.raises(ParseError):
        parse_concept_labels(b"nope")
    with pytest.raises(ParseError):
        parse_public_float(b'{"units": []}')


def test_public_float_usd_only():
    body = _concept(
        {
            "USD": [
                {"end": "2025-06-30", "val": 1500000000, "accn": "A", "form": "10-K",
                 "filed": "2026-02-01"},
                {"end": "2024-06-30", "val": 1, "accn": "A", "form": "10-K", "filed": "2026-02-01"},
            ],
            "shares": [{"end": "2025-06-30", "val": 99, "accn": "S", "form": "10-K",
                        "filed": "2026-02-01"}],
        }
    )  # fmt: skip
    assert parse_public_float(body) == {"A": (1500000000.0, date(2025, 6, 30))}
