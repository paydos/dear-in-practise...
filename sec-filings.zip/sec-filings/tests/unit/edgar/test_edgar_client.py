"""EdgarClient: status-code behaviour, pacing, budget, offline fixtures. No network."""

from __future__ import annotations

import gzip
import hashlib

import httpx
import pytest

from sec_filings.edgar.client import EdgarClient
from sec_filings.errors import EdgarHTTPError, RequestBudgetExceeded, SecAccessDenied

URL = "https://data.sec.gov/submissions/CIK0000320193.json"
UA = "unit-test contact@example.com"


class FakeTime:
    """A clock that only moves when the client 'sleeps'."""

    def __init__(self) -> None:
        self.now = 1000.0
        self.sleeps: list[float] = []

    def clock(self) -> float:
        return self.now

    def sleep(self, seconds: float) -> None:
        self.sleeps.append(seconds)
        self.now += seconds


def make_client(handler, **kw) -> tuple[EdgarClient, FakeTime]:
    t = FakeTime()
    client = EdgarClient(
        UA,
        transport=httpx.MockTransport(handler),
        sleep=t.sleep,
        clock=t.clock,
        **kw,
    )
    return client, t


def test_headers_are_exactly_user_agent_and_accept_encoding():
    seen: list[httpx.Request] = []

    def handler(req: httpx.Request) -> httpx.Response:
        seen.append(req)
        return httpx.Response(200, content=b"{}")

    client, _ = make_client(handler)
    client.get(URL)
    headers = dict(seen[0].headers)
    assert headers["user-agent"] == UA
    assert headers["accept-encoding"] == "gzip, deflate"
    assert set(headers) == {"host", "user-agent", "accept-encoding"}


def test_200_returns_decompressed_body_and_sha256():
    payload = b'{"hello": "world"}' * 50

    def handler(req: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200, content=gzip.compress(payload), headers={"Content-Encoding": "gzip"}
        )

    client, _ = make_client(handler)
    resp = client.get(URL)
    assert resp.status == 200
    assert resp.body == payload
    assert resp.sha256 == hashlib.sha256(payload).hexdigest()
    assert resp.from_fixture is False
    assert resp.fetched_at.tzinfo is not None
    assert resp.url == URL


def test_404_is_returned_not_raised_and_reported():
    got = []
    client, _ = make_client(
        lambda req: httpx.Response(404, content=b"nope"), on_response=got.append
    )
    resp = client.get(URL)
    assert resp.status == 404
    assert [r.status for r in got] == [404]


def test_on_response_called_for_200():
    got = []
    client, _ = make_client(lambda req: httpx.Response(200, content=b"x"), on_response=got.append)
    client.get(URL)
    assert len(got) == 1 and got[0].body == b"x"


def test_403_raises_at_once_without_retry():
    calls = []

    def handler(req: httpx.Request) -> httpx.Response:
        calls.append(1)
        return httpx.Response(403)

    got = []
    client, t = make_client(handler, on_response=got.append)
    with pytest.raises(SecAccessDenied):
        client.get(URL)
    assert len(calls) == 1
    assert t.sleeps == []
    assert got == []


@pytest.mark.parametrize("status", [429, 500, 502, 503])
def test_retryable_status_then_success(status):
    responses = [httpx.Response(status), httpx.Response(status), httpx.Response(200, content=b"ok")]

    def handler(req: httpx.Request) -> httpx.Response:
        return responses.pop(0)

    client, t = make_client(handler, requests_per_second=1000)
    resp = client.get(URL)
    assert resp.body == b"ok"
    assert client.requests_made == 3
    assert len(t.sleeps) == 2


def test_gives_up_after_max_retries_with_edgar_http_error():
    calls = []

    def handler(req: httpx.Request) -> httpx.Response:
        calls.append(1)
        return httpx.Response(503)

    client, _ = make_client(handler, max_retries=2, request_budget=50)
    with pytest.raises(EdgarHTTPError):
        client.get(URL)
    assert len(calls) == 3  # first try plus two retries


def test_transport_errors_are_retried():
    attempts = []

    def handler(req: httpx.Request) -> httpx.Response:
        attempts.append(1)
        if len(attempts) < 3:
            raise httpx.ConnectError("reset", request=req)
        return httpx.Response(200, content=b"fine")

    client, _ = make_client(handler)
    assert client.get(URL).body == b"fine"
    assert len(attempts) == 3


def test_transport_errors_exhaust_into_edgar_http_error():
    def handler(req: httpx.Request) -> httpx.Response:
        raise httpx.ReadTimeout("slow", request=req)

    client, _ = make_client(handler, max_retries=1)
    with pytest.raises(EdgarHTTPError):
        client.get(URL)


def test_other_4xx_is_not_retried():
    calls = []

    def handler(req: httpx.Request) -> httpx.Response:
        calls.append(1)
        return httpx.Response(400)

    client, _ = make_client(handler)
    with pytest.raises(EdgarHTTPError):
        client.get(URL)
    assert len(calls) == 1


def test_backoff_grows_exponentially_with_bounded_jitter():
    def handler(req: httpx.Request) -> httpx.Response:
        return httpx.Response(500)

    client, t = make_client(handler, max_retries=3, requests_per_second=1000, request_budget=50)
    with pytest.raises(EdgarHTTPError):
        client.get(URL)
    backoffs = [s for s in t.sleeps if s >= 0.4]
    assert len(backoffs) == 3
    for attempt, delay in enumerate(backoffs):
        base = 0.5 * 2**attempt
        assert base <= delay <= base * 1.5 + 1e-9


def test_retry_after_header_is_honoured_for_429():
    responses = [httpx.Response(429, headers={"Retry-After": "7"}), httpx.Response(200)]
    client, t = make_client(lambda req: responses.pop(0), requests_per_second=1000)
    client.get(URL)
    assert max(t.sleeps) >= 7


def test_budget_checked_before_sending():
    calls = []

    def handler(req: httpx.Request) -> httpx.Response:
        calls.append(1)
        return httpx.Response(200, content=b"x")

    client, _ = make_client(handler, request_budget=2)
    client.get(URL)
    client.get(URL)
    with pytest.raises(RequestBudgetExceeded):
        client.get(URL)
    assert len(calls) == 2
    assert client.requests_made == 2


def test_retries_count_against_the_budget():
    client, _ = make_client(lambda req: httpx.Response(500), request_budget=2, max_retries=5)
    with pytest.raises(RequestBudgetExceeded):
        client.get(URL)
    assert client.requests_made == 2


def test_pacing_spaces_requests_by_the_rate():
    client, t = make_client(
        lambda req: httpx.Response(200, content=b"x"), requests_per_second=4, request_budget=100
    )
    for _ in range(5):
        client.get(URL)
    # First request is free; each following one waits a full 0.25 s token interval.
    assert t.sleeps == pytest.approx([0.25] * 4)
    assert t.now - 1000.0 == pytest.approx(1.0)


def test_pacing_credits_time_spent_elsewhere():
    client, t = make_client(lambda req: httpx.Response(200, content=b"x"), requests_per_second=4)
    client.get(URL)
    t.now += 10  # long gap: the bucket refills, but only to one token (no burst)
    client.get(URL)
    client.get(URL)
    assert t.sleeps == pytest.approx([0.25])


def test_bucket_is_shared_across_urls():
    client, t = make_client(lambda req: httpx.Response(200, content=b"x"), requests_per_second=2)
    client.get(URL)
    client.get("https://www.sec.gov/files/company_tickers.json")
    assert t.sleeps == pytest.approx([0.5])


def test_context_manager_closes():
    client, _ = make_client(lambda req: httpx.Response(200, content=b"x"))
    with client as c:
        c.get(URL)
    assert client._http is not None and client._http.is_closed


# ------------------------------------------------------------------ offline mode


def test_offline_reads_plain_fixture(tmp_path):
    path = tmp_path / "data.sec.gov" / "submissions" / "CIK0000320193.json"
    path.parent.mkdir(parents=True)
    path.write_bytes(b'{"a": 1}')
    got = []
    client = EdgarClient(UA, fixtures_dir=tmp_path, on_response=got.append)
    resp = client.get(URL)
    assert resp.status == 200 and resp.body == b'{"a": 1}' and resp.from_fixture
    assert resp.sha256 == hashlib.sha256(b'{"a": 1}').hexdigest()
    assert client.requests_made == 1
    assert len(got) == 1


def test_offline_reads_gz_fixture_decompressed(tmp_path):
    path = tmp_path / "data.sec.gov" / "submissions" / "CIK0000320193.json.gz"
    path.parent.mkdir(parents=True)
    path.write_bytes(gzip.compress(b"big body"))
    client = EdgarClient(UA, fixtures_dir=tmp_path)
    resp = client.get(URL)
    assert resp.status == 200 and resp.body == b"big body"
    assert resp.sha256 == hashlib.sha256(b"big body").hexdigest()


def test_offline_prefers_plain_over_gz(tmp_path):
    d = tmp_path / "data.sec.gov" / "submissions"
    d.mkdir(parents=True)
    (d / "CIK0000320193.json").write_bytes(b"plain")
    (d / "CIK0000320193.json.gz").write_bytes(gzip.compress(b"zipped"))
    assert EdgarClient(UA, fixtures_dir=tmp_path).get(URL).body == b"plain"


def test_offline_missing_fixture_is_404_with_empty_body(tmp_path):
    got = []
    client = EdgarClient(UA, fixtures_dir=tmp_path, on_response=got.append)
    resp = client.get(URL)
    assert resp.status == 404 and resp.body == b"" and resp.from_fixture
    assert client.requests_made == 1
    assert [r.status for r in got] == [404]


def test_offline_never_sleeps_and_counts_reads(tmp_path):
    slept = []
    client = EdgarClient(
        UA, fixtures_dir=tmp_path, requests_per_second=1, sleep=slept.append, request_budget=100
    )
    for _ in range(5):
        client.get(URL)
    assert slept == []
    assert client.requests_made == 5


def test_offline_budget_applies_too(tmp_path):
    client = EdgarClient(UA, fixtures_dir=tmp_path, request_budget=1)
    client.get(URL)
    with pytest.raises(RequestBudgetExceeded):
        client.get(URL)
