from __future__ import annotations

from datetime import date
from pathlib import Path

import pytest

from sec_filings.companies import CikSpan, load_companies
from sec_filings.errors import ConfigError

REPO = Path(__file__).resolve().parents[2]


def write(tmp_path: Path, csv: str, yml: str = "") -> tuple[Path, Path]:
    c, y = tmp_path / "companies.csv", tmp_path / "companies.yml"
    c.write_text(csv, encoding="utf-8")
    y.write_text(yml, encoding="utf-8")
    return c, y


def test_csv_tickers_are_uppercased_deduplicated_and_ordered(tmp_path):
    csv, yml = write(tmp_path, "ticker\naapl\n\n  msft \nAAPL\n,\nxom\n")
    assert [c.ticker for c in load_companies(csv, yml)] == ["AAPL", "MSFT", "XOM"]


def test_ticker_without_a_yaml_entry_is_unreviewed(tmp_path):
    csv, yml = write(tmp_path, "ticker\nNFLX\n")
    (nflx,) = load_companies(csv, yml)
    assert nflx == type(nflx)("NFLX", False, (), None, None, None, {}, None)


def test_missing_yaml_file_means_everything_is_unreviewed(tmp_path):
    csv, _ = write(tmp_path, "ticker\nAAPL\n")
    (aapl,) = load_companies(csv, tmp_path / "absent.yml")
    assert not aapl.reviewed and aapl.ciks == ()


def test_reviewed_entry_carries_spans_flags_and_overrides(tmp_path):
    csv, yml = write(
        tmp_path,
        "ticker\nXOM\nLCID\n",
        """
XOM:
  ciks:
    - {cik: 34088, valid_from: null, valid_to: 2026-06-30, source: manual, note: "old"}
    - {cik: 2115436, valid_from: 2026-07-01, valid_to: null, source: successor_8k}
  foreign_filer: false
  notes: >-
    two lines
    of notes
LCID:
  ciks: [{cik: 1811210, valid_from: null, valid_to: null, source: ticker_file}]
  pre_merger_until: 2021-07-23
  fiscal_year_end: "0331"
  overrides:
    0001-1:
      amendment_scope: full
      fiscal_year: 2020
""",
    )
    xom, lcid = load_companies(csv, yml)
    assert xom.reviewed and xom.foreign_filer is False
    assert xom.ciks == (
        CikSpan(34088, None, date(2026, 6, 30), "manual", "old"),
        CikSpan(2115436, date(2026, 7, 1), None, "successor_8k", None),
    )
    assert xom.notes == "two lines of notes"
    assert lcid.foreign_filer is None  # not stated: the flow decides from the filings
    assert lcid.pre_merger_until == date(2021, 7, 23)
    assert lcid.fiscal_year_end == "0331"
    assert lcid.overrides == {"0001-1": {"amendment_scope": "full", "fiscal_year": "2020"}}


def test_bad_inputs_fail_with_a_clear_message(tmp_path):
    csv, yml = write(tmp_path, "symbol\nAAPL\n")
    with pytest.raises(ConfigError, match="ticker"):
        load_companies(csv, yml)
    csv, yml = write(tmp_path, "ticker\nAAPL\n", "AAPL:\n  ciks: [{cik: 1, source: bogus}]\n")
    with pytest.raises(ConfigError, match="source"):
        load_companies(csv, yml)
    bad_date = "AAPL:\n  ciks: [{cik: 1}]\n  pre_merger_until: soon\n"
    csv, yml = write(tmp_path, "ticker\nAAPL\n", bad_date)
    with pytest.raises(ConfigError, match="YYYY-MM-DD"):
        load_companies(csv, yml)
    with pytest.raises(ConfigError, match="repo root.*COMPANIES_CSV"):
        load_companies(tmp_path / "missing.csv", yml)


def test_the_real_company_files_load_and_every_ticker_is_reviewed():
    companies = load_companies(REPO / "companies.csv", REPO / "companies.yml")
    assert len(companies) == 20
    assert all(c.reviewed and c.ciks for c in companies)
    xom = next(c for c in companies if c.ticker == "XOM")
    assert [s.cik for s in xom.ciks] == [34088, 2115436]
    aapl = next(c for c in companies if c.ticker == "AAPL")
    assert aapl.overrides["0001193125-10-012091"]["amendment_kind"] == "accounting_change"
    lcid = next(c for c in companies if c.ticker == "LCID")
    assert lcid.pre_merger_until == date(2021, 7, 23)
    foreign = sorted(c.ticker for c in companies if c.foreign_filer)
    assert foreign == ["BABA", "NVO", "SAP", "SHEL", "TM"]
