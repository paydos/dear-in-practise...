from pathlib import Path

import pytest

from sec_filings.config import DEFAULT_USER_AGENT, load_settings
from sec_filings.errors import ConfigError


def test_missing_database_url():
    with pytest.raises(ConfigError, match="DATABASE_URL"):
        load_settings({})


def test_default_user_agent_is_real():
    """Release guard (D-09): the shipped default must carry a real contact, never a placeholder
    and never an employer address."""
    name, _, email = DEFAULT_USER_AGENT.rpartition(" ")
    assert name.strip(), "User-Agent needs a name before the email"
    assert "@" in email and "." in email.split("@", 1)[1]
    lowered = DEFAULT_USER_AGENT.lower()
    for forbidden in ("replace_me", "example.", "invalid"):
        assert forbidden not in lowered


def test_defaults():
    s = load_settings({"DATABASE_URL": "postgresql://x/y"})
    assert s.database_url == "postgresql://x/y"
    assert s.user_agent == DEFAULT_USER_AGENT
    assert s.requests_per_second == 4.0
    assert s.sync_request_budget == 200
    assert s.backfill_request_budget == 6000
    assert s.fixtures_dir is None
    assert s.heartbeat_url is None
    assert s.companies_csv == Path("companies.csv")


def test_rate_capped_at_nine():
    s = load_settings({"DATABASE_URL": "x", "SEC_REQUESTS_PER_SECOND": "50"})
    assert s.requests_per_second == 9
    s = load_settings({"DATABASE_URL": "x", "SEC_REQUESTS_PER_SECOND": "2.5"})
    assert s.requests_per_second == 2.5


def test_fixtures_dir_and_others():
    s = load_settings(
        {
            "DATABASE_URL": "x",
            "SEC_FIXTURES_DIR": "tests/fixtures/edgar",
            "SEC_USER_AGENT": "me me@example.com",
            "HEARTBEAT_URL": "https://hc.example/ping",
        }
    )
    assert s.fixtures_dir == Path("tests/fixtures/edgar")
    assert s.user_agent == "me me@example.com"
    assert s.heartbeat_url == "https://hc.example/ping"


def test_path_settings_come_from_the_environment():
    s = load_settings(
        {
            "DATABASE_URL": "x",
            "COMPANIES_CSV": "/data/companies.csv",
            "COMPANIES_YML": "/data/companies.yml",
            "REPORTS_DIR": "/data/reports",
        }
    )
    assert s.companies_csv == Path("/data/companies.csv")
    assert s.companies_yml == Path("/data/companies.yml")
    assert s.reports_dir == Path("/data/reports")
    d = load_settings({"DATABASE_URL": "x"})
    assert (d.companies_csv, d.companies_yml, d.reports_dir) == (
        Path("companies.csv"),
        Path("companies.yml"),
        Path("reports"),
    )
