"""The Stop hook blocks only on a real failure and never traps the agent (PLAN.md 10.3)."""

from __future__ import annotations

import importlib.util
import json
import subprocess
from pathlib import Path

import pytest

SCRIPT = Path(__file__).resolve().parents[2] / "scripts" / "stop_hook.py"
spec = importlib.util.spec_from_file_location("stop_hook", SCRIPT)
stop_hook = importlib.util.module_from_spec(spec)
spec.loader.exec_module(stop_hook)


def done(returncode: int, stdout: str = "", stderr: str = "") -> subprocess.CompletedProcess:
    return subprocess.CompletedProcess([], returncode, stdout, stderr)


@pytest.fixture
def uv_present(monkeypatch):
    monkeypatch.setattr(stop_hook.shutil, "which", lambda name: "/usr/bin/uv")


def script(monkeypatch, tests, verify):
    """Mock subprocess.run: first call is pytest, second is verify. Returns the call log."""
    calls = []
    replies = iter([tests, verify])

    def fake_run(cmd, **kwargs):
        calls.append((cmd, kwargs))
        reply = next(replies)
        if isinstance(reply, Exception):
            raise reply
        return reply

    monkeypatch.setattr(stop_hook.subprocess, "run", fake_run)
    return calls


def test_tests_pass_and_no_database_allows_stop(uv_present, monkeypatch, capsys):
    calls = script(
        monkeypatch,
        done(0, "10 passed"),
        done(0, "database: not reachable (refused)\nNo database is reachable."),
    )
    assert stop_hook.main("") == 0
    assert "no database" in capsys.readouterr().err
    assert calls[0][1]["timeout"] == 60
    assert "--if-db" in calls[1][0]


def test_tests_fail_blocks_and_shows_tail(uv_present, monkeypatch, capsys):
    calls = script(monkeypatch, done(1, "FAILED tests/unit/test_x.py::test_y - boom"), done(0))
    assert stop_hook.main("") == 2
    assert "test_y" in capsys.readouterr().err
    assert len(calls) == 1  # verify is not reached


def test_verify_red_blocks(uv_present, monkeypatch, capsys):
    script(monkeypatch, done(0, "ok"), done(1, "checks: 1 red\nRESULT: RED"))
    assert stop_hook.main("") == 2
    assert "RESULT: RED" in capsys.readouterr().err


def test_verify_ok_allows_stop(uv_present, monkeypatch):
    script(monkeypatch, done(0, "ok"), done(0, "RESULT: OK"))
    assert stop_hook.main("") == 0


def test_stop_hook_active_exits_immediately(monkeypatch):
    def boom(*args, **kwargs):
        raise AssertionError("must not run anything")

    monkeypatch.setattr(stop_hook.subprocess, "run", boom)
    monkeypatch.setattr(stop_hook.shutil, "which", boom)
    assert stop_hook.main(json.dumps({"stop_hook_active": True})) == 0


def test_uv_missing_allows_stop(monkeypatch, capsys):
    monkeypatch.setattr(stop_hook.shutil, "which", lambda name: None)

    def boom(*args, **kwargs):
        raise AssertionError("must not run anything")

    monkeypatch.setattr(stop_hook.subprocess, "run", boom)
    assert stop_hook.main("") == 0
    assert "uv" in capsys.readouterr().err


def test_test_timeout_allows_stop(uv_present, monkeypatch, capsys):
    script(monkeypatch, subprocess.TimeoutExpired("pytest", 60), done(0))
    assert stop_hook.main("") == 0
    assert "skipped" in capsys.readouterr().err


def test_unexpected_exception_allows_stop(uv_present, monkeypatch):
    script(monkeypatch, done(0, "ok"), OSError("disk on fire"))
    assert stop_hook.main("") == 0


ROOT = SCRIPT.parent.parent


def test_settings_run_the_hook_from_the_project_dir_and_deny_brief_writes():
    settings = json.loads((ROOT / ".claude" / "settings.json").read_text(encoding="utf-8"))
    command = settings["hooks"]["Stop"][0]["hooks"][0]["command"]
    assert command == 'python "$CLAUDE_PROJECT_DIR/scripts/stop_hook.py"'
    deny = settings["permissions"]["deny"]
    assert "Edit(brief.md)" in deny and "Write(brief.md)" in deny


def test_hook_resolves_its_root_from_its_own_path_not_the_cwd():
    assert stop_hook.ROOT == ROOT
