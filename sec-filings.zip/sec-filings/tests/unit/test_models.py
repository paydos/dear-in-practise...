import dataclasses
from datetime import UTC, date, datetime
from uuid import uuid4

import pytest

from sec_filings import models as m

D = date(2025, 9, 27)
DT = datetime(2025, 10, 31, 18, 0, tzinfo=UTC)


def _raw() -> m.RawFiling:
    return m.RawFiling(
        "0000320193-25-000079",
        320193,
        "10-K",
        D,
        DT,
        D,
        ("2.02",),
        "a.htm",
        "10-K",
        True,
        True,
        100,
        "001-36743",
        "251",
    )


def _frozen_instances() -> list:
    cover = m.CoverTags(
        2025, "FY", "10-K", D, "Large Accelerated Filer", False, None, False, "Yes", 0
    )
    return [
        m.FormerName("Old Co", None, D),
        m.PageRef("CIK0000320193-submissions-001.json", 10, D, D),
        m.CompanyMeta(320193, "Apple Inc.", ("AAPL",), "0926", "Large Accelerated Filer", ()),
        _raw(),
        m.SubmissionsDoc(
            m.CompanyMeta(320193, "Apple Inc.", ("AAPL",), "0926", None, ()), (_raw(),), ()
        ),
        cover,
        m.IndexEntry("10-K", "Apple Inc.", 320193, D, "0000320193-25-000079"),
        m.Label(2025, "FY", "filing_dei", "high"),
        m.FetchedResponse("https://x", 200, b"", "abc", DT, False),
        m.Version("0000320193-25-000079", D, DT, False, None),
        m.CanonicalChoice("a", "a", "a", 1),
        m.ScopeSignals(True, None, 0.9, None),
        m.DueDates(D, D, "10-K 60d"),
        m.CheckResult("C1", "heartbeat", "core", "green", "ok"),
    ]


@pytest.mark.parametrize("obj", _frozen_instances(), ids=lambda o: type(o).__name__)
def test_frozen(obj):
    first = dataclasses.fields(obj)[0].name
    with pytest.raises(dataclasses.FrozenInstanceError):
        setattr(obj, first, "changed")


def test_check_result_defaults():
    r = m.CheckResult("C1", "n", "core", "red", "bad")
    assert (r.observed, r.expected, r.company_id) == (None, None, None)


def test_mutable_results():
    run = m.RunResult(uuid4(), "sync", "success", DT, None, 0, 0, 0, 0, [], [], None)
    run.status = "failed"
    assert run.status == "failed"
    rep = m.CheckReport(run.run_id, [], 0, "")
    rep.exit_code = 2
    assert rep.exit_code == 2
