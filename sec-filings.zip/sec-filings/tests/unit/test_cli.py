"""Command line: argument handling that needs no database."""

from __future__ import annotations

import logging
import re
import subprocess
import sys

from typer.testing import CliRunner

from sec_filings.cli import _ProgressHandler, app


def test_check_rejects_a_bad_expect_run_by(monkeypatch):
    monkeypatch.setenv("DATABASE_URL", "postgresql://unused/unused")
    result = CliRunner().invoke(app, ["check", "--expect-run-by", "half past six"])
    assert result.exit_code == 3
    assert "--expect-run-by must be HH:MM" in result.output


def test_check_help_documents_expect_run_by(monkeypatch):
    # FORCE_COLOR in the caller's shell makes the help text coloured; compare the plain text.
    monkeypatch.delenv("FORCE_COLOR", raising=False)
    result = CliRunner().invoke(app, ["check", "--help"])
    assert "--expect-run-by" in re.sub(r"\x1b\[[0-9;]*m", "", result.output)


def test_the_cli_does_not_need_click():
    # Typer >= 0.29 bundles its own click and no longer installs it. A stale click in a dev
    # environment once hid an `import click` that broke every fresh install (trust log T-19).
    # Simulate a fresh install: any `import click` fails, as it does when click is absent.
    # (httpx imports click for its own CLI when it happens to be installed; that is harmless.)
    code = (
        "import sys\n"
        "class NoClick:\n"
        "    def find_spec(self, name, path=None, target=None):\n"
        "        if name == 'click' or name.startswith('click.'):\n"
        "            raise ImportError('click is not installed')\n"
        "sys.meta_path.insert(0, NoClick())\n"
        "import sec_filings.cli\n"
    )
    result = subprocess.run([sys.executable, "-c", code], check=False, capture_output=True)
    assert result.returncode == 0, result.stderr.decode(errors="replace")


def _progress_handlers():
    return [h for h in logging.getLogger("sec_filings").handlers if isinstance(h, _ProgressHandler)]


def test_progress_lines_go_to_stderr_with_time_and_colour(capsys, monkeypatch):
    monkeypatch.setenv("FORCE_COLOR", "1")
    monkeypatch.delenv("NO_COLOR", raising=False)
    log = logging.getLogger("sec_filings.flows")
    handler = _ProgressHandler()
    log.addHandler(handler)
    try:
        log.info("[ 1/20] AAPL: ok", extra={"tone": "ok"})
        log.error("[ 2/20] MSFT: FAILED")
    finally:
        log.removeHandler(handler)
    out = capsys.readouterr()
    assert out.out == ""  # stdout carries the report only
    assert "AAPL: ok" in out.err and "MSFT: FAILED" in out.err
    assert "\x1b[32m" in out.err and "\x1b[31m" in out.err  # green, red
    assert re.search(r"\d\d:\d\d:\d\d", out.err)


def test_no_color_wins(capsys, monkeypatch):
    monkeypatch.setenv("FORCE_COLOR", "1")
    monkeypatch.setenv("NO_COLOR", "1")
    handler = _ProgressHandler()
    handler.emit(logging.LogRecord("sec_filings", logging.ERROR, "", 0, "bad", None, None))
    assert "\x1b[" not in capsys.readouterr().err


def test_quiet_removes_the_progress_handler():
    CliRunner().invoke(app, ["check", "--help"])
    assert len(_progress_handlers()) == 1  # installed once, never stacked
    CliRunner().invoke(app, ["--quiet", "check", "--help"])
    assert _progress_handlers() == []
