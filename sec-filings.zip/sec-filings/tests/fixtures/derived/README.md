﻿# tests/fixtures/derived

Anything here is NOT a byte-exact SEC response.

- `master_2026Q4_excerpt.idx`: derived from https://www.sec.gov/Archives/edgar/full-index/2026/QTR4/master.idx (10,662,072 bytes, 117,459 lines, "Last Data Received: November 9, 2026", fetched 2026-11-10). Kept the 11-line header (through the dashed line) verbatim, then every data line whose CIK is one of our 21 CIKs, in original order (3,201 lines, mostly JPMorgan 424B2). Pipe-delimited, LF line endings, latin-1 safe.
