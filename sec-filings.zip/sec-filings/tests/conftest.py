from __future__ import annotations

import os
import uuid
from pathlib import Path

import psycopg
import pytest
from psycopg import sql

from sec_filings.db.connection import connect
from sec_filings.db.migrate import apply_migrations


@pytest.fixture(scope="session")
def pg_server_uri(tmp_path_factory: pytest.TempPathFactory):
    """Admin URI of a Postgres server: TEST_DATABASE_URL, else an embedded pgserver."""
    url = os.environ.get("TEST_DATABASE_URL")
    if url:
        yield url
        return
    import pgserver

    base = os.environ.get("PGSERVER_DATA")
    datadir = Path(base) / "pytest" if base else tmp_path_factory.mktemp("pgdata")
    datadir.mkdir(parents=True, exist_ok=True)
    srv = pgserver.get_server(datadir, cleanup_mode="stop")
    yield srv.get_uri()
    srv.cleanup()


def _with_dbname(uri: str, dbname: str) -> str:
    info = psycopg.conninfo.conninfo_to_dict(uri)
    info["dbname"] = dbname
    return psycopg.conninfo.make_conninfo(**info)


@pytest.fixture
def db_conn(pg_server_uri: str):
    """A connection to a fresh, migrated database; dropped afterwards."""
    name = f"t_{uuid.uuid4().hex[:12]}"
    with psycopg.connect(pg_server_uri, autocommit=True, connect_timeout=10) as admin:
        admin.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(name)))
    conn = connect(_with_dbname(pg_server_uri, name))
    try:
        apply_migrations(conn)
        conn.commit()
        yield conn
    finally:
        conn.close()
        with psycopg.connect(pg_server_uri, autocommit=True, connect_timeout=10) as admin:
            admin.execute(
                sql.SQL("DROP DATABASE IF EXISTS {} WITH (FORCE)").format(sql.Identifier(name))
            )
