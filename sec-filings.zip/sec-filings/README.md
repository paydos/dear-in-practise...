# SEC filings tracker

Keeps a Postgres table of every 10-K, 10-Q and (for foreign filers) 20-F that the 20 companies in
`companies.csv` have filed with SEC EDGAR. Each filing is labelled with the fiscal year or quarter it covers.

## The one command

```
DATABASE_URL=postgresql://USER:PASSWORD@HOST:5432/DBNAME uv run sec-filings sync
```

Only `DATABASE_URL` is needed. Migrations apply themselves. An empty database is loaded as a full
backfill. No `uv`? Use `pip install .` and then `sec-filings sync` (Python 3.12 or newer).
PowerShell: `$env:DATABASE_URL = "..."` first. `python -m sec_filings sync` also works.

While it runs, progress lines go to stderr with a timestamp, one per company, in colour: green when a
company is done, yellow for a retry or warning, red for a failure. The report goes to stdout.
`sec-filings --quiet sync` turns the progress off; `NO_COLOR=1` keeps it but drops the colour.

```
21:38:25 backfill started: run efff4fd0-..., 20 companies, request budget 6000
21:38:31 [ 1/20] AAPL: fetching
21:39:24 [ 1/20] AAPL: ok, 138 new, 0 updated, 0 unchanged (53.4s, 19 requests so far)
```

## What you get

Tables: `company`, `company_cik`, `company_name_history`, `filing`, `filing_cik_alias`, `report_period`,
`correction_event`, `expected_filing`, `history_page`, `daily_index_reconciliation`, `check_result`,
`run`, `raw_payload`, `raw_fetch`.
Views for analysts: `v_annual_reports`, `v_quarterly_reports`, `v_correction_events`, `v_amendments`,
`v_company_coverage`, `v_morning_check`.

Every filing is a row, keyed by accession number. Each period has one canonical answer: the latest
complete version ([D-03](DECISIONS.md)). Other versions stay on file.

```
$ uv run sec-filings show AAPL 2009
Apple Inc.   fiscal year 2009   (period ended 2009-09-26)
ANSWER   10-K/A  filed 2010-01-25  0001193125-10-012091  complete, accounting change
         label: filing_dei, high confidence via concept
         amends 0001193125-09-214859
         evidence: manual: kind set to 'accounting_change' by a reviewed override; reason: Apple's 10-K/A of 2010-01-25 re-presents fiscal 2009 after voluntarily adopting new revenue-recognition rules retrospectively. A change in accounting principle, not an error correction (trust log T-1).
also     10-K    filed 2009-10-27  0001193125-09-214859  original
expected: due 2009-11-25 (with extension 2009-12-10), large_accelerated [public_float]: received
```

Other commands: `backfill [-t TICKER ...]`, `check [--expect-run-by HH:MM]`,
`show TICKER YEAR [-q 1..3]`, `resolve-companies`, `verify`, `ack C3 YYYY-MM-DD --reason "..."`.
Full table in [AGENTS.md](AGENTS.md).

## How it fits together

```mermaid
flowchart LR
  SEC["SEC EDGAR<br/>submissions, history pages,<br/>concept files, cover pages,<br/>daily index"] -->|"4 req/s, gzip,<br/>User-Agent, budget"| Client["edgar/client.py"]
  Client --> Raw[("raw_payload<br/>raw_fetch")]
  Client --> Domain["domain/<br/>forms, labels, amendments,<br/>corrections, deadlines"]
  Domain --> Filing[("filing<br/>report_period<br/>expected_filing<br/>correction_event")]
  Filing --> Checks["checks/<br/>C1 to C12"]
  Checks --> Report["reports/morning_check_*.md<br/>exit code, heartbeat ping"]
  Filing --> Views["v_annual_reports, v_amendments,<br/>v_correction_events ..."]
  Views --> Users["analysts: SQL, show,<br/>MCP query server"]
```

How the job was built (who planned, who built, who reviewed): [docs/how-it-was-built.md](docs/how-it-was-built.md).

## Query server (MCP)

A small read-only server lets an agent or analyst ask questions without writing SQL. It is an
optional extra; the job never depends on it.

- Start (stdio): `uv run --extra mcp sec-filings mcp`. Claude Code finds it through `.mcp.json`
  (passes `DATABASE_URL` through). Without the extra the command prints the install hint and exits 1.
- Tools: `get_annual_report(company, fiscal_year)`, `get_quarterly_report(company, fiscal_year,
  quarter)`, `list_filings(company, family, since, limit)`, `morning_check(date)`,
  `explain_label(accession)` (label source, confidence, declared vs used year, amendment evidence).
  Answers come from the same code as `sec-filings show`.
- Read-only: no free-SQL tool, fixed parameterised queries, every connection runs
  `SET default_transaction_read_only = on` and a 5 s statement timeout.
- Production: run `scripts/create_reader_role.sql` once, then set `MCP_DATABASE_URL` to the
  `sec_reader` login (SELECT on all tables and views). It falls back to `DATABASE_URL`.
  `.mcp.json` passes both variables through.

## Getting a database

Any Postgres works. Docker: `docker compose up -d db`, then
`postgresql://sec:sec@localhost:5432/sec_filings`. No install: an embedded Postgres via
`scripts/dev_db.py`. Steps are in [AGENTS.md](AGENTS.md), section "Getting a database".

## First-run cost

Measured on 2026-11-10 against the live SEC, 20 companies, empty database:

- 507 requests in 186 seconds, paced at 4 per second, all successful.
- 6,419 filings stored. 0 red checks.
- A daily sync after that used 22 requests.
- Repeated from an empty database on 2026-11-12, an evening when the SEC was slow and answered some
  requests with 503 (retried): 500 requests in 758 seconds, the same 6,419 filings, 0 red.

A backfill is limited to 6,000 requests and a daily sync to 200. Hitting the limit stops the run before
the next request is sent.

## The morning check

`sync` ends by running the checks. `sec-filings check` runs them alone. Each run writes
`reports/morning_check_YYYY-MM-DD.md` and a JSON twin. The first lines give the verdict and the red items.
A real red report is in [reports/sample_red_report.md](reports/sample_red_report.md).

| Exit code | Meaning | What to do |
|---|---|---|
| 0 | All green | Nothing. |
| 1 | Amber only | Read the amber lines. They are explained, not ignored. |
| 2 | At least one red | The data or the run is wrong. Use [docs/runbooks/investigate-red-check.md](docs/runbooks/investigate-red-check.md). |
| 3 | The run failed, the SEC was unreachable, or the config is wrong | Read the error. A 403 has its own runbook. |
| 4 | `sync` was skipped because another run held the lock | Nothing, if the other run finishes. C2 judges that run. |

A known gap can be accepted with a reason, so it stops being red every morning but stays visible:
`sec-filings ack C3 2026-11-05 --reason "SEC index lists a filing withdrawn the same day"`. The item
turns amber and the report prints the reason. Only C3 days can be acknowledged ([D-23](DECISIONS.md)).

The checks catch a missing run (C1), a failed or half-run (C2), a filing the SEC daily index shows that
we lack (C3), a changed ticker-to-CIK mapping (C4), page-count drift (C5), a falling row count (C6),
a period without exactly one canonical filing (C7), bad labels (C8), a filing past its deadline (C9),
unresolved amendments (C10), fixed golden questions answering differently (C11) and unknown form types (C12).
Each has a test that makes it fire: red for most, amber for C10 and C12, which ask for a review
rather than say the data is wrong. A run that died while "running" (after 2 hours) or a last run more
than 26 hours old is red under C2.

## Scheduling with Prefect

Prefect is not installed, and CI fails if it appears in the dependencies. `flows.sync(settings)` and
`flows.check(settings)` are plain functions. `sync` returns a `RunResult` and raises `RunFailed` if the job
fails; with `raise_on_red=True` it also raises `ChecksRed` when any check of that run is red, after
the report is written. `check` alone raises `ChecksRed` on any red. This is what a team would write,
shown as text only (not installed, for illustration):

```
from prefect import flow
from sec_filings import flows
from sec_filings.config import load_settings

@flow
def sec_filings_morning():
    flows.sync(load_settings(), raise_on_red=True)  # one call: the run, then its checks
```

## Detecting a run that never happened

A job cannot report that it did not start. Three options, any one will do:

1. `HEARTBEAT_URL`: after each run the job pings this URL. A partial or failed run pings `URL/fail`.
   Use a monitor that alerts on silence, such as healthchecks.io.
2. A separate schedule entry at 06:30 London time: `sec-filings check --expect-run-by 06:30`
   (06:30 is the default). C1 is red from that time if no whole-job sync has succeeded today.
3. A Prefect automation on "flow run not completed by 06:30".

"06:00" is taken as 06:00 Europe/London ([D-16](DECISIONS.md)).

## SEC fair access

Rules from the [SEC page](https://www.sec.gov/os/accessing-edgar-data), and how the code meets each:

| Rule | How |
|---|---|
| Declare who you are | Every request carries a `User-Agent` of the form "Name contact". Set your own in `SEC_USER_AGENT`. The default is the author's personal contact ([D-09](DECISIONS.md)). |
| Compress | `Accept-Encoding: gzip, deflate` on every request. |
| At most 10 requests per second | One client, one token bucket at 4 per second. The setting is capped at 9. One process at a time (advisory lock). |
| Download only what is needed | No bulk archives, no per-filing XBRL (about 4 GB). A small concept file per company, small cover pages for recent reports and amendments, and the daily index. Raw responses are stored and hashed, so nothing is fetched twice for parsing. |
| Back off when told to | 429 and 5xx are retried with exponential backoff, honouring `Retry-After`. The first 403 stops the run ([runbook](docs/runbooks/sec-403.md)). A per-run request budget bounds the damage from any bug. |

## Environment variables

| Name | Default | Use |
|---|---|---|
| `DATABASE_URL` | none, required | Postgres connection string. |
| `MCP_DATABASE_URL` | `DATABASE_URL` | Read-only login for the MCP server. |
| `SEC_USER_AGENT` | author's contact | Your own "Name contact" string. |
| `SEC_REQUESTS_PER_SECOND` | 4 (cap 9) | Request pacing. |
| `HEARTBEAT_URL` | unset | Monitor to ping after each run. |
| `SEC_FIXTURES_DIR` | unset | Serve recorded files, no network. |
| `COMPANIES_CSV`, `COMPANIES_YML` | files in the repo root | Company list and reviewed details. |
| `REPORTS_DIR` | `reports` | Where morning reports go. |
| `PGSERVER_DATA` | unset | Folder for the embedded dev database. |
| `TEST_DATABASE_URL` | unset | Database for the integration tests. |

## Running the tests

```
uv sync --group dev
uv run pytest -q -m "not db and not live"     # unit tests: no database, no network
uv run pytest -q -m "not live"                # all 628 tests; starts an embedded Postgres,
                                              # or set TEST_DATABASE_URL to use your own server
uv run ruff check src tests scripts
uv run sec-filings verify                      # the evidence block an agent must paste
```

Tests never call the SEC. They read recorded files from `tests/fixtures/edgar`.

## Where the five deliverables are

| Deliverable | File |
|---|---|
| The job | `src/sec_filings/`, run with `sec-filings sync` |
| The morning check | [src/sec_filings/checks/](src/sec_filings/checks/), [reports/](reports/) |
| The handover kit | [AGENTS.md](AGENTS.md), [CLAUDE.md](CLAUDE.md), [DECISIONS.md](DECISIONS.md), [docs/runbooks/](docs/runbooks/) |
| What I didn't trust | [docs/what-i-didnt-trust.md](docs/what-i-didnt-trust.md) |
| An analyst's question | [docs/analyst-answer.md](docs/analyst-answer.md) |
| How it was built | [docs/how-it-was-built.md](docs/how-it-was-built.md) (diagrams), [docs/agent-log.md](docs/agent-log.md), [docs/agent-usage.md](docs/agent-usage.md) |

A ten-minute tour for reviewers is in [REVIEW.md](REVIEW.md).
