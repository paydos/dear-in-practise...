# PLAN.md: SEC filings tracker for In Practise

> **Historical document.** This is the plan as approved before the build (revision 2.1, 2026-11-09). The build then changed several rules, each logged with its reason: see [DECISIONS.md](DECISIONS.md) for the decisions in force, [docs/contracts.md](docs/contracts.md) amendments 1 to 3, and [docs/trust-log.md](docs/trust-log.md) for what turned out wrong. Files it mentions that were planning-only (a separate plan review, research notes, call preparation) are not in this repository.

The plan is written so that a strong model can plan from it, cheaper models can implement one section at a time, and a reviewer can score the result against section 13 without reading anything else.

---

## 0. The short version

A Python job keeps a Postgres table of every annual and quarterly report filed by 20 companies. Each report is labelled with the fiscal year and period it covers, so "Apple's 2009 annual report" returns exactly one canonical row. The job runs with one command, is idempotent, and respects SEC fair-access rules. A morning check turns red when the data is wrong, when the SEC shows a filing we lack, or when the run never happened. Around the job sit a handover kit with a measured pass rate on fresh agents, a small read-only MCP server, and two half-pages: where the agent was wrong, and the analyst's answer on late and corrected annual reports.

The code is table stakes. The grade comes from decisions, checks, and evidence that the agent was supervised. **Keep the core small and the proof deep.**

## 1. Non-negotiables

| ID | Rule | Enforced by |
|----|------|-------------|
| N1 | Python. Postgres. Connection from `DATABASE_URL`. | Config fails fast with a clear message if it is missing. |
| N2 | **One command** runs it, on an empty database, with only `DATABASE_URL` set. | `uv run sec-filings sync`. Migrations apply themselves. A default User-Agent ships in code. CI runs exactly this command. |
| N3 | Safe every morning: idempotent, re-runnable, overlap-safe. | Upsert by accession number. Postgres advisory lock. Run ledger. |
| N4 | Shaped for a scheduler, Prefect never installed. | `flows.sync()` and `flows.check()` are plain functions taking explicit arguments and returning result objects. `sync` raises only when the job itself fails. `check` raises `ChecksRed` when any check is red, so a scheduler marks the run failed and alerts. The README shows, as text only, the five-line Prefect wrapper their team would write. CI fails if `prefect` appears in dependency files. |
| N5 | SEC fair access, per the page the brief links (`sec.gov/os/accessing-edgar-data`): declared User-Agent, gzip encoding, at most 10 requests per second, download only what is needed. | One HTTP client, token bucket at 4 per second, `Accept-Encoding: gzip, deflate`, hard stop on 403, fetch only periodic filings' cover tags. The README has a short fair-access section showing how each rule is met. |
| N6 | Every open question decided and written down. | `DECISIONS.md`, one short entry each. |
| N7 | Nothing is "done" without evidence. | `sec-filings verify` prints an evidence block that every agent must paste. A safe Stop hook (section 10.3). |

`make` and Docker Compose are conveniences only. Windows does not ship `make`.

## 2. Decisions (become `DECISIONS.md`)

| ID | Decision | Why |
|----|----------|-----|
| D-01 | Foreign private issuers are in scope. SAP, SHEL, BABA, NVO and TM file 20-F as the annual report. Their 6-Ks are kept as `foreign_current_report`, because most are not interim results (Toyota has 603 in its recent window alone). A 6-K never answers a quarterly question. For these five, the honest quarterly answer is "no periodic quarterly report is filed with the SEC". | The analyst must get an answer for all 20 names. The brief's "10-K/10-Q" is read as "annual and quarterly reports". |
| D-02 | A company is an entity with a history of CIKs. | Since 2026-07-01 the ticker XOM maps to CIK 2115436. Its history sits under CIK 34088. The Q2 2026 10-Q appears under both CIKs. |
| D-03 | Every filing is a row. The canonical answer for a period is the **latest complete version**. The latest filed version is kept as a separate column. | Most 10-K/As add only Part III or an exhibit. "Latest filed wins" would answer with a stub. Apple FY2009's 10-K/A is complete, so it is canonical. |
| D-04 | Fiscal labels come from the filing's own XBRL cover tags. Older filings use a naming convention learned from the same company's tagged filings. Every label stores its source and confidence. | Walmart names a fiscal year by the year it ends in. GameStop names it by the year it starts in. No universal rule exists. |
| D-05 | Full history from 1994. | It costs little, and the brief's own example is 2009. |
| D-06 | Raw API payloads are stored, hashed, before parsing. | Lets us replay, diff, test offline, and prove what the SEC said on a given day. |
| D-07 | The job never deletes rows. Rows that disappear upstream are flagged as stale. | A silent delete would hide an SEC-side change. |
| D-08 | `companies.csv`, in the brief's own format (header `ticker`, one per row), is the list of record and the place to add companies. `companies.yml` holds the reviewed details per ticker: CIK history, flags and notes. A ticker in the CSV without a reviewed entry is resolved automatically, ingested, and flagged amber by C4 until a reviewer pins it. The daily run re-resolves every ticker and alerts on any CIK change. It never silently follows one. | Adding five companies next quarter must work the obvious way, by editing the CSV. The next XOM-style change must be noticed, not absorbed. |
| D-09 | One command, with a default User-Agent carrying the author's **personal** contact address, overridable by `SEC_USER_AGENT`. Never the employer address. Until the address is supplied, the default is the placeholder `sec-filings-takehome REPLACE_ME_PERSONAL_EMAIL`, defined in one constant in `config.py`. Development runs set `SEC_USER_AGENT` explicitly. A release test, `test_default_user_agent_is_real`, fails while the placeholder remains, and P12 cannot finish until it passes. | A grader with only `DATABASE_URL` set must succeed first time, and the repo must carry nothing from the current employer. |
| D-10 | Corrections are reported as **events**, separate from amendments. An event is either a non-reliance 8-K (item 4.02) linked to the filings that later carry the corrected numbers, whether amendments or the next original report, or a cover-page error-correction flag on any filing. Amendments separately get a kind: `restatement`, `accounting_change` or `administrative`. | A restatement can arrive in the next original 10-K with no amendment at all. Apple FY2009's 10-K/A came from a voluntary accounting change, not an error, and must not count as a correction. |
| D-11 | Lucid's pre-merger shell history (Churchill Capital Corp IV, same CIK) is kept, flagged `pre_merger_shell`, and reported separately. | Its May 2021 restatement is real but belongs to the shell. The analyst decides whether it counts, with the facts shown. |
| D-12 | AT&T's history under CIK 732717 includes SBC Communications before 2005. The old AT&T Corp, a different CIK, is out of scope. | Same legal entity. Stated so nobody is surprised. |
| D-13 | Lateness uses the filer category on the filing's own cover page, EDGAR's `filingDate` (which already applies the 5:30 pm Eastern cutoff), and Rule 12b-25 grace. "Last 10 years" means fiscal years ending 2016-11-01 to 2026-10-31. | Removes the "today's category" caveat for the XBRL era and makes the window unambiguous. |
| D-14 | Deployment is optional. The heartbeat that detects a missing run must be external to the job. | A job cannot report that it did not run. |
| D-15 | Session logs are shared after a scrub of personal remarks, the employer email (it appears in research-session commands), and local and OneDrive paths. | They are the strongest evidence of the working style. |
| D-16 | "06:00" means 06:00 Europe/London, where In Practise is based. That is 01:00 or 02:00 US Eastern, a few hours after EDGAR publishes the previous business day's index at about 22:00 Eastern. The heartbeat deadline is 07:00 London. | The brief gives no time zone. The choice decides whether yesterday's SEC data is complete when the job runs. |
| D-17 | Submission is a private GitHub repository shared with the reviewers, with a zip that includes the `.git` folder as a fallback. Commits follow the phases, so the history itself shows the process. | The brief accepts either. History is evidence, and a zip without `.git` would lose it. |

## 3. Repository layout

```
sec-filings/
  README.md            the one command, what you get, how to read the morning check, first-run cost
  REVIEW.md            10-minute tour for graders: each deliverable -> one file
  AGENTS.md            canonical agent instructions (any coding agent)
  CLAUDE.md            "@AGENTS.md" plus Claude-specific notes
  DECISIONS.md         D-01..D-nn
  PLAN.md              this file
  brief.md             as received, read-only
  companies.csv        the list of record, brief's format; edited to add companies
  companies.yml        pinned company -> CIK history, filer type, flags such as pre_merger_shell
  pyproject.toml uv.lock   Python 3.12, uv; deps: httpx, psycopg[binary], typer; optional extra "mcp"
  Makefile docker-compose.yml Dockerfile .env.example    conveniences only
  .mcp.json            registers the read-only MCP server for Claude Code
  src/sec_filings/
    cli.py             sync | backfill | check | verify | show | resolve-companies | mcp
                       `show AAPL 2009` answers the brief's example: canonical report plus every version
    config.py          env + defaults
    edgar/client.py    UA, token bucket, retries, 403 stop, raw capture, offline fixture mode
    edgar/submissions.py   main JSON + history pages -> normalised rows
    edgar/cover_tags.py    filing index.json -> XBRL instance -> DEI cover tags
    edgar/daily_index.py   daily form index fetch + parse (second source)
    edgar/tickers.py       company_tickers.json resolution
    domain/forms.py        raw form -> family
    domain/labels.py       fiscal labelling tiers
    domain/amendments.py   linking, scope, kind, canonical selection
    domain/deadlines.py    filer category, due dates, 12b-25, business-day roll
    db/migrations/*.sql    forward-only, applied automatically
    db/repo.py             upserts, run ledger, advisory lock
    checks/core.py         the 12 core checks
    checks/extended.py     the extended set
    checks/report.py       markdown + JSON report, exit code, heartbeat ping
    flows.py               sync(), backfill(), check(): scheduler entry points
    mcp_server.py          read-only MCP server
  tests/
    fixtures/edgar/        recorded payloads for the golden companies
    golden/labels.csv      hand-verified labels against filing cover pages
    golden/queries.sql     canonical questions with expected accession numbers
    unit/ integration/
  scripts/
    handover_eval.py       headless fresh-agent runs, scored
    agent_usage.py         tokens and cost per model per phase from session logs
  docs/
    runbooks/              add-companies, cik-changed, sec-403, backfill, red-check
    handover/              protocol, scenarios, results.md, transcripts/
    agent-log.md           what was delegated, to whom, what came back wrong
    trust-log.md           raw material for deliverable 4 (seeded, section 12)
    what-i-didnt-trust.md  deliverable 4
    analyst-answer.md      deliverable 5, with appendix-full-table.md
    call-prep.md           for the author: likely questions, answers, backing queries
    agent-usage.md         output of scripts/agent_usage.py
  .claude/
    agents/ edgar-implementer.md (sonnet), reviewer.md (opus, read-only), lookup.md (haiku)
    skills/ add-companies/SKILL.md, investigate-red-check/SKILL.md
    settings.json          safe Stop hook, deny prefect installs, deny edits to brief.md
  reports/
    sample_red_report.md   what failure looks like
    morning_check_YYYY-MM-DD.md   committed by the scheduled run if deployed
  .github/workflows/ ci.yml, daily.yml (optional), heartbeat.yml (optional)
```

## 4. Data model

Plain SQL, names readable without docs.

### 4.1 Tables

**company**: `company_id` (ticker as given, PK), `name`, `is_foreign_private_issuer`, `fiscal_year_end_mmdd`, `filer_category_current`, `fy_naming_convention` (`ends_in`, `starts_in`, `unknown`; learned), `pre_merger_until` (date, null), `notes`.

**company_cik**: `company_id`, `cik`, `valid_from`, `valid_to`, `source` (`ticker_file`, `manual`, `successor_8k`), `note`. Unique on `cik`.

**company_name_history**: `cik`, `name`, `valid_from`, `valid_to`, from the API's `formerNames`.

**filing**: one row per accession.
- Identity: `accession_number` (PK), `cik`, `company_id`, `file_number`, `film_number`.
- Form: `form` (raw), `form_family` (`annual`, `annual_amendment`, `quarterly`, `quarterly_amendment`, `foreign_current_report`, `late_notice`, `transition_annual`, `transition_quarterly`, `non_reliance_8k`).
- Dates: `filing_date` (EDGAR's, used for lateness), `acceptance_datetime` (timestamptz), `period_of_report`.
- Label: `fiscal_year`, `fiscal_period` (`FY`, `Q1`..`Q4`, `H1`, `H2`, `OTHER`), `label_source` (`filing_dei`, `convention`, `rule`, `manual`, `none`), `label_confidence` (`high`, `medium`, `low`).
- Cover tags (null when no XBRL): `dei_filer_category`, `dei_amendment_flag`, `dei_amendment_description`, `dei_error_correction_flag`, `dei_current_reporting_status`.
- Amendments: `amends_accession`, `amendment_scope` (`full`, `partial`, `unknown`), `amendment_kind` (`restatement`, `accounting_change`, `administrative`, `unknown`; null for originals), `kind_evidence` (text).
- Canonical: `is_canonical` (bool).
- Document: `is_xbrl`, `is_inline_xbrl`, `primary_document`, `primary_doc_description`, `primary_doc_url`, `index_url`, `size_bytes`, `items`.
- Lineage: `first_seen_run_id`, `last_seen_run_id`, `last_seen_at`, `is_stale`, `raw_payload_hash`.

**filing_cik_alias**: `accession_number`, `cik`. A joint filing is stored once, with every CIK it appeared under.

**correction_event**: one row per correction signal. `event_type` (`non_reliance_8k` or `cover_error_flag`), `source_accession`, `event_date`, `company_id`, `affected_periods` (text, from the 8-K where parseable, else null), `corrected_in_accessions` (the amendments or next original reports for the affected periods filed after the event, within 24 months), `link_confidence`, `pre_merger_shell` (bool). Rebuilt every run.

**report_period**: one row per (company, `annual` or `quarterly`, fiscal year, fiscal period). `canonical_accession`, `latest_filed_accession`, `original_accession`, `version_count`. Rebuilt every run. This is the "one clear answer" table.

**expected_filing**: (company, report kind, fiscal year, fiscal period), `period_end_estimate`, `filer_category_used`, `category_source`, `due_date`, `due_date_with_extension`, `status` (`received`, `received_late`, `nt_filed`, `due_soon`, `overdue`, `not_applicable`), `matched_accession`. Rebuilt every run.

**raw_payload**: `url`, `fetched_at`, `run_id`, `http_status`, `sha256`, gzipped body. Deduplicated on hash.

**run**: `run_id`, `started_at`, `finished_at`, `mode`, `status` (`success`, `partial`, `failed`, `skipped_locked`), counts per company, HTTP stats, rows inserted, updated and unchanged, `git_sha`.

**check_result**: `run_id`, `check_id`, `tier` (`core`, `extended`), `severity` (`red`, `amber`, `info`), `passed`, `observed`, `expected`, `message`, `company_id`.

### 4.2 Analyst views

- `v_annual_reports`: one row per company per fiscal year from `report_period`, joined to the canonical filing, with `was_amended`, `amendment_kinds`, `filed_late`, `nt_filed`, `days_after_period_end`, `filer_category_used`.
- `v_quarterly_reports`: the same for quarters.
- `v_correction_events`: every correction event with what it corrected and where the corrected numbers were filed.
- `v_amendments`: every amendment with its scope, kind and evidence.
- `v_morning_check`: the last run's checks, red first.
- `v_company_coverage`: first and last filing, counts per family, gaps.

### 4.3 Integrity rules

- Unique partial index: one `is_canonical = true` per (company, report kind, fiscal year, fiscal period).
- `label_source = 'none'` implies `fiscal_year is null`.
- `amends_accession` must point at a filing of the matching original family.
- Original annual and quarterly forms are always `complete`. Only amendments need a scope decision.

## 5. EDGAR access

### 5.1 Endpoints

| Purpose | URL | Verified |
|---------|-----|----------|
| Ticker to CIK, current only | `https://www.sec.gov/files/company_tickers.json` | yes |
| Company metadata and recent filings | `https://data.sec.gov/submissions/CIK##########.json` | yes |
| Older filing pages | `https://data.sec.gov/submissions/<name from filings.files>` | yes |
| Filing directory | `https://www.sec.gov/Archives/edgar/data/<cik>/<accession without dashes>/index.json` | yes |
| XBRL instance with cover tags | the `*_htm.xml` file in that directory for inline XBRL; for older XBRL, the `.xml` that is not `_cal`, `_def`, `_lab`, `_pre` or `FilingSummary` | inline yes, older to verify in the spike |
| Single cover concept, fallback | `https://data.sec.gov/api/xbrl/companyconcept/CIK##########/dei/EntityCommonStockSharesOutstanding.json` | yes |
| Daily form index, second source | `https://www.sec.gov/Archives/edgar/daily-index/YYYY/QTRn/form.YYYYMMDD.idx` | yes |
| Quarterly full index, rebuilt every Saturday with corrections and deletions | `https://www.sec.gov/Archives/edgar/full-index/YYYY/QTRn/master.idx` | documented on the fair-access page, not yet fetched |
| Financial Statement Data Sets, backfill cross-check | quarterly zips from the SEC data set page | documented, not yet downloaded |

No companyfacts. JPMorgan's file is very large and the per-filing cover tags are more authoritative.

### 5.2 Client rules

1. User-Agent from `SEC_USER_AGENT`, defaulting to the author's name and personal contact address (D-09). Always send `Accept-Encoding: gzip, deflate`, as the fair-access page shows.
2. Token bucket at 4 requests per second for the whole process. The limit is 10. During research, overlapping scripts caused a connection reset.
3. Three retries with exponential backoff and jitter on 429, 5xx and connection errors. On 403, stop the run, mark it failed, exit code 3.
4. Request budget by mode: 200 for `sync`, 6,000 for `backfill`. A `sync` on an empty database runs as a backfill and uses the backfill budget. Exceeding the budget fails the run.
5. Every response is stored and hashed before parsing. Parsers read the stored copy.
6. No conditional requests. Verified: data.sec.gov sends no ETag, Last-Modified or Cache-Control.
7. Offline mode via `SEC_FIXTURES_DIR`. Tests and the handover evaluation never touch the network.
8. One client instance, 30-second timeout, keep-alive.

### 5.3 Incremental strategy

- **Daily `sync`.** Fetch the main submissions JSON per CIK, about 21 requests. Fetch history pages only when `filings.files` changed or the coverage check fails. Fetch cover tags only for new XBRL periodic filings, about two requests each. Fetch the daily index for every business day since the last successful reconciliation, normally one file. A normal morning costs under 50 requests.
- **`backfill`.** Walk every page for every CIK. Fetch cover tags for every XBRL periodic filing since 2009. Expect a few thousand requests and roughly 10 to 15 minutes. **The README states this figure once the spike has measured it.**
- `sync` on an empty database runs the backfill automatically and says so.

## 6. Pipeline

```
resolve companies -> per CIK: submissions (+pages) -> store raw -> normalise -> classify form
  -> upsert filings -> fetch cover tags for new XBRL periodic filings -> label
  -> link amendments, decide scope and kind -> rebuild report_period (canonical)
  -> rebuild expected_filing -> reconcile daily index -> run checks -> report -> heartbeat -> exit code
```

Each company runs in its own transaction. One failure makes the run `partial` and that company red. It does not stop the others.

### 6.1 Form families

| Raw forms | Family |
|-----------|--------|
| `10-K`, `10-K405`, `10-KSB`, `20-F`, `40-F` | `annual` |
| `10-KT`, `10-KSBT` | `transition_annual` |
| `10-K/A`, `10-K405/A`, `10-KSB/A`, `10-KT/A`, `20-F/A`, `40-F/A` | `annual_amendment` |
| `10-Q`, `10-QSB` | `quarterly` |
| `10-QT` | `transition_quarterly` |
| `10-Q/A`, `10-QSB/A`, `10-QT/A` | `quarterly_amendment` |
| `6-K`, `6-K/A` | `foreign_current_report` |
| `NT 10-K`, `NT 10-Q`, `NT 20-F`, their `/A` forms, `NT 10-KT`, `NT 10-QT` | `late_notice` |
| `8-K` whose items include exactly `4.02` | `non_reliance_8k` |
| anything else | not stored; counted per run |

An unknown form starting with `10-K`, `10-Q`, `20-F`, `40-F`, `6-K` or `NT` raises an amber check instead of being dropped.

### 6.2 Fiscal labelling

- **Tier 1, `filing_dei`, high.** `DocumentFiscalYearFocus` and `DocumentFiscalPeriodFocus` from the filing's own XBRL instance. Sanity rule: the fiscal year must be within one year of the period-end year, otherwise drop to tier 2 and raise amber. During backfill, compare against the data sets' `fy` and `fp` and raise amber on any disagreement.
- **Tier 2, `convention`, medium.** For filings without XBRL, mostly before 2009 for US filers and before XBRL adoption for foreign filers. Learn the offset between fiscal year and period-end year from the company's tier-1 annual filings. Require at least three consistent observations. Quarter number comes from months since fiscal year start, with period ends snapped to the nearest month end within seven days to absorb 52/53-week calendars. GameStop's period ends move between 28 January and 3 February.
- **Tier 3, `rule`, low.** No convention can be learned. Assume `ends_in` and say so.
- **Tier 4, `manual`.** Overrides in `companies.yml` by accession, each with a reason. Rare and always visible.
- **`none`.** 6-K without XBRL, late notices, non-reliance 8-Ks.

Transition reports get period `OTHER` and are excluded from the one-per-year rule. A shift of more than one month in annual period ends raises an amber "fiscal year end changed" check.

### 6.3 Amendments and the canonical answer

**Linking.** An amendment links to the original of the matching family with the same period of report. Fallback: same fiscal label. Fallback: nearest earlier original within 400 days. No match means amber.

**Scope.** Decided from several signals. No single signal decides alone.
- The XBRL instance contains financial-statement facts for the period, not just cover tags.
- The filing appears in the data sets' submission table, which holds only filings with rendered statements. Backfill only.
- The primary document is at least half the original's size.
- `AmendmentDescription` or the document description mentions re-presenting, restating or full financial statements.

Two or more positive signals mean `full`. Cover tags only and under a quarter of the original's size mean `partial`. Anything else is `unknown`: the original stays canonical and the check is amber. This choice is conservative and documented.

**Canonical.** Within each report period, `is_canonical` is the latest `complete` version by filing date, then acceptance time. Originals are always complete. `latest_filed_accession` records whatever came last.

**Amendment kind**, with evidence text, never over-claimed:
- `restatement`: the amendment is full and is linked to a correction event (below), or its own cover error-correction flag is set.
- `accounting_change`: retrospective adoption of a new standard. Set manually with a reason. Apple FY2009 is the golden case.
- `administrative`: partial scope, such as Part III, exhibits or a cover-page fix.
- `unknown`: everything else, amber.

### 6.4 Correction events

Corrections are anchored on the signal, not on amendments, because a restatement can be carried by the next original 10-K with no amendment.
- **Non-reliance 8-K.** Each 8-K with item 4.02 is an event. Link it to the filings that later carry corrected numbers for the affected periods: amendments or the next original reports filed after the event, within 24 months. A fixed 365-day window is too fragile: Plug Power's FY2020 10-K/A came 363 days after its 4.02 notice.
- **Cover error-correction flag.** Any filing whose cover says its statements correct an error is an event. The box exists only from about 2023 (exact date in the spike), so earlier corrections without a 4.02 notice, known as revisions, are invisible to us. The analyst answer says so.
- Events from Lucid's pre-merger shell are flagged and reported separately (D-11).

## 7. Deadlines and expected filings

| Form | Large accelerated | Accelerated | Non-accelerated | Rule 12b-25 extension |
|------|-------------------|-------------|-----------------|------------------------|
| 10-K | 60 days | 75 days | 90 days | +15 calendar days |
| 10-Q | 40 days | 40 days | 45 days | +5 calendar days |
| 20-F | 4 months, or 6 months for fiscal years ending before 15 Dec 2011 | | | +15 calendar days |
| 6-K | no deadline | | | |

- **Filer category used:** the filing's own cover tag `EntityFilerCategory` when present (`category_source = cover`). Otherwise the previous annual filing's cover tag (`previous_cover`). Otherwise today's category from the API (`current`, low confidence). A first 10-K after listing is treated as non-accelerated, subject to spike verification.
- Due dates on weekends and federal holidays roll to the next business day. The holiday list is hard-coded with a stated range.
- `filing_date` decides lateness, never acceptance time.
- An NT filed within one business day of the due date extends it. A report filed inside the extension counts as timely.

**`expected_filing`**, rebuilt each run: one annual per fiscal year, and three quarterlies for US filers because the 10-K covers Q4. Expectations start at the first periodic filing and after `pre_merger_until`. Status rules: `received`, `received_late`, `nt_filed`, `due_soon` within seven days, `overdue` (red), `not_applicable`.

## 8. The morning check (deliverable 2)

Runs at the end of every sync and on its own with `sec-filings check`. It writes `reports/morning_check_<date>.md`, a JSON twin and `check_result` rows. Exit codes: 0 green, 1 amber only, 2 any red, 3 run failed or SEC unreachable. The report opens with a one-line verdict and the red items, then a per-company table. `reports/sample_red_report.md` shows a real failure.

### 8.1 Core checks (built first; each maps to an observed failure or to the brief's question)

| # | Check | Red when | Why it exists |
|---|-------|----------|---------------|
| C1 | `HEARTBEAT` (external) | No successful run recorded by 07:00 | A job cannot report that it never started. |
| C2 | `RUN_STATUS` | Run failed, any 403, or a company failed | "It crashed" and "it half-ran" must both be visible. |
| C3 | `DAILY_INDEX_RECONCILE` | A periodic filing for our CIKs, in any daily index since the last successful reconciliation, is missing from our table. A gap of more than 30 business days is red and points to the backfill runbook. An index not yet published is amber and retried on the next run. On Mondays, the current quarter's full index, rebuilt on Saturdays with corrections and deletions, is also reconciled. | A second, independent SEC system confirms completeness, missed mornings are caught up, and SEC-side deletions surface within a week. |
| C4 | `COMPANY_MAPPING` | Red when a ticker now maps to a CIK not in `company_cik`. Amber when a ticker in `companies.csv` has no reviewed entry in `companies.yml`, listing the hints the reviewer needs: foreign filer, earliest filing date, former names. | Catches the next XOM, and keeps newly added companies visible until a human has looked. |
| C5 | `COVERAGE_DRIFT` | A history page's `filingCount` differs from the number of rows parsed from the stored raw copy of that page, or a page listed in `filings.files` has no stored copy | Catches the pagination trap structurally. Compares against all forms in the raw page, not the periodic rows we keep, which would never match. |
| C6 | `ROWCOUNT_MONOTONIC` | Any company and family has fewer rows than yesterday | Rows vanished or a CIK was mis-mapped. |
| C7 | `ONE_CANONICAL_PER_PERIOD` | A report period has zero or several canonical rows | Guarantees "one clear answer". |
| C8 | `LABELS_PRESENT_AND_PLAUSIBLE` | An XBRL-era annual or quarterly row has no label, or the fiscal year is more than one year from the period end | Labelling regressions. |
| C9 | `EXPECTED_OVERDUE` | A filing is past its due date, plus extension if an NT exists, with nothing received | Wrong without crashing: a report that should be there is not. |
| C10 | `AMENDMENTS_RESOLVED` | Amber when an amendment is orphaned or its scope or kind is unknown | Keeps the canonical rule honest. |
| C11 | `GOLDEN_QUERIES` | Any fixed question returns a different accession than expected | The labelling design, regression-tested in production every morning. |
| C12 | `UNKNOWN_PERIODIC_FORM` | Amber when a new periodic form string appears | New forms are not silently dropped. |

**Heartbeat mechanics.** The job pings `HEARTBEAT_URL` when set, for example a free healthchecks.io check, which alerts on silence. Without one, `sec-filings check --expect-run-by 06:30` is scheduled as a separate entry. In Prefect, the equivalent is an automation on "flow run not completed by 06:30". The README states all three.

**Golden queries.** Expected accession numbers are pinned in P1 when fixtures are recorded, and each is checked against the filing itself. Items marked *seen* were observed in EDGAR during research. The rest are expectations to confirm.
- *Seen:* Apple FY2009 annual, canonical is the 10-K/A of 2010-01-25, kind `accounting_change`. Walmart FY2026, period 2026-01-31. GameStop FY2024, period 2025-02-01. Toyota FY2026 20-F. Exxon Q2 2026 10-Q `0000034088-26-000093` stored once with two CIK aliases. Exxon Q3 2026 10-Q `0002115436-26-000020` under the new CIK only. Plug Power's 4.02 notice of 2021-03-16 and its FY2020 10-K/A of 2022-03-14.
- *To confirm:* Exxon FY2015 annual under CIK 34088. Plug Power's original FY2020 10-K. Lucid's first post-merger 10-K.

### 8.2 Extended checks (built if time allows; documented regardless)

HTTP error rate, request budget, bounded daily growth, three quarterlies per US fiscal year, stale rows, fiscal year end changed, name changed, filer category changed, low-confidence label share, cover tags versus data sets disagreement, inconsistent cover tags.

### 8.3 Proving the checks fire

Integration tests inject each failure and assert the check turns red: a deleted row, a changed ticker mapping, a missing run, an overdue filing, a daily-index filing we lack, a page-count mismatch, a broken golden query.

## 9. MCP server (read-only, timeboxed to half a day)

Part of the handover kit: how agents and analysts query the data safely instead of writing raw SQL.

- Connects with a dedicated read-only Postgres role, `sec_reader`. No write tools.
- Tools: `get_annual_report(company, fiscal_year)`, `get_quarterly_report(company, fiscal_year, quarter)`, `list_filings(company, family, since)`, `morning_check(date)`, `explain_label(accession)`. The last one returns source, confidence and evidence.
- An optional extra, so the core job never depends on it. Started with `uv run --extra mcp sec-filings mcp` over stdio. Registered in `.mcp.json` so Claude Code finds it automatically.
- Built with the stable official Python SDK. No newer spec features.
- Test: ten analyst questions through the server must match `golden/queries.sql`.
- Call demo: ask Claude "which of these companies filed an annual report late in the last ten years?" and show it answering through the server.

## 10. Handover kit (deliverable 3)

### 10.1 Content

- **`AGENTS.md`** (under 100 lines), readable by any coding agent: purpose; the one command; the non-negotiables; the definition of done; pointers to `DECISIONS.md`, runbooks and skills; and "if a data decision is unclear, add a `DECISIONS.md` entry and stop, do not guess".
- **`CLAUDE.md`**: imports `AGENTS.md` and adds Claude-specific notes.
- **Skills** in `.claude/skills/`: `add-companies` and `investigate-red-check`. The same procedures are mirrored in `docs/runbooks/` for other agents.
- **Getting a database:** the kit states both routes, an existing Postgres via `DATABASE_URL` or `docker compose up -d db`, so a fresh agent can run the job without the author.
- **`add-companies` procedure:** add the tickers to `companies.csv`; run `sec-filings resolve-companies` and read its hints; compare the earliest filing with the listing date to spot predecessor CIKs; check for foreign filer status and multiple registrants; write the reviewed entries in `companies.yml`; record fixtures; backfill those CIKs only; run `sec-filings verify`; add a golden query per new company; add a decision entry if something new appeared.
- **Runbooks:** CIK changed, SEC 403, backfill, and one section per check ID covering what it means, the first query to run and the usual causes.

### 10.2 Definition of done

`sec-filings verify` prints an evidence block: unit test summary, check summary by severity, golden query results, and row-count delta. An agent is done only when it pastes this block showing zero red.

### 10.3 Safe Stop hook

The hook ships with the repo, so it will also run on the graders' agent. It must never trap them.
- Runs only offline unit tests, with a 60-second timeout.
- Then runs `sec-filings verify --if-db`. If no database is reachable, it **allows the stop** and prints how to start one.
- Blocks only on a real failure, with the failing output shown.

### 10.4 Measured handover evaluation

`scripts/handover_eval.py` runs `claude -p` headless in a clean clone, offline against recorded fixtures, several times per scenario and model. It scores each run automatically from the database state and from whether the evidence block is in the final message.

| Scenario | Task given to the fresh agent | Pass means |
|----------|-------------------------------|------------|
| S1 | "Add NFLX, ORCL, BP, RIO and SONY, then prove it worked." | Tickers added to `companies.csv` with reviewed entries in `companies.yml`; foreign filers detected; Rio Tinto's registrants handled per a new decision entry; backfill limited to the new CIKs; evidence block green. |
| S2 | A fixture ticker file maps one ticker to a new CIK. "This morning's check is red. Fix it." | Follows the CIK runbook; adds the CIK with dates; does not delete history. |
| S3 | A seeded overdue filing and an orphan amendment. "Explain the morning report." | Correct diagnosis of both; no data edits without a decision entry. |

Matrix: three runs each on Sonnet and Haiku. Results go in `docs/handover/results.md` as pass rates, with transcripts. The kit is fixed and rerun until the pass rate stops improving. The before-and-after table is evidence in its own right.

## 11. Testing

- **Unit:** form mapping, every label tier, 52/53-week snapping, amendment scope, kind and canonical selection, deadlines with weekend roll and 12b-25, the expected-filing state machine, daily index parsing, matching by CIK only.
- **Golden labels:** about 40 filings, each checked by a human against the filing's cover page. Must include every golden query company, Apple's 10-K405 of 2001, Apple's NT 10-K of 2006, and one 20-F per foreign filer.
- **Integration:** Postgres in Docker plus fixtures. Run backfill, then sync twice. The second sync changes zero rows. All core checks green. Exit codes correct. Failure injection per section 8.3.
- **Reconciliation, by hand, recorded in `trust-log.md`:** annual counts and dates for Apple, Exxon (both CIKs), Toyota and GameStop against EDGAR's own pages; ten random labels against cover pages; a backfill sample of cover tags against the data sets.
- **CI:** lint, tests, and the one command against a service Postgres in offline mode, finishing green in under two minutes.

## 12. Agent orchestration (visible in the logs)

Principles: a strong model plans and judges; cheaper models execute narrow, fully specified briefs; every subagent brief is complete because subagents start with no context; reviewers get the spec, not the conversation, and read-only tools; "done" is proven by a command's output, not claimed. Do the quick things directly. Delegate where the work is independent or verbose.

| Phase | Who | Output and evidence |
|-------|-----|---------------------|
| P0 Seed | Author | Brief, companies file, PLAN.md, DECISIONS.md, AGENTS.md skeleton, agent definitions, safe hook, `trust-log.md` seeded with T-1 to T-5 below. First commit. |
| P1 Spike, 90 min | Main session, Opus or Fable | Settle every item in section 15. Record fixtures. Update this plan. |
| P2 Scaffold | `edgar-implementer` (Sonnet) | Package, migrations, config, CLI skeleton, CI running the one command. Returns test output. |
| P3 Parallel build | Three `edgar-implementer` runs in separate worktrees, no shared files | (a) `edgar/*` client, pages, cover tags, daily index, offline mode; (b) `domain/*` forms, labels, amendments, deadlines, with golden tests; (c) `checks/*`, report, heartbeat, failure injection tests. Each returns the test command and full output. |
| P4 Integrate | Main session | Wire `flows.py`; backfill against fixtures; fix seams. |
| P5 Review | `reviewer` (Opus, read-only, fresh context) | Given sections 4 to 8 only. Findings ranked; fixes go back to Sonnet; reviewer re-checks. Logged. |
| P6 Live backfill and reconciliation | Main session | All 20 companies live. Section 11 reconciliation. Every discrepancy goes into `trust-log.md` with the query that found it, at the moment it is found. |
| P7 Writing | Main session, Opus as critic | `what-i-didnt-trust.md`, `analyst-answer.md` with appendix. The reviewer checks every claim against a query in the repo. |
| P8 Handover evaluation | `scripts/handover_eval.py` | Pass-rate table, fixes, rerun. |
| P9 MCP server | `edgar-implementer` (Sonnet) | Section 9, timeboxed. |
| P10 Reviewer pack | Main session | `README.md`, `REVIEW.md` (ending with "What I'd do next": restatement ground truth from a commercial source such as Audit Analytics, 6-K interim parsing, predecessor CIK lineage, historical filer category before XBRL), `docs/call-prep.md`, sample red report. |
| P11 Deploy (optional) | Sonnet | GitHub Actions daily run plus a separate heartbeat. Note: scheduled runs can be delayed and are disabled after 60 days without repository activity. |
| P12 Logs | Author | Replace the User-Agent placeholder and confirm `test_default_user_agent_is_real` passes (D-09). Scrub per D-15, then grep the exported logs for the employer domain and local paths to prove the scrub worked. Run `scripts/agent_usage.py` and publish `docs/agent-usage.md`. |
| P13 Submit | Author | Fresh clone into an empty folder; run the one command against an empty Postgres; run `sec-filings show AAPL 2009`; grep the whole repo for the employer domain and the placeholder; push the private repository and build the zip with `.git` (D-17); reply to the email with the link. |

**Agent definitions** (`.claude/agents/`):
- `edgar-implementer`, Sonnet, read/write/shell tools. Implement only the named plan section; touch only the listed files; never call the live SEC (fixtures only); finish by running the named command and pasting its output; if the plan is ambiguous, stop and list the question.
- `reviewer`, Opus, read-only tools. Review against the named sections; report correctness and spec gaps with file and line; ignore style.
- `lookup`, Haiku, read and web tools. Documentation and fixture lookups; facts with sources only.

**Brief template**, used for every delegation: one-sentence goal; plan sections; files allowed; files forbidden; fixtures available; the command that proves it works; what to return, a summary under 200 words plus command output; what to do if blocked.

**Agent log.** Each entry records date, phase, delegate, what came back, what was wrong, how it was found, what was done, and a link to the session and timestamp. Include the occasions when work was deliberately *not* delegated, and why. **Never stage mistakes.** The real ones are better, and the graders read the transcripts.

**Usage evidence.** `scripts/agent_usage.py` totals tokens and estimated cost per model per phase from the session `.jsonl` files. The table goes in `docs/agent-usage.md`.

**Trust log seed** (already true, from the research session):

| ID | Claimed | Actually | Caught by |
|----|---------|----------|-----------|
| T-1 | Apple's 2010 10-K/A "restated" FY2009 | A voluntary retrospective accounting change, not an error correction | Reading the 10-K/A's explanatory note and Apple's Q1 2010 release |
| T-2 | Walmart labels "verified" | The evidence showed the cover share-count date, not the period end | Re-joining cover facts to the submissions period end |
| T-3 | GameStop labels "verified" | The query had failed twice; never verified | Re-running: period 2025-02-01 is fiscal 2024 |
| T-4 | Background EDGAR pull "running" | Stalled 20 minutes, CPU-bound on 16,000 JPMorgan rows | Checking saved files and process CPU |
| T-5 | Exxon history "under the old CIK" | Incomplete: Q2 2026 10-Q is joint, Q3 2026 only under the new CIK | Comparing both CIKs by accession |

## 13. Acceptance criteria

1. With only `DATABASE_URL` set against an empty Postgres, `uv run sec-filings sync` succeeds. Its report shows no red caused by the job itself, and every amber or red item, such as a genuinely overdue filing or an unclassified amendment, carries an explanation. No other step is needed. The README also gives a fallback for graders without `uv`: `pip install .` then `sec-filings sync`.
2. A second run changes zero filing rows and says so.
3. `v_annual_reports` for Apple FY2009 returns one row: canonical accession of the 10-K/A of 2010-01-25, `was_amended = true`, kind `accounting_change`.
4. Plug Power FY2024's canonical row is the original 10-K unless the spike shows the 10-K/A is complete. Either way the reason is recorded.
5. Exxon has one canonical annual report per fiscal year across two CIKs, for every year its history pages cover (range confirmed in P1), and its Q2 2026 10-Q is stored once with two aliases.
6. The five foreign filers have labelled 20-F rows. Their 6-Ks are stored as `foreign_current_report` and never appear in `v_quarterly_reports`.
7. Every row has a label source and confidence. XBRL-era periodic rows are `filing_dei`.
8. Each failure in section 8.3 turns its check red in tests. `reports/sample_red_report.md` exists.
9. Removing the run ledger's latest entry makes the heartbeat check red when run separately.
10. No `prefect` in `pyproject.toml`, `uv.lock` or `Dockerfile`. `flows.sync` is importable and Prefect-free.
11. The Stop hook allows stopping when no database is reachable.
12. `docs/handover/results.md` shows pass rates for S1 to S3 on two models, before and after kit fixes, with transcripts.
13. The MCP server answers the ten golden questions correctly through its tools, using the read-only role.
14. `what-i-didnt-trust.md` is about half a page and answers the brief's four questions in order: where the agent was wrong, how it was found, what it was checked against, and the data decisions made with reasons. It cites at least five real agent errors with accession numbers or check IDs, and links to `DECISIONS.md`.
15. `analyst-answer.md` is about half a page and answers both halves of the brief: the answer with how sure we are, and what is missing with what we would add. It covers definitions, correction events kept apart from accounting changes and administrative amendments, and confidence per claim. The full per-company table is in the appendix and reproducible from one SQL file.
16. `REVIEW.md` lets a grader find every deliverable in under ten minutes.
17. Session logs are included and scrubbed, with `docs/agent-usage.md`.
18. `sec-filings show AAPL 2009` prints one canonical answer followed by every version on file, and the README shows that output.
19. Adding a ticker to `companies.csv` and running the one command ingests it and turns C4 amber until a reviewed entry exists.
20. A Prefect-style caller gets an exception when the job fails or any check is red, and a result object otherwise.
21. Every row of the traceability table in section 17 points at something that exists in the repo.

## 14. Edge-case register

`O` means observed in these 20 companies, with evidence. `H` means hypothetical. Observed cases get tests first. New cases are appended, never handled silently.

| ID | O/H | Case and evidence | Handling | Test |
|----|-----|-------------------|----------|------|
| E-01 | O | XOM ticker moved to successor CIK 2115436 on 2026-07-01 | D-02, C4 | golden; fixture ticker change |
| E-02 | O | Joint filing under two CIKs: Exxon `0000034088-26-000093` | alias table | golden |
| E-03 | O | Foreign filers file 20-F and 6-K | D-01, 20-F deadline | golden Toyota |
| E-04 | O | Amendments that are complete (Apple FY2009) and probably partial (Plug FY2024) | 6.3 scope and canonical | golden both |
| E-05 | O | Accounting change versus error correction (Apple FY2009) | D-10, amendment kind | golden |
| E-05b | H | Restatement carried by the next original 10-K, with no amendment | correction events (6.4) | unit |
| E-05c | O | Most 6-Ks are not interim results (Toyota: 603 in its recent window) | `foreign_current_report`, never a quarterly answer | unit |
| E-06 | O | Non-reliance 8-Ks: Plug 2021-03-16, Lucid shell 2021-05-14 | `non_reliance_8k`, kind rules | unit; analyst appendix |
| E-07 | O | Late notices: Apple NT 10-K 2006, Plug NT 10-K 2021, Lucid NT 10-Q 2021 | 12b-25 logic | unit; golden |
| E-08 | O | Fiscal naming differs: Walmart ends-in, GameStop starts-in | D-04 tiers | golden both |
| E-09 | O | 52/53-week drift: GameStop periods 2023-01-28, 2024-02-03, 2025-02-01, 2026-01-31 | month-end snap | unit |
| E-10 | O | Retired form 10-K405 (Apple 1998, 2001) | form table | golden |
| E-11 | O | SPAC shell history under Lucid's CIK | D-11 | golden Lucid |
| E-12 | O | Pagination: Apple one extra page, Microsoft two, JPMorgan 41 | page walk, C5 | integration |
| E-13 | O | Name changes: Apple Computer, SBC Communications, Royal Dutch Shell | name history, never key on name | unit |
| E-14 | O | Name matching is dangerous: "Exxon" also matched "Texxon Holding Ltd" in the daily index | match on CIK only | unit |
| E-15 | O | Connection reset from overlapping clients | single client, advisory lock | unit |
| E-16 | O | Shell filed two 20-F/As on 2025-07-02, nature unknown | scope and kind rules, amber until known | spike |
| E-17 | O | Companies listed mid-history: Tesla, Carvana, AMC, Lucid | expectations start at first filing | unit |
| E-18 | O | Q4 covered by the 10-K | three quarterlies expected | unit |
| E-19 | O | No caching headers on data.sec.gov | no conditional requests | none needed |
| E-20 | H | Transition reports after a fiscal year end change | `OTHER` period, excluded from C7 | unit |
| E-21 | H | Cover tags mis-tagged or disagreeing with the data sets | plausibility, amber | unit |
| E-22 | H | Blank period of report (Apple had none) | label `none`, amber | unit |
| E-23 | H | SEC removes a filing | D-07, stale flag, C6 | integration |
| E-24 | H | Overlapping scheduler runs | advisory lock, `skipped_locked` | integration |
| E-25 | H | One company fails mid-run | per-company transaction, `partial` | integration |
| E-26 | H | Due date on a weekend or holiday | business-day roll | unit |
| E-27 | H | First-year filer deadlines (Lucid, Carvana) | non-accelerated for first 10-K, pending spike | unit |
| E-28 | H | Rio Tinto has two SEC registrants | handover scenario S1 forces a decision entry | eval |
| E-29 | H | Paper-era accessions with no primary document | nullable document fields | unit |
| E-30 | H | Run in London at 06:00 sees late US filings from the previous evening | timestamps stored with time zone; "yesterday" in US Eastern | unit |
| E-31 | H | Two originals for one period that are not amendments | C7 red, manual tier | unit |
| E-32 | H | Database missing or on an old schema | auto-migrate, exit 3 with message | integration |
| E-33 | H | Runaway request loop | per-mode budget | unit |

## 15. Spike checklist (P1, 90 minutes, before any code depends on these)

1. Find the XBRL instance in pre-inline filings (2009 to 2019) for Apple, JPMorgan and one foreign filer. Confirm the file-naming rule.
2. Find when each foreign filer's XBRL began, and whether their 20-F covers carry `DocumentFiscalYearFocus` and `EntityFilerCategory`.
3. Confirm when the cover-page error-correction box took effect and its exact tag name in older filings.
4. Read Plug Power's FY2020 10-K and its 10-K/A of 2022-03-14, Plug's 10-K/As of 2023 and 2025, and Shell's two 20-F/As of 2025-07-02. Classify scope and kind by hand, and check how the 4.02 notice links to the corrected filings. These become golden cases.
5. Confirm the first-year non-accelerated rule and the 20-F deadline history.
6. Confirm how Rio Tinto is registered, for scenario S1.
7. Download one quarter of the Financial Statement Data Sets and compare `fy`, `fp` and `afs` with cover tags for ten filings.
8. Measure backfill request count and duration on three companies, then extrapolate for the README.
9. Check whether any of the 20 has a 10-KT or a fiscal year end change in the electronic era.
10. Confirm the daily index for the previous US business day is published by 06:00 London, and how the job sees an unpublished one. Confirm older years remain available under `daily-index`, since the fair-access page says it covers the current year.
11. Fetch one quarter's `full-index/.../master.idx` and confirm its format for the Monday reconciliation.

## 16. Priorities and timeline

If time runs short, cut from the bottom. Never cut items 2 to 4.

1. Correct core job with the canonical rule and the one command.
2. Core morning checks, the heartbeat and daily-index reconciliation, and failure-injection tests.
3. Trust log, `what-i-didnt-trust.md` and `analyst-answer.md`.
4. Handover kit with the measured evaluation.
5. `REVIEW.md`, call preparation and the sample red report.
6. MCP server, timeboxed.
7. Extended checks.
8. Deployment.

- **Day 1:** P0 to P4. Fixtures recorded, three builds merged, tests green, one command works offline.
- **Day 2:** P5 to P7. Live backfill reconciled, trust log has at least eight real entries, core checks green on real data, both half-pages drafted and claim-checked.
- **Day 3:** P8 to P13. Handover pass rates measured and improved, MCP server, reviewer pack, logs scrubbed with the usage table, tag v1.0, submitted.

## 17. Brief traceability

Every sentence of the brief (`brief.md` as downloaded, and the page) mapped to where the plan meets it. `REVIEW.md` reuses this table with file links.

| Brief says | Plan meets it in |
|------------|------------------|
| "Using AI agents as you normally would" / "exactly as you would at work" | Section 12; proportionate delegation; quick things done directly |
| "every annual (10-K) and quarterly (10-Q) report these 20 companies have filed" | D-05 full history from 1994; 6.1 form families including amendments and retired variants; D-01 foreign filers |
| "record which fiscal year or quarter it covers" | 6.2 labelling tiers; label source and confidence on every row |
| "what do we have for Apple's 2009 annual report?' and get one clear answer" | D-03 canonical rule; `report_period`; `sec-filings show AAPL 2009`; golden query; criteria 3 and 18 |
| The 20 tickers; `companies.csv` | D-08: the CSV in the brief's format is the list of record |
| "Source: EDGAR, free, no key. Start at data.sec.gov/submissions/" | 5.1 endpoints |
| "Fair-access rules: sec.gov/os/accessing-edgar-data" | N5; 5.2 client rules; README fair-access section |
| "Python, with a local Postgres database" | N1 |
| "Read the connection from a DATABASE_URL environment variable" | N1; criterion 1 |
| "a README with the one command that runs it" | N2; D-09; criterion 1 |
| "It must be safe to run every morning" | N3; idempotent upserts, advisory lock, request budgets; criterion 2 |
| "Our jobs run on Prefect, so shape it as something a scheduler could call, but don't install Prefect" | N4; criteria 10 and 20 |
| "If tomorrow's 06:00 run is wrong, what tells us? 'It didn't crash' is not an answer" | Section 8: 12 core checks, external heartbeat, daily and weekly index reconciliation, expected-filing calendar, failure-injection tests, sample red report; D-16 time zone |
| "Instructions and checks that let an AI agent run, extend or fix this job later without you" | Section 10: `AGENTS.md`, skills, runbooks, database setup routes, safe hook |
| "for example adding five new companies next quarter" | D-08; add-companies procedure; scenario S1; criterion 19 |
| "Tell the agent what decisions you made" | `DECISIONS.md`, linked from `AGENTS.md` |
| "and what it must check before it says it's done" | 10.2 `sec-filings verify` evidence block |
| "We'll test it by handing it to a fresh agent" | 10.4 measured evaluation on two models; criterion 12 |
| "What you didn't trust (half a page): where was the agent wrong? How did you find out? What did you check it against? Include any decisions you made about the data, and why" | Trust log seeded with T-1 to T-5; P6 logging; criterion 14 |
| "An analyst's question (half a page) ... late, or had to correct one, in the last 10 years" | D-10, D-11, D-13; 6.4 correction events; section 7 deadlines; criterion 15 |
| "If yes, give the answer and say how sure you are. If not, say what's missing and what you'd add" | Criterion 15 requires both halves |
| "Please also send your agent session logs" | D-15; P12; criterion 17 |
| "If the brief leaves something open, make the call yourself and write down why" | `DECISIONS.md` D-01 to D-17 |
| "Reply ... with a link to a Git repository or a zip file" | D-17; P13 |
| "Followed by a 60-minute call" | `docs/call-prep.md`; MCP live demo |
