"""Read companies.csv (list of record) and companies.yml (reviewed details), PLAN D-08."""

from __future__ import annotations

import csv
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Any

import yaml

from sec_filings.errors import ConfigError

_SPAN_SOURCES = ("ticker_file", "manual", "successor_8k")


@dataclass(frozen=True)
class CikSpan:
    cik: int
    valid_from: date | None
    valid_to: date | None
    source: str
    note: str | None


@dataclass(frozen=True)
class CompanyConfig:
    ticker: str
    reviewed: bool
    ciks: tuple[CikSpan, ...]
    foreign_filer: bool | None
    fiscal_year_end: str | None
    pre_merger_until: date | None
    overrides: Mapping[str, Mapping[str, str]]
    notes: str | None


def _date(value: Any, where: str) -> date | None:
    if value is None or value == "":
        return None
    if isinstance(value, date):
        return value
    try:
        return date.fromisoformat(str(value))
    except ValueError as exc:
        raise ConfigError(f"{where}: {value!r} is not a YYYY-MM-DD date") from exc


def _read_tickers(csv_path: Path) -> list[str]:
    if not Path(csv_path).is_file():
        raise ConfigError(
            f"{csv_path} not found: run from the repo root (where companies.csv lives) "
            "or set COMPANIES_CSV to its path"
        )
    try:
        text = Path(csv_path).read_text(encoding="utf-8-sig")
    except OSError as exc:
        raise ConfigError(f"cannot read {csv_path}: {exc}") from exc
    reader = csv.DictReader(text.splitlines())
    fields = {(f or "").strip().lower(): f for f in (reader.fieldnames or [])}
    if "ticker" not in fields:
        raise ConfigError(f"{csv_path} must have a header column named 'ticker'")
    key = fields["ticker"]
    seen: set[str] = set()
    out: list[str] = []
    for row in reader:
        ticker = (row.get(key) or "").strip().upper()
        if ticker and ticker not in seen:
            seen.add(ticker)
            out.append(ticker)
    return out


def _read_yaml(yml_path: Path) -> dict[str, Any]:
    path = Path(yml_path)
    if not path.is_file():
        return {}
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except (OSError, yaml.YAMLError) as exc:
        raise ConfigError(f"cannot read {path}: {exc}") from exc
    if not isinstance(data, dict):
        raise ConfigError(f"{path} must be a mapping of ticker to reviewed details")
    return {str(k).strip().upper(): v for k, v in data.items()}


def _spans(ticker: str, raw: Any) -> tuple[CikSpan, ...]:
    out = []
    for item in raw or ():
        where = f"companies.yml {ticker}.ciks"
        if isinstance(item, int):
            item = {"cik": item}
        if not isinstance(item, dict) or "cik" not in item:
            raise ConfigError(f"{where}: each entry needs a 'cik'")
        source = str(item.get("source") or "manual")
        if source not in _SPAN_SOURCES:
            raise ConfigError(f"{where}: source {source!r} must be one of {_SPAN_SOURCES}")
        note = item.get("note")
        out.append(
            CikSpan(
                cik=int(item["cik"]),
                valid_from=_date(item.get("valid_from"), where),
                valid_to=_date(item.get("valid_to"), where),
                source=source,
                note=None if note is None else str(note),
            )
        )
    return tuple(out)


def _overrides(ticker: str, raw: Any) -> dict[str, dict[str, str]]:
    if not raw:
        return {}
    if not isinstance(raw, dict):
        raise ConfigError(f"companies.yml {ticker}.overrides must map accession numbers to facts")
    return {
        str(acc): {str(k): str(v) for k, v in (facts or {}).items()} for acc, facts in raw.items()
    }


def load_companies(csv_path: Path, yml_path: Path) -> list[CompanyConfig]:
    """Every ticker in the CSV, in order. A ticker with no YAML entry is unreviewed: no CIKs
    (resolved at run time from the SEC ticker file) and foreign_filer None."""
    entries = _read_yaml(yml_path)
    out: list[CompanyConfig] = []
    for ticker in _read_tickers(csv_path):
        entry = entries.get(ticker)
        if entry is None:
            out.append(CompanyConfig(ticker, False, (), None, None, None, {}, None))
            continue
        if not isinstance(entry, dict):
            raise ConfigError(f"companies.yml {ticker}: entry must be a mapping")
        foreign = entry.get("foreign_filer")
        fye = entry.get("fiscal_year_end")
        notes = entry.get("notes")
        out.append(
            CompanyConfig(
                ticker=ticker,
                reviewed=True,
                ciks=_spans(ticker, entry.get("ciks")),
                foreign_filer=None if foreign is None else bool(foreign),
                fiscal_year_end=None if fye is None else str(fye).strip(),
                pre_merger_until=_date(entry.get("pre_merger_until"), f"{ticker}.pre_merger_until"),
                overrides=_overrides(ticker, entry.get("overrides")),
                notes=None if notes is None else " ".join(str(notes).split()),
            )
        )
    return out
