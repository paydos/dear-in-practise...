"""The canonical answer for one company and period, as plain data.

Shared by `sec-filings show` (which renders it as text) and the MCP server (which returns it as
JSON), so both give the same answer for the same question. Read-only: SELECTs only.
"""

from __future__ import annotations

from datetime import date
from typing import Any

import psycopg

from sec_filings.domain.deadlines import COVID_NOTE, covid_relief_applies
from sec_filings.domain.labels import effective_period_end

FAMILIES = {
    "annual": ("annual", "annual_amendment"),
    "quarterly": ("quarterly", "quarterly_amendment"),
}

FOREIGN_QUARTERLY = (
    "{name} is a foreign private issuer: no periodic quarterly report is filed with "
    "the SEC (its annual report is a 20-F; 6-Ks are not interim reports, D-01)."
)
Q4_IN_ANNUAL = "{name}: the fourth quarter is covered by the annual report (10-K)."

# Statuses that end the answer with a one-line message, and the CLI exit code for each.
MESSAGE_ONLY = {
    "unknown_company": 1,
    "foreign_no_quarterly": 0,
    "q4_in_annual": 0,
    "nothing_on_file": 1,
}


def _jsonable(value: Any) -> Any:
    return value.isoformat() if isinstance(value, date) else value


def describe(row: dict) -> str:
    """'original', 'complete, accounting change', 'partial, kind unknown', ..."""
    if row["form_family"] in ("annual", "quarterly"):
        return "original"
    scope = {"full": "complete", "partial": "partial"}.get(row["amendment_scope"], "scope unknown")
    kind = (row["amendment_kind"] or "unknown").replace("_", " ")
    return f"{scope}, {kind}" if kind != "unknown" else f"{scope}, kind unknown"


def _version(row: dict) -> dict:
    return {
        "accession": row["accession_number"],
        "form": row["form"],
        "filing_date": _jsonable(row["filing_date"]),
        "description": describe(row),
        "amendment_scope": row["amendment_scope"],
        "amendment_kind": row["amendment_kind"],
        "amends_accession": row["amends_accession"],
        "evidence": row["kind_evidence"],
        "label_source": row["label_source"],
        "label_confidence": row["label_confidence"],
        "cover_source": row["cover_source"],
        "pre_merger_shell": row["pre_merger_shell"],
    }


UNCONFIRMED_LATE = "late (unconfirmed: filer category for that year unknown)"


def _expected(report: dict | None, first_filed: date | None = None) -> dict | None:
    """The expected-filing block. A late status is only claimed when the filer category is known
    for that year (D-19); one judged by today's category reads as unconfirmed. A filing inside the
    assumed COVID-19 relief (45 days, deadlines 2020-03-01 to 2020-07-01) is not late."""
    if not report or not report["status"]:
        return None
    status = raw = report["status"]
    filed_late = bool(report["filed_late"])
    note = None
    if status == "received_late" and report["due_date"] and first_filed is not None:
        if covid_relief_applies(report["due_date"], first_filed):
            status, filed_late, note = "received", False, COVID_NOTE
    if status == "received" and report["due_date"] and first_filed is not None:
        if covid_relief_applies(report["due_date"], first_filed):
            note = COVID_NOTE
    late_confidence = None
    if status == "received_late":
        unconfirmed = report["category_source"] == "current"
        late_confidence = "unconfirmed" if unconfirmed else "confirmed"
        if unconfirmed:
            status, filed_late = UNCONFIRMED_LATE, False
    return {
        "status": status,
        "raw_status": raw,
        "late_confidence": late_confidence,
        "basis_note": note,
        "due_date": _jsonable(report["due_date"]),
        "due_date_with_extension": _jsonable(report["due_date_with_extension"]),
        "filer_category": report["filer_category_used"],
        "category_source": report["category_source"],
        "filed_late": filed_late,
        "late_notice_filed": report["nt_filed"],
    }


def find_company(conn: psycopg.Connection, text: str) -> dict | None:
    """A company by ticker (any case), else by a unique name match. `conn` uses dict_row."""
    text = text.strip()
    cols = "company_id, name, is_foreign_private_issuer"
    row = conn.execute(
        f"SELECT {cols} FROM company WHERE company_id = %s", (text.upper(),)
    ).fetchone()
    if row is not None or not text:
        return row
    rows = conn.execute(
        f"SELECT {cols} FROM company WHERE name ILIKE %s ORDER BY company_id LIMIT 2",
        (f"%{text}%",),
    ).fetchall()
    return rows[0] if len(rows) == 1 else None


def period_answer(
    conn: psycopg.Connection, ticker: str, year: int, quarter: int | None = None
) -> dict:
    """Everything `show` prints, as a dict. `conn` must use the dict_row factory.

    status is one of: found, no_canonical (only partial amendments on file), nothing_on_file,
    unknown_company, foreign_no_quarterly, q4_in_annual. Every dict has `status` and `message`.
    """
    ticker = ticker.strip().upper()
    company = conn.execute(
        "SELECT company_id, name, is_foreign_private_issuer FROM company WHERE company_id = %s",
        (ticker,),
    ).fetchone()
    base = {"company": ticker, "fiscal_year": year, "quarter": quarter}
    if company is None:
        message = f"{ticker} is not in the database; add it to companies.csv and run sync"
        return {**base, "status": "unknown_company", "message": message}
    name = company["name"] or ticker
    base["company_name"] = name
    if quarter is not None and company["is_foreign_private_issuer"]:
        message = FOREIGN_QUARTERLY.format(name=name)
        return {**base, "status": "foreign_no_quarterly", "message": message}
    if quarter == 4:
        return {**base, "status": "q4_in_annual", "message": Q4_IN_ANNUAL.format(name=name)}

    kind = "annual" if quarter is None else "quarterly"
    period = "FY" if quarter is None else f"Q{quarter}"
    view = "v_annual_reports" if quarter is None else "v_quarterly_reports"
    what = f"fiscal year {year}" + ("" if quarter is None else f" Q{quarter}")
    versions = conn.execute(
        "SELECT * FROM filing WHERE company_id = %s AND form_family = ANY(%s) "
        "AND fiscal_year = %s AND fiscal_period = %s "
        "ORDER BY filing_date, acceptance_datetime NULLS FIRST, accession_number",
        (ticker, list(FAMILIES[kind]), year, period),
    ).fetchall()
    if not versions:
        have = conn.execute(
            "SELECT fiscal_year FROM report_period WHERE company_id = %s AND report_kind = %s "
            "ORDER BY fiscal_year",
            (ticker, kind),
        ).fetchall()
        years = [r["fiscal_year"] for r in have]
        listed = ", ".join(str(y) for y in years) or "none"
        message = f"{name}   {what}: nothing on file. Fiscal years on file: {listed}."
        return {**base, "status": "nothing_on_file", "message": message, "years_on_file": years}
    report = conn.execute(
        f"SELECT * FROM {view} WHERE company_id = %s AND fiscal_year = %s"
        + (" AND fiscal_period = %s" if quarter is not None else ""),
        (ticker, year) if quarter is None else (ticker, year, period),
    ).fetchone()
    canonical_acc = report["accession"] if report else None
    canonical = next((v for v in versions if v["accession_number"] == canonical_acc), None)
    shown = canonical or versions[0]
    fye = conn.execute(
        "SELECT fiscal_year_end_mmdd FROM company WHERE company_id = %s", (ticker,)
    ).fetchone()
    sec_end = shown["period_of_report"]
    fixed_end, corrected = effective_period_end(
        family=shown["form_family"],
        period_of_report=sec_end,
        filing_date=shown["filing_date"],
        fiscal_year_end_mmdd=fye["fiscal_year_end_mmdd"] if fye else None,
    )
    # Only a real correction replaces the SEC's date. An uncorrected annual period comes back
    # snapped to month end for labelling, which would turn Apple's 52/53-week year end
    # (2009-09-26) into a false "correction" to 2009-09-30.
    period_end = fixed_end if corrected else sec_end
    if period_end is None:
        period_end = sec_end or (report["period_end"] if report else None)
    period_note = None
    if corrected and period_end != sec_end:
        listed = sec_end.isoformat() if sec_end is not None else "no period"
        period_note = f"SEC lists {listed}; corrected to fiscal year end"
        if quarter is not None:
            period_note = period_note.replace("fiscal year end", "fiscal quarter end")
    answer = _version(canonical) if canonical is not None else None
    if answer is not None:
        answer["version_count"] = report["version_count"]
        answer["was_amended"] = report["was_amended"]
        answer["original_accession"] = report["original_accession"]
        answer["latest_filed_accession"] = report["latest_filed_accession"]
        answer["days_after_period_end"] = report["days_after_period_end"]
    if answer is not None:
        status, message = "found", f"{name}   {what}: {answer['form']} {answer['accession']}"
    else:
        status = "no_canonical"
        message = f"{name}   {what}: only partial amendments are on file for this period"
    return {
        **base,
        "status": status,
        "message": message,
        "period_end": _jsonable(period_end),
        "period_end_sec": _jsonable(sec_end),
        "period_end_note": period_note,
        "answer": answer,
        "other_versions": [_version(v) for v in versions if v["accession_number"] != canonical_acc],
        "expected": _expected(
            report, (report or {}).get("original_filing_date") or shown["filing_date"]
        ),
    }
