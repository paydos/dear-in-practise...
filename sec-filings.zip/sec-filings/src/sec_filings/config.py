"""Settings from the environment (docs/contracts.md section 6)."""

from __future__ import annotations

import os
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path

from sec_filings.errors import ConfigError

# The SEC fair-access rules require a declared contact. This default is the author's personal
# contact (D-09), so the one command works with only DATABASE_URL set. Anyone running the job for
# themselves should set SEC_USER_AGENT to their own "Name email" string.
DEFAULT_USER_AGENT = "Daniel Ruiz druizblancopdecastro@gmail.com"
MAX_REQUESTS_PER_SECOND = 9.0


@dataclass(frozen=True)
class Settings:
    database_url: str
    user_agent: str = DEFAULT_USER_AGENT
    requests_per_second: float = 4.0
    sync_request_budget: int = 200
    backfill_request_budget: int = 6000
    fixtures_dir: Path | None = None  # SEC_FIXTURES_DIR; when set, no network at all
    heartbeat_url: str | None = None  # HEARTBEAT_URL
    companies_csv: Path = Path("companies.csv")
    companies_yml: Path = Path("companies.yml")
    reports_dir: Path = Path("reports")


def load_settings(env: Mapping[str, str] | None = None) -> Settings:
    """Read settings from `env` (default: os.environ). DATABASE_URL is required."""
    e = os.environ if env is None else env
    database_url = (e.get("DATABASE_URL") or "").strip()
    if not database_url:
        raise ConfigError("DATABASE_URL is not set; point it at a Postgres database")

    kwargs: dict[str, object] = {"database_url": database_url}
    if e.get("SEC_USER_AGENT"):
        kwargs["user_agent"] = e["SEC_USER_AGENT"]
    if e.get("SEC_FIXTURES_DIR"):
        kwargs["fixtures_dir"] = Path(e["SEC_FIXTURES_DIR"])
    if e.get("HEARTBEAT_URL"):
        kwargs["heartbeat_url"] = e["HEARTBEAT_URL"]
    if e.get("COMPANIES_CSV"):
        kwargs["companies_csv"] = Path(e["COMPANIES_CSV"])
    if e.get("COMPANIES_YML"):
        kwargs["companies_yml"] = Path(e["COMPANIES_YML"])
    if e.get("REPORTS_DIR"):
        kwargs["reports_dir"] = Path(e["REPORTS_DIR"])
    raw_rps = e.get("SEC_REQUESTS_PER_SECOND")
    if raw_rps:
        try:
            rps = float(raw_rps)
        except ValueError as exc:
            raise ConfigError(f"SEC_REQUESTS_PER_SECOND is not a number: {raw_rps!r}") from exc
        if rps <= 0:
            raise ConfigError("SEC_REQUESTS_PER_SECOND must be positive")
        kwargs["requests_per_second"] = min(rps, MAX_REQUESTS_PER_SECOND)
    return Settings(**kwargs)  # type: ignore[arg-type]
