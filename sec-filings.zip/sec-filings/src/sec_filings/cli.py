"""Command line entry point: sync, backfill, check, show, resolve-companies, verify, mcp."""

from __future__ import annotations

import functools
import json
import logging
import os
import subprocess
import sys
from collections import Counter
from datetime import UTC, date, datetime, time
from pathlib import Path
from typing import Annotated

import psycopg
import typer
import yaml
from psycopg.rows import dict_row

from sec_filings import flows
from sec_filings.answers import MESSAGE_ONLY, period_answer
from sec_filings.checks.core import CheckContext, check_golden_queries, load_golden_queries
from sec_filings.checks.report import exit_code, render_markdown
from sec_filings.companies import load_companies
from sec_filings.config import Settings, load_settings
from sec_filings.db import repo
from sec_filings.db.connection import connect
from sec_filings.db.migrate import apply_migrations
from sec_filings.edgar.client import EdgarClient
from sec_filings.edgar.submissions import parse_submissions, submissions_url
from sec_filings.edgar.tickers import TICKERS_URL, parse_company_tickers
from sec_filings.errors import ChecksRed, ConfigError, RunFailed, SecFilingsError
from sec_filings.models import CheckResult, RunResult


class _TyperApp(typer.Typer):
    """Every command turns an unexpected exception into exit code 3 (Python's default is 1,
    which the exit-code contract reserves for 'amber')."""

    def command(self, *args, **kwargs):  # type: ignore[override]
        register = super().command(*args, **kwargs)

        def decorate(func):
            @functools.wraps(func)
            def guarded(*a, **kw):
                try:
                    return func(*a, **kw)
                # TyperException is the base of Typer's usage errors (Typer >= 0.29 bundles
                # its own click, so `import click` would fail on a fresh install).
                except (typer.Exit, typer.Abort, typer.TyperException):
                    raise
                except Exception as exc:
                    typer.echo(f"unexpected error: {type(exc).__name__}: {exc}", err=True)
                    raise typer.Exit(code=3) from exc

            return register(guarded)

        return decorate


app = _TyperApp(help="Track SEC 10-K and 10-Q filings in Postgres.", no_args_is_help=True)


class _ProgressHandler(logging.Handler):
    """Progress lines on stderr, so a long run never looks stuck: time-stamped, green for done,
    yellow for a warning, red for a failure. Colour is dropped when stderr is not a terminal
    (unless FORCE_COLOR is set) or NO_COLOR is set; stdout (the report) is untouched."""

    _FG = {"ok": "green", "warn": "yellow", "bad": "red"}

    def emit(self, record: logging.LogRecord) -> None:
        try:
            tone = getattr(record, "tone", None) or (
                "bad" if record.levelno >= logging.ERROR
                else "warn" if record.levelno >= logging.WARNING
                else None
            )  # fmt: skip
            # NO_COLOR and FORCE_COLOR are the usual conventions; otherwise colour only on a tty.
            color = (
                False if os.environ.get("NO_COLOR")
                else True if os.environ.get("FORCE_COLOR")
                else None
            )  # fmt: skip
            stamp = datetime.fromtimestamp(record.created).strftime("%H:%M:%S")
            typer.secho(f"{stamp} ", err=True, dim=True, nl=False, color=color)
            typer.secho(record.getMessage(), err=True, fg=self._FG.get(tone or ""), color=color)
        except Exception:  # a progress line must never break the job
            self.handleError(record)


@app.callback()
def _main(
    quiet: Annotated[
        bool, typer.Option("--quiet", help="No progress lines on stderr; only the report.")
    ] = False,
) -> None:
    logger = logging.getLogger("sec_filings")
    for h in [h for h in logger.handlers if isinstance(h, _ProgressHandler)]:
        logger.removeHandler(h)
    if not quiet:
        logger.addHandler(_ProgressHandler())
        logger.setLevel(logging.INFO)


_REPORT_LINES = 14
_TODAY = typer.Option("--today", help="Pretend today is this date (YYYY-MM-DD).")


def _fail(message: str, code: int = 3) -> typer.Exit:
    typer.echo(message, err=True)
    return typer.Exit(code=code)


def _settings() -> Settings:
    try:
        return load_settings()
    except ConfigError as exc:
        raise _fail(str(exc)) from exc


def _parse_day(value: str | None) -> date | None:
    if value is None:
        return None
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise _fail(f"--today must be YYYY-MM-DD, got {value!r}") from exc


def _report_date(today: date | None) -> date:
    return today or datetime.now(UTC).astimezone(flows.LONDON).date()


def _print_summary(
    run: RunResult, results: list[CheckResult], settings: Settings, day: date
) -> None:
    for line in render_markdown(results, run, day).splitlines()[:_REPORT_LINES]:
        typer.echo(line)
    typer.echo("")
    typer.echo(
        f"run {run.run_id} ({run.mode}): {run.status}. {run.http_requests} requests; "
        f"filings: {run.rows_inserted} new, {run.rows_updated} updated, "
        f"{run.rows_unchanged} unchanged; companies ok {len(run.companies_ok)}, "
        f"failed {len(run.companies_failed)}"
        + (f" ({', '.join(run.companies_failed)})" if run.companies_failed else "")
    )
    if run.error_summary:
        typer.echo(f"note: {run.error_summary}")
    typer.echo(f"report: {Path(settings.reports_dir) / f'morning_check_{day.isoformat()}.md'}")


def _run_job(job_name: str, today: date | None, tickers: list[str] | None) -> None:
    settings = _settings()
    day = _report_date(today)
    try:
        if job_name == "backfill":
            run = flows.backfill(settings, today=today, tickers=tickers)
        else:
            run = flows.sync(settings, today=today, tickers=tickers)
    except RunFailed as exc:
        run = getattr(exc, "result", None)
        typer.echo(f"run failed: {exc}", err=True)
        if run is not None:
            _print_summary(run, flows.read_results(settings, run.run_id), settings, day)
        raise typer.Exit(code=3) from exc
    except (ConfigError, SecFilingsError, psycopg.Error) as exc:
        raise _fail(f"{type(exc).__name__}: {exc}") from exc
    if run.status == "skipped_locked":
        typer.echo(f"skipped: {run.error_summary}")
        raise typer.Exit(code=exit_code([], False, run_skipped=True))  # 4
    results = flows.read_results(settings, run.run_id)
    _print_summary(run, results, settings, day)
    raise typer.Exit(code=exit_code(results, False))


@app.command()
def sync(today: Annotated[str | None, _TODAY] = None) -> None:
    """Run the daily incremental sync (an empty database is loaded as a backfill)."""
    _run_job("sync", _parse_day(today), None)


@app.command()
def backfill(
    ticker: Annotated[list[str] | None, typer.Option("--ticker", "-t", help="Only these.")] = None,
    today: Annotated[str | None, _TODAY] = None,
) -> None:
    """Load full filing history (every history page, every concept file)."""
    _run_job("backfill", _parse_day(today), list(ticker) if ticker else None)


@app.command()
def check(
    today: Annotated[str | None, _TODAY] = None,
    expect_run_by: Annotated[
        str,
        typer.Option(
            "--expect-run-by",
            help="HH:MM London time: C1 is red from then on if no sync succeeded today.",
        ),
    ] = "06:30",
) -> None:
    """Run the morning checks against what the last sync stored."""
    settings = _settings()
    day = _report_date(_parse_day(today))
    try:
        deadline = time.fromisoformat(expect_run_by)
    except ValueError as exc:
        raise _fail(f"--expect-run-by must be HH:MM, got {expect_run_by!r}") from exc
    try:
        report = flows.check(settings, today=_parse_day(today), expect_run_by=deadline)
    except ChecksRed as exc:
        report = exc.report
    except (ConfigError, SecFilingsError, psycopg.Error) as exc:
        raise _fail(f"{type(exc).__name__}: {exc}") from exc
    for line in report.markdown.splitlines()[:_REPORT_LINES]:
        typer.echo(line)
    typer.echo("")
    typer.echo(f"report: {Path(settings.reports_dir) / f'morning_check_{day.isoformat()}.md'}")
    raise typer.Exit(code=report.exit_code)


@app.command()
def ack(
    check_id: Annotated[str, typer.Argument(help="Check id; only C3 can be acknowledged.")],
    item: Annotated[str, typer.Argument(help="C3: the index day, YYYY-MM-DD.")],
    reason: Annotated[str, typer.Option("--reason", help="Why this is accepted (required).")],
) -> None:
    """Acknowledge a known problem: the check item turns amber and shows the reason."""
    settings = _settings()
    if check_id.upper() != "C3":
        raise _fail(f"only C3 items can be acknowledged, got {check_id!r}")
    if not reason.strip():
        raise _fail("--reason must not be empty")
    try:
        day = date.fromisoformat(item)
    except ValueError as exc:
        raise _fail(f"C3 item must be a day YYYY-MM-DD, got {item!r}") from exc
    conn = connect(settings.database_url)
    try:
        apply_migrations(conn)
        row = conn.execute(
            "SELECT status FROM daily_index_reconciliation WHERE index_date = %s", (day,)
        ).fetchone()
        repo.acknowledge(conn, "C3", day.isoformat(), reason)
        conn.commit()
    finally:
        conn.close()
    typer.echo(f"acknowledged C3 {day}: {reason.strip()}")
    if row is None or row[0] != "missing_filings":
        typer.echo(f"note: {day} has no missing_filings row today; it is stored anyway", err=True)


# --------------------------------------------------------------------------- show


def _render_answer(res: dict) -> None:
    """Print a period_answer() dict the way `show` always has."""
    name = res["company_name"]
    what = f"fiscal year {res['fiscal_year']}" + (
        "" if res["quarter"] is None else f" Q{res['quarter']}"
    )
    versions = ([res["answer"]] if res["answer"] else []) + res["other_versions"]
    width = max(6, *(len(v["form"]) for v in versions)) + 2
    end_note = f"; {res['period_end_note']}" if res.get("period_end_note") else ""
    typer.echo(f"{name}   {what}   (period ended {res['period_end']}{end_note})")

    def line(tag: str, v: dict) -> str:
        flag = "  [filed by the pre-merger shell]" if v["pre_merger_shell"] else ""
        return (
            f"{tag:<9}{v['form']:<{width}}filed {v['filing_date']}  "
            f"{v['accession']}  {v['description']}{flag}"
        )

    canonical = res["answer"]
    if canonical is not None:
        typer.echo(line("ANSWER", canonical))
        conf = (
            f", {canonical['label_confidence']} confidence" if canonical["label_confidence"] else ""
        )
        via = f" via {canonical['cover_source']}" if canonical["cover_source"] else ""
        typer.echo(f"{'':<9}label: {canonical['label_source']}{conf}{via}")
        if canonical["amends_accession"]:
            typer.echo(f"{'':<9}amends {canonical['amends_accession']}")
        if canonical["evidence"]:
            typer.echo(f"{'':<9}evidence: {canonical['evidence']}")
    else:
        typer.echo("ANSWER   none: only partial amendments are on file for this period")
    for v in res["other_versions"]:
        typer.echo(line("also", v))
    exp = res["expected"]
    if exp:
        late = " (filed late)" if exp["filed_late"] else ""
        if exp["status"] == "received_late" and not exp["filed_late"]:
            late = " (late by today's filer category: not claimed)"
        nt = ", late notice filed" if exp["late_notice_filed"] else ""
        typer.echo(
            f"expected: due {exp['due_date']} (with extension "
            f"{exp['due_date_with_extension']}), {exp['filer_category']} "
            f"[{exp['category_source']}]: {exp['status']}{late}{nt}"
        )
        if exp.get("basis_note"):
            typer.echo(f"{'':<9}note: {exp['basis_note']}")
    else:
        typer.echo("expected: no expected-filing row for this period")


@app.command()
def show(
    ticker: Annotated[str, typer.Argument(help="Ticker as in companies.csv, e.g. AAPL")],
    year: Annotated[int, typer.Argument(help="Fiscal year, e.g. 2009")],
    quarter: Annotated[
        int | None, typer.Option("--quarter", "-q", help="Quarter 1 to 3 (omit for annual).")
    ] = None,
) -> None:
    """Answer 'what do we have for TICKER's YEAR annual report?': one canonical row, then every
    other version on file, then the expected-filing status."""
    settings = _settings()
    if quarter is not None and not 1 <= quarter <= 4:
        raise _fail("--quarter must be 1 to 4", 1)
    try:
        conn = connect(settings.database_url)
    except psycopg.Error as exc:
        raise _fail(f"cannot connect to the database: {exc}") from exc
    try:
        conn.row_factory = dict_row
        res = period_answer(conn, ticker, year, quarter)
    except psycopg.errors.UndefinedTable as exc:
        raise _fail("the database has no schema yet: run `sec-filings sync` first", 1) from exc
    finally:
        conn.close()
    if res["status"] in MESSAGE_ONLY:
        typer.echo(res["message"], err=res["status"] == "unknown_company")
        raise typer.Exit(code=MESSAGE_ONLY[res["status"]])
    _render_answer(res)


# --------------------------------------------------------------------------- resolve-companies


def _edgar_settings() -> Settings:
    env = dict(os.environ)
    env.setdefault("DATABASE_URL", "unused")  # resolve-companies never touches the database
    return load_settings(env)


@app.command("resolve-companies")
def resolve_companies() -> None:
    """For each ticker in companies.csv print its CIK(s), whether a reviewed entry exists, and
    hints for a reviewer (foreign filer, earliest filing, former names)."""
    settings = _edgar_settings()
    configs = load_companies(settings.companies_csv, settings.companies_yml)
    today = datetime.now(UTC).date().isoformat()
    with EdgarClient(
        settings.user_agent,
        requests_per_second=settings.requests_per_second,
        request_budget=settings.sync_request_budget,
        fixtures_dir=settings.fixtures_dir,
    ) as client:
        resp = client.get(TICKERS_URL)
        tickers = parse_company_tickers(resp.body) if resp.status == 200 else {}
        if resp.status != 200:
            typer.echo(f"warning: SEC ticker file returned HTTP {resp.status}", err=True)
        for cfg in configs:
            hit = tickers.get(cfg.ticker)
            sec = f"ticker file: CIK {hit[0]}" if hit else "ticker file: not listed"
            if cfg.reviewed:
                ciks = ", ".join(str(s.cik) for s in cfg.ciks) or "none"
                agrees = hit is not None and hit[0] in {s.cik for s in cfg.ciks}
                verdict = "agrees" if agrees else "DISAGREES: review the CIK history"
                typer.echo(f"{cfg.ticker:<6} reviewed    CIK(s) {ciks}; {sec} ({verdict})")
            else:
                typer.echo(f"{cfg.ticker:<6} UNREVIEWED  {sec}")
                if hit is None:
                    typer.echo("       not in the SEC ticker file: add reviewed CIKs to the yml")
                    continue
            hint_ciks = [s.cik for s in cfg.ciks] or [hit[0]]  # type: ignore[index]
            hints = _hints(client, hint_ciks)
            if hints is None:
                typer.echo("       hints unavailable (submissions JSON not found)")
                continue
            name, fye, foreign, earliest, former = hints
            note = ""
            if cfg.reviewed and cfg.foreign_filer is not None and cfg.foreign_filer != foreign:
                note = f" (companies.yml says {cfg.foreign_filer}: check it)"
            typer.echo(f"       {name}; fiscal year end {fye}; earliest filing {earliest}")
            typer.echo(
                f"       foreign filer by its filings (20-F/40-F, no 10-K): "
                f"{'yes' if foreign else 'no'}{note}; former names: {former}"
            )
            if not cfg.reviewed:
                typer.echo("       paste into companies.yml after review:")
                typer.echo(f"{cfg.ticker}:")
                typer.echo(
                    f"  ciks: [{{cik: {hit[0]}, valid_from: null, valid_to: null, "  # type: ignore[index]
                    "source: ticker_file}]"
                )
                typer.echo(f"  foreign_filer: {str(foreign).lower()}")
                typer.echo(f"  reviewed_by: <your name>\n  reviewed_on: {today}")


def _hints(client: EdgarClient, ciks: list[int]) -> tuple[str, str | None, bool, date, str] | None:
    """(name, fiscal year end, foreign filer?, earliest filing, former names) from the
    submissions JSON of each CIK; None when none of them can be read."""
    docs = []
    for cik in ciks:
        resp = client.get(submissions_url(cik))
        if resp.status == 200:
            docs.append(parse_submissions(resp.body))
    if not docs:
        return None
    forms = {f.form.upper() for d in docs for f in d.filings}
    foreign = any(f.startswith(("20-F", "40-F")) for f in forms) and not any(
        f.startswith("10-K") for f in forms
    )
    starts = [f.filing_date for d in docs for f in d.filings] + [
        p.filing_from for d in docs for p in d.pages if p.filing_from
    ]
    former = "; ".join(n.name for d in docs for n in d.meta.former_names) or "none"
    return docs[-1].meta.name, docs[-1].meta.fiscal_year_end_mmdd, foreign, min(starts), former


# --------------------------------------------------------------------------- verify

_NO_DB_HELP = (
    "No database is reachable. Start one with either:\n"
    "  - any Postgres: set DATABASE_URL=postgresql://USER:PASSWORD@HOST:5432/sec_filings\n"
    "  - docker compose up -d db, then use the DATABASE_URL printed in the README"
)


def _repo_root() -> Path | None:
    for candidate in (Path.cwd(), Path(__file__).resolve().parents[2]):
        if (candidate / "tests").is_dir() and (candidate / "pyproject.toml").is_file():
            return candidate
    return None


def _run_unit_tests(root: Path | None) -> tuple[bool, str]:
    if root is None:
        return True, "skipped (no tests directory next to this install)"
    proc = subprocess.run(
        [sys.executable, "-m", "pytest", "-q", "-m", "not db and not live"],
        cwd=root,
        capture_output=True,
        text=True,
        timeout=900,
    )
    lines = [ln for ln in proc.stdout.splitlines() if ln.strip()]
    summary = lines[-1] if lines else "no output"
    if proc.returncode != 0:
        summary += "  <-- FAILED"
    return proc.returncode == 0, summary


def _c6_total(observed: str) -> int:
    try:
        return sum(int(v) for v in json.loads(observed).values())
    except (ValueError, AttributeError):
        return 0


@app.command()
def verify(
    if_db: Annotated[
        bool, typer.Option("--if-db", help="Exit 0 with instructions if no database is reachable.")
    ] = False,
) -> None:
    """Print the evidence block an agent must paste before saying it is done."""
    root = _repo_root()
    red = False
    typer.echo("== sec-filings verify ==")
    ok, summary = _run_unit_tests(root)
    red |= not ok
    typer.echo(f"unit tests (not db, not live): {summary}")

    try:
        settings = load_settings()
        conn = psycopg.connect(settings.database_url, connect_timeout=5)
    except (ConfigError, psycopg.Error) as exc:
        typer.echo(f"database: not reachable ({str(exc).splitlines()[0]})")
        typer.echo(_NO_DB_HELP)
        raise typer.Exit(code=1 if red or not if_db else 0) from exc
    try:
        if conn.execute("SELECT to_regclass('public.check_result')").fetchone()[0] is None:
            typer.echo("database: reachable but empty. Run `sec-filings sync` first.")
            raise typer.Exit(code=1 if red or not if_db else 0)
        latest = conn.execute(
            "SELECT cr.run_id, r.mode FROM check_result cr JOIN run r USING (run_id) "
            "ORDER BY cr.created_at DESC LIMIT 1"
        ).fetchone()
        if latest is None:
            typer.echo("checks: none recorded yet. Run `sec-filings sync` first.")
            raise typer.Exit(code=1 if red or not if_db else 0)
        counts = Counter(
            r[0]
            for r in conn.execute(
                "SELECT status FROM check_result WHERE run_id = %s AND check_id <> 'C12-input'",
                (latest[0],),
            )
        )
        typer.echo(
            f"checks (latest run {latest[0]}, {latest[1]}): {counts['green']} green, "
            f"{counts['amber']} amber, {counts['red']} red"
        )
        red |= counts["red"] > 0

        tickers = [c.ticker for c in load_companies(settings.companies_csv, settings.companies_yml)]
        ctx = CheckContext(latest[0], date.today(), datetime.now(UTC), None, tickers)
        results = check_golden_queries(conn, ctx)
        failed = [r for r in results if r.status == "red"]
        try:
            total = len(
                [
                    q
                    for q in load_golden_queries()
                    if isinstance(q, dict)
                    and str(q.get("company_id", "")).upper() in {t.upper() for t in tickers}
                ]
            )
        except (OSError, ValueError, yaml.YAMLError) as exc:
            typer.echo(f"golden queries: unreadable ({exc})")
        else:
            typer.echo(f"golden queries: {total - len(failed)}/{total} pass")
            for r in failed:
                typer.echo(f"  FAIL {r.message}")
        red |= bool(failed)

        n = conn.execute("SELECT count(*) FROM filing").fetchone()[0]
        baselines = conn.execute(
            "SELECT observed FROM check_result WHERE check_id = 'C6' AND observed IS NOT NULL "
            "ORDER BY created_at DESC LIMIT 2"
        ).fetchall()
        delta = (
            f"{_c6_total(baselines[0][0]) - _c6_total(baselines[1][0]):+d} since the previous run"
            if len(baselines) == 2
            else "first baseline, no previous run to compare"
        )
        typer.echo(f"filing rows: {n} ({delta})")
    finally:
        conn.close()
    typer.echo("RESULT: " + ("RED" if red else "OK"))
    raise typer.Exit(code=1 if red else 0)


@app.command()
def mcp() -> None:
    """Start the read-only MCP server on stdio (needs the `mcp` extra)."""
    try:
        import mcp as _mcp  # noqa: F401
    except ImportError as exc:
        typer.echo(
            "The MCP server needs the optional `mcp` package. Install it with:\n"
            "  uv sync --extra mcp      (or: pip install 'sec-filings[mcp]')\n"
            "or run it directly: uv run --extra mcp sec-filings mcp",
            err=True,
        )
        raise typer.Exit(code=1) from exc
    from sec_filings.mcp_server import main

    main()
