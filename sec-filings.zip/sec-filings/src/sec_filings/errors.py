"""Exception classes (docs/contracts.md section 5)."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from sec_filings.models import CheckReport


class SecFilingsError(Exception):
    """Base class for all package errors."""


class ConfigError(SecFilingsError):
    """Invalid or missing configuration."""


class SecAccessDenied(SecFilingsError):
    """HTTP 403. Stops the run. Never retried."""


class RequestBudgetExceeded(SecFilingsError):
    """The per-run request budget would be exceeded."""


class EdgarHTTPError(SecFilingsError):
    """Non-2xx other than 404, after retries."""


class ParseError(SecFilingsError):
    """A payload could not be parsed."""


class RunFailed(SecFilingsError):
    """Raised by flows.sync when the job itself fails."""


class ChecksRed(SecFilingsError):
    """Raised by flows.check when any check is red."""

    def __init__(self, report: CheckReport) -> None:
        super().__init__("one or more checks are red")
        self.report = report
