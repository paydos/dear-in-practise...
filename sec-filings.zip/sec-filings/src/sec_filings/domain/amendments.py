"""Amendment linking, scope and canonical selection (plan 6.3)."""

from __future__ import annotations

from collections.abc import Sequence
from datetime import UTC, date, datetime, timedelta
from typing import Literal

from sec_filings.models import CanonicalChoice, Label, RawFiling, ScopeSignals, Version

_FULL_WORDS = (
    "restat",
    "complete",
    "full",
    "in its entirety",
    "re-present",
    "financial statements",
)
_PARTIAL_WORDS = ("part iii", "exhibit", "signature", "cover page")
# Primary documents of the amendments the reconciliation judged partial (XBRL, exhibit or
# certification furnishings) are 20 to 76 KB; every complete re-filing is above 700 KB.
_SMALL_PRIMARY_DOC_BYTES = 100_000
_EARLIEST = datetime.min.replace(tzinfo=UTC)


def _raw_key(f: RawFiling) -> tuple[date, datetime, str]:
    return (f.filing_date, f.acceptance_datetime or _EARLIEST, f.accession_number)


def link_amendment(
    amendment: RawFiling,
    amendment_label: Label,
    originals: Sequence[tuple[RawFiling, Label]],
) -> str | None:
    """Same period_of_report -> latest such original filed on or before the amendment;
    else same (fiscal_year, fiscal_period); else nearest earlier original within 400 days."""
    earlier = [
        (f, lab)
        for f, lab in originals
        if f.filing_date <= amendment.filing_date
        and f.accession_number != amendment.accession_number
    ]
    if amendment.period_of_report is not None:
        same_period = [f for f, _ in earlier if f.period_of_report == amendment.period_of_report]
        if same_period:
            return max(same_period, key=_raw_key).accession_number
    if amendment_label.fiscal_year is not None and amendment_label.fiscal_period is not None:
        same_label = [
            f
            for f, lab in earlier
            if lab.fiscal_year == amendment_label.fiscal_year
            and lab.fiscal_period == amendment_label.fiscal_period
        ]
        if same_label:
            return max(same_label, key=_raw_key).accession_number
    window = timedelta(days=400)
    near = [f for f, _ in earlier if amendment.filing_date - f.filing_date <= window]
    if near:
        return max(near, key=_raw_key).accession_number
    return None


_NO_SCOPE_BEFORE = date(2009, 6, 15)  # D-20: no rendered reports before this to judge by


def decide_scope(
    signals: ScopeSignals, filing_date: date | None = None
) -> Literal["full", "partial", "unknown"]:
    """Vetoes first (T-11): descriptions that name only exhibits, Part III, signatures or the
    cover page (``partial_only_text``), or a primary document under 100 KB with no description
    of restated or complete statements, give 'partial'. Positives: has_financial_facts True,
    in_financial_data_sets True, size_ratio >= 0.5, description_says_full True. >= 2 positives
    -> 'full'. has_financial_facts False and size_ratio < 0.25 -> 'partial'. Else 'unknown'.
    An amendment filed before 2009-06-15 (D-20) is always 'unknown': the signals above do not
    exist for it, and a small primary document there says nothing about scope."""
    if filing_date is not None and filing_date < _NO_SCOPE_BEFORE:
        return "unknown"
    if signals.partial_only_text is True:
        return "partial"  # T-11: the description names only exhibits, Part III, a cover fix
    if (
        signals.primary_doc_bytes is not None
        and signals.primary_doc_bytes < _SMALL_PRIMARY_DOC_BYTES
        and signals.description_says_full is not True
    ):
        return "partial"  # a complete periodic report of these filers is never this small
    positives = sum(
        [
            signals.has_financial_facts is True,
            signals.in_financial_data_sets is True,
            signals.size_ratio is not None and signals.size_ratio >= 0.5,
            signals.description_says_full is True,
        ]
    )
    if positives >= 2:
        return "full"
    if (
        signals.has_financial_facts is False
        and signals.size_ratio is not None
        and signals.size_ratio < 0.25
    ):
        return "partial"
    return "unknown"


def partial_only_text(*texts: str | None) -> bool | None:
    """True when at least one text names only exhibits, Part III, signatures or the cover page
    and none of them names restated or complete statements (the veto of T-11); None when no
    text says either."""
    verdicts = [description_says_full(t) for t in texts]
    if True in verdicts:
        return None
    return True if False in verdicts else None


def description_says_full(text: str | None) -> bool | None:
    """True when the description points to a complete document or restated statements,
    False when it points only to Part III, exhibits, signatures or the cover page, None when
    there is no text or it says neither."""
    if text is None or not text.strip():
        return None
    low = text.lower()
    if any(w in low for w in _FULL_WORDS):
        return True
    if any(w in low for w in _PARTIAL_WORDS):
        return False
    return None


def decide_kind(
    *,
    scope: str,
    linked_to_correction_event: bool,
    cover_error_flag: bool | None,
    manual_kind: str | None,
) -> tuple[str, str]:
    """Return (kind, evidence text)."""
    if manual_kind:
        return manual_kind, f"manual: kind set to '{manual_kind}' by a reviewed override"
    if scope == "full" and (linked_to_correction_event or cover_error_flag is True):
        reasons = []
        if linked_to_correction_event:
            reasons.append("linked to a correction event")
        if cover_error_flag is True:
            reasons.append("own cover error-correction flag is set")
        return "restatement", "rule: full scope and " + " and ".join(reasons)
    if scope == "partial":
        return (
            "administrative",
            "rule: partial scope (no financial statements; Part III, exhibits or cover fix)",
        )
    return "unknown", f"rule: scope '{scope}' with no correction link or cover flag; not claimed"


def select_canonical(versions: Sequence[Version]) -> CanonicalChoice:
    """complete = original, or amendment with scope 'full'. Canonical = latest complete by
    (filing_date, acceptance_datetime). Latest filed = latest of all. Original = earliest
    original. Ties on date break on acceptance time, then accession number."""
    if not versions:
        raise ValueError("select_canonical needs at least one version")

    def key(v: Version) -> tuple[date, datetime, str]:
        return (v.filing_date, v.acceptance_datetime or _EARLIEST, v.accession_number)

    complete = [v for v in versions if not v.is_amendment or v.amendment_scope == "full"]
    originals = [v for v in versions if not v.is_amendment]
    return CanonicalChoice(
        canonical_accession=max(complete, key=key).accession_number if complete else None,
        latest_filed_accession=max(versions, key=key).accession_number,
        original_accession=min(originals, key=key).accession_number if originals else None,
        version_count=len(versions),
    )
