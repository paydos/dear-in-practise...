"""Filing deadlines (plan 7)."""

from __future__ import annotations

import calendar
from datetime import date, timedelta
from functools import cache

from sec_filings.models import DueDates, FilerCategory, ReportKind

_ANNUAL_DAYS: dict[str, int] = {"large_accelerated": 60, "accelerated": 75, "non_accelerated": 90}
_QUARTERLY_DAYS: dict[str, int] = {
    "large_accelerated": 40,
    "accelerated": 40,
    "non_accelerated": 45,
}
_FOREIGN_CHANGE = date(2011, 12, 15)
# SEC COVID-19 conditional relief (March 2020 orders): 45 extra days for reports originally due
# in this window, given a current report explaining the delay. Assumed, not verified.
COVID_WINDOW = (date(2020, 3, 1), date(2020, 7, 1))
COVID_EXTRA_DAYS = 45
COVID_NOTE = "COVID-19 relief assumed (not verified)"


def normalize_filer_category(raw: str | None) -> FilerCategory | None:
    """Normalise raw SEC category text ('Large accelerated filer', 'Non-accelerated Filer'...)."""
    if not raw:
        return None
    text = raw.lower().replace("-", " ")
    if "large" in text and "accelerated" in text:
        return "large_accelerated"
    if "non accelerated" in text or "nonaccelerated" in text:
        return "non_accelerated"
    if "accelerated" in text:
        return "accelerated"
    if "smaller reporting" in text:
        return "non_accelerated"
    return None


def _nth_weekday(year: int, month: int, weekday: int, n: int) -> date:
    first = date(year, month, 1)
    offset = (weekday - first.weekday()) % 7
    return first + timedelta(days=offset + 7 * (n - 1))


def _last_weekday(year: int, month: int, weekday: int) -> date:
    last = date(year, month, calendar.monthrange(year, month)[1])
    return last - timedelta(days=(last.weekday() - weekday) % 7)


def _observed(d: date) -> date:
    if d.weekday() == 5:
        return d - timedelta(days=1)
    if d.weekday() == 6:
        return d + timedelta(days=1)
    return d


@cache
def us_federal_holidays(year: int) -> frozenset[date]:
    """Observed dates, rule-based, Juneteenth from 2021.

    Saturday holidays are observed on Friday and Sunday holidays on Monday. A New Year's Day
    on a Saturday of the next year is observed on 31 December of this year, so it is included
    here. A New Year's Day on a Saturday this year is observed in the previous year.
    """
    fixed = [date(year, 1, 1), date(year, 7, 4), date(year, 11, 11), date(year, 12, 25)]
    if year >= 2021:
        fixed.append(date(year, 6, 19))
    days = {_observed(d) for d in fixed}
    days |= {
        _nth_weekday(year, 1, 0, 3),  # Martin Luther King Jr. Day
        _nth_weekday(year, 2, 0, 3),  # Washington's Birthday
        _last_weekday(year, 5, 0),  # Memorial Day
        _nth_weekday(year, 9, 0, 1),  # Labor Day
        _nth_weekday(year, 10, 0, 2),  # Columbus Day
        _nth_weekday(year, 11, 3, 4),  # Thanksgiving
    }
    return frozenset(d for d in days if d.year == year) | (
        frozenset({date(year, 12, 31)}) if date(year + 1, 1, 1).weekday() == 5 else frozenset()
    )


def _is_business_day(d: date) -> bool:
    return d.weekday() < 5 and d not in us_federal_holidays(d.year)


def roll_forward(d: date) -> date:
    """Roll to the next business day (the date itself when it already is one)."""
    while not _is_business_day(d):
        d += timedelta(days=1)
    return d


def _add_months(d: date, months: int) -> date:
    index = d.year * 12 + (d.month - 1) + months
    year, month = divmod(index, 12)
    month += 1
    last = calendar.monthrange(year, month)[1]
    if d.day == calendar.monthrange(d.year, d.month)[1]:
        return date(year, month, last)
    return date(year, month, min(d.day, last))


def due_dates(
    *,
    report_kind: ReportKind,
    is_foreign: bool,
    category: FilerCategory | None,
    period_end: date,
    first_annual_after_listing: bool = False,
) -> DueDates:
    """10-K 60/75/90, 10-Q 40/40/45, 20-F 4 months (6 if period_end < 2011-12-15).
    Unknown category -> non_accelerated. Extension +15 annual, +5 quarterly, then rolled.

    The extension is counted from the already rolled due date (D-18, lenient reading of Rule
    12b-25: 15 or 5 calendar days after the prescribed date, and a prescribed date on a weekend
    or holiday is the next business day), then the sum is rolled again.
    """
    if is_foreign:
        if report_kind != "annual":
            raise ValueError("foreign private issuers have no periodic quarterly deadline")
        months = 6 if period_end < _FOREIGN_CHANGE else 4
        due = roll_forward(_add_months(period_end, months))
        return DueDates(
            due=due,
            due_with_extension=roll_forward(due + timedelta(days=15)),
            basis=f"20-F, {months} months after period end, extension +15 days",
        )
    used: FilerCategory = "non_accelerated"
    if category is not None and not first_annual_after_listing:
        used = category
    if report_kind == "annual":
        days, ext, form = _ANNUAL_DAYS[used], 15, "10-K"
    else:
        days, ext, form = _QUARTERLY_DAYS[used], 5, "10-Q"
    due = roll_forward(period_end + timedelta(days=days))
    suffix = " (first annual after listing)" if first_annual_after_listing else ""
    return DueDates(
        due=due,
        due_with_extension=roll_forward(due + timedelta(days=ext)),
        basis=f"{form}, {used}, {days} days after period end, extension +{ext} days{suffix}",
    )


def covid_relief_applies(due: date, filed: date | None) -> bool:
    """True for a filing after its normal deadline but within 45 days of it, when that deadline
    fell from 2020-03-01 to 2020-07-01 (SEC COVID-19 conditional relief, assumed)."""
    if filed is None or not COVID_WINDOW[0] <= due <= COVID_WINDOW[1]:
        return False
    return due < filed <= due + timedelta(days=COVID_EXTRA_DAYS)


def timeliness(*, dates: DueDates, filed: date | None, nt_filed: bool, today: date) -> str:
    """'received' | 'received_late' | 'nt_filed' | 'due_soon' (<= 7 days to due) |
    'overdue' | 'pending'. A report filed inside the extension counts as timely only when
    a late notice was filed. A filing covered by the assumed COVID-19 relief is
    `received` (see covid_relief_applies)."""
    if filed is not None:
        if filed <= dates.due:
            return "received"
        if covid_relief_applies(dates.due, filed):
            return "received"
        if nt_filed and filed <= dates.due_with_extension:
            return "received"
        return "received_late"
    if nt_filed and today <= dates.due_with_extension:
        return "nt_filed"
    if today > dates.due:
        return "overdue"
    if (dates.due - today).days <= 7:
        return "due_soon"
    return "pending"
