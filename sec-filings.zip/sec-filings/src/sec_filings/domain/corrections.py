"""Correction events (plan 6.4)."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import date, timedelta

from sec_filings.models import CoverTags, FormFamily, Label, RawFiling

_LINK_WINDOW = timedelta(days=120)
_ORIGINAL_WINDOW = timedelta(days=730)
_PERIODIC = (
    "annual",
    "annual_amendment",
    "quarterly",
    "quarterly_amendment",
    "transition_annual",
    "transition_quarterly",
)


@dataclass(frozen=True)
class CorrectionEventDraft:
    company_id: str
    event_type: str
    source_accession: str
    event_date: date
    corrected_in_accessions: tuple[str, ...]
    link_confidence: str
    pre_merger_shell: bool


def build_correction_events(
    *,
    company_id: str,
    filings: Sequence[tuple[RawFiling, FormFamily, Label, CoverTags | None]],
    amendment_scopes: Mapping[str, str],
    pre_merger_until: date | None,
) -> list[CorrectionEventDraft]:
    """non_reliance_8k: link full-scope amendments filed within 730 days after the event
    (confidence 'medium'); if none, the first original annual filed after the event ('low');
    if none, 'none'. cover_error_flag: any periodic filing whose cover flag is True;
    corrected_in = itself ('high')."""

    def shell(d: date) -> bool:
        return pre_merger_until is not None and d < pre_merger_until

    def order(f: RawFiling) -> tuple[date, str]:
        return (f.filing_date, f.accession_number)

    events: list[CorrectionEventDraft] = []
    for filing, family, _, _ in filings:
        if family != "non_reliance_8k":
            continue
        event_date = filing.filing_date
        amendments = sorted(
            (
                f
                for f, fam, _, _ in filings
                if fam in ("annual_amendment", "quarterly_amendment")
                and amendment_scopes.get(f.accession_number) == "full"
                and event_date <= f.filing_date <= event_date + _LINK_WINDOW
            ),
            key=order,
        )
        later = sorted(
            (
                f
                for f, fam, _, _ in filings
                if fam in ("annual", "quarterly")
                and event_date < f.filing_date <= event_date + _ORIGINAL_WINDOW
            ),
            key=order,
        )
        linked = tuple(f.accession_number for f in amendments)
        if later:
            linked += (later[0].accession_number,)
        confidence = "high" if amendments else ("medium" if later else "none")
        events.append(
            CorrectionEventDraft(
                company_id=company_id,
                event_type="non_reliance_8k",
                source_accession=filing.accession_number,
                event_date=event_date,
                corrected_in_accessions=linked,
                link_confidence=confidence,
                pre_merger_shell=shell(event_date),
            )
        )

    for filing, family, _, cover in filings:
        if family in _PERIODIC and cover is not None and cover.error_correction_flag is True:
            events.append(
                CorrectionEventDraft(
                    company_id=company_id,
                    event_type="cover_error_flag",
                    source_accession=filing.accession_number,
                    event_date=filing.filing_date,
                    corrected_in_accessions=(filing.accession_number,),
                    link_confidence="high",
                    pre_merger_shell=shell(filing.filing_date),
                )
            )
    events.sort(key=lambda e: (e.event_date, e.event_type, e.source_accession))
    return events
