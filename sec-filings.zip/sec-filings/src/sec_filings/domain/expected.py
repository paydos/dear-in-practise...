"""Expected-filing calendar (plan 7)."""

from __future__ import annotations

import calendar
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import date, timedelta

from sec_filings.domain.deadlines import due_dates, normalize_filer_category, timeliness
from sec_filings.domain.labels import effective_period_end, fye_month, infer_fiscal_year_end
from sec_filings.models import Convention, CoverTags, FilerCategory, FormFamily, Label, RawFiling

_MATCH_DAYS = 10
_HORIZON_DAYS = 7
# Before this the filer category cannot be read from tagged filings (contract 12.3).
_FIRST_EXPECTED_PERIOD_END = date(2009, 6, 15)
_PERIOD_ORDER = {"Q1": 1, "Q2": 2, "Q3": 3, "FY": 4}
_ANNUAL_NT_PREFIXES = ("NT 10-K", "NT 20-F", "NT 40-F")
_QUARTERLY_NT_PREFIXES = ("NT 10-Q",)

_Filing = tuple[RawFiling, FormFamily, Label, CoverTags | None]


@dataclass(frozen=True)
class ExpectedFiling:
    company_id: str
    report_kind: str
    fiscal_year: int
    fiscal_period: str
    period_end_estimate: date
    filer_category_used: str | None
    category_source: str | None
    due_date: date
    due_date_with_extension: date
    status: str
    matched_accession: str | None
    nt_accession: str | None


@dataclass(frozen=True)
class _Slot:
    kind: str
    fiscal_year: int
    fiscal_period: str
    end: date

    @property
    def key(self) -> tuple[int, int]:
        return (self.fiscal_year, _PERIOD_ORDER[self.fiscal_period])


def _month_end(year: int, month: int) -> date:
    return date(year, month, calendar.monthrange(year, month)[1])


def _shift_month_end(d: date, months: int) -> date:
    index = d.year * 12 + (d.month - 1) + months
    year, month = divmod(index, 12)
    return _month_end(year, month + 1)


def _slots(m_fye: int, convention: Convention, first_year: int, last_year: int, annual_only: bool):
    """Slots derived from the fiscal year end alone, so a missing filing shows as a gap."""
    offset = -1 if convention == "starts_in" else 0
    out: list[_Slot] = []
    for year in range(first_year, last_year + 1):
        fye = _month_end(year, m_fye)
        label_year = year + offset
        if not annual_only:
            for q, back in (("Q1", 9), ("Q2", 6), ("Q3", 3)):
                out.append(_Slot("quarterly", label_year, q, _shift_month_end(fye, -back)))
        out.append(_Slot("annual", label_year, "FY", fye))
    return out


def _kind_of(family: FormFamily) -> str | None:
    if family == "annual":
        return "annual"
    if family == "quarterly":
        return "quarterly"
    return None


def build_expected(
    *,
    company_id: str,
    is_foreign: bool,
    fiscal_year_end_mmdd: str | None,
    convention: Convention,
    filings: Sequence[_Filing],
    current_filer_category: str | None,
    pre_merger_until: date | None,
    today: date,
    float_categories: Mapping[str, FilerCategory] | None = None,
) -> list[ExpectedFiling]:
    """One annual per fiscal year and three quarterlies (US only) from the first periodic
    filing (after pre_merger_until) up to the latest period whose due date is <= today + 7
    days. Category chain (T-12): matched filing's own cover -> its own public-float estimate
    (``float_categories``, accession -> category) -> previous annual report's cover -> previous
    annual report's float estimate -> today's category (source 'current') -> none."""
    float_categories = float_categories or {}
    annual_filings = [t for t in filings if t[1] == "annual"]
    mmdd = fiscal_year_end_mmdd
    if fye_month(mmdd) is None:
        mmdd = infer_fiscal_year_end(
            d for f, _, _, _ in annual_filings if (d := f.period_of_report) is not None
        )
    m_fye = fye_month(mmdd)
    if m_fye is None:
        return []

    def in_scope(t: _Filing) -> bool:
        if _kind_of(t[1]) is None:
            return False
        if is_foreign and t[1] != "annual":
            return False
        return pre_merger_until is None or t[0].filing_date >= pre_merger_until

    periodic = sorted(
        (t for t in filings if in_scope(t)), key=lambda t: (t[0].filing_date, t[0].accession_number)
    )
    if not periodic:
        return []

    slots = _slots(m_fye, convention, today.year - 40, today.year + 2, is_foreign)
    slots = [s for s in slots if s.end.year >= 1993]

    # Per-filing period end used for date matching and due dates.
    info: dict[str, tuple[date | None, bool]] = {}
    for f, fam, _, _ in periodic:
        info[f.accession_number] = effective_period_end(
            family=fam,
            period_of_report=f.period_of_report,
            filing_date=f.filing_date,
            fiscal_year_end_mmdd=mmdd,
        )

    def end_of(f: RawFiling) -> date | None:
        eff, corrected = info[f.accession_number]
        if not corrected and f.period_of_report is not None:
            return f.period_of_report
        return eff

    # Match filings to slots: label first, then period end within 10 days.
    by_key = {(s.kind, s.key): s for s in slots}
    assigned: dict[tuple[str, tuple[int, int]], _Filing] = {}
    used: set[str] = set()
    for t in periodic:
        f, fam, label, _ = t
        kind = _kind_of(fam)
        if label.fiscal_year is None or label.fiscal_period not in _PERIOD_ORDER:
            continue
        slot_key = (kind, (label.fiscal_year, _PERIOD_ORDER[label.fiscal_period]))
        if (
            slot_key in by_key
            and slot_key not in assigned
            and _kind_of(fam) == by_key[slot_key].kind
        ):
            assigned[slot_key] = t
            used.add(f.accession_number)
    for t in periodic:
        f, fam, _, _ = t
        if f.accession_number in used:
            continue
        end = end_of(f)
        if end is None:
            continue
        near = [
            s
            for s in slots
            if s.kind == _kind_of(fam)
            and (s.kind, s.key) not in assigned
            and abs((s.end - end).days) <= _MATCH_DAYS
        ]
        if near:
            best = min(near, key=lambda s: abs((s.end - end).days))
            assigned[(best.kind, best.key)] = t
            used.add(f.accession_number)

    # Start at the first periodic filing's slot.
    order = {(s.kind, s.key): i for i, s in enumerate(sorted(slots, key=lambda s: (s.end, s.kind)))}
    slot_of = {id(t): k for k, t in assigned.items()}
    start_index: int | None = None
    for t in periodic:
        k = slot_of.get(id(t))
        if k is not None:
            start_index = order[k]
            break
    if start_index is None:
        return []

    # Late notices by kind.
    notices = sorted(
        (t for t in filings if t[1] == "late_notice" and t[0].period_of_report is not None),
        key=lambda t: (t[0].filing_date, t[0].accession_number),
    )

    def notice_for(slot: _Slot) -> RawFiling | None:
        prefixes = _ANNUAL_NT_PREFIXES if slot.kind == "annual" else _QUARTERLY_NT_PREFIXES
        for f, _, _, _ in notices:
            if (
                f.form.strip().upper().startswith(prefixes)
                and f.period_of_report is not None
                and abs((f.period_of_report - slot.end).days) <= _MATCH_DAYS
            ):
                return f
        return None

    annual_cats = sorted(
        (
            (end_of(f), c.filer_category if c is not None else None, f.accession_number)
            for f, fam, _, c in filings
            if fam == "annual" and f.accession_number in info
        ),
        key=lambda x: x[0] or date.min,
    )
    # (period end, category, source) of each annual report that has one.
    annual_covers: list[tuple[date, FilerCategory, str]] = []
    for e, raw_cat, acc in annual_cats:
        if e is None:
            continue
        cat = normalize_filer_category(raw_cat)
        if cat is not None:
            annual_covers.append((e, cat, "previous_cover"))
        elif acc in float_categories:
            annual_covers.append((e, float_categories[acc], "previous_public_float"))
    current = normalize_filer_category(current_filer_category)
    horizon = today + timedelta(days=_HORIZON_DAYS)

    ordered = sorted(slots, key=lambda s: (s.end, s.kind))
    rows: list[ExpectedFiling] = []
    first_annual_done = False
    for idx, slot in enumerate(ordered):
        if idx < start_index:
            continue
        if slot.end < _FIRST_EXPECTED_PERIOD_END:
            first_annual_done = first_annual_done or slot.kind == "annual"
            continue
        match = assigned.get((slot.kind, slot.key))
        matched_f = match[0] if match else None
        end = (end_of(matched_f) if matched_f else None) or slot.end

        category: FilerCategory | None = None
        source: str = "none"
        if match is not None and match[3] is not None:
            category = normalize_filer_category(match[3].filer_category)
            if category is not None:
                source = "cover"
        if category is None and matched_f is not None:
            own = float_categories.get(matched_f.accession_number)
            if own is not None:
                category, source = own, "public_float"
        if category is None:
            earlier = [(c, s) for e, c, s in annual_covers if e < end]
            if earlier:
                category, source = earlier[-1]
        if category is None and current is not None:
            category, source = current, "current"

        dues = due_dates(
            report_kind=slot.kind,  # type: ignore[arg-type]
            is_foreign=is_foreign,
            category=category,
            period_end=end,
            first_annual_after_listing=slot.kind == "annual" and not first_annual_done,
        )
        if slot.kind == "annual":
            first_annual_done = True
        if matched_f is None and dues.due > horizon:
            continue
        if pre_merger_until is not None and matched_f is None and dues.due < pre_merger_until:
            continue
        nt = notice_for(slot)
        status = timeliness(
            dates=dues,
            filed=matched_f.filing_date if matched_f else None,
            nt_filed=nt is not None,
            today=today,
        )
        rows.append(
            ExpectedFiling(
                company_id=company_id,
                report_kind=slot.kind,
                fiscal_year=slot.fiscal_year,
                fiscal_period=slot.fiscal_period,
                period_end_estimate=end,
                filer_category_used=category,
                category_source=source,
                due_date=dues.due,
                due_date_with_extension=dues.due_with_extension,
                status=status,
                matched_accession=matched_f.accession_number if matched_f else None,
                nt_accession=nt.accession_number if nt else None,
            )
        )
    return rows
