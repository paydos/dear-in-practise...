"""Fiscal year / period labelling (plan 6.2, contract 9 and amendment 1)."""

from __future__ import annotations

import calendar
from collections import Counter
from collections.abc import Iterable
from datetime import date, timedelta

from sec_filings.models import Convention, CoverTags, FiscalPeriod, FormFamily, Label

_NO_LABEL_FAMILIES = ("foreign_current_report", "late_notice", "non_reliance_8k")
_ANNUAL_FAMILIES = ("annual", "annual_amendment")
_QUARTERLY_FAMILIES = ("quarterly", "quarterly_amendment")
_TRANSITION_FAMILIES = ("transition_annual", "transition_quarterly")
_VALID_PERIODS = ("FY", "Q1", "Q2", "Q3", "Q4", "H1", "H2", "OTHER")


def _month_end(year: int, month: int) -> date:
    return date(year, month, calendar.monthrange(year, month)[1])


def snap_to_month_end(d: date, tolerance_days: int = 7) -> date:
    """Snap a date within `tolerance_days` of a month end to that month end.

    Dates just after a month end (GameStop 2025-02-01) snap back to it; dates just before
    one (Apple 2009-09-26) snap forward. Other dates are returned unchanged.
    """
    this_end = _month_end(d.year, d.month)
    if (this_end - d).days <= tolerance_days:
        return this_end
    prev_end = d.replace(day=1) - timedelta(days=1)
    if (d - prev_end).days <= tolerance_days:
        return prev_end
    return d


def fye_month(fiscal_year_end_mmdd: str | None) -> int | None:
    """Month number from an 'MMDD' fiscal year end, or None when missing or malformed."""
    if not fiscal_year_end_mmdd or len(fiscal_year_end_mmdd) != 4:
        return None
    try:
        month = int(fiscal_year_end_mmdd[:2])
    except ValueError:
        return None
    return month if 1 <= month <= 12 else None


def infer_fiscal_year_end(annual_period_ends: Iterable[date]) -> str | None:
    """Most common month of the snapped annual period ends, as 'MMDD' (month's last day)."""
    months = Counter(snap_to_month_end(d).month for d in annual_period_ends)
    if not months:
        return None
    top = max(months.values())
    month = min(m for m, n in months.items() if n == top)
    return f"{month:02d}{calendar.monthrange(2001, month)[1]:02d}"


def _period_ends(month: int, years: range, offsets: tuple[int, ...]) -> list[date]:
    """Month-ends of the fiscal-year-end month and the given quarter offsets (months back)."""
    out: list[date] = []
    for year in years:
        for back in offsets:
            index = year * 12 + (month - 1) - back
            y, m = divmod(index, 12)
            out.append(_month_end(y, m + 1))
    return out


def _is_fiscal_period_end(
    period: date | None,
    filing_date: date,
    month: int | None,
    annual: bool,
    quarterly: bool,
) -> bool:
    """True when the period is a real fiscal period end (a month end in the fiscal-year-end
    month, or a quarter end offset from it) that falls strictly before the filing date.
    Such a filing is not a bad cover date even when it is filed within 14 days of the
    period end (Oracle, May year end, files its 10-Qs about 11 to 13 days after quarter end)."""
    if period is None or month is None or not (annual or quarterly) or period >= filing_date:
        return False
    if period != _month_end(period.year, period.month):
        return False
    offsets = (0,) if annual else (0, 3, 6, 9)
    return (month - period.month) % 12 in offsets


def effective_period_end(
    *,
    family: FormFamily,
    period_of_report: date | None,
    filing_date: date,
    fiscal_year_end_mmdd: str | None,
) -> tuple[date | None, bool]:
    """Return (period end to label with, corrected?). See contract 12.2.

    A period is unreliable when missing, on or after filing_date - 14 days, or too far
    (> 31 days) from every fiscal year end (annual) or fiscal quarter end (quarterly).
    Unreliable periods are replaced by the latest fiscal year end (annual) or Q1 to Q3
    quarter end (quarterly) at least 20 days before the filing date.
    """
    annual = family in _ANNUAL_FAMILIES
    quarterly = family in _QUARTERLY_FAMILIES
    month = fye_month(fiscal_year_end_mmdd)
    suspicious = period_of_report is None or period_of_report >= filing_date - timedelta(days=14)
    if (
        suspicious
        and quarterly
        and _is_fiscal_period_end(period_of_report, filing_date, month, annual, quarterly)
    ):
        suspicious = False
    if not suspicious and month is not None and period_of_report is not None:
        years = range(period_of_report.year - 1, period_of_report.year + 2)
        if annual:
            ends = _period_ends(month, years, (0,))
        elif quarterly:
            ends = _period_ends(month, years, (0, 3, 6, 9))
        else:
            ends = []
        if ends and min(abs((period_of_report - e).days) for e in ends) > 31:
            suspicious = True
    if suspicious and month is not None and (annual or quarterly):
        cutoff = filing_date - timedelta(days=20)
        years = range(filing_date.year - 2, filing_date.year + 2)
        candidates = [
            e for e in _period_ends(month, years, (0,) if annual else (3, 6, 9)) if e <= cutoff
        ]
        return max(candidates), True
    if period_of_report is None:
        return None, False
    if quarterly:
        return period_of_report, False
    return snap_to_month_end(period_of_report), False


def learn_convention(observations: Iterable[tuple[int, date]]) -> Convention:
    """Observations are (declared fiscal year, period of report) for annual filings.
    Offset = fy - snapped period year. With >= 3 observations the offset shared by at least
    60 % of them wins: 0 -> 'ends_in', -1 -> 'starts_in'; otherwise 'unknown' (12.1)."""
    offsets = [fy - snap_to_month_end(period).year for fy, period in observations]
    n = len(offsets)
    if n < 3:
        return "unknown"
    if offsets.count(0) * 5 >= n * 3:
        return "ends_in"
    if offsets.count(-1) * 5 >= n * 3:
        return "starts_in"
    return "unknown"


def normalize_fiscal_period(raw: str | None) -> FiscalPeriod | None:
    """Normalise a raw DocumentFiscalPeriodFocus value."""
    if raw is None:
        return None
    value = raw.strip().upper()
    if value in _VALID_PERIODS:
        return value  # type: ignore[return-value]
    return None


def label_filing(
    *,
    family: FormFamily,
    period_of_report: date | None,
    cover: CoverTags | None,
    convention: Convention,
    fiscal_year_end_mmdd: str | None,
    manual: Label | None = None,
) -> Label:
    """Order: manual -> tier 1 filing_dei (plausible: |fy - period.year| <= 1) -> tier 2
    convention -> tier 3 rule (assume ends_in) -> none. See contract 9."""
    if manual is not None:
        return manual
    if family in _NO_LABEL_FAMILIES:
        return Label(None, None, "none", None)

    transition = family in _TRANSITION_FAMILIES
    period = snap_to_month_end(period_of_report) if period_of_report else None
    derived = _derive(family, period, fiscal_year_end_mmdd) if period else None

    # Known convention: always derive from the period end; the declared label only
    # decides the source and confidence (contract 12.1).
    if convention != "unknown" and derived is not None:
        fye_year, fiscal_period = derived
        year = fye_year + (0 if convention == "ends_in" else -1)
        if cover is not None and cover.fiscal_year == year:
            fp = normalize_fiscal_period(cover.fiscal_period)
            if family in _ANNUAL_FAMILIES:
                fp = "FY"  # GE's FY2014 cover says Q4
            if fp is not None and (transition or fp == fiscal_period):
                return Label(year, fiscal_period, "filing_dei", "high")
        return Label(year, fiscal_period, "convention", "medium")

    # Unknown convention: the filing's own cover tags, as declared.
    if cover is not None and cover.fiscal_year is not None:
        fp = normalize_fiscal_period(cover.fiscal_period)
        plausible = period is None or abs(cover.fiscal_year - period.year) <= 1
        if family in _ANNUAL_FAMILIES:
            fp = "FY"  # GE's FY2014 cover says Q4
        if fp is not None and plausible:
            return Label(cover.fiscal_year, "OTHER" if transition else fp, "filing_dei", "high")

    if derived is None:
        return Label(None, None, "none", None)
    return Label(derived[0], derived[1], "rule", "low")


def _derive(
    family: FormFamily, period: date, fiscal_year_end_mmdd: str | None
) -> tuple[int, FiscalPeriod] | None:
    """(fiscal year end's calendar year, fiscal period) from a snapped period end."""
    transition = family in _TRANSITION_FAMILIES
    m_fye = fye_month(fiscal_year_end_mmdd)
    if family in _QUARTERLY_FAMILIES:
        if m_fye is None:
            return None
        quarter = ((period.month - m_fye - 1) % 12) // 3 + 1
        fye_year = period.year if period.month <= m_fye else period.year + 1
        return fye_year, f"Q{quarter}"  # type: ignore[return-value]
    # Annual and transition reports: the period end is the fiscal year end.
    fye_year = period.year
    if family == "transition_quarterly" and m_fye is not None and period.month > m_fye:
        fye_year = period.year + 1
    return fye_year, "OTHER" if transition else "FY"
