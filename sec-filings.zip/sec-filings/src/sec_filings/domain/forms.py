"""Form type classification (plan 6.1)."""

from __future__ import annotations

from collections.abc import Sequence

from sec_filings.models import FormFamily, ReportKind

_FORM_TO_FAMILY: dict[str, FormFamily] = {
    "10-K": "annual",
    "10-K405": "annual",
    "10-KSB": "annual",
    "20-F": "annual",
    "40-F": "annual",
    "10-KT": "transition_annual",
    "10-KSBT": "transition_annual",
    "10-K/A": "annual_amendment",
    "10-K405/A": "annual_amendment",
    "10-KSB/A": "annual_amendment",
    "10-KT/A": "annual_amendment",
    "20-F/A": "annual_amendment",
    "40-F/A": "annual_amendment",
    "10-Q": "quarterly",
    "10-QSB": "quarterly",
    "10-QT": "transition_quarterly",
    "10-Q/A": "quarterly_amendment",
    "10-QSB/A": "quarterly_amendment",
    "10-QT/A": "quarterly_amendment",
    "6-K": "foreign_current_report",
    "6-K/A": "foreign_current_report",
}
for _nt in ("NT 10-K", "NT 10-Q", "NT 20-F", "NT 10-KT", "NT 10-QT"):
    _FORM_TO_FAMILY[_nt] = "late_notice"
    _FORM_TO_FAMILY[_nt + "/A"] = "late_notice"

_UNKNOWN_PREFIXES = ("10-K", "10-Q", "20-F", "40-F", "6-K", "NT 10-", "NT 20-F", "NT 40-F")

_ANNUAL_FAMILIES = ("annual", "annual_amendment", "transition_annual")
_QUARTERLY_FAMILIES = ("quarterly", "quarterly_amendment", "transition_quarterly")
_ORIGINAL = {
    "annual_amendment": "annual",
    "quarterly_amendment": "quarterly",
}


def form_family(form: str, items: Sequence[str] = ()) -> FormFamily | None:
    """Map a form type (and 8-K items) to a family, per plan 6.1."""
    key = form.strip().upper()
    if key == "8-K":
        return "non_reliance_8k" if "4.02" in [i.strip() for i in items] else None
    return _FORM_TO_FAMILY.get(key)


def report_kind(family: FormFamily) -> ReportKind | None:
    """annual*/transition_annual -> 'annual'; quarterly* -> 'quarterly'; else None."""
    if family in _ANNUAL_FAMILIES:
        return "annual"
    if family in _QUARTERLY_FAMILIES:
        return "quarterly"
    return None


def is_amendment(family: FormFamily) -> bool:
    """True for annual_amendment and quarterly_amendment."""
    return family in ("annual_amendment", "quarterly_amendment")


def original_family(family: FormFamily) -> FormFamily | None:
    """annual_amendment -> annual, quarterly_amendment -> quarterly, ...

    Families that are not amendments return themselves for the periodic originals and None
    for families with no original (current reports, late notices, non-reliance 8-Ks).
    """
    if family in _ORIGINAL:
        return _ORIGINAL[family]  # type: ignore[return-value]
    if family in ("annual", "quarterly", "transition_annual", "transition_quarterly"):
        return family
    return None


def is_unknown_periodic_form(form: str) -> bool:
    """Prefix 10-K/10-Q/20-F/40-F/6-K/NT 10-/NT 20-F/NT 40-F and form_family is None."""
    key = form.strip().upper()
    return key.startswith(_UNKNOWN_PREFIXES) and form_family(key) is None
