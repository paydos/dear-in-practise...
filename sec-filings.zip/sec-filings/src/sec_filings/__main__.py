"""Allow `python -m sec_filings ...` as an equivalent of the `sec-filings` console script.

Some locked-down Windows machines refuse to run freshly built console-script launchers;
this entry point needs only the Python interpreter.
"""

from sec_filings.cli import app

if __name__ == "__main__":
    app(prog_name="sec-filings")
