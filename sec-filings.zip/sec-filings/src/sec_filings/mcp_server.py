"""Read-only MCP server over the filings database (PLAN.md section 9).

Five fixed, parameterised queries; no free-SQL tool. Every connection is set read-only with a
5 second statement timeout. The tool functions are plain Python (they return JSON-serialisable
dicts) so tests can call them directly; `build_server()` registers them with FastMCP, which is
imported only there, so the `mcp` package stays an optional extra.
"""

from __future__ import annotations

import datetime as dt
import os
import re
from collections.abc import Iterator
from contextlib import contextmanager
from functools import wraps
from typing import Any
from zoneinfo import ZoneInfo

import psycopg
from psycopg.rows import dict_row

from sec_filings.answers import find_company, period_answer

LONDON = ZoneInfo("Europe/London")
STATEMENT_TIMEOUT_MS = 5000
MAX_LIMIT = 200

INSTRUCTIONS = """\
Read-only view of SEC periodic filings (10-K annual, 10-Q quarterly, 20-F for foreign private \
issuers) for a fixed list of companies, kept in Postgres by a daily job.
Each filing is a row. For a fiscal period the canonical answer is the latest COMPLETE version \
(D-03): a partial 10-K/A (Part III only, an exhibit) never replaces the full report. Other \
versions are returned alongside.
Fiscal labels follow D-04: they come from the filing's own XBRL cover tags, or from a naming \
convention learned from the company's other filings (Walmart names a fiscal year by the year it \
ends in, GameStop by the year it starts in). Every label carries its source and confidence; use \
explain_label when a label matters.
Foreign private issuers (SAP, SHEL, BABA, NVO, TM) file no periodic quarterly report with the \
SEC (D-01). A fiscal year is never inferred from a calendar date: ask for the label, read the \
period_end.
Tools: get_annual_report, get_quarterly_report, list_filings, morning_check, explain_label. \
Nothing here can write."""

_FAMILIES = (
    "annual",
    "annual_amendment",
    "quarterly",
    "quarterly_amendment",
    "transition_annual",
    "transition_quarterly",
    "foreign_current_report",
    "late_notice",
    "non_reliance_8k",
)
_PERIODIC = _FAMILIES[:6]
_ACCESSION = re.compile(r"^\d{10}-\d{2}-\d{6}$")


def database_url() -> str:
    url = (os.environ.get("MCP_DATABASE_URL") or os.environ.get("DATABASE_URL") or "").strip()
    if not url:
        raise RuntimeError("set MCP_DATABASE_URL (or DATABASE_URL) to a Postgres connection string")
    return url


def connect_readonly(url: str | None = None) -> psycopg.Connection:
    """A connection that cannot write and cannot run long. Autocommit, so the SETs stick."""
    conn = psycopg.connect(url or database_url(), autocommit=True, connect_timeout=5)
    conn.row_factory = dict_row
    conn.execute("SET default_transaction_read_only = on")
    conn.execute(f"SET statement_timeout = {STATEMENT_TIMEOUT_MS}")
    return conn


@contextmanager
def _db() -> Iterator[psycopg.Connection]:
    conn = connect_readonly()
    try:
        yield conn
    finally:
        conn.close()


def _json(value: Any) -> Any:
    if isinstance(value, dict):
        return {k: _json(v) for k, v in value.items()}
    if isinstance(value, list | tuple):
        return [_json(v) for v in value]
    if hasattr(value, "isoformat"):
        return value.isoformat()
    return value


def _error(message: str, **extra: Any) -> dict:
    return {"status": "error", "message": message, **extra}


def _guard(fn):
    """Turn database trouble into an error dict instead of a stack trace."""

    @wraps(fn)
    def wrapper(*args, **kwargs):
        try:
            return _json(fn(*args, **kwargs))
        except (psycopg.Error, RuntimeError) as exc:
            return _error(f"{type(exc).__name__}: {str(exc).splitlines()[0] if str(exc) else ''}")

    return wrapper


def _resolve(conn: psycopg.Connection, company: str) -> dict | None:
    return find_company(conn, company)


def _unknown(conn: psycopg.Connection, company: str) -> dict:
    known = [r["company_id"] for r in conn.execute("SELECT company_id FROM company ORDER BY 1")]
    return {
        "status": "unknown_company",
        "message": f"{company!r} is not one tracked company. Use a ticker.",
        "tickers": known,
    }


@_guard
def get_annual_report(company: str, fiscal_year: int) -> dict:
    """The canonical annual report (10-K, or 20-F for foreign filers) for a company and fiscal
    year: the latest complete version, every other version on file, and the expected-filing
    status (due date, filer category, late or not). company is a ticker such as AAPL."""
    with _db() as conn:
        row = _resolve(conn, company)
        if row is None:
            return _unknown(conn, company)
        return period_answer(conn, row["company_id"], fiscal_year, None)


@_guard
def get_quarterly_report(company: str, fiscal_year: int, quarter: int) -> dict:
    """The canonical quarterly report (10-Q) for a company, fiscal year and quarter 1 to 3.
    Foreign private issuers file none (D-01); quarter 4 is covered by the annual report."""
    if not 1 <= quarter <= 4:
        return _error("quarter must be 1 to 4")
    with _db() as conn:
        row = _resolve(conn, company)
        if row is None:
            return _unknown(conn, company)
        return period_answer(conn, row["company_id"], fiscal_year, quarter)


@_guard
def list_filings(
    company: str, family: str | None = None, since: str | None = None, limit: int = 50
) -> dict:
    """Filings on file for a company, newest first. family: annual, annual_amendment, quarterly,
    quarterly_amendment, transition_annual, transition_quarterly, foreign_current_report,
    late_notice, non_reliance_8k, or all. Default (none) is the periodic reports only, so a
    foreign filer's many 6-Ks do not drown the list. since is a YYYY-MM-DD filing date.
    limit is 1 to 200."""
    if family is not None and family != "all" and family not in _FAMILIES:
        return _error(f"family must be one of {', '.join(_FAMILIES)} or all")
    since_day = None
    if since:
        try:
            since_day = dt.date.fromisoformat(since)
        except ValueError:
            return _error("since must be YYYY-MM-DD")
    limit = max(1, min(int(limit), MAX_LIMIT))
    families = list(_PERIODIC if family is None else _FAMILIES if family == "all" else (family,))
    with _db() as conn:
        row = _resolve(conn, company)
        if row is None:
            return _unknown(conn, company)
        rows = conn.execute(
            "SELECT accession_number AS accession, form, form_family, filing_date, "
            "period_of_report, fiscal_year, fiscal_period, is_canonical, amends_accession, "
            "amendment_scope, amendment_kind, pre_merger_shell, is_stale "
            "FROM filing WHERE company_id = %s AND form_family = ANY(%s) "
            "AND (%s::date IS NULL OR filing_date >= %s::date) "
            "ORDER BY filing_date DESC, accession_number DESC LIMIT %s",
            (row["company_id"], families, since_day, since_day, limit + 1),
        ).fetchall()
    return {
        "status": "ok",
        "company": row["company_id"],
        "family": family or "periodic",
        "count": min(len(rows), limit),
        "truncated": len(rows) > limit,
        "filings": rows[:limit],
    }


@_guard
def morning_check(date: str | None = None) -> dict:  # noqa: A002
    """The checks of the latest run, red first (C1 to C12: missing run, missing filings, changed
    CIK mapping, bad labels, late filings, golden queries...). With date (YYYY-MM-DD, London),
    the last run recorded on that day instead."""
    day = None
    if date:
        try:
            day = dt.date.fromisoformat(date)
        except ValueError:
            return _error("date must be YYYY-MM-DD")
    with _db() as conn:
        if day is not None:
            start = dt.datetime.combine(day, dt.time.min, tzinfo=LONDON)
            end = start + dt.timedelta(days=1)
        if day is None:
            rows = conn.execute("SELECT * FROM v_morning_check").fetchall()
        else:
            rows = conn.execute(
                "SELECT cr.run_id, r.mode AS run_mode, r.started_at AS run_started_at, "
                "cr.check_id, cr.check_name, cr.tier, cr.status, cr.message, cr.observed, "
                "cr.expected, cr.company_id FROM check_result cr JOIN run r USING (run_id) "
                "WHERE cr.check_id <> 'C12-input' AND cr.run_id = ("
                "  SELECT run_id FROM check_result "
                "  WHERE created_at >= %s AND created_at < %s "
                "  ORDER BY created_at DESC LIMIT 1) "
                "ORDER BY CASE cr.status WHEN 'red' THEN 0 WHEN 'amber' THEN 1 ELSE 2 END, "
                "cr.check_id, cr.company_id",
                (start, end),
            ).fetchall()
    if not rows:
        return {"status": "no_results", "message": "no check results for that run", "checks": []}
    counts = {s: sum(1 for r in rows if r["status"] == s) for s in ("red", "amber", "green")}
    verdict = "red" if counts["red"] else "amber" if counts["amber"] else "green"
    return {
        "status": "ok",
        "verdict": verdict,
        "counts": counts,
        "run_id": str(rows[0]["run_id"]),
        "run_mode": rows[0]["run_mode"],
        "run_started_at": rows[0]["run_started_at"],
        "checks": rows,
    }


@_guard
def explain_label(accession: str) -> dict:
    """Why a filing carries its fiscal label: label source and confidence, the fiscal year and
    period used versus the one the filing declared itself, where the cover data came from, and
    for amendments the scope (full or partial), kind and the evidence for it."""
    acc = accession.strip()
    if re.fullmatch(r"\d{18}", acc):
        acc = f"{acc[:10]}-{acc[10:12]}-{acc[12:]}"
    if not _ACCESSION.match(acc):
        return _error("accession looks like 0000320193-25-000079")
    with _db() as conn:
        f = conn.execute(
            "SELECT f.*, c.name AS company_name, c.fy_naming_convention "
            "FROM filing f JOIN company c USING (company_id) WHERE f.accession_number = %s",
            (acc,),
        ).fetchone()
    if f is None:
        return {"status": "not_found", "message": f"{acc} is not on file"}
    used = (f["fiscal_year"], f["fiscal_period"])
    declared = (f["declared_fiscal_year"], f["declared_fiscal_period"])
    out = {
        "status": "ok",
        "accession": acc,
        "company": f["company_id"],
        "company_name": f["company_name"],
        "form": f["form"],
        "form_family": f["form_family"],
        "filing_date": f["filing_date"],
        "period_of_report": f["period_of_report"],
        "is_canonical": f["is_canonical"],
        "label": {
            "fiscal_year": f["fiscal_year"],
            "fiscal_period": f["fiscal_period"],
            "source": f["label_source"],
            "confidence": f["label_confidence"],
            "declared_fiscal_year": f["declared_fiscal_year"],
            "declared_fiscal_period": f["declared_fiscal_period"],
            "differs_from_declared": declared != (None, None) and declared != used,
            "company_naming_convention": f["fy_naming_convention"],
            "cover_source": f["cover_source"],
        },
        "pre_merger_shell": f["pre_merger_shell"],
    }
    if f["form_family"] in ("annual_amendment", "quarterly_amendment"):
        out["amendment"] = {
            "amends_accession": f["amends_accession"],
            "scope": f["amendment_scope"],
            "kind": f["amendment_kind"],
            "evidence": f["kind_evidence"],
            "dei_description": f["dei_amendment_description"],
        }
    return out


def build_server():
    """The FastMCP server with the five tools registered."""
    from mcp.server.fastmcp import FastMCP

    server = FastMCP("sec-filings", instructions=INSTRUCTIONS)
    for fn in (get_annual_report, get_quarterly_report, list_filings, morning_check, explain_label):
        server.tool()(fn)
    return server


def main() -> None:
    build_server().run(transport="stdio")
