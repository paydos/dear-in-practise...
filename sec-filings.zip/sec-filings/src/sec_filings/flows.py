"""Entry points for the daily job: plain functions a scheduler can call (PLAN N4).

``sync`` and ``backfill`` return a RunResult and raise RunFailed only when the job itself
fails. ``check`` returns a CheckReport and raises ChecksRed when any check is red. Prefect is
never imported here.
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
import time as _clock  # `time` below is datetime.time
from collections.abc import Iterable, Sequence
from dataclasses import asdict, dataclass, field, replace
from datetime import UTC, date, datetime, time, timedelta
from pathlib import Path
from uuid import UUID
from zoneinfo import ZoneInfo

import psycopg

from sec_filings.checks.core import (
    CheckContext,
    heartbeat_check,
    is_business_day,
    previous_business_day,
    run_core_checks,
    unreconciled_business_days,
)
from sec_filings.checks.report import exit_code, ping_heartbeat, render_markdown
from sec_filings.companies import CikSpan, CompanyConfig, load_companies
from sec_filings.config import Settings
from sec_filings.db import repo
from sec_filings.db.connection import connect
from sec_filings.db.migrate import apply_migrations
from sec_filings.db.repo import FilingRecord
from sec_filings.domain.amendments import (
    decide_kind,
    decide_scope,
    description_says_full,
    link_amendment,
    partial_only_text,
    select_canonical,
)
from sec_filings.domain.corrections import build_correction_events
from sec_filings.domain.deadlines import normalize_filer_category
from sec_filings.domain.expected import build_expected
from sec_filings.domain.forms import form_family, is_unknown_periodic_form, original_family
from sec_filings.domain.labels import (
    effective_period_end,
    infer_fiscal_year_end,
    label_filing,
    learn_convention,
)
from sec_filings.edgar.client import EdgarClient
from sec_filings.edgar.cover_tags import (
    cover_page_url,
    filing_index_url,
    parse_cover_page,
    parse_filing_index,
)
from sec_filings.edgar.daily_index import (
    daily_index_url,
    full_index_url,
    parse_form_index,
    parse_master_index,
)
from sec_filings.edgar.submissions import (
    history_page_url,
    parse_history_page,
    parse_submissions,
    submissions_url,
)
from sec_filings.edgar.tickers import TICKERS_URL, parse_company_tickers
from sec_filings.edgar.xbrl_concepts import (
    ConceptLabel,
    company_concept_url,
    parse_concept_labels,
    parse_public_float,
)
from sec_filings.errors import (
    ChecksRed,
    ConfigError,
    EdgarHTTPError,
    ParseError,
    RequestBudgetExceeded,
    RunFailed,
    SecAccessDenied,
)
from sec_filings.models import (
    CheckReport,
    CheckResult,
    CoverTags,
    FetchedResponse,
    Label,
    RawFiling,
    RunResult,
    ScopeSignals,
    SubmissionsDoc,
    Version,
)

DEFAULT_EXPECT_RUN_BY = time(6, 30)
LONDON = ZoneInfo("Europe/London")
NEW_YORK = ZoneInfo("America/New_York")

log = logging.getLogger(__name__)  # progress lines; the CLI shows them on stderr, in colour

_monotonic = _clock.monotonic


def _log_check_summary(results: Sequence[CheckResult]) -> None:
    """One progress line per non-green check, then the verdict, so the operator sees them live."""
    for r in results:
        if r.status != "green":
            level = logging.ERROR if r.status == "red" else logging.WARNING
            log.log(level, "%s %s: %s", r.check_id, r.status.upper(), r.message)
    red = sum(r.status == "red" for r in results)
    amber = sum(r.status == "amber" for r in results)
    if red:
        log.error("checks: %d red, %d amber", red, amber)
    elif amber:
        log.warning("checks: 0 red, %d amber", amber)
    else:
        log.info("checks: all green", extra={"tone": "ok"})


_ANNUAL = ("annual", "annual_amendment")
_AMENDMENTS = ("annual_amendment", "quarterly_amendment")
_PERIODIC = ("annual", "annual_amendment", "quarterly", "quarterly_amendment")
_LABELLED = _PERIODIC + ("transition_annual", "transition_quarterly")
_RECONCILED_FAMILIES = (
    "annual",
    "annual_amendment",
    "quarterly",
    "quarterly_amendment",
    "foreign_current_report",
    "late_notice",
)
_COVER_WINDOW_START = date(2016, 11, 1)  # D-13: fiscal years ending on or after this date
_MAX_RECONCILE_DAYS = 30
_FULL_STATEMENT_REPORTS = 6  # contract 11.1: more than this many R files means statements
_FLOAT_LARGE = 700e6
_FLOAT_ACCELERATED = 75e6
_CONCEPT_SHARES = "EntityCommonStockSharesOutstanding"
_CONCEPT_FLOAT = "EntityPublicFloat"


# --------------------------------------------------------------------------- small helpers


def _git_sha() -> str | None:
    if os.environ.get("GIT_SHA"):
        return os.environ["GIT_SHA"]
    try:
        out = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            capture_output=True,
            text=True,
            timeout=3,
            cwd=Path(__file__).resolve().parent,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    return out.stdout.strip() or None if out.returncode == 0 else None


_is_business_day = is_business_day
_previous_business_day = previous_business_day


def _days_between(start: date, end: date) -> Iterable[date]:
    d = start
    while d <= end:
        yield d
        d += timedelta(days=1)


def _category_from_float(value: float) -> str:
    if value >= _FLOAT_LARGE:
        return "Large Accelerated Filer"
    if value >= _FLOAT_ACCELERATED:
        return "Accelerated Filer"
    return "Non-accelerated Filer"


def _select_companies(settings: Settings, tickers: Sequence[str] | None) -> list[CompanyConfig]:
    configs = load_companies(settings.companies_csv, settings.companies_yml)
    if tickers:
        wanted = [t.strip().upper() for t in tickers]
        known = {c.ticker for c in configs}
        unknown = [t for t in wanted if t not in known]
        if unknown:
            raise ConfigError(f"ticker(s) not in {settings.companies_csv}: {', '.join(unknown)}")
        configs = [c for c in configs if c.ticker in wanted]
    return configs


@dataclass
class _Stats:
    inserted: int = 0
    updated: int = 0
    unchanged: int = 0
    unknown_forms: set[str] = field(default_factory=set)


@dataclass
class _Row:
    raw: RawFiling
    family: str
    ciks: list[int]


@dataclass
class _Fetched:
    docs: list[SubmissionsDoc]
    rows: dict[str, _Row]  # kept rows (family is not None), first-seen CIK is the primary
    seen_by_cik: dict[int, set[str]]  # every accession (all forms) seen per CIK
    unknown_forms: set[str]


# --------------------------------------------------------------------------- per company


def _fetch_submissions(
    conn: psycopg.Connection,
    client: EdgarClient,
    spans: Sequence[CikSpan],
    *,
    mode: str,
) -> _Fetched:
    """Main JSON per CIK, plus history pages: all in backfill, in sync only those that changed
    or were never stored (unchanged pages are re-read from the stored raw copy, no request)."""
    docs: list[SubmissionsDoc] = []
    rows: dict[str, _Row] = {}
    seen_by_cik: dict[int, set[str]] = {}
    unknown: set[str] = set()
    for span in spans:
        cik = span.cik
        resp = client.get(submissions_url(cik))
        if resp.status != 200:
            raise RuntimeError(f"submissions JSON for CIK {cik} returned HTTP {resp.status}")
        doc = parse_submissions(resp.body)
        docs.append(doc)
        stored = dict(
            conn.execute(
                "SELECT page_name, filing_count FROM history_page WHERE cik = %s", (cik,)
            ).fetchall()
        )
        raw_rows: list[RawFiling] = list(doc.filings)
        for page in doc.pages:
            url = history_page_url(page.name)
            need = mode == "backfill" or stored.get(page.name) != page.filing_count
            body: bytes | None = None
            sha: str | None = None
            if not need:
                body = repo.latest_raw_payload(conn, url)
                need = body is None
            if need:
                page_resp = client.get(url)
                if page_resp.status != 200:
                    raise RuntimeError(f"history page {page.name} returned HTTP {page_resp.status}")
                body, sha = page_resp.body, page_resp.sha256
            assert body is not None
            page_rows = parse_history_page(body, cik)
            if sha is not None:
                repo.record_history_page(
                    conn, cik=cik, page=page, rows_in_payload=len(page_rows), payload_sha256=sha
                )
            raw_rows.extend(page_rows)
        seen = seen_by_cik.setdefault(cik, set())
        for raw in raw_rows:
            seen.add(raw.accession_number)
            family = form_family(raw.form, raw.items)
            if family is None:
                if is_unknown_periodic_form(raw.form):
                    unknown.add(raw.form)
                continue
            known = rows.get(raw.accession_number)
            if known is None:
                rows[raw.accession_number] = _Row(raw, family, [cik])
            elif cik not in known.ciks:
                known.ciks.append(cik)
    return _Fetched(docs, rows, seen_by_cik, unknown)


def _concept_body(
    conn: psycopg.Connection, client: EdgarClient, cik: int, concept: str, fetch: bool
) -> bytes | None:
    url = company_concept_url(cik, concept)
    if fetch:
        resp = client.get(url)
        return resp.body if resp.status == 200 else None
    return repo.latest_raw_payload(conn, url)


def _cover_for(
    conn: psycopg.Connection,
    client: EdgarClient,
    row: _Row,
    existing: dict | None,
) -> tuple[CoverTags | None, bool]:
    """(cover tags or None, fetched flag). A filing whose cover was fetched before is read from
    the stored raw copy; a 404 or an unreadable page means no cover (flag still true)."""
    cik, acc = row.ciks[0], row.raw.accession_number
    url = cover_page_url(cik, acc)
    if existing is not None and existing["cover_tags_fetched"]:
        body = repo.latest_raw_payload(conn, url)
        if body is not None:
            try:
                return parse_cover_page(body), True
            except ParseError:
                return None, True
        if any(
            existing[c] is not None
            for c in (
                "dei_filer_category",
                "dei_amendment_flag",
                "dei_amendment_description",
                "dei_error_correction_flag",
                "dei_current_reporting_status",
            )
        ):
            return (
                CoverTags(
                    fiscal_year=None,
                    fiscal_period=None,
                    document_type=None,
                    period_end_date=None,
                    filer_category=existing["dei_filer_category"],
                    amendment_flag=existing["dei_amendment_flag"],
                    amendment_description=existing["dei_amendment_description"],
                    error_correction_flag=existing["dei_error_correction_flag"],
                    current_reporting_status=existing["dei_current_reporting_status"],
                    non_dei_fact_count=existing["dei_non_dei_fact_count"] or -1,
                ),
                True,
            )
        return None, True
    resp = client.get(url)
    if resp.status != 200 or not resp.body:
        return None, True
    try:
        return parse_cover_page(resp.body), True
    except ParseError:
        return None, True


def _process_company(
    conn: psycopg.Connection,
    client: EdgarClient,
    cfg: CompanyConfig,
    ticker_map: dict[str, tuple[int, str]] | None,
    *,
    mode: str,
    run_id: UUID,
    today: date,
    stats: _Stats,
) -> None:
    ticker = cfg.ticker
    # a. CIKs: reviewed spans, else the ticker file.
    spans = list(cfg.ciks)
    if not spans:
        # An unreviewed ticker is resolved from the ticker file only once. After that its stored
        # CIKs stand, and a different CIK in the ticker file turns C4 red (D-08), not a new span.
        spans = [
            CikSpan(int(cik), vf, vt, source, note)
            for cik, vf, vt, source, note in conn.execute(
                "SELECT cik, valid_from, valid_to, source, note FROM company_cik "
                "WHERE company_id = %s ORDER BY valid_from NULLS FIRST, cik",
                (ticker,),
            ).fetchall()
        ]
    if not spans:
        hit = None if ticker_map is None else ticker_map.get(ticker)
        if hit is None:
            raise RuntimeError(f"{ticker} has no reviewed CIKs and is not in the SEC ticker file")
        spans = [CikSpan(hit[0], None, None, "ticker_file", None)]

    existing = {r["accession_number"]: r for r in repo.company_filings(conn, ticker)}

    # b + c. Submissions, history pages, form families.
    fetched = _fetch_submissions(conn, client, spans, mode=mode)
    rows = fetched.rows
    stats.unknown_forms |= fetched.unknown_forms
    forms = {r.raw.form.upper() for r in rows.values()}
    is_foreign = cfg.foreign_filer
    if is_foreign is None:
        is_foreign = any(f.startswith(("20-F", "40-F")) for f in forms) and not any(
            f.startswith("10-K") for f in forms
        )

    # d. Fiscal year end: submissions metadata, else the reviewed file, else inferred.
    fye = next(
        (m for m in (d.meta.fiscal_year_end_mmdd for d in reversed(fetched.docs)) if m), None
    )
    fye = (
        fye
        or cfg.fiscal_year_end
        or infer_fiscal_year_end(
            r.raw.period_of_report
            for r in rows.values()
            if r.family == "annual" and r.raw.period_of_report is not None
        )
    )
    effective = {
        acc: effective_period_end(
            family=r.family,  # type: ignore[arg-type]
            period_of_report=r.raw.period_of_report,
            filing_date=r.raw.filing_date,
            fiscal_year_end_mmdd=fye,
        )
        for acc, r in rows.items()
        if r.family in _LABELLED
    }

    # e. Concept labels and public float (contract 11.1).
    concept_labels: dict[str, ConceptLabel] = {}
    public_float: dict[str, tuple[float, date]] = {}
    for span in spans:
        cik = span.cik
        has_new = any(
            r.family in _LABELLED and cik in r.ciks and acc not in existing
            for acc, r in rows.items()
        )
        fetch = mode == "backfill" or has_new
        shares = _concept_body(conn, client, cik, _CONCEPT_SHARES, fetch)
        if shares is not None:
            concept_labels.update(parse_concept_labels(shares))
        flt = _concept_body(conn, client, cik, _CONCEPT_FLOAT, fetch)
        if flt is not None:
            public_float.update(parse_public_float(flt))

    # f. Cover pages.
    covers: dict[str, CoverTags | None] = {}
    cover_fetched: dict[str, bool] = {}
    for acc, r in rows.items():
        if not r.raw.is_xbrl:
            continue
        eff_end = effective.get(acc, (None, False))[0]
        wanted = r.family in _AMENDMENTS or (
            r.family in _ANNUAL and eff_end is not None and eff_end >= _COVER_WINDOW_START
        )
        prior = existing.get(acc)
        if wanted or (prior is not None and prior["cover_tags_fetched"]):
            covers[acc], cover_fetched[acc] = _cover_for(conn, client, r, prior)

    # g. Filing index for amendments that have no scope yet.
    overrides = cfg.overrides
    report_files: dict[str, int | None] = {}
    primary_bytes: dict[str, int | None] = {}
    for acc, r in rows.items():
        if r.family not in _AMENDMENTS or overrides.get(acc, {}).get("amendment_scope"):
            continue
        prior = existing.get(acc)
        url = filing_index_url(r.ciks[0], acc)
        body = repo.latest_raw_payload(conn, url)
        if body is None and (prior is None or prior["amendment_scope"] is None):
            resp = client.get(url)
            body = resp.body if resp.status == 200 else None
        count = None
        primary = None
        if body is not None:
            try:
                index = parse_filing_index(body)
                count = index.report_file_count
                primary = next(
                    (size for name, size in index.files if name == r.raw.primary_document), None
                )
            except ParseError:
                count = None
        report_files[acc] = count
        primary_bytes[acc] = primary

    # h. Labels.
    def tier1(acc: str) -> tuple[CoverTags | None, str | None]:
        cover = covers.get(acc)
        if cover is not None and cover.fiscal_year is not None and cover.fiscal_period:
            return cover, "cover_page"
        cl = concept_labels.get(acc)
        if cl is not None and cl.consistent and cl.fiscal_year is not None and cl.fiscal_period:
            tags = CoverTags(
                fiscal_year=cl.fiscal_year,
                fiscal_period=cl.fiscal_period,
                document_type=cl.form,
                period_end_date=None,
                filer_category=None,
                amendment_flag=None,
                amendment_description=None,
                error_correction_flag=None,
                current_reporting_status=None,
                non_dei_fact_count=-1,
            )
            return tags, "concept"
        return None, None

    observations = []
    for acc, r in rows.items():
        tags, _src = tier1(acc)
        eff_end = effective.get(acc, (None, False))[0]
        # Originals only: an amendment re-declares the year of the report it amends and would
        # count the same report twice (Toyota: 9 v 6 for originals, 9 v 8 with amendments).
        if r.family == "annual" and tags is not None and tags.fiscal_year and eff_end is not None:
            observations.append((tags.fiscal_year, eff_end))
    convention = learn_convention(observations)

    labels: dict[str, Label] = {}
    cover_source: dict[str, str | None] = {}
    for acc, r in rows.items():
        ov = overrides.get(acc, {})
        manual = None
        if ov.get("fiscal_year") and ov.get("fiscal_period"):
            manual = Label(int(ov["fiscal_year"]), ov["fiscal_period"], "manual", "high")  # type: ignore[arg-type]
        tags, src = tier1(acc)
        label = label_filing(
            family=r.family,  # type: ignore[arg-type]
            period_of_report=effective.get(acc, (r.raw.period_of_report, False))[0],
            cover=tags,
            convention=convention,
            fiscal_year_end_mmdd=fye,
            manual=manual,
        )
        labels[acc] = label
        cover_source[acc] = src if label.source == "filing_dei" else None

    # i. Amendments: link, scope, correction events, kind.
    originals: dict[str, list[tuple[RawFiling, Label]]] = {"annual": [], "quarterly": []}
    for acc, r in rows.items():
        if r.family in originals:
            originals[r.family].append((r.raw, labels[acc]))
    amends: dict[str, str | None] = {}
    scopes: dict[str, str] = {}
    for acc, r in rows.items():
        if r.family not in _AMENDMENTS:
            continue
        orig_family = original_family(r.family)  # type: ignore[arg-type]
        target = link_amendment(r.raw, labels[acc], originals.get(orig_family or "", []))
        amends[acc] = target
        ov = overrides.get(acc, {})
        if ov.get("amendment_scope"):
            scopes[acc] = ov["amendment_scope"]
            continue
        count = report_files.get(acc)
        size_ratio = None
        if target is not None:
            osize, asize = rows[target].raw.size_bytes, r.raw.size_bytes
            if osize and asize is not None:
                size_ratio = asize / osize
        cover = covers.get(acc)
        scopes[acc] = decide_scope(
            ScopeSignals(
                has_financial_facts=None if count is None else count > _FULL_STATEMENT_REPORTS,
                in_financial_data_sets=None,
                size_ratio=size_ratio,
                description_says_full=description_says_full(
                    cover.amendment_description if cover else None
                ),
                partial_only_text=partial_only_text(
                    cover.amendment_description if cover else None,
                    r.raw.primary_doc_description,
                ),
                primary_doc_bytes=primary_bytes.get(acc),
            ),
            filing_date=r.raw.filing_date,
        )

    triples = [(r.raw, r.family, labels[acc], covers.get(acc)) for acc, r in rows.items()]
    float_categories = {
        acc: normalize_filer_category(_category_from_float(value))
        for acc, (value, _as_of) in public_float.items()
    }

    events = build_correction_events(
        company_id=ticker,
        filings=triples,  # type: ignore[arg-type]
        amendment_scopes=scopes,
        pre_merger_until=cfg.pre_merger_until,
    )
    corrected = {a for e in events for a in e.corrected_in_accessions}
    kinds: dict[str, tuple[str, str]] = {}
    for acc, r in rows.items():
        if r.family not in _AMENDMENTS:
            continue
        ov = overrides.get(acc, {})
        cover = covers.get(acc)
        kind, evidence = decide_kind(
            scope=scopes[acc],
            linked_to_correction_event=acc in corrected,
            cover_error_flag=cover.error_correction_flag if cover else None,
            manual_kind=ov.get("amendment_kind") or None,
        )
        if ov.get("reason"):
            evidence = f"{evidence}; reason: {ov['reason']}"
        kinds[acc] = (kind, evidence)

    # Records.
    records: list[FilingRecord] = []
    for acc, r in rows.items():
        raw, label = r.raw, labels[acc]
        cover = covers.get(acc)
        declared, _src = tier1(acc)
        records.append(
            FilingRecord(
                accession_number=acc,
                cik=r.ciks[0],
                company_id=ticker,
                form=raw.form,
                form_family=r.family,
                filing_date=raw.filing_date,
                acceptance_datetime=raw.acceptance_datetime,
                period_of_report=raw.period_of_report,
                fiscal_year=label.fiscal_year,
                fiscal_period=label.fiscal_period,
                declared_fiscal_year=declared.fiscal_year if declared else None,
                declared_fiscal_period=declared.fiscal_period if declared else None,
                label_source=label.source,
                label_confidence=label.confidence,
                dei_filer_category=cover.filer_category if cover else None,
                dei_amendment_flag=cover.amendment_flag if cover else None,
                dei_amendment_description=cover.amendment_description if cover else None,
                dei_error_correction_flag=cover.error_correction_flag if cover else None,
                dei_current_reporting_status=cover.current_reporting_status if cover else None,
                dei_non_dei_fact_count=cover.non_dei_fact_count if cover else None,
                cover_tags_fetched=cover_fetched.get(acc, False),
                amends_accession=amends.get(acc),
                amendment_scope=scopes.get(acc),
                amendment_kind=kinds[acc][0] if acc in kinds else None,
                kind_evidence=kinds[acc][1] if acc in kinds else None,
                is_xbrl=raw.is_xbrl,
                is_inline_xbrl=raw.is_inline_xbrl,
                primary_document=raw.primary_document,
                primary_doc_description=raw.primary_doc_description,
                size_bytes=raw.size_bytes,
                items=raw.items,
                file_number=raw.file_number,
                film_number=raw.film_number,
                pre_merger_shell=(
                    cfg.pre_merger_until is not None and raw.filing_date < cfg.pre_merger_until
                ),
            )
        )

    # j. Canonical choice per report period.
    groups: dict[tuple[str, int, str], list[Version]] = {}
    for rec in records:
        if rec.form_family not in _PERIODIC or rec.fiscal_year is None or not rec.fiscal_period:
            continue
        kind = "annual" if rec.form_family in _ANNUAL else "quarterly"
        groups.setdefault((kind, rec.fiscal_year, rec.fiscal_period), []).append(
            Version(
                accession_number=rec.accession_number,
                filing_date=rec.filing_date,
                acceptance_datetime=rec.acceptance_datetime,
                is_amendment=rec.form_family in _AMENDMENTS,
                amendment_scope=rec.amendment_scope,
            )
        )
    choices = [
        (kind, fy, fp, select_canonical(versions))
        for (kind, fy, fp), versions in sorted(groups.items())
    ]

    # k. Expected filings (category chain: own cover, own float, previous annual's cover and
    # float, today's).
    meta = fetched.docs[-1].meta
    expected = build_expected(
        company_id=ticker,
        is_foreign=is_foreign,
        fiscal_year_end_mmdd=fye,
        convention=convention,
        filings=triples,  # type: ignore[arg-type]
        current_filer_category=meta.filer_category,
        pre_merger_until=cfg.pre_merger_until,
        today=today,
        float_categories=float_categories,  # type: ignore[arg-type]
    )

    # l. Write everything for this company (the caller commits).
    repo.upsert_company(
        conn,
        company_id=ticker,
        name=meta.name or None,
        is_foreign_private_issuer=is_foreign,
        fiscal_year_end_mmdd=fye,
        filer_category_current=meta.filer_category,
        fy_naming_convention=convention,
        pre_merger_until=cfg.pre_merger_until,
        reviewed=cfg.reviewed,
        notes=cfg.notes,
    )
    for span, doc in zip(spans, fetched.docs, strict=True):
        repo.upsert_company_cik(
            conn,
            company_id=ticker,
            cik=span.cik,
            valid_from=span.valid_from,
            valid_to=span.valid_to,
            source=span.source,
            note=span.note,
        )
        repo.replace_name_history(conn, span.cik, doc.meta.former_names)
    inserted, updated, unchanged = repo.upsert_filings(conn, records, run_id)
    stats.inserted += inserted
    stats.updated += updated
    stats.unchanged += unchanged
    for acc, r in rows.items():
        if len(r.ciks) > 1:
            for cik in r.ciks:
                repo.add_cik_alias(conn, acc, cik)
    conn.execute(
        "UPDATE filing f SET cover_source = v.src "
        "FROM (SELECT unnest(%s::text[]) AS acc, unnest(%s::text[]) AS src) v "
        "WHERE f.accession_number = v.acc AND f.cover_source IS DISTINCT FROM v.src",
        (list(cover_source), [cover_source[a] for a in cover_source]),
    )
    repo.write_canonical(conn, ticker, choices)
    repo.replace_expected(conn, ticker, expected)
    repo.replace_correction_events(conn, ticker, events)
    if mode == "backfill":
        everything = set().union(*fetched.seen_by_cik.values())
        for span in spans:
            repo.mark_stale(conn, cik=span.cik, seen_accessions=everything, run_id=run_id)


# --------------------------------------------------------------------------- reconciliation


def _present_accessions(conn: psycopg.Connection, accessions: Sequence[str]) -> set[str]:
    return {
        r[0]
        for r in conn.execute(
            "SELECT accession_number FROM filing WHERE accession_number = ANY(%s) "
            "UNION SELECT accession_number FROM filing_cik_alias "
            "WHERE accession_number = ANY(%s)",
            (list(accessions), list(accessions)),
        ).fetchall()
    }


def _recheck_missing_days(conn: psycopg.Connection, run_id: UUID) -> None:
    """A day left as 'missing_filings' is re-reconciled on every run until it turns 'ok': the
    stored missing accessions are checked against the table again (the day's index does not
    change, so nothing is refetched)."""
    days = conn.execute(
        "SELECT index_date, entries_for_us, missing FROM daily_index_reconciliation "
        "WHERE status = 'missing_filings' ORDER BY index_date"
    ).fetchall()
    for day, entries_for_us, missing in days:
        present = _present_accessions(conn, missing)
        still = [a for a in missing if a not in present]
        if len(still) != len(missing):
            repo.record_reconciliation(
                conn,
                index_date=day,
                status="missing_filings" if still else "ok",
                entries_for_us=entries_for_us,
                missing=still,
                run_id=run_id,
            )
    conn.commit()


def _reconcile_daily_index(
    conn: psycopg.Connection,
    client: EdgarClient,
    run_id: UUID,
    *,
    ny_today: date,
    errors: list[str],
) -> date:
    """Reconcile every business day since the last reconciled one. Returns the last day that
    was due (the previous business day)."""
    end = _previous_business_day(ny_today)
    _recheck_missing_days(conn, run_id)
    last = repo.last_reconciled_date(conn)
    if last is None:
        days = [end]
    else:
        days = [d for d in _days_between(last + timedelta(days=1), end) if _is_business_day(d)]
    # Every business day of the 30-day window without an ok or missing_filings row is tried
    # again: unpublished days, and any hole left by an interrupted run.
    retry = unreconciled_business_days(conn, ny_today)
    days = sorted(set(days) | set(retry))[:_MAX_RECONCILE_DAYS]
    known = repo.known_ciks(conn)
    for day in days:
        status, entries_for_us, missing = "not_published", 0, []
        try:
            resp = client.get(daily_index_url(day))
        except EdgarHTTPError as exc:  # recorded as not published and retried; never fails the run
            errors.append(f"daily index {day}: {exc}")
        else:
            if resp.status == 200:
                try:
                    entries = parse_form_index(resp.body)
                except ParseError as exc:
                    errors.append(f"daily index {day}: {exc}")
                else:
                    ours = [
                        e.accession_number
                        for e in entries
                        if e.cik in known and form_family(e.form) in _RECONCILED_FAMILIES
                    ]
                    entries_for_us = len(ours)
                    missing = sorted(set(ours) - _present_accessions(conn, ours))
                    status = "missing_filings" if missing else "ok"
        repo.record_reconciliation(
            conn,
            index_date=day,
            status=status,
            entries_for_us=entries_for_us,
            missing=missing,
            run_id=run_id,
        )
        conn.commit()
    return end


def _reconcile_master_index(
    conn: psycopg.Connection,
    client: EdgarClient,
    run_id: UUID,
    *,
    ny_today: date,
    end: date,
    errors: list[str],
) -> None:
    """Mondays (US Eastern): the current quarter's master.idx, rebuilt by the SEC with
    corrections and deletions, against our table. Our periodic filings dated in the quarter that
    master.idx no longer lists are marked stale (D-07, never deleted) and reported. Entries of
    ours that are missing from the table are recorded like daily-index misses (C3 goes red)."""
    if ny_today.weekday() != 0:
        return
    quarter = (ny_today.month - 1) // 3 + 1
    url = full_index_url(ny_today.year, quarter)
    try:
        resp = client.get(url)
    except EdgarHTTPError as exc:
        errors.append(f"master index {ny_today.year} QTR{quarter}: {exc}")
        return
    if resp.status != 200:
        errors.append(f"master index {ny_today.year} QTR{quarter}: HTTP {resp.status}")
        return
    try:
        entries = parse_master_index(resp.body)
    except ParseError as exc:
        errors.append(f"master index {ny_today.year} QTR{quarter}: {exc}")
        return
    known = repo.known_ciks(conn)
    ours = [e for e in entries if e.cik in known]
    if not ours:
        errors.append(
            f"master index {ny_today.year} QTR{quarter} has no entry for our CIKs: not reconciled"
        )
        return
    # Filings newer than the index's last entry (or than the last due day) are not judged.
    horizon = min(end, max(e.date_filed for e in entries))
    start = date(ny_today.year, 3 * quarter - 2, 1)
    listed = {e.accession_number for e in entries}

    mine = conn.execute(
        "SELECT accession_number FROM filing WHERE cik = ANY(%s) AND NOT is_stale "
        "AND form_family = ANY(%s) AND filing_date >= %s AND filing_date <= %s",
        (list(known), list(_LABELLED), start, horizon),
    ).fetchall()
    gone = [r[0] for r in mine if r[0] not in listed]
    if gone:
        flagged = repo.mark_accessions_stale(conn, gone, run_id)
        if flagged:
            errors.append(
                f"master index: {len(flagged)} periodic filing(s) dated in {ny_today.year} "
                f"QTR{quarter} no longer listed, marked stale: {', '.join(flagged[:10])}"
            )

    wanted = {
        e.accession_number: e
        for e in ours
        if form_family(e.form) in _RECONCILED_FAMILIES and start <= e.date_filed <= horizon
    }
    absent = sorted(set(wanted) - _present_accessions(conn, list(wanted)))
    by_day: dict[date, list[str]] = {}
    for acc in absent:
        by_day.setdefault(wanted[acc].date_filed, []).append(acc)
    for day, accs in sorted(by_day.items()):
        row = conn.execute(
            "SELECT status, entries_for_us, missing FROM daily_index_reconciliation "
            "WHERE index_date = %s",
            (day,),
        ).fetchone()
        if row is not None and row[0] == "not_published":
            continue  # the daily path retries this day and will find the same misses
        repo.record_reconciliation(
            conn,
            index_date=day,
            status="missing_filings",
            entries_for_us=max(len(accs), row[1] if row else 0),
            missing=sorted(set(accs) | set(row[2] if row else ())),
            run_id=run_id,
        )
    if absent:
        errors.append(
            f"master index: {len(absent)} filing(s) of ours listed by the SEC but not in the "
            f"table: {', '.join(absent[:10])}"
        )
    conn.commit()


# --------------------------------------------------------------------------- reports


def _write_report(
    settings: Settings,
    results: Sequence[CheckResult],
    run: RunResult,
    today: date,
    markdown: str,
) -> None:
    out = Path(settings.reports_dir)
    out.mkdir(parents=True, exist_ok=True)
    stem = out / f"morning_check_{today.isoformat()}"
    stem.with_suffix(".md").write_text(markdown, encoding="utf-8")
    payload = {
        "date": today.isoformat(),
        "exit_code": exit_code(results, run.status == "failed"),
        "run": {
            **{k: v for k, v in asdict(run).items() if k not in ("run_id",)},
            "run_id": str(run.run_id),
        },
        "results": [asdict(r) for r in results],
    }
    stem.with_suffix(".json").write_text(
        json.dumps(payload, indent=2, default=str), encoding="utf-8"
    )


def read_results(settings: Settings, run_id: UUID) -> list[CheckResult]:
    """The core check results written for a run (C12-input rows excluded)."""
    conn = connect(settings.database_url)
    try:
        rows = conn.execute(
            "SELECT check_id, check_name, tier, status, message, observed, expected, company_id "
            "FROM check_result WHERE run_id = %s AND check_id <> 'C12-input' "
            "ORDER BY created_at, check_id",
            (run_id,),
        ).fetchall()
    finally:
        conn.close()
    return [CheckResult(*r) for r in rows]


def _stored_ticker_map(conn: psycopg.Connection) -> dict[str, int] | None:
    body = repo.latest_raw_payload(conn, TICKERS_URL)
    if body is None:
        return None
    try:
        return {t: cik for t, (cik, _name) in parse_company_tickers(body).items()}
    except ParseError:
        return None


# --------------------------------------------------------------------------- entry points


def sync(
    settings: Settings,
    *,
    mode: str = "sync",
    today: date | None = None,
    now: datetime | None = None,
    tickers: Sequence[str] | None = None,
    client: EdgarClient | None = None,
    golden_queries_path: Path | None = None,
    raise_on_red: bool = False,
) -> RunResult:
    """Daily incremental sync (or a full backfill). Raises RunFailed when the job itself fails.
    With `raise_on_red`, also raises ChecksRed (after the report is written) when any check of
    this run is red, so a scheduler needs one call instead of sync then check."""
    injected = now is not None  # a caller-supplied clock is used as is, for repeatable runs
    now = now or datetime.now(UTC)
    ny_today = today if today is not None else now.astimezone(NEW_YORK).date()
    today = today if today is not None else now.astimezone(LONDON).date()
    configs = _select_companies(settings, tickers)
    scope = "subset" if tickers else "all"

    conn = connect(settings.database_url)
    try:
        apply_migrations(conn)
        conn.commit()
        if not repo.try_advisory_lock(conn):
            log.warning("another run holds the lock: this run is skipped")
            conn.rollback()
            run_id = repo.start_run(conn, mode, _git_sha(), scope)
            result = RunResult(
                run_id, mode, "skipped_locked", now, now if injected else datetime.now(UTC),
                0, 0, 0, 0, [], [], "another run holds the advisory lock; nothing was done",
            )  # fmt: skip
            repo.finish_run(conn, result)
            conn.commit()
            return result
        try:
            return _run_locked(
                settings, conn, configs, mode, today, ny_today, now, injected, client,
                golden_queries_path, scope, raise_on_red,
            )  # fmt: skip
        finally:
            try:
                conn.rollback()
                repo.release_advisory_lock(conn)
                conn.commit()
            except psycopg.Error:
                pass  # a dead connection already released the lock; keep the original error
    finally:
        conn.close()


def backfill(
    settings: Settings, *, tickers: Sequence[str] | None = None, **kw: object
) -> RunResult:
    """Full history load: every history page and every concept file is fetched."""
    return sync(settings, tickers=tickers, mode="backfill", **kw)  # type: ignore[arg-type]


def _run_locked(
    settings: Settings,
    conn: psycopg.Connection,
    configs: list[CompanyConfig],
    mode: str,
    today: date,
    ny_today: date,
    now: datetime,
    injected: bool,
    client: EdgarClient | None,
    golden_queries_path: Path | None,
    scope: str = "all",
    raise_on_red: bool = False,
) -> RunResult:
    notes: list[str] = []
    empty = conn.execute("SELECT NOT EXISTS (SELECT 1 FROM filing)").fetchone()[0]
    if mode != "backfill" and empty:
        mode = "backfill"
        notes.append("filing table was empty: ran as a backfill")
    have = {r[0] for r in conn.execute("SELECT DISTINCT company_id FROM filing").fetchall()}
    onboarding = [c.ticker for c in configs if c.ticker not in have]
    budget = (
        settings.backfill_request_budget
        if mode == "backfill" or onboarding
        else settings.sync_request_budget
    )
    if mode != "backfill" and onboarding:
        notes.append(f"new compan(ies) {', '.join(onboarding)} loaded with the backfill budget")
    run_id = repo.start_run(conn, mode, _git_sha(), scope)
    log.info(
        "%s started: run %s, %d compan%s, request budget %d",
        mode, run_id, len(configs), "y" if len(configs) == 1 else "ies", budget,
    )  # fmt: skip
    for note in notes:
        log.info("note: %s", note)
    try:
        conn.commit()
        return _run_with_client(
            settings, conn, client, configs, mode, run_id, today, ny_today, now, injected, notes,
            golden_queries_path, budget, scope, raise_on_red,
        )  # fmt: skip
    except (RunFailed, ChecksRed):
        raise  # outcomes already recorded, reported and pinged: not an unexpected death
    except Exception as exc:  # incl. a lost database connection: the run must not stay 'running'
        _last_chance(settings, run_id, exc)
        raise


def _last_chance(settings: Settings, run_id: UUID, exc: BaseException) -> None:
    """The run died with an unexpected error. Over a NEW connection (the old one may be gone)
    mark the run failed with the error, and ping the heartbeat's /fail URL. Never raises."""
    try:
        with psycopg.connect(settings.database_url, autocommit=True, connect_timeout=10) as c:
            c.execute(
                "UPDATE run SET status = 'failed', finished_at = clock_timestamp(), "
                "error_summary = %s WHERE run_id = %s",
                (f"run died: {type(exc).__name__}: {exc}"[:2000], run_id),
            )
    except Exception:
        log.exception("could not mark run %s as failed", run_id)
    if settings.heartbeat_url:
        try:
            ping_heartbeat(settings.heartbeat_url, failed=True)
        except Exception:
            log.exception("heartbeat /fail ping failed")


def _run_with_client(
    settings: Settings,
    conn: psycopg.Connection,
    client: EdgarClient | None,
    configs: list[CompanyConfig],
    mode: str,
    run_id: UUID,
    today: date,
    ny_today: date,
    now: datetime,
    injected: bool,
    notes: list[str],
    golden_queries_path: Path | None,
    budget: int,
    scope: str,
    raise_on_red: bool,
) -> RunResult:
    raw_conn = psycopg.connect(settings.database_url, autocommit=True, connect_timeout=10)
    try:

        def store(resp: FetchedResponse) -> None:
            repo.store_raw_payload(raw_conn, resp, run_id)

        if client is None:
            client = EdgarClient(
                settings.user_agent,
                requests_per_second=settings.requests_per_second,
                request_budget=budget,
                fixtures_dir=settings.fixtures_dir,
                on_response=store,
            )
        elif getattr(client, "_on_response", None) is None:
            client._on_response = store  # an injected client still stores raw payloads
        return _run_body(
            settings, conn, client, configs, mode, run_id, today, ny_today, now, injected, notes,
            golden_queries_path, scope, raise_on_red,
        )  # fmt: skip
    finally:
        raw_conn.close()
        if client is not None:
            client.close()


def _run_body(
    settings: Settings,
    conn: psycopg.Connection,
    client: EdgarClient,
    configs: list[CompanyConfig],
    mode: str,
    run_id: UUID,
    today: date,
    ny_today: date,
    now: datetime,
    injected: bool,
    notes: list[str],
    golden_queries_path: Path | None,
    scope: str = "all",
    raise_on_red: bool = False,
) -> RunResult:
    errors: list[str] = []
    ok: list[str] = []
    failed: list[str] = []
    stats = _Stats()
    ticker_map: dict[str, tuple[int, str]] | None = None
    fatal: Exception | None = None

    started = _monotonic()
    try:
        log.info("fetching the SEC ticker file")
        try:
            resp = client.get(TICKERS_URL)
        except EdgarHTTPError as exc:  # an outage of this one file must not stop the run (C4 amber)
            errors.append(f"ticker file unavailable: {exc}")
            log.warning("ticker file unavailable: %s (C4 will be amber)", exc)
        else:
            if resp.status == 200:
                try:
                    ticker_map = parse_company_tickers(resp.body)
                except ParseError as exc:
                    errors.append(f"ticker file unreadable: {exc}")
                    log.warning("ticker file unreadable: %s", exc)
            else:
                errors.append(f"ticker file returned HTTP {resp.status}")
                log.warning("ticker file returned HTTP %s", resp.status)
        width = len(str(len(configs)))
        for i, cfg in enumerate(configs, 1):
            before = (stats.inserted, stats.updated, stats.unchanged)
            t0 = _monotonic()
            log.info("[%*d/%d] %s: fetching", width, i, len(configs), cfg.ticker)
            try:
                _process_company(
                    conn, client, cfg, ticker_map, mode=mode, run_id=run_id, today=today,
                    stats=stats,
                )  # fmt: skip
                conn.commit()
                ok.append(cfg.ticker)
                log.info(
                    "[%*d/%d] %s: ok, %d new, %d updated, %d unchanged (%.1fs, %d requests so far)",
                    width, i, len(configs), cfg.ticker, stats.inserted - before[0],
                    stats.updated - before[1], stats.unchanged - before[2], _monotonic() - t0,
                    client.requests_made, extra={"tone": "ok"},
                )  # fmt: skip
            except (SecAccessDenied, RequestBudgetExceeded):
                conn.rollback()
                raise
            except Exception as exc:
                conn.rollback()
                failed.append(cfg.ticker)
                errors.append(f"{cfg.ticker}: {type(exc).__name__}: {exc}")
                log.error(
                    "[%*d/%d] %s: FAILED, %s: %s", width, i, len(configs), cfg.ticker,
                    type(exc).__name__, exc,
                )  # fmt: skip
        log.info("reconciling against the SEC daily index")
        end = _reconcile_daily_index(conn, client, run_id, ny_today=ny_today, errors=errors)
        if mode == "sync":
            log.info("reconciling against the SEC quarterly index")
            _reconcile_master_index(conn, client, run_id, ny_today=ny_today, end=end, errors=errors)
    except (SecAccessDenied, RequestBudgetExceeded) as exc:
        conn.rollback()
        fatal = exc
        errors.append(f"{type(exc).__name__}: {exc}")
        log.error("run stopped: %s: %s", type(exc).__name__, exc)
    except Exception as exc:  # the job itself failed (ticker file, daily index, database)
        conn.rollback()
        fatal = exc
        errors.append(f"{type(exc).__name__}: {exc}")
        log.error("run failed: %s: %s", type(exc).__name__, exc)

    status = "failed" if fatal else ("partial" if failed else "success")
    log.log(
        logging.INFO if status == "success" else logging.ERROR,
        "fetching done: %s, %d companies ok, %d failed, %d requests in %.0fs",
        status, len(ok), len(failed), client.requests_made, _monotonic() - started,
        extra={"tone": "ok"} if status == "success" else {},
    )  # fmt: skip
    summary = "; ".join(notes + errors) or None
    result = RunResult(
        run_id=run_id,
        mode=mode,
        status=status,
        started_at=now,
        finished_at=now if injected else datetime.now(UTC),
        http_requests=client.requests_made,
        rows_inserted=stats.inserted,
        rows_updated=stats.updated,
        rows_unchanged=stats.unchanged,
        companies_ok=ok,
        companies_failed=failed,
        error_summary=summary,
    )
    # The run row must carry its final status before the checks read it (C2).
    repo.finish_run(conn, result, sec_denied=isinstance(fatal, SecAccessDenied))
    conn.commit()

    unknown = [
        CheckResult("C12-input", "Unknown periodic form (input)", "extended", "amber", form)
        for form in sorted(stats.unknown_forms)
    ]
    repo.write_check_results(conn, run_id, unknown)
    ctx = CheckContext(
        run_id=run_id,
        today=today,
        now=now,
        ticker_map=None if ticker_map is None else {t: v[0] for t, v in ticker_map.items()},
        tickers_in_csv=[c.ticker for c in configs],
        golden_queries_path=golden_queries_path,
    )
    log.info("running the morning checks (C2 to C12)")
    results = run_core_checks(conn, ctx)
    repo.write_check_results(conn, run_id, results)
    conn.commit()

    any_red = any(r.status == "red" for r in results)
    _log_check_summary(results)
    if settings.heartbeat_url:
        # OK only when the run succeeded and nothing is red; a narrow run never vouches for the
        # morning job, so it can only ever report a failure.
        healthy = status == "success" and not any_red
        if scope == "all" or not healthy:
            ping_heartbeat(settings.heartbeat_url, failed=not healthy)
    markdown = ""
    try:
        markdown = render_markdown(results, result, today)
        _write_report(settings, results, result, today, markdown)
    except Exception:  # the report is a convenience; the verdict below must not depend on it
        log.exception("morning report could not be written")
    if status == "failed":
        failure = RunFailed(summary or "run failed")
        failure.result = result  # type: ignore[attr-defined]  # so a caller can still report it
        raise failure
    if raise_on_red and any_red:
        raise ChecksRed(CheckReport(run_id, results, exit_code(results, False), markdown))
    return result


def check(
    settings: Settings,
    *,
    today: date | None = None,
    now: datetime | None = None,
    golden_queries_path: Path | None = None,
    expect_run_by: time = DEFAULT_EXPECT_RUN_BY,
) -> CheckReport:
    """Run the heartbeat check and the core checks against what the last sync stored. Results
    are written under a new 'check' run. Raises ChecksRed when any check is red. C1 is red when
    it is `expect_run_by` (London time, default 06:30) or later and no sync or backfill has
    finished successfully today."""
    injected = now is not None
    now = now or datetime.now(UTC)
    today = today if today is not None else now.astimezone(LONDON).date()
    configs = load_companies(settings.companies_csv, settings.companies_yml)
    conn = connect(settings.database_url)
    try:
        apply_migrations(conn)
        conn.commit()
        previous = conn.execute(
            "SELECT run_id FROM run WHERE mode IN ('sync', 'backfill') "
            "AND status <> 'skipped_locked' ORDER BY started_at DESC LIMIT 1"
        ).fetchone()
        run_id = repo.start_run(conn, "check", _git_sha())
        if previous is not None:  # C12 reads its input rows by run id
            conn.execute(
                "INSERT INTO check_result (run_id, check_id, check_name, tier, status, message) "
                "SELECT %s, check_id, check_name, tier, status, message FROM check_result "
                "WHERE run_id = %s AND check_id = 'C12-input'",
                (run_id, previous[0]),
            )
        ctx = CheckContext(
            run_id=run_id,
            today=today,
            now=now,
            ticker_map=_stored_ticker_map(conn),
            tickers_in_csv=[c.ticker for c in configs],
            golden_queries_path=golden_queries_path,
        )
        results = [
            heartbeat_check(conn, now=now, deadline_local=expect_run_by),
            *run_core_checks(conn, ctx),
        ]
        finished = now if injected else datetime.now(UTC)
        run = RunResult(run_id, "check", "success", now, finished, 0, 0, 0, 0, [], [], None)
        repo.finish_run(conn, run)
        # Keep C6's baseline where the last sync left it: a check must not "accept" a drop.
        repo.write_check_results(
            conn,
            run_id,
            [replace(r, observed=None) if r.check_id == "C6" else r for r in results],
        )
        conn.commit()
    finally:
        conn.close()
    markdown = ""
    try:
        markdown = render_markdown(results, run, today)
        _write_report(settings, results, run, today, markdown)
    except Exception as exc:  # a full disk or bad path must not hide the verdict
        log.exception("morning report could not be written")
        markdown += f"\nWARNING: the report file could not be written: {exc}\n"
    report = CheckReport(run_id, results, exit_code(results, False), markdown)
    if any(r.status == "red" for r in results):
        raise ChecksRed(report)
    return report
