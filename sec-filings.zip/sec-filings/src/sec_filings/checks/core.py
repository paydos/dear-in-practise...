"""Core checks C1..C12 (docs/contracts.md section 10, PLAN.md section 8.1).

Each check is ``check_xxx(conn, ctx) -> list[CheckResult]`` and returns at least one result
(green when nothing is wrong). Checks only read; the caller writes the results.
"""

from __future__ import annotations

import json
import os
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta
from importlib import resources
from pathlib import Path
from typing import Literal
from uuid import UUID
from zoneinfo import ZoneInfo

import psycopg
import yaml
from psycopg.rows import dict_row

from sec_filings.domain.deadlines import us_federal_holidays
from sec_filings.models import CheckResult, CheckStatus

# Annual / quarterly families that carry a fiscal label (transition filings are labelled OTHER
# and are excluded from the label and canonical checks).
_PERIODIC = ("annual", "annual_amendment", "quarterly", "quarterly_amendment")
_KIND_SQL = (
    "(CASE WHEN form_family IN ('annual','annual_amendment') THEN 'annual' ELSE 'quarterly' END)"
)
_LIST_LIMIT = 10
_RUN_DIED_AFTER = timedelta(hours=2)  # a run still 'running' after this is dead
_C3_WINDOW_DAYS = 30
_RUN_TOO_OLD = timedelta(hours=26)  # a daily job whose last run started longer ago than this
_C10_FIRST_DATE = date(2009, 6, 15)  # contract 12.3: no rendered reports before this to judge


@dataclass(frozen=True)
class CheckContext:
    run_id: UUID
    today: date
    now: datetime
    ticker_map: Mapping[str, int] | None  # current SEC ticker -> CIK, None if not fetched
    tickers_in_csv: Sequence[str]
    golden_queries_path: Path | None = None  # None: $GOLDEN_QUERIES, else the packaged file


def _res(
    cid: str,
    name: str,
    status: CheckStatus,
    message: str,
    *,
    observed: str | None = None,
    expected: str | None = None,
    company_id: str | None = None,
    tier: Literal["core", "extended"] = "core",
) -> CheckResult:
    return CheckResult(
        cid,
        name,
        tier,
        status,
        message,
        observed=observed,
        expected=expected,
        company_id=company_id,
    )


def _rows(conn: psycopg.Connection, query: str, params: Sequence = ()) -> list[dict]:
    with conn.cursor(row_factory=dict_row) as cur:
        cur.execute(query, params)
        return cur.fetchall()


def _listing(items: Sequence[str], limit: int = _LIST_LIMIT) -> str:
    shown = ", ".join(items[:limit])
    extra = len(items) - limit
    return shown + (f" (+{extra} more)" if extra > 0 else "")


def is_business_day(d: date) -> bool:
    return d.weekday() < 5 and d not in us_federal_holidays(d.year)


def previous_business_day(d: date) -> date:
    d -= timedelta(days=1)
    while not is_business_day(d):
        d -= timedelta(days=1)
    return d


# --------------------------------------------------------------------------- C2


def _judged_run(
    conn: psycopg.Connection, ctx: CheckContext, *, whole_job_only: bool = False
) -> dict | None:
    """The run whose outcome the checks judge: this run, or for a standalone `check` run the
    latest data job (mode sync or backfill) that was not skipped because another run held the
    lock. None when there is no such run. With `whole_job_only` (C2) only runs with scope 'all'
    count: a run limited to some tickers says nothing about the morning job, so it is replaced
    by the latest scope-'all' run."""
    runs = _rows(conn, "SELECT * FROM run WHERE run_id = %s", (ctx.run_id,))
    if not runs:
        return None
    if runs[0]["mode"] != "check" and not (whole_job_only and runs[0]["scope"] != "all"):
        return runs[0]
    scope = "AND scope = 'all' " if whole_job_only else ""
    prior = _rows(
        conn,
        "SELECT * FROM run WHERE mode IN ('sync', 'backfill') AND status <> 'skipped_locked' "
        f"{scope}ORDER BY started_at DESC LIMIT 1",
    )
    return prior[0] if prior else None


def _run_problems(run: dict, ctx: CheckContext, *, age: bool) -> list[CheckResult]:
    """Red results for one run row: failed, partial, died, 403, skipped, too old."""
    name = "Run status"
    status = run["status"]
    summary = run["error_summary"] or ""
    failed = list(run["companies_failed"] or [])
    out: list[CheckResult] = []
    if status == "failed":
        denied = " (SEC denied access: HTTP 403)" if run["sec_denied"] else ""
        out.append(
            _res(
                "C2",
                name,
                "red",
                f"run {run['run_id']} failed{denied}: {summary or 'no detail'}",
                observed=status,
                expected="success",
            )
        )
    elif status == "partial":
        out.append(
            _res(
                "C2",
                name,
                "red",
                f"run {run['run_id']} partial; companies_failed: {_listing(failed)}",
                observed=status,
                expected="success",
            )
        )
    elif status == "skipped_locked":
        out.append(
            _res(
                "C2",
                name,
                "amber",
                f"run {run['run_id']} skipped: another run held the lock",
                observed=status,
                expected="success",
            )
        )
    if status == "running" and ctx.now - run["started_at"] > _RUN_DIED_AFTER:
        out.append(
            _res(
                "C2",
                name,
                "red",
                f"run {run['run_id']} has been 'running' since {run['started_at']:%Y-%m-%d %H:%M} "
                "UTC: run died",
                observed=status,
                expected="success",
            )
        )
    if run["sec_denied"] and status != "failed":  # a failed run's message already shows it
        out.append(
            _res(
                "C2",
                name,
                "red",
                f"SEC returned 403 (access denied): {summary}",
                observed=summary,
                expected="no 403",
            )
        )
    if age and status != "running" and ctx.now - run["started_at"] > _RUN_TOO_OLD:
        hours = int((ctx.now - run["started_at"]).total_seconds() // 3600)
        out.append(
            _res(
                "C2",
                name,
                "red",
                f"last run is {hours} hours old (run {run['run_id']} started "
                f"{run['started_at']:%Y-%m-%d %H:%M} UTC): the daily job has not run",
                observed=f"{hours} hours",
                expected=f"<= {int(_RUN_TOO_OLD.total_seconds() // 3600)} hours",
            )
        )
    return out


def check_run_status(conn: psycopg.Connection, ctx: CheckContext) -> list[CheckResult]:
    name = "Run status"
    own = _rows(conn, "SELECT * FROM run WHERE run_id = %s", (ctx.run_id,))
    if not own:
        return [_res("C2", name, "red", f"no run row found for run {ctx.run_id}")]
    run = _judged_run(conn, ctx, whole_job_only=True)
    if run is None:
        return [_res("C2", name, "red", "no whole-job sync or backfill run has ever been recorded")]
    out = _run_problems(run, ctx, age=True)
    # A narrow run (some tickers) that failed is still worth saying, next to the whole-job verdict.
    o = own[0]
    if o["mode"] != "check" and o["scope"] != "all" and o["status"] in ("failed", "partial"):
        out += [r for r in _run_problems(o, ctx, age=False) if r.status == "red"]
    if not out:
        status = run["status"]
        msg = "run in progress" if status == "running" else "last run succeeded"
        out.append(_res("C2", name, "green", msg, observed=status, expected="success"))
    return out


# --------------------------------------------------------------------------- C3


def unreconciled_business_days(conn: psycopg.Connection, today: date) -> list[date]:
    """US business days in the last 30 days, up to the previous business day (`today` is the
    New York date), that have no 'ok' or 'missing_filings' row. The window starts no earlier than
    the first day ever recorded: days before the install are not gaps."""
    first = conn.execute("SELECT min(index_date) FROM daily_index_reconciliation").fetchone()[0]
    if first is None:
        return []
    end = previous_business_day(today)
    start = max(end - timedelta(days=_C3_WINDOW_DAYS), first)
    done = {
        r[0]
        for r in conn.execute(
            "SELECT index_date FROM daily_index_reconciliation "
            "WHERE status IN ('ok','missing_filings') AND index_date >= %s",
            (start,),
        ).fetchall()
    }
    days = []
    d = start
    while d <= end:
        if is_business_day(d) and d not in done:
            days.append(d)
        d += timedelta(days=1)
    return days


def check_daily_index_reconcile(conn: psycopg.Connection, ctx: CheckContext) -> list[CheckResult]:
    name = "Daily index reconcile"
    out: list[CheckResult] = []
    # Every day with missing filings counts until it is re-reconciled to 'ok' or acknowledged:
    # a gap does not age out.
    missing = _rows(
        conn,
        "SELECT index_date, missing FROM daily_index_reconciliation "
        "WHERE status = 'missing_filings' ORDER BY index_date",
    )
    acks = {
        r["item_key"]: r["reason"]
        for r in _rows(
            conn, "SELECT item_key, reason FROM check_acknowledgement WHERE check_id = 'C3'"
        )
    }
    open_days = [r for r in missing if str(r["index_date"]) not in acks]
    acked_days = [r for r in missing if str(r["index_date"]) in acks]
    if open_days:
        accs = [a for r in open_days for a in r["missing"]]
        days = ", ".join(str(r["index_date"]) for r in open_days[:_LIST_LIMIT])
        out.append(
            _res(
                "C3",
                name,
                "red",
                f"{len(accs)} filing(s) in the SEC daily index but not in our table "
                f"(days {days}): {_listing(accs)}",
                observed=str(len(accs)),
                expected="0",
            )
        )
    for r in acked_days:
        out.append(
            _res(
                "C3",
                name,
                "amber",
                f"{len(r['missing'])} filing(s) missing for {r['index_date']}, acknowledged: "
                f"{acks[str(r['index_date'])]} ({_listing(list(r['missing']))})",
                observed=str(len(r["missing"])),
                expected="0",
            )
        )
    gaps = unreconciled_business_days(conn, ctx.today)
    if gaps:
        status_of = {
            r[0]: r[1]
            for r in conn.execute(
                "SELECT index_date, status FROM daily_index_reconciliation "
                "WHERE index_date = ANY(%s)",
                (gaps,),
            ).fetchall()
        }
        items = [f"{d} ({'not published' if status_of.get(d) else 'never checked'})" for d in gaps]
        out.append(
            _res(
                "C3",
                name,
                "amber",
                f"{len(gaps)} business day(s) without a reconciled daily index: "
                f"{_listing(items)}; retried next run",
                observed=str(len(gaps)),
                expected="0",
            )
        )
    latest = conn.execute("SELECT max(index_date) FROM daily_index_reconciliation").fetchone()[0]
    if latest is not None and latest not in gaps:
        status = conn.execute(
            "SELECT status FROM daily_index_reconciliation WHERE index_date = %s", (latest,)
        ).fetchone()[0]
        if status == "not_published":
            out.append(
                _res(
                    "C3",
                    name,
                    "amber",
                    f"daily index for {latest} not yet published; retried next run",
                )
            )
    recent = conn.execute(
        "SELECT count(*) FROM daily_index_reconciliation "
        "WHERE status IN ('ok','missing_filings') AND index_date >= %s",
        (ctx.today - timedelta(days=30),),
    ).fetchone()[0]
    last = conn.execute(
        "SELECT max(index_date) FROM daily_index_reconciliation "
        "WHERE status IN ('ok','missing_filings')"
    ).fetchone()[0]
    # A table holding only "not published" days has not reconciled anything yet, but nothing was
    # missed either: that is the amber above, not a red gap.
    only_unpublished = last is None and latest is not None
    if recent == 0 and not only_unpublished:
        out.append(
            _res(
                "C3",
                name,
                "red",
                f"no daily index reconciled in the last 30 days (last: {last}); "
                "gap, see backfill runbook",
                observed=str(last),
                expected=f">= {ctx.today - timedelta(days=30)}",
            )
        )
    if not out:
        out.append(_res("C3", name, "green", f"daily index reconciled (latest {latest})"))
    return out


# --------------------------------------------------------------------------- C4


def check_company_mapping(conn: psycopg.Connection, ctx: CheckContext) -> list[CheckResult]:
    name = "Company mapping"
    out: list[CheckResult] = []
    companies = {
        r["company_id"]: r
        for r in _rows(
            conn,
            "SELECT company_id, reviewed FROM company WHERE company_id = ANY(%s)",
            (list(ctx.tickers_in_csv),),
        )
    }
    ciks_by_company: dict[str, set[int]] = {}
    for r in _rows(conn, "SELECT company_id, cik FROM company_cik"):
        ciks_by_company.setdefault(r["company_id"], set()).add(int(r["cik"]))
    judged = _judged_run(conn, ctx)
    failed = set(judged["companies_failed"] or []) if judged else set()
    if not ctx.tickers_in_csv:
        return [
            _res(
                "C4",
                name,
                "red",
                "companies.csv lists no tickers: nothing is tracked",
                observed="0",
                expected=">= 1",
            )
        ]
    if ctx.ticker_map is None:
        out.append(
            _res(
                "C4",
                name,
                "amber",
                "ticker map unavailable: current SEC ticker file not fetched; mapping not verified",
            )
        )
    for t in ctx.tickers_in_csv:
        if t in failed:  # its stored data is from before this run: nothing to judge, say so
            out.append(
                _res(
                    "C4",
                    name,
                    "amber",
                    f"{t} not resolved: company failed this run",
                    company_id=t,
                )
            )
            continue
        known = ciks_by_company.get(t, set())
        sec_cik = None if ctx.ticker_map is None else ctx.ticker_map.get(t)
        if ctx.ticker_map is not None and sec_cik is None:
            out.append(
                _res(
                    "C4",
                    name,
                    "amber",
                    f"{t} is absent from the SEC ticker file (delisted, renamed or acquired?)",
                    company_id=t,
                )
            )
        if sec_cik is not None and int(sec_cik) not in known:
            out.append(
                _res(
                    "C4",
                    name,
                    "red",
                    f"{t} now maps to CIK {sec_cik}, not in company_cik "
                    f"(known: {sorted(known) or 'none'})",
                    observed=str(sec_cik),
                    expected=_listing([str(c) for c in sorted(known)]),
                    company_id=t,
                )
            )
        if t not in companies:
            out.append(
                _res(
                    "C4", name, "amber", f"{t} is in companies.csv but not yet synced", company_id=t
                )
            )
        elif not companies[t]["reviewed"]:
            out.append(
                _res(
                    "C4", name, "amber", f"{t} has no reviewed entry in companies.yml", company_id=t
                )
            )
    if not out:
        out.append(
            _res("C4", name, "green", f"{len(ctx.tickers_in_csv)} ticker(s) mapped and reviewed")
        )
    return out


# --------------------------------------------------------------------------- C5


def check_coverage_drift(conn: psycopg.Connection, ctx: CheckContext) -> list[CheckResult]:
    name = "Coverage drift"
    bad = _rows(
        conn,
        "SELECT cik, page_name, filing_count, rows_in_payload FROM history_page "
        "WHERE rows_in_payload IS DISTINCT FROM filing_count OR rows_in_payload IS NULL "
        "ORDER BY cik, page_name",
    )
    if not bad:
        n = conn.execute("SELECT count(*) FROM history_page").fetchone()[0]
        return [_res("C5", name, "green", f"{n} history page(s) match their stated filing count")]
    out = []
    for r in bad[:_LIST_LIMIT]:
        got = "no stored copy" if r["rows_in_payload"] is None else str(r["rows_in_payload"])
        out.append(
            _res(
                "C5",
                name,
                "red",
                f"CIK {r['cik']} page {r['page_name']}: SEC says {r['filing_count']}, parsed {got}",
                observed=got,
                expected=str(r["filing_count"]),
            )
        )
    if len(bad) > _LIST_LIMIT:
        out.append(_res("C5", name, "red", f"+{len(bad) - _LIST_LIMIT} more drifting page(s)"))
    return out


# --------------------------------------------------------------------------- C6


def check_rowcount_monotonic(conn: psycopg.Connection, ctx: CheckContext) -> list[CheckResult]:
    name = "Row count never falls"
    # Every row counts, stale or not: rows are never deleted (D-07), so a count only falls when
    # rows were deleted. The baseline is the last GREEN result, so a drop stays red until the
    # rows are restored.
    now_counts = {
        f"{r['company_id']}|{r['form_family']}": int(r["n"])
        for r in _rows(
            conn,
            "SELECT company_id, form_family, count(*) AS n FROM filing GROUP BY 1, 2",
        )
    }
    observed = json.dumps(now_counts, sort_keys=True)
    prev = _rows(
        conn,
        "SELECT observed FROM check_result WHERE check_id = 'C6' AND run_id <> %s "
        "AND status = 'green' AND observed IS NOT NULL ORDER BY created_at DESC LIMIT 1",
        (ctx.run_id,),
    )
    if not prev:
        return [
            _res(
                "C6",
                name,
                "green",
                "no previous run to compare; baseline stored",
                observed=observed,
            )
        ]
    try:
        before: dict[str, int] = json.loads(prev[0]["observed"])
    except ValueError:
        return [
            _res(
                "C6",
                name,
                "amber",
                "previous C6 counts unreadable; baseline reset",
                observed=observed,
            )
        ]
    drops = [
        f"{k} {v} -> {now_counts.get(k, 0)}"
        for k, v in sorted(before.items())
        if now_counts.get(k, 0) < v
    ]
    if drops:
        return [
            _res(
                "C6",
                name,
                "red",
                f"{len(drops)} company/family count(s) fell: {_listing(drops)}",
                observed=observed,
                expected="no decrease",
            )
        ]
    return [
        _res(
            "C6",
            name,
            "green",
            f"{len(now_counts)} company/family count(s) did not fall",
            observed=observed,
        )
    ]


# --------------------------------------------------------------------------- C7


def check_one_canonical(conn: psycopg.Connection, ctx: CheckContext) -> list[CheckResult]:
    name = "One canonical per period"
    groups = _rows(
        conn,
        f"""
        SELECT company_id, {_KIND_SQL} AS kind, fiscal_year, fiscal_period,
               count(*) FILTER (WHERE is_canonical) AS canon,
               count(*) FILTER (WHERE form_family IN ('annual', 'quarterly')) AS originals
        FROM filing
        WHERE NOT is_stale AND form_family = ANY(%s) AND fiscal_year IS NOT NULL
        GROUP BY 1, 2, 3, 4
        HAVING count(*) FILTER (WHERE is_canonical) <> 1
            OR count(*) FILTER (WHERE form_family IN ('annual', 'quarterly')) > 1
        ORDER BY 1, 2, 3, 4
        """,
        (list(_PERIODIC),),
    )
    mismatched = _rows(
        conn,
        """
        SELECT rp.company_id, rp.report_kind, rp.fiscal_year, rp.fiscal_period
        FROM report_period rp
        LEFT JOIN filing f ON f.accession_number = rp.canonical_accession
        WHERE rp.canonical_accession IS NOT NULL AND f.is_canonical IS NOT TRUE
        """,
    )
    items = []
    for g in groups:
        why = []
        if g["canon"] != 1:
            why.append(f"{g['canon']} canonical")
        if g["originals"] > 1:  # two originals under one label: the labelling is wrong (E-31)
            why.append(f"{g['originals']} original filings")
        items.append(
            f"{g['company_id']} {g['kind']} FY{g['fiscal_year']} {g['fiscal_period']} "
            f"({', '.join(why)})"
        )
    items += [
        f"{m['company_id']} {m['report_kind']} FY{m['fiscal_year']} {m['fiscal_period']} "
        "(report_period points at a non-canonical filing)"
        for m in mismatched
    ]
    if items:
        return [
            _res(
                "C7",
                name,
                "red",
                f"{len(items)} period(s) without exactly one canonical or with several "
                f"originals: {_listing(items)}",
                observed=str(len(items)),
                expected="0",
            )
        ]
    return [_res("C7", name, "green", "every labelled period has exactly one canonical filing")]


# --------------------------------------------------------------------------- C8


def check_labels(conn: psycopg.Connection, ctx: CheckContext) -> list[CheckResult]:
    name = "Labels present and plausible"
    bad = _rows(
        conn,
        """
        SELECT accession_number, company_id, form, filing_date, label_source, fiscal_year,
               period_of_report
        FROM filing
        WHERE NOT is_stale AND form_family = ANY(%s) AND filing_date >= DATE '2011-01-01'
          AND (label_source = 'none'
               OR abs(fiscal_year - extract(year FROM period_of_report)) > 1)
        ORDER BY filing_date, accession_number
        """,
        (list(_PERIODIC),),
    )
    out: list[CheckResult] = []
    if bad:
        items = [
            f"{b['company_id']} {b['accession_number']} ({b['form']}, "
            + (
                "no label"
                if b["label_source"] == "none"
                else f"FY{b['fiscal_year']} vs period {b['period_of_report']}"
            )
            + ")"
            for b in bad
        ]
        out.append(
            _res(
                "C8",
                name,
                "red",
                f"{len(bad)} filing(s) unlabelled or implausible: {_listing(items)}",
                observed=str(len(bad)),
                expected="0",
            )
        )
    # Green (informational), one result per company: the filing declared a different fiscal year
    # than the label we stored. The convention rule chose that on purpose (D-04, contract 12.1),
    # so it is not a problem and must not keep the morning report amber.
    disagree = _rows(
        conn,
        """
        SELECT accession_number, company_id, form, fiscal_year, declared_fiscal_year,
               period_of_report
        FROM filing
        WHERE NOT is_stale AND form_family = ANY(%s)
          AND declared_fiscal_year IS NOT NULL AND fiscal_year IS NOT NULL
          AND declared_fiscal_year <> fiscal_year
        ORDER BY company_id, filing_date, accession_number
        """,
        (list(_PERIODIC),),
    )
    by_company: dict[str, list[dict]] = {}
    for d in disagree:
        by_company.setdefault(d["company_id"], []).append(d)
    for company, rows in by_company.items():
        examples = [
            f"{r['accession_number']} ({r['form']}, period {r['period_of_report']}: "
            f"declared FY{r['declared_fiscal_year']}, labelled FY{r['fiscal_year']})"
            for r in rows[:5]
        ]
        out.append(
            _res(
                "C8",
                name,
                "green",
                f"info: {company}: {len(rows)} filing(s) declare a different fiscal year than "
                f"the convention label (deliberate, D-04): {', '.join(examples)}"
                + (f" (+{len(rows) - 5} more)" if len(rows) > 5 else ""),
                observed=str(len(rows)),
                expected="0",
                company_id=company,
            )
        )
    if not out:
        out.append(
            _res("C8", name, "green", "all XBRL-era periodic filings are labelled plausibly")
        )
    return out


# --------------------------------------------------------------------------- C9


def check_expected_overdue(conn: psycopg.Connection, ctx: CheckContext) -> list[CheckResult]:
    name = "Expected but overdue"
    rows = _rows(
        conn,
        "SELECT company_id, report_kind, fiscal_year, fiscal_period, due_date_with_extension "
        "FROM expected_filing WHERE status = 'overdue' "
        "ORDER BY company_id, fiscal_year, fiscal_period",
    )
    if not rows:
        return [_res("C9", name, "green", "no overdue filings")]
    by_company: dict[str, list[str]] = {}
    for r in rows:
        by_company.setdefault(r["company_id"], []).append(
            f"{r['report_kind']} FY{r['fiscal_year']} {r['fiscal_period']} "
            f"(due {r['due_date_with_extension']})"
        )
    return [
        _res(
            "C9",
            name,
            "red",
            f"{c}: overdue {_listing(items)}",
            observed=str(len(items)),
            expected="0",
            company_id=c,
        )
        for c, items in by_company.items()
    ]


# --------------------------------------------------------------------------- C10


def check_amendments_resolved(conn: psycopg.Connection, ctx: CheckContext) -> list[CheckResult]:
    name = "Amendments resolved"
    bad = _rows(
        conn,
        """
        SELECT accession_number, company_id, amends_accession, amendment_scope, amendment_kind
        FROM filing
        WHERE NOT is_stale AND form_family IN ('annual_amendment', 'quarterly_amendment')
          AND filing_date >= %s
          AND (amends_accession IS NULL OR amendment_scope IS NULL OR amendment_scope = 'unknown'
               OR amendment_kind IS NULL OR amendment_kind = 'unknown')
        ORDER BY filing_date, accession_number
        """,
        (_C10_FIRST_DATE,),
    )
    if not bad:
        return [_res("C10", name, "green", "every amendment is linked with a known scope and kind")]
    items = []
    for b in bad:
        why = []
        if b["amends_accession"] is None:
            why.append("orphan")
        if b["amendment_scope"] in (None, "unknown"):
            why.append("scope unknown")
        if b["amendment_kind"] in (None, "unknown"):
            why.append("kind unknown")
        items.append(f"{b['company_id']} {b['accession_number']} ({', '.join(why)})")
    return [
        _res(
            "C10",
            name,
            "amber",
            f"{len(bad)} amendment(s) unresolved: {_listing(items)}",
            observed=str(len(bad)),
            expected="0",
        )
    ]


# --------------------------------------------------------------------------- C11


def golden_queries_source(path: Path | None = None) -> tuple[str, str | None]:
    """(label, text) of the golden queries: `path`, else $GOLDEN_QUERIES, else the file packaged
    with the library (golden_queries.yml). text is None when a given file does not exist."""
    chosen = path if path is not None else (os.environ.get("GOLDEN_QUERIES") or None)
    if chosen is not None:
        p = Path(chosen)
        return str(p), p.read_text(encoding="utf-8") if p.is_file() else None
    ref = resources.files("sec_filings") / "golden_queries.yml"
    return "sec_filings/golden_queries.yml", ref.read_text(encoding="utf-8")


def load_golden_queries(path: Path | None = None) -> list[dict]:
    """Parsed golden queries. Raises FileNotFoundError, ValueError or yaml.YAMLError."""
    label, text = golden_queries_source(path)
    if text is None:
        raise FileNotFoundError(label)
    queries = yaml.safe_load(text) or []
    if not isinstance(queries, list):
        raise ValueError("top level must be a list")
    return queries


def check_golden_queries(conn: psycopg.Connection, ctx: CheckContext) -> list[CheckResult]:
    name = "Golden queries"
    try:
        queries = load_golden_queries(ctx.golden_queries_path)
    except FileNotFoundError as exc:
        return [_res("C11", name, "amber", f"golden queries file not found: {exc}")]
    except (ValueError, yaml.YAMLError) as exc:
        return [_res("C11", name, "amber", f"golden queries file unreadable: {exc}")]
    tracked = {str(t).upper() for t in ctx.tickers_in_csv}
    required = (
        "company_id",
        "report_kind",
        "fiscal_year",
        "fiscal_period",
        "expected_canonical_accession",
    )
    out: list[CheckResult] = []
    judged = 0
    for n, q in enumerate(queries, start=1):
        if not isinstance(q, dict):
            out.append(_res("C11", name, "amber", f"golden query entry {n} is not a mapping"))
            continue
        qid = q.get("id", f"entry {n}")
        if q.get("company_id") is not None and str(q["company_id"]).upper() not in tracked:
            continue
        absent = [k for k in required if q.get(k) is None]
        if absent:  # a broken entry is amber for that entry, never a crash
            out.append(
                _res(
                    "C11",
                    name,
                    "amber",
                    f"golden query {qid} is missing key(s): {', '.join(absent)}",
                    company_id=None if q.get("company_id") is None else str(q["company_id"]),
                )
            )
            continue
        judged += 1
        try:
            with conn.transaction():  # a savepoint: a bad value must not poison the caller
                row = conn.execute(
                    "SELECT canonical_accession FROM report_period WHERE company_id = %s "
                    "AND report_kind = %s AND fiscal_year = %s AND fiscal_period = %s",
                    (q["company_id"], q["report_kind"], q["fiscal_year"], q["fiscal_period"]),
                ).fetchone()
        except psycopg.Error as exc:
            out.append(
                _res(
                    "C11",
                    name,
                    "amber",
                    f"golden query {qid} could not be evaluated: {exc}",
                    company_id=str(q["company_id"]),
                )
            )
            continue
        expected = str(q["expected_canonical_accession"])
        if row is None:
            out.append(
                _res(
                    "C11",
                    name,
                    "red",
                    f"{qid}: no report period found",
                    observed="missing",
                    expected=expected,
                    company_id=q["company_id"],
                )
            )
        elif row[0] != expected:
            out.append(
                _res(
                    "C11",
                    name,
                    "red",
                    f"{qid}: canonical is {row[0]}, expected {expected}",
                    observed=str(row[0]),
                    expected=expected,
                    company_id=q["company_id"],
                )
            )
    if not out:
        out.append(_res("C11", name, "green", f"{judged} golden queries match"))
    return out


# --------------------------------------------------------------------------- C12


def check_unknown_periodic_form(conn: psycopg.Connection, ctx: CheckContext) -> list[CheckResult]:
    """The filing table cannot hold forms with no family, so the sync reports them by writing
    ``check_result`` rows with check_id 'C12-input' for this run, one per form string
    (message = the form). Any such row makes this check amber."""
    name = "Unknown periodic form"
    forms = sorted(
        {
            r["message"]
            for r in _rows(
                conn,
                "SELECT message FROM check_result WHERE check_id = 'C12-input' AND run_id = %s",
                (ctx.run_id,),
            )
        }
    )
    if not forms:
        return [_res("C12", name, "green", "no unknown periodic forms")]
    return [
        _res(
            "C12",
            name,
            "amber",
            f"unknown periodic form(s) seen: {_listing(forms)}",
            observed=_listing(forms),
            expected="none",
        )
    ]


# --------------------------------------------------------------------------- X1


def check_stale_rows(conn: psycopg.Connection, ctx: CheckContext) -> list[CheckResult]:
    """Extended check X1: rows newly flagged stale (D-07) by the judged run, i.e. filings the SEC
    no longer lists. Amber, because nothing is deleted but an analyst should look."""
    name = "Stale rows"
    run = _judged_run(conn, ctx)
    rows = (
        []
        if run is None
        else _rows(
            conn,
            "SELECT accession_number, company_id, form, filing_date FROM filing "
            "WHERE is_stale AND stale_run_id = %s ORDER BY company_id, filing_date",
            (run["run_id"],),
        )
    )
    if not rows:
        return [_res("X1", name, "green", "no rows newly flagged stale", tier="extended")]
    items = [
        f"{r['company_id']} {r['form']} {r['accession_number']} ({r['filing_date']})" for r in rows
    ]
    return [
        _res(
            "X1",
            name,
            "amber",
            f"{len(rows)} row(s) newly flagged stale (no longer listed by the SEC): "
            f"{_listing(items)}",
            observed=str(len(rows)),
            expected="0",
            tier="extended",
        )
    ]


# --------------------------------------------------------------------------- registry


CORE_CHECKS: tuple[Callable[[psycopg.Connection, CheckContext], list[CheckResult]], ...] = (
    check_run_status,
    check_daily_index_reconcile,
    check_company_mapping,
    check_coverage_drift,
    check_rowcount_monotonic,
    check_one_canonical,
    check_labels,
    check_expected_overdue,
    check_amendments_resolved,
    check_golden_queries,
    check_unknown_periodic_form,
    check_stale_rows,
)


def run_core_checks(conn: psycopg.Connection, ctx: CheckContext) -> list[CheckResult]:
    """Run every check in CORE_CHECKS (C2..C12, then extended X1, in order) and return the
    flattened results."""
    results: list[CheckResult] = []
    for check in CORE_CHECKS:
        results.extend(check(conn, ctx))
    return results


def heartbeat_check(
    conn: psycopg.Connection,
    *,
    now: datetime,
    deadline_local: time = time(6, 30),
    tz: str = "Europe/London",
) -> CheckResult:
    """C1: red when `now` is at or after the local deadline (`check --expect-run-by`, default
    06:30 London) and no sync or backfill run with status success finished today (local date)
    before `now`. Before the deadline it is green: the run is not due yet. Run separately from
    run_core_checks."""
    name = "Heartbeat"
    zone = ZoneInfo(tz)
    local_now = now.astimezone(zone)
    today = local_now.date()
    deadline = datetime.combine(today, deadline_local, tzinfo=zone)
    dl = f"{deadline_local:%H:%M}"
    done = sorted(
        f
        for f in (
            r[0].astimezone(zone)
            for r in conn.execute(
                "SELECT finished_at FROM run WHERE status = 'success' AND scope = 'all' "
                "AND mode IN ('sync', 'backfill') AND finished_at IS NOT NULL "
                "ORDER BY finished_at DESC LIMIT 200"
            )
        )
        if f.date() == today and f <= local_now
    )
    if done:
        return _res("C1", name, "green", f"run finished {done[0]:%H:%M} today ({tz})")
    if local_now < deadline:
        return _res("C1", name, "green", f"before {dl} {tz}: today's run is not due yet")
    return _res(
        "C1",
        name,
        "red",
        f"no successful sync or backfill finished on {today} by {local_now:%H:%M}; "
        f"expected one by {dl} {tz}",
        expected=f"<= {deadline.isoformat()}",
    )
