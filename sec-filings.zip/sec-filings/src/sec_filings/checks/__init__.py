"""Morning checks."""
