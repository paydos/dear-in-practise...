"""Check report rendering and heartbeat."""

from __future__ import annotations

from collections.abc import Sequence
from datetime import date

import httpx

from sec_filings.models import CheckResult, RunResult

_TABLE_MESSAGE_MAX = 120


def exit_code(results: Sequence[CheckResult], run_failed: bool, run_skipped: bool = False) -> int:
    """4 run skipped (another run held the lock), 3 run failed, 2 red, 1 amber, 0 green."""
    if run_failed:
        return 3
    if run_skipped:
        return 4
    if any(r.status == "red" for r in results):
        return 2
    if any(r.status == "amber" for r in results):
        return 1
    return 0


def _overall(results: Sequence[CheckResult], run_failed: bool) -> str:
    if run_failed or any(r.status == "red" for r in results):
        return "RED"
    if any(r.status == "amber" for r in results):
        return "AMBER"
    return "GREEN"


def _one_line(text: str, limit: int | None = None) -> str:
    flat = " ".join(text.split()).replace("|", "/")
    if limit is not None and len(flat) > limit:
        flat = flat[: limit - 3] + "..."
    return flat


def _label(r: CheckResult) -> str:
    who = f" [{r.company_id}]" if r.company_id else ""
    return f"{r.check_id} {r.check_name}{who}: {_one_line(r.message)}"


def render_markdown(results: Sequence[CheckResult], run: RunResult | None, today: date) -> str:
    run_failed = run is not None and run.status == "failed"
    overall = _overall(results, run_failed)
    reds = [r for r in results if r.status == "red"]
    ambers = [r for r in results if r.status == "amber"]
    greens = [r for r in results if r.status == "green"]

    if overall == "GREEN":
        verdict = f"All {len(results)} checks passed."
    else:
        verdict = f"{len(reds)} red, {len(ambers)} amber, {len(greens)} green."
    if run is not None:
        verdict += f" Run {run.run_id} ({run.mode}): {run.status}."

    lines = [f"# Morning check {today.isoformat()}: {overall}", "", verdict, ""]
    if reds:
        lines += ["## Red", ""] + [f"- {_label(r)}" for r in reds] + [""]
    if ambers:
        lines += ["## Amber", ""] + [f"- {_label(r)}" for r in ambers] + [""]
    lines += [
        "## All checks",
        "",
        "| Check | Name | Status | Message |",
        "|-------|------|--------|---------|",
    ]
    for r in results:
        name = r.check_name + (f" [{r.company_id}]" if r.company_id else "")
        lines.append(
            f"| {r.check_id} | {_one_line(name)} | {r.status} | "
            f"{_one_line(r.message, _TABLE_MESSAGE_MAX)} |"
        )
    return "\n".join(lines) + "\n"


def ping_heartbeat(url: str, *, failed: bool = False, timeout: float = 10.0) -> bool:
    """GET the heartbeat URL (healthchecks.io convention). A successful run pings `url`; a
    partial or failed run pings `url + "/fail"`, so the monitor alerts at once instead of
    waiting for silence. True on a 2xx response, False on any error. Never raises."""
    target = url.rstrip("/") + "/fail" if failed else url
    try:
        resp = httpx.get(target, timeout=timeout, follow_redirects=True)
        return resp.is_success
    except Exception:
        return False
