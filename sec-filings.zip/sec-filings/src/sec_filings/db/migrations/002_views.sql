-- 002_views.sql: contract amendment 2 (section 11.1) and the analyst views (PLAN 4.2).

-- The filer category can now come from the public float estimate.
ALTER TABLE expected_filing DROP CONSTRAINT IF EXISTS expected_filing_category_source_check;
ALTER TABLE expected_filing ADD CONSTRAINT expected_filing_category_source_check
  CHECK (category_source IN ('cover','public_float','previous_cover','current','none'));

-- Where the fiscal year and period of a filing came from: its rendered cover page (R1.htm),
-- the company-concept file, or an XBRL instance. Null when the label is not from tags.
ALTER TABLE filing ADD COLUMN cover_source text
  CHECK (cover_source IN ('cover_page','concept','instance'));


-- One row per company and fiscal year: the canonical annual report and how it came about.
CREATE VIEW v_annual_reports AS
SELECT
  rp.company_id,
  rp.fiscal_year,
  f.form,
  rp.canonical_accession                       AS accession,
  f.filing_date,
  f.period_of_report,
  COALESCE(e.period_end_estimate, f.period_of_report) AS period_end,
  f.label_source,
  f.label_confidence,
  f.cover_source,
  rp.version_count > 1                         AS was_amended,
  (SELECT array_agg(DISTINCT v.amendment_kind ORDER BY v.amendment_kind)
     FROM filing v
    WHERE v.company_id = rp.company_id
      AND v.form_family IN ('annual', 'annual_amendment')
      AND v.fiscal_year = rp.fiscal_year
      AND v.fiscal_period = rp.fiscal_period
      AND v.amendment_kind IS NOT NULL)        AS amendment_kinds,
  f.amendment_scope                            AS canonical_amendment_scope,
  f.amendment_kind                             AS canonical_amendment_kind,
  rp.version_count,
  rp.original_accession,
  rp.latest_filed_accession,
  f.pre_merger_shell,
  e.due_date,
  e.due_date_with_extension,
  e.status,
  e.status = 'received_late'                   AS filed_late,
  e.nt_accession IS NOT NULL                   AS nt_filed,
  m.filing_date - e.period_end_estimate        AS days_after_period_end,
  e.filer_category_used,
  e.category_source
FROM report_period rp
LEFT JOIN filing f ON f.accession_number = rp.canonical_accession
LEFT JOIN expected_filing e
       ON e.company_id = rp.company_id AND e.report_kind = rp.report_kind
      AND e.fiscal_year = rp.fiscal_year AND e.fiscal_period = rp.fiscal_period
LEFT JOIN filing m ON m.accession_number = e.matched_accession
WHERE rp.report_kind = 'annual';

COMMENT ON VIEW v_annual_reports IS
  'One row per company and fiscal year. days_after_period_end and filed_late judge the original '
  'report (the filing the deadline applies to), not a later amendment.';


-- The same for quarters: Q1 to Q3 (the 10-K covers Q4). Foreign filers have no rows.
CREATE VIEW v_quarterly_reports AS
SELECT
  rp.company_id,
  rp.fiscal_year,
  rp.fiscal_period,
  f.form,
  rp.canonical_accession                       AS accession,
  f.filing_date,
  f.period_of_report,
  COALESCE(e.period_end_estimate, f.period_of_report) AS period_end,
  f.label_source,
  f.label_confidence,
  f.cover_source,
  rp.version_count > 1                         AS was_amended,
  (SELECT array_agg(DISTINCT v.amendment_kind ORDER BY v.amendment_kind)
     FROM filing v
    WHERE v.company_id = rp.company_id
      AND v.form_family IN ('quarterly', 'quarterly_amendment')
      AND v.fiscal_year = rp.fiscal_year
      AND v.fiscal_period = rp.fiscal_period
      AND v.amendment_kind IS NOT NULL)        AS amendment_kinds,
  f.amendment_scope                            AS canonical_amendment_scope,
  f.amendment_kind                             AS canonical_amendment_kind,
  rp.version_count,
  rp.original_accession,
  rp.latest_filed_accession,
  f.pre_merger_shell,
  e.due_date,
  e.due_date_with_extension,
  e.status,
  e.status = 'received_late'                   AS filed_late,
  e.nt_accession IS NOT NULL                   AS nt_filed,
  m.filing_date - e.period_end_estimate        AS days_after_period_end,
  e.filer_category_used,
  e.category_source
FROM report_period rp
LEFT JOIN filing f ON f.accession_number = rp.canonical_accession
LEFT JOIN expected_filing e
       ON e.company_id = rp.company_id AND e.report_kind = rp.report_kind
      AND e.fiscal_year = rp.fiscal_year AND e.fiscal_period = rp.fiscal_period
LEFT JOIN filing m ON m.accession_number = e.matched_accession
WHERE rp.report_kind = 'quarterly';


-- Correction events: a non-reliance 8-K (item 4.02) or a cover error-correction flag, with the
-- filings that carry the corrected numbers.
CREATE VIEW v_correction_events AS
SELECT
  ce.event_id,
  ce.company_id,
  c.name                                       AS company_name,
  ce.event_type,
  ce.source_accession,
  s.form                                       AS source_form,
  ce.event_date,
  ce.link_confidence,
  ce.pre_merger_shell,
  ce.corrected_in_accessions,
  (SELECT array_agg(f.form || ' filed ' || f.filing_date || ' ' || f.accession_number
                    ORDER BY f.filing_date, f.accession_number)
     FROM filing f
    WHERE f.accession_number = ANY (ce.corrected_in_accessions)) AS corrected_in
FROM correction_event ce
JOIN company c ON c.company_id = ce.company_id
JOIN filing s ON s.accession_number = ce.source_accession;


-- Every amendment, the filing it amends, and how scope and kind were decided.
CREATE VIEW v_amendments AS
SELECT
  a.company_id,
  a.accession_number,
  a.form,
  a.filing_date,
  a.fiscal_year,
  a.fiscal_period,
  a.amends_accession,
  o.form                                       AS original_form,
  o.filing_date                                AS original_filing_date,
  a.amendment_scope                            AS scope,
  a.amendment_kind                             AS kind,
  a.kind_evidence                              AS evidence,
  round(a.size_bytes::numeric / NULLIF(o.size_bytes, 0), 3) AS size_ratio,
  a.is_canonical,
  a.pre_merger_shell,
  a.label_source,
  a.dei_amendment_description
FROM filing a
LEFT JOIN filing o ON o.accession_number = a.amends_accession
WHERE a.form_family IN ('annual_amendment', 'quarterly_amendment');


-- The checks of the most recent run, red first.
CREATE VIEW v_morning_check AS
SELECT
  cr.run_id,
  r.mode                                       AS run_mode,
  r.started_at                                 AS run_started_at,
  cr.check_id,
  cr.check_name,
  cr.tier,
  cr.status,
  cr.message,
  cr.observed,
  cr.expected,
  cr.company_id
FROM check_result cr
JOIN run r ON r.run_id = cr.run_id
WHERE cr.run_id = (SELECT run_id FROM check_result ORDER BY created_at DESC LIMIT 1)
  AND cr.check_id <> 'C12-input'
ORDER BY CASE cr.status WHEN 'red' THEN 0 WHEN 'amber' THEN 1 ELSE 2 END,
         cr.check_id, cr.company_id;


-- Per company: what we hold, how far back it goes, and under which CIKs.
CREATE VIEW v_company_coverage AS
SELECT
  c.company_id,
  c.name,
  c.is_foreign_private_issuer,
  c.reviewed,
  (SELECT array_agg(k.cik ORDER BY k.valid_from NULLS FIRST, k.cik)
     FROM company_cik k WHERE k.company_id = c.company_id)    AS ciks,
  min(f.filing_date)                                          AS first_filing_date,
  max(f.filing_date)                                          AS last_filing_date,
  count(f.*) FILTER (WHERE f.form_family = 'annual')                 AS annual_reports,
  count(f.*) FILTER (WHERE f.form_family = 'annual_amendment')       AS annual_amendments,
  count(f.*) FILTER (WHERE f.form_family = 'quarterly')              AS quarterly_reports,
  count(f.*) FILTER (WHERE f.form_family = 'quarterly_amendment')    AS quarterly_amendments,
  count(f.*) FILTER (WHERE f.form_family IN ('transition_annual', 'transition_quarterly'))
                                                              AS transition_reports,
  count(f.*) FILTER (WHERE f.form_family = 'foreign_current_report') AS foreign_current_reports,
  count(f.*) FILTER (WHERE f.form_family = 'late_notice')            AS late_notices,
  count(f.*) FILTER (WHERE f.form_family = 'non_reliance_8k')        AS non_reliance_8ks,
  count(f.*) FILTER (WHERE f.is_stale)                               AS stale_rows
FROM company c
LEFT JOIN filing f ON f.company_id = c.company_id
GROUP BY c.company_id, c.name, c.is_foreign_private_issuer, c.reviewed;
