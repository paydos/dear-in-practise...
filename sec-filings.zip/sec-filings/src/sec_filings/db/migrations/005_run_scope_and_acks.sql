-- 005_run_scope_and_acks.sql: what a run covered, whether the SEC denied it, and acknowledgements.

-- 'subset' = a run limited to some tickers (backfill -t, sync with tickers). C1 and C2 judge only
-- runs with scope 'all', so a narrow run cannot make a failed morning sync look healthy.
ALTER TABLE run ADD COLUMN scope text NOT NULL DEFAULT 'all' CHECK (scope IN ('all', 'subset'));

-- Set when HTTP 403 (SecAccessDenied) stopped the run. C2's 403 message uses only this flag.
ALTER TABLE run ADD COLUMN sec_denied boolean NOT NULL DEFAULT false;

-- A person's decision to live with a known problem (C3: a day with missing filings). The check
-- stays visible as amber with the reason instead of red; it never disappears by itself.
CREATE TABLE check_acknowledgement (
  check_id        text NOT NULL,
  item_key        text NOT NULL,
  reason          text NOT NULL CHECK (length(btrim(reason)) > 0),
  acknowledged_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (check_id, item_key)
);
