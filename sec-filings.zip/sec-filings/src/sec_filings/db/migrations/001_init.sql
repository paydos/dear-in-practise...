-- 001_init.sql
CREATE TABLE IF NOT EXISTS schema_migrations (
  version     text PRIMARY KEY,
  applied_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE company (
  company_id                 text PRIMARY KEY,            -- ticker as given in companies.csv
  name                       text,
  is_foreign_private_issuer  boolean NOT NULL DEFAULT false,
  fiscal_year_end_mmdd       text,                        -- e.g. '0926', from the latest submissions JSON
  filer_category_current     text,                        -- raw text from submissions JSON 'category'
  fy_naming_convention       text NOT NULL DEFAULT 'unknown'
                             CHECK (fy_naming_convention IN ('ends_in','starts_in','unknown')),
  pre_merger_until           date,
  reviewed                   boolean NOT NULL DEFAULT false,   -- true when companies.yml has an entry
  notes                      text,
  updated_at                 timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE company_cik (
  company_id  text NOT NULL REFERENCES company(company_id),
  cik         bigint NOT NULL UNIQUE,
  valid_from  date,
  valid_to    date,
  source      text NOT NULL CHECK (source IN ('ticker_file','manual','successor_8k')),
  note        text,
  PRIMARY KEY (company_id, cik)
);

CREATE TABLE company_name_history (
  cik         bigint NOT NULL,
  name        text NOT NULL,
  valid_from  date,
  valid_to    date,
  PRIMARY KEY (cik, name)
);

CREATE TABLE run (
  run_id         uuid PRIMARY KEY,
  started_at     timestamptz NOT NULL,
  finished_at    timestamptz,
  mode           text NOT NULL CHECK (mode IN ('sync','backfill','check')),
  status         text NOT NULL CHECK (status IN ('running','success','partial','failed','skipped_locked')),
  http_requests  integer NOT NULL DEFAULT 0,
  http_errors    integer NOT NULL DEFAULT 0,
  rows_inserted  integer NOT NULL DEFAULT 0,
  rows_updated   integer NOT NULL DEFAULT 0,
  rows_unchanged integer NOT NULL DEFAULT 0,
  companies_ok     text[] NOT NULL DEFAULT '{}',
  companies_failed text[] NOT NULL DEFAULT '{}',
  error_summary  text,
  git_sha        text
);

CREATE TABLE raw_payload (
  sha256      text PRIMARY KEY,
  url         text NOT NULL,
  first_fetched_at timestamptz NOT NULL,
  last_fetched_at  timestamptz NOT NULL,
  run_id      uuid REFERENCES run(run_id),
  http_status integer NOT NULL,
  body_gzip   bytea NOT NULL
);
CREATE INDEX raw_payload_url ON raw_payload(url, last_fetched_at DESC);

CREATE TABLE filing (
  accession_number        text PRIMARY KEY,               -- '0000320193-25-000079'
  cik                     bigint NOT NULL,                -- CIK it was first seen under
  company_id              text NOT NULL REFERENCES company(company_id),
  form                    text NOT NULL,
  form_family             text NOT NULL CHECK (form_family IN (
                            'annual','annual_amendment','quarterly','quarterly_amendment',
                            'transition_annual','transition_quarterly',
                            'foreign_current_report','late_notice','non_reliance_8k')),
  filing_date             date NOT NULL,
  acceptance_datetime     timestamptz,
  period_of_report        date,
  fiscal_year             integer,
  fiscal_period           text CHECK (fiscal_period IN ('FY','Q1','Q2','Q3','Q4','H1','H2','OTHER')),
  label_source            text NOT NULL DEFAULT 'none'
                          CHECK (label_source IN ('filing_dei','convention','rule','manual','none')),
  label_confidence        text CHECK (label_confidence IN ('high','medium','low')),
  dei_filer_category      text,
  dei_amendment_flag      boolean,
  dei_amendment_description text,
  dei_error_correction_flag boolean,
  dei_current_reporting_status text,
  dei_non_dei_fact_count  integer,
  cover_tags_fetched      boolean NOT NULL DEFAULT false,
  amends_accession        text REFERENCES filing(accession_number),
  amendment_scope         text CHECK (amendment_scope IN ('full','partial','unknown')),
  amendment_kind          text CHECK (amendment_kind IN ('restatement','accounting_change','administrative','unknown')),
  kind_evidence           text,
  is_canonical            boolean NOT NULL DEFAULT false,
  is_xbrl                 boolean NOT NULL DEFAULT false,
  is_inline_xbrl          boolean NOT NULL DEFAULT false,
  primary_document        text,
  primary_doc_description text,
  size_bytes              bigint,
  items                   text[] NOT NULL DEFAULT '{}',
  file_number             text,
  film_number             text,
  pre_merger_shell        boolean NOT NULL DEFAULT false,
  first_seen_run_id       uuid REFERENCES run(run_id),
  last_seen_run_id        uuid REFERENCES run(run_id),
  last_seen_at            timestamptz,
  is_stale                boolean NOT NULL DEFAULT false,
  CHECK (label_source <> 'none' OR fiscal_year IS NULL)
);
CREATE INDEX filing_company_family ON filing(company_id, form_family, fiscal_year, fiscal_period);
CREATE INDEX filing_cik ON filing(cik);

CREATE TABLE filing_cik_alias (
  accession_number text NOT NULL REFERENCES filing(accession_number),
  cik              bigint NOT NULL,
  PRIMARY KEY (accession_number, cik)
);

-- Raw row counts per history page, for the coverage check (plan C5).
CREATE TABLE history_page (
  cik              bigint NOT NULL,
  page_name        text NOT NULL,
  filing_count     integer NOT NULL,     -- as stated by the SEC in filings.files
  rows_in_payload  integer,              -- rows parsed from the stored raw copy, all forms
  filing_from      date,
  filing_to        date,
  payload_sha256   text REFERENCES raw_payload(sha256),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (cik, page_name)
);

CREATE TABLE report_period (
  company_id             text NOT NULL REFERENCES company(company_id),
  report_kind            text NOT NULL CHECK (report_kind IN ('annual','quarterly')),
  fiscal_year            integer NOT NULL,
  fiscal_period          text NOT NULL,          -- 'FY' for annual
  canonical_accession    text REFERENCES filing(accession_number),
  latest_filed_accession text REFERENCES filing(accession_number),
  original_accession     text REFERENCES filing(accession_number),
  version_count          integer NOT NULL,
  PRIMARY KEY (company_id, report_kind, fiscal_year, fiscal_period)
);

CREATE TABLE correction_event (
  event_id               bigserial PRIMARY KEY,
  company_id             text NOT NULL REFERENCES company(company_id),
  event_type             text NOT NULL CHECK (event_type IN ('non_reliance_8k','cover_error_flag')),
  source_accession       text NOT NULL REFERENCES filing(accession_number),
  event_date             date NOT NULL,
  corrected_in_accessions text[] NOT NULL DEFAULT '{}',
  link_confidence        text NOT NULL CHECK (link_confidence IN ('high','medium','low','none')),
  pre_merger_shell       boolean NOT NULL DEFAULT false,
  UNIQUE (event_type, source_accession)
);

CREATE TABLE expected_filing (
  company_id              text NOT NULL REFERENCES company(company_id),
  report_kind             text NOT NULL CHECK (report_kind IN ('annual','quarterly')),
  fiscal_year             integer NOT NULL,
  fiscal_period           text NOT NULL,
  period_end_estimate     date NOT NULL,
  filer_category_used     text,
  category_source         text CHECK (category_source IN ('cover','previous_cover','current','none')),
  due_date                date NOT NULL,
  due_date_with_extension date NOT NULL,
  status                  text NOT NULL CHECK (status IN ('received','received_late','nt_filed','due_soon','overdue','pending','not_applicable')),
  matched_accession       text REFERENCES filing(accession_number),
  nt_accession            text REFERENCES filing(accession_number),
  PRIMARY KEY (company_id, report_kind, fiscal_year, fiscal_period)
);

CREATE TABLE daily_index_reconciliation (
  index_date     date PRIMARY KEY,
  status         text NOT NULL CHECK (status IN ('ok','missing_filings','not_published')),
  entries_for_us integer NOT NULL DEFAULT 0,
  missing        text[] NOT NULL DEFAULT '{}',    -- accession numbers listed by the SEC but absent here
  run_id         uuid REFERENCES run(run_id),
  checked_at     timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE check_result (
  run_id      uuid NOT NULL REFERENCES run(run_id),
  check_id    text NOT NULL,                       -- 'C1'..'C12' or 'X..' for extended
  check_name  text NOT NULL,
  tier        text NOT NULL CHECK (tier IN ('core','extended')),
  status      text NOT NULL CHECK (status IN ('green','amber','red')),
  message     text NOT NULL,
  observed    text,
  expected    text,
  company_id  text,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX check_result_run ON check_result(run_id);

-- Unique canonical row per report period, enforced at the filing level too.
CREATE UNIQUE INDEX one_canonical_per_period ON filing(company_id,
  (CASE WHEN form_family IN ('annual','annual_amendment') THEN 'annual' ELSE 'quarterly' END),
  fiscal_year, fiscal_period)
  WHERE is_canonical;
