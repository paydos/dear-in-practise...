-- 004_original_report_and_float_source.sql (round 2 review: T-11, T-12)

-- The category chain can end in the previous annual report's public float estimate.
ALTER TABLE expected_filing DROP CONSTRAINT IF EXISTS expected_filing_category_source_check;
ALTER TABLE expected_filing ADD CONSTRAINT expected_filing_category_source_check
  CHECK (category_source IN
         ('cover','public_float','previous_cover','previous_public_float','current','none'));

-- The run that flagged a row stale (D-07), so the X1 check can list rows newly flagged.
ALTER TABLE filing ADD COLUMN stale_run_id uuid;

-- The report views say which filing was first filed, and judge lateness on that one. A row whose
-- deadline used today's filer category (category_source = 'current') is never claimed as late.
DROP VIEW IF EXISTS v_annual_reports;
DROP VIEW IF EXISTS v_quarterly_reports;

CREATE VIEW v_annual_reports AS
SELECT
  rp.company_id,
  rp.fiscal_year,
  f.form,
  rp.canonical_accession                       AS accession,
  f.filing_date,
  f.period_of_report,
  COALESCE(e.period_end_estimate, f.period_of_report) AS period_end,
  f.label_source,
  f.label_confidence,
  f.cover_source,
  rp.version_count > 1                         AS was_amended,
  (SELECT array_agg(DISTINCT v.amendment_kind ORDER BY v.amendment_kind)
     FROM filing v
    WHERE v.company_id = rp.company_id
      AND v.form_family IN ('annual', 'annual_amendment')
      AND v.fiscal_year = rp.fiscal_year
      AND v.fiscal_period = rp.fiscal_period
      AND v.amendment_kind IS NOT NULL)        AS amendment_kinds,
  f.amendment_scope                            AS canonical_amendment_scope,
  f.amendment_kind                             AS canonical_amendment_kind,
  rp.version_count,
  rp.original_accession,
  o.filing_date                                AS original_filing_date,
  rp.latest_filed_accession,
  f.pre_merger_shell,
  e.due_date,
  e.due_date_with_extension,
  e.status,
  (e.status = 'received_late'
    AND e.category_source IS DISTINCT FROM 'current') AS filed_late,
  e.nt_accession IS NOT NULL                   AS nt_filed,
  COALESCE(o.filing_date, m.filing_date) - e.period_end_estimate AS days_after_period_end,
  e.filer_category_used,
  e.category_source
FROM report_period rp
LEFT JOIN filing f ON f.accession_number = rp.canonical_accession
LEFT JOIN expected_filing e
       ON e.company_id = rp.company_id AND e.report_kind = rp.report_kind
      AND e.fiscal_year = rp.fiscal_year AND e.fiscal_period = rp.fiscal_period
LEFT JOIN filing m ON m.accession_number = e.matched_accession
LEFT JOIN filing o ON o.accession_number = rp.original_accession
WHERE rp.report_kind = 'annual';

CREATE VIEW v_quarterly_reports AS
SELECT
  rp.company_id,
  rp.fiscal_year,
  rp.fiscal_period,
  f.form,
  rp.canonical_accession                       AS accession,
  f.filing_date,
  f.period_of_report,
  COALESCE(e.period_end_estimate, f.period_of_report) AS period_end,
  f.label_source,
  f.label_confidence,
  f.cover_source,
  rp.version_count > 1                         AS was_amended,
  (SELECT array_agg(DISTINCT v.amendment_kind ORDER BY v.amendment_kind)
     FROM filing v
    WHERE v.company_id = rp.company_id
      AND v.form_family IN ('quarterly', 'quarterly_amendment')
      AND v.fiscal_year = rp.fiscal_year
      AND v.fiscal_period = rp.fiscal_period
      AND v.amendment_kind IS NOT NULL)        AS amendment_kinds,
  f.amendment_scope                            AS canonical_amendment_scope,
  f.amendment_kind                             AS canonical_amendment_kind,
  rp.version_count,
  rp.original_accession,
  o.filing_date                                AS original_filing_date,
  rp.latest_filed_accession,
  f.pre_merger_shell,
  e.due_date,
  e.due_date_with_extension,
  e.status,
  (e.status = 'received_late'
    AND e.category_source IS DISTINCT FROM 'current') AS filed_late,
  e.nt_accession IS NOT NULL                   AS nt_filed,
  COALESCE(o.filing_date, m.filing_date) - e.period_end_estimate AS days_after_period_end,
  e.filer_category_used,
  e.category_source
FROM report_period rp
LEFT JOIN filing f ON f.accession_number = rp.canonical_accession
LEFT JOIN expected_filing e
       ON e.company_id = rp.company_id AND e.report_kind = rp.report_kind
      AND e.fiscal_year = rp.fiscal_year AND e.fiscal_period = rp.fiscal_period
LEFT JOIN filing m ON m.accession_number = e.matched_accession
LEFT JOIN filing o ON o.accession_number = rp.original_accession
WHERE rp.report_kind = 'quarterly';

COMMENT ON VIEW v_annual_reports IS
  'One row per company and fiscal year. original_accession and original_filing_date name the '
  'first-filed report; days_after_period_end and filed_late judge that original, not the '
  'canonical amendment. filed_late is not claimed when the deadline used today''s filer category.';
COMMENT ON VIEW v_quarterly_reports IS
  'Same as v_annual_reports for quarters Q1 to Q3.';
