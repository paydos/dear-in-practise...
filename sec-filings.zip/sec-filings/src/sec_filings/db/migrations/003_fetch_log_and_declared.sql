-- 003_fetch_log_and_declared.sql (contract amendment 3, section 12.1 and 12.4)

-- raw_payload is content-addressed: identical bodies from different URLs (every empty 404)
-- share one row. raw_fetch records every fetch, so "latest payload for this URL" still works.
CREATE TABLE raw_fetch (
  url         text NOT NULL,
  sha256      text NOT NULL REFERENCES raw_payload(sha256),
  fetched_at  timestamptz NOT NULL,
  run_id      uuid REFERENCES run(run_id),
  http_status integer NOT NULL
);
CREATE INDEX raw_fetch_url ON raw_fetch(url, fetched_at DESC);

-- Existing payloads carry one URL and one fetch time each: keep them reachable.
INSERT INTO raw_fetch (url, sha256, fetched_at, run_id, http_status)
SELECT url, sha256, last_fetched_at, run_id, http_status FROM raw_payload;

-- The label the filing itself declared (cover page or concept file), before the company's
-- naming convention is applied. Kept so a disagreement with fiscal_year stays visible (C8).
ALTER TABLE filing ADD COLUMN declared_fiscal_year integer;
ALTER TABLE filing ADD COLUMN declared_fiscal_period text;
