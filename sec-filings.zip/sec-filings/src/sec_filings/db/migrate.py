"""Apply SQL migrations in name order, recording versions in schema_migrations."""

from __future__ import annotations

from importlib import resources

import psycopg

# Arbitrary constant key for pg_advisory_xact_lock; serialises concurrent migrators.
_LOCK_KEY = 0x5EC_F111


def _migration_files() -> list[tuple[str, str]]:
    root = resources.files("sec_filings.db") / "migrations"
    items = [(p.name, p) for p in root.iterdir() if p.name.endswith(".sql")]
    items.sort(key=lambda t: t[0])
    return [(name.removesuffix(".sql"), p.read_text(encoding="utf-8")) for name, p in items]


def apply_migrations(conn: psycopg.Connection) -> list[str]:
    """Apply pending migrations; return the versions newly applied."""
    applied_now: list[str] = []
    with conn.transaction():
        conn.execute("SELECT pg_advisory_xact_lock(%s)", (_LOCK_KEY,))
        conn.execute(
            "CREATE TABLE IF NOT EXISTS schema_migrations ("
            "version text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())"
        )
        done = {r[0] for r in conn.execute("SELECT version FROM schema_migrations").fetchall()}
        for version, sql in _migration_files():
            if version in done:
                continue
            conn.execute(sql)
            conn.execute("INSERT INTO schema_migrations (version) VALUES (%s)", (version,))
            applied_now.append(version)
    return applied_now
