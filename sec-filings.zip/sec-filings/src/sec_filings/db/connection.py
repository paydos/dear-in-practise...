"""Postgres connection helper."""

from __future__ import annotations

import psycopg


def connect(database_url: str) -> psycopg.Connection:
    """Open a connection with autocommit off; callers commit explicitly."""
    return psycopg.connect(database_url, autocommit=False, connect_timeout=10)
