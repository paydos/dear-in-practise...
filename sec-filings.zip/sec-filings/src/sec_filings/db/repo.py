"""Reads and writes against Postgres (docs/contracts.md section 10).

Plain functions taking a psycopg Connection. Callers own transactions: nothing here commits.
"""

from __future__ import annotations

import gzip
from collections.abc import Sequence
from dataclasses import dataclass, fields
from datetime import date, datetime
from typing import Any
from uuid import UUID, uuid4

import psycopg
from psycopg.rows import dict_row

from sec_filings.domain.corrections import CorrectionEventDraft
from sec_filings.domain.expected import ExpectedFiling
from sec_filings.models import (
    CanonicalChoice,
    CheckResult,
    FetchedResponse,
    FormerName,
    PageRef,
    RunResult,
)

DEFAULT_LOCK_KEY = 7_302_026


@dataclass(frozen=True)
class FilingRecord:
    """One filing row as written by the sync. Excludes the run-tracking columns
    (first_seen_run_id, last_seen_run_id, last_seen_at, is_stale), which upsert_filings owns."""

    accession_number: str
    cik: int
    company_id: str
    form: str
    form_family: str
    filing_date: date
    acceptance_datetime: datetime | None = None
    period_of_report: date | None = None
    fiscal_year: int | None = None
    fiscal_period: str | None = None
    declared_fiscal_year: int | None = None  # raw cover/concept label, before the convention rule
    declared_fiscal_period: str | None = None
    label_source: str = "none"
    label_confidence: str | None = None
    dei_filer_category: str | None = None
    dei_amendment_flag: bool | None = None
    dei_amendment_description: str | None = None
    dei_error_correction_flag: bool | None = None
    dei_current_reporting_status: str | None = None
    dei_non_dei_fact_count: int | None = None
    cover_tags_fetched: bool = False
    amends_accession: str | None = None
    amendment_scope: str | None = None
    amendment_kind: str | None = None
    kind_evidence: str | None = None
    is_canonical: bool = False
    is_xbrl: bool = False
    is_inline_xbrl: bool = False
    primary_document: str | None = None
    primary_doc_description: str | None = None
    size_bytes: int | None = None
    items: tuple[str, ...] = ()
    file_number: str | None = None
    film_number: str | None = None
    pre_merger_shell: bool = False


_ALL_COLS = [f.name for f in fields(FilingRecord)]
# is_canonical is owned by write_canonical: upsert sets it on insert only, never on update,
# and it is not part of the "did this row change" comparison.
_COMPARE_COLS = [c for c in _ALL_COLS if c not in ("accession_number", "is_canonical")]


def _record_values(rec: FilingRecord) -> dict[str, Any]:
    d = {c: getattr(rec, c) for c in _ALL_COLS}
    d["items"] = list(rec.items)
    return d


def _norm(col: str, value: Any) -> Any:
    if col == "items":
        return tuple(value or ())
    return value


# --------------------------------------------------------------------------- companies


def upsert_company(
    conn: psycopg.Connection,
    *,
    company_id: str,
    name: str | None,
    is_foreign_private_issuer: bool,
    fiscal_year_end_mmdd: str | None,
    filer_category_current: str | None,
    fy_naming_convention: str = "unknown",
    pre_merger_until: date | None = None,
    reviewed: bool = False,
    notes: str | None = None,
) -> None:
    conn.execute(
        """
        INSERT INTO company (company_id, name, is_foreign_private_issuer, fiscal_year_end_mmdd,
                             filer_category_current, fy_naming_convention, pre_merger_until,
                             reviewed, notes, updated_at)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, now())
        ON CONFLICT (company_id) DO UPDATE SET
          name = EXCLUDED.name,
          is_foreign_private_issuer = EXCLUDED.is_foreign_private_issuer,
          fiscal_year_end_mmdd = EXCLUDED.fiscal_year_end_mmdd,
          filer_category_current = EXCLUDED.filer_category_current,
          fy_naming_convention = EXCLUDED.fy_naming_convention,
          pre_merger_until = EXCLUDED.pre_merger_until,
          reviewed = EXCLUDED.reviewed,
          notes = EXCLUDED.notes,
          updated_at = now()
        """,
        (
            company_id,
            name,
            is_foreign_private_issuer,
            fiscal_year_end_mmdd,
            filer_category_current,
            fy_naming_convention,
            pre_merger_until,
            reviewed,
            notes,
        ),
    )


def upsert_company_cik(
    conn: psycopg.Connection,
    *,
    company_id: str,
    cik: int,
    valid_from: date | None,
    valid_to: date | None,
    source: str,
    note: str | None = None,
) -> None:
    """cik is globally unique, so a cik already owned by another company raises."""
    conn.execute(
        """
        INSERT INTO company_cik (company_id, cik, valid_from, valid_to, source, note)
        VALUES (%s, %s, %s, %s, %s, %s)
        ON CONFLICT (company_id, cik) DO UPDATE SET
          valid_from = EXCLUDED.valid_from, valid_to = EXCLUDED.valid_to,
          source = EXCLUDED.source, note = EXCLUDED.note
        """,
        (company_id, cik, valid_from, valid_to, source, note),
    )


def replace_name_history(
    conn: psycopg.Connection, cik: int, former_names: Sequence[FormerName]
) -> None:
    conn.execute("DELETE FROM company_name_history WHERE cik = %s", (cik,))
    seen: set[str] = set()
    for fn in former_names:
        if fn.name in seen:
            continue
        seen.add(fn.name)
        conn.execute(
            "INSERT INTO company_name_history (cik, name, valid_from, valid_to) "
            "VALUES (%s, %s, %s, %s)",
            (cik, fn.name, fn.valid_from, fn.valid_to),
        )


def known_ciks(conn: psycopg.Connection) -> dict[int, str]:
    return {int(c): str(co) for c, co in conn.execute("SELECT cik, company_id FROM company_cik")}


# --------------------------------------------------------------------------- runs and locks


def start_run(
    conn: psycopg.Connection, mode: str, git_sha: str | None = None, scope: str = "all"
) -> UUID:
    """scope 'all' = every company in companies.csv; 'subset' = limited to some tickers."""
    run_id = uuid4()
    conn.execute(
        "INSERT INTO run (run_id, started_at, mode, status, git_sha, scope) "
        "VALUES (%s, clock_timestamp(), %s, 'running', %s, %s)",
        (run_id, mode, git_sha, scope),
    )
    return run_id


def finish_run(conn: psycopg.Connection, result: RunResult, *, sec_denied: bool = False) -> None:
    conn.execute(
        """
        UPDATE run SET finished_at = COALESCE(%s, clock_timestamp()), status = %s,
          http_requests = %s,
          rows_inserted = %s, rows_updated = %s, rows_unchanged = %s,
          companies_ok = %s, companies_failed = %s, error_summary = %s,
          sec_denied = %s
        WHERE run_id = %s
        """,
        (
            result.finished_at,
            result.status,
            result.http_requests,
            result.rows_inserted,
            result.rows_updated,
            result.rows_unchanged,
            list(result.companies_ok),
            list(result.companies_failed),
            result.error_summary,
            sec_denied,
            result.run_id,
        ),
    )


def acknowledge(conn: psycopg.Connection, check_id: str, item_key: str, reason: str) -> None:
    """Record (or replace) a person's acknowledgement of one item of a check. The reason is
    required. Callers own the transaction."""
    if not reason or not reason.strip():
        raise ValueError("an acknowledgement needs a reason")
    conn.execute(
        """
        INSERT INTO check_acknowledgement (check_id, item_key, reason, acknowledged_at)
        VALUES (%s, %s, %s, now())
        ON CONFLICT (check_id, item_key) DO UPDATE
          SET reason = EXCLUDED.reason, acknowledged_at = now()
        """,
        (check_id, item_key, reason.strip()),
    )


def acknowledgements(conn: psycopg.Connection, check_id: str) -> dict[str, str]:
    """{item_key: reason} for one check."""
    return {
        r[0]: r[1]
        for r in conn.execute(
            "SELECT item_key, reason FROM check_acknowledgement WHERE check_id = %s", (check_id,)
        ).fetchall()
    }


def last_run(
    conn: psycopg.Connection, *, status: str | None = None, mode: str | None = None
) -> dict | None:
    clauses, params = [], []
    if status is not None:
        clauses.append("status = %s")
        params.append(status)
    if mode is not None:
        clauses.append("mode = %s")
        params.append(mode)
    where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
    with conn.cursor(row_factory=dict_row) as cur:
        cur.execute(f"SELECT * FROM run {where} ORDER BY started_at DESC LIMIT 1", params)
        return cur.fetchone()


def try_advisory_lock(conn: psycopg.Connection, key: int = DEFAULT_LOCK_KEY) -> bool:
    row = conn.execute("SELECT pg_try_advisory_lock(%s)", (key,)).fetchone()
    return bool(row[0])


def release_advisory_lock(conn: psycopg.Connection, key: int = DEFAULT_LOCK_KEY) -> None:
    conn.execute("SELECT pg_advisory_unlock(%s)", (key,))


# --------------------------------------------------------------------------- raw payloads


def store_raw_payload(conn: psycopg.Connection, resp: FetchedResponse, run_id: UUID) -> str:
    """Store the gzipped body keyed by sha256 (on a repeat only last_fetched_at moves) and log
    the fetch of this URL in raw_fetch, so identical bodies from different URLs keep their URL."""
    conn.execute(
        """
        INSERT INTO raw_payload (sha256, url, first_fetched_at, last_fetched_at, run_id,
                                 http_status, body_gzip)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        ON CONFLICT (sha256) DO UPDATE SET last_fetched_at = EXCLUDED.last_fetched_at
        """,
        (
            resp.sha256,
            resp.url,
            resp.fetched_at,
            resp.fetched_at,
            run_id,
            resp.status,
            gzip.compress(resp.body),
        ),
    )
    conn.execute(
        "INSERT INTO raw_fetch (url, sha256, fetched_at, run_id, http_status) "
        "VALUES (%s, %s, %s, %s, %s)",
        (resp.url, resp.sha256, resp.fetched_at, run_id, resp.status),
    )
    return resp.sha256


def latest_raw_payload(conn: psycopg.Connection, url: str) -> bytes | None:
    """Body of the latest fetch of this URL, or None when it was never fetched or the latest
    fetch was a 404 (a stored 404 means "not there", not a payload)."""
    row = conn.execute(
        "SELECT f.http_status, p.body_gzip FROM raw_fetch f "
        "JOIN raw_payload p ON p.sha256 = f.sha256 "
        "WHERE f.url = %s ORDER BY f.fetched_at DESC LIMIT 1",
        (url,),
    ).fetchone()
    if row is None or row[0] == 404:
        return None
    return gzip.decompress(bytes(row[1]))


# --------------------------------------------------------------------------- filings


def _order_for_fk(records: Sequence[FilingRecord]) -> list[FilingRecord]:
    """Insert targets of amends_accession before the amendments that point at them."""
    in_batch = {r.accession_number for r in records}
    pending = list(records)
    done: set[str] = set()
    ordered: list[FilingRecord] = []
    while pending:
        progressed = False
        rest: list[FilingRecord] = []
        for r in pending:
            dep = r.amends_accession
            if dep is None or dep not in in_batch or dep in done or dep == r.accession_number:
                ordered.append(r)
                done.add(r.accession_number)
                progressed = True
            else:
                rest.append(r)
        if not progressed:  # cycle: let the database decide
            ordered.extend(rest)
            break
        pending = rest
    return ordered


def upsert_filings(
    conn: psycopg.Connection, records: Sequence[FilingRecord], run_id: UUID
) -> tuple[int, int, int]:
    """Returns (inserted, updated, unchanged). Never deletes. Every row touched gets
    last_seen_run_id, last_seen_at and is_stale = false; first_seen_run_id only on insert.
    is_canonical is written on insert only (write_canonical owns it afterwards)."""
    if not records:
        return (0, 0, 0)
    # Last record wins when the batch repeats an accession.
    unique = {r.accession_number: r for r in records}
    records = _order_for_fk(list(unique.values()))

    cols = ", ".join(_COMPARE_COLS)
    with conn.cursor(row_factory=dict_row) as cur:
        cur.execute(
            f"SELECT accession_number, {cols} FROM filing WHERE accession_number = ANY(%s)",
            ([r.accession_number for r in records],),
        )
        existing = {row["accession_number"]: row for row in cur.fetchall()}

    inserted = updated = unchanged = 0
    insert_cols = _ALL_COLS + ["first_seen_run_id", "last_seen_run_id", "last_seen_at", "is_stale"]
    insert_sql = (
        f"INSERT INTO filing ({', '.join(insert_cols)}) VALUES ("
        + ", ".join(f"%({c})s" for c in _ALL_COLS)
        + ", %(run_id)s, %(run_id)s, now(), false)"
    )
    update_sql = (
        "UPDATE filing SET "
        + ", ".join(f"{c} = %({c})s" for c in _COMPARE_COLS)
        + ", last_seen_run_id = %(run_id)s, last_seen_at = now(), is_stale = false, "
        "stale_run_id = NULL "
        "WHERE accession_number = %(accession_number)s"
    )
    touch_sql = (
        "UPDATE filing SET last_seen_run_id = %s, last_seen_at = now(), is_stale = false, "
        "stale_run_id = NULL WHERE accession_number = %s"
    )
    for rec in records:
        vals = _record_values(rec)
        old = existing.get(rec.accession_number)
        if old is None:
            conn.execute(insert_sql, {**vals, "run_id": run_id})
            inserted += 1
        elif any(_norm(c, old[c]) != _norm(c, getattr(rec, c)) for c in _COMPARE_COLS):
            conn.execute(update_sql, {**vals, "run_id": run_id})
            updated += 1
        else:
            conn.execute(touch_sql, (run_id, rec.accession_number))
            unchanged += 1
    return (inserted, updated, unchanged)


def add_cik_alias(conn: psycopg.Connection, accession_number: str, cik: int) -> None:
    conn.execute(
        "INSERT INTO filing_cik_alias (accession_number, cik) VALUES (%s, %s) "
        "ON CONFLICT DO NOTHING",
        (accession_number, cik),
    )


def record_history_page(
    conn: psycopg.Connection,
    *,
    cik: int,
    page: PageRef,
    rows_in_payload: int | None,
    payload_sha256: str | None,
) -> None:
    conn.execute(
        """
        INSERT INTO history_page (cik, page_name, filing_count, rows_in_payload, filing_from,
                                  filing_to, payload_sha256, updated_at)
        VALUES (%s, %s, %s, %s, %s, %s, %s, now())
        ON CONFLICT (cik, page_name) DO UPDATE SET
          filing_count = EXCLUDED.filing_count, rows_in_payload = EXCLUDED.rows_in_payload,
          filing_from = EXCLUDED.filing_from, filing_to = EXCLUDED.filing_to,
          payload_sha256 = EXCLUDED.payload_sha256, updated_at = now()
        """,
        (
            cik,
            page.name,
            page.filing_count,
            rows_in_payload,
            page.filing_from,
            page.filing_to,
            payload_sha256,
        ),
    )


def mark_stale(
    conn: psycopg.Connection,
    *,
    cik: int,
    seen_accessions: set[str],
    run_id: UUID | None = None,
) -> int:
    """Flag rows of this cik missing from a full fetch. Returns the number newly flagged
    (rows already stale are not counted). Only call after a complete fetch of the cik."""
    cur = conn.execute(
        "UPDATE filing SET is_stale = true, stale_run_id = %s "
        "WHERE cik = %s AND NOT is_stale AND NOT (accession_number = ANY(%s))",
        (run_id, cik, list(seen_accessions)),
    )
    return cur.rowcount


def mark_accessions_stale(
    conn: psycopg.Connection, accessions: Sequence[str], run_id: UUID | None = None
) -> list[str]:
    """Flag these filings stale (D-07: never delete). Returns the accessions newly flagged."""
    rows = conn.execute(
        "UPDATE filing SET is_stale = true, stale_run_id = %s "
        "WHERE accession_number = ANY(%s) AND NOT is_stale RETURNING accession_number",
        (run_id, list(accessions)),
    ).fetchall()
    return sorted(r[0] for r in rows)


# --------------------------------------------------------------------------- derived tables


def write_canonical(
    conn: psycopg.Connection,
    company_id: str,
    choices: Sequence[tuple[str, int, str, CanonicalChoice]],
) -> None:
    """Replace the company's canonical flags and report_period rows."""
    conn.execute(
        "UPDATE filing SET is_canonical = false WHERE company_id = %s AND is_canonical",
        (company_id,),
    )
    conn.execute("DELETE FROM report_period WHERE company_id = %s", (company_id,))
    for report_kind, fiscal_year, fiscal_period, ch in choices:
        if ch.canonical_accession is not None:
            conn.execute(
                "UPDATE filing SET is_canonical = true WHERE accession_number = %s",
                (ch.canonical_accession,),
            )
        conn.execute(
            """
            INSERT INTO report_period (company_id, report_kind, fiscal_year, fiscal_period,
                                       canonical_accession, latest_filed_accession,
                                       original_accession, version_count)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                company_id,
                report_kind,
                fiscal_year,
                fiscal_period,
                ch.canonical_accession,
                ch.latest_filed_accession,
                ch.original_accession,
                ch.version_count,
            ),
        )


def replace_expected(
    conn: psycopg.Connection, company_id: str, rows: Sequence[ExpectedFiling]
) -> None:
    conn.execute("DELETE FROM expected_filing WHERE company_id = %s", (company_id,))
    for r in rows:
        conn.execute(
            """
            INSERT INTO expected_filing (company_id, report_kind, fiscal_year, fiscal_period,
              period_end_estimate, filer_category_used, category_source, due_date,
              due_date_with_extension, status, matched_accession, nt_accession)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                company_id,
                r.report_kind,
                r.fiscal_year,
                r.fiscal_period,
                r.period_end_estimate,
                r.filer_category_used,
                r.category_source,
                r.due_date,
                r.due_date_with_extension,
                r.status,
                r.matched_accession,
                r.nt_accession,
            ),
        )


def replace_correction_events(
    conn: psycopg.Connection, company_id: str, events: Sequence[CorrectionEventDraft]
) -> None:
    conn.execute("DELETE FROM correction_event WHERE company_id = %s", (company_id,))
    for e in events:
        conn.execute(
            """
            INSERT INTO correction_event (company_id, event_type, source_accession, event_date,
              corrected_in_accessions, link_confidence, pre_merger_shell)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (event_type, source_accession) DO UPDATE SET
              company_id = EXCLUDED.company_id, event_date = EXCLUDED.event_date,
              corrected_in_accessions = EXCLUDED.corrected_in_accessions,
              link_confidence = EXCLUDED.link_confidence,
              pre_merger_shell = EXCLUDED.pre_merger_shell
            """,
            (
                company_id,
                e.event_type,
                e.source_accession,
                e.event_date,
                list(e.corrected_in_accessions),
                e.link_confidence,
                e.pre_merger_shell,
            ),
        )


# --------------------------------------------------------------------------- reconciliation


def record_reconciliation(
    conn: psycopg.Connection,
    *,
    index_date: date,
    status: str,
    entries_for_us: int,
    missing: Sequence[str],
    run_id: UUID,
) -> None:
    conn.execute(
        """
        INSERT INTO daily_index_reconciliation (index_date, status, entries_for_us, missing,
                                                run_id, checked_at)
        VALUES (%s, %s, %s, %s, %s, now())
        ON CONFLICT (index_date) DO UPDATE SET
          status = EXCLUDED.status, entries_for_us = EXCLUDED.entries_for_us,
          missing = EXCLUDED.missing, run_id = EXCLUDED.run_id, checked_at = now()
        """,
        (index_date, status, entries_for_us, list(missing), run_id),
    )


def last_reconciled_date(conn: psycopg.Connection) -> date | None:
    row = conn.execute(
        "SELECT max(index_date) FROM daily_index_reconciliation "
        "WHERE status IN ('ok', 'missing_filings')"
    ).fetchone()
    return row[0]


def write_check_results(
    conn: psycopg.Connection, run_id: UUID, results: Sequence[CheckResult]
) -> None:
    for r in results:
        conn.execute(
            """
            INSERT INTO check_result (run_id, check_id, check_name, tier, status, message,
                                      observed, expected, company_id, created_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, clock_timestamp())
            """,
            (
                run_id,
                r.check_id,
                r.check_name,
                r.tier,
                r.status,
                r.message,
                r.observed,
                r.expected,
                r.company_id,
            ),
        )


def company_filings(conn: psycopg.Connection, company_id: str) -> list[dict]:
    with conn.cursor(row_factory=dict_row) as cur:
        cur.execute(
            "SELECT * FROM filing WHERE company_id = %s ORDER BY filing_date, accession_number",
            (company_id,),
        )
        return cur.fetchall()
