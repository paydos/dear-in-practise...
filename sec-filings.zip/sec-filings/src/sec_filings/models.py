"""Shared dataclasses (docs/contracts.md section 4). Frozen contract."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from typing import Literal
from uuid import UUID

FormFamily = Literal[
    "annual",
    "annual_amendment",
    "quarterly",
    "quarterly_amendment",
    "transition_annual",
    "transition_quarterly",
    "foreign_current_report",
    "late_notice",
    "non_reliance_8k",
]
ReportKind = Literal["annual", "quarterly"]
FiscalPeriod = Literal["FY", "Q1", "Q2", "Q3", "Q4", "H1", "H2", "OTHER"]
LabelSource = Literal["filing_dei", "convention", "rule", "manual", "none"]
Confidence = Literal["high", "medium", "low"]
Convention = Literal["ends_in", "starts_in", "unknown"]
FilerCategory = Literal["large_accelerated", "accelerated", "non_accelerated"]
CheckStatus = Literal["green", "amber", "red"]


@dataclass(frozen=True, slots=True)
class FormerName:
    name: str
    valid_from: date | None
    valid_to: date | None


@dataclass(frozen=True, slots=True)
class PageRef:
    name: str
    filing_count: int
    filing_from: date | None
    filing_to: date | None


@dataclass(frozen=True, slots=True)
class CompanyMeta:
    cik: int
    name: str
    tickers: tuple[str, ...]
    fiscal_year_end_mmdd: str | None
    filer_category: str | None
    former_names: tuple[FormerName, ...]


@dataclass(frozen=True, slots=True)
class RawFiling:
    """One row of the submissions arrays; every form, not only periodic ones."""

    accession_number: str
    cik: int
    form: str
    filing_date: date
    acceptance_datetime: datetime | None
    period_of_report: date | None
    items: tuple[str, ...]
    primary_document: str | None
    primary_doc_description: str | None
    is_xbrl: bool
    is_inline_xbrl: bool
    size_bytes: int | None
    file_number: str | None
    film_number: str | None


@dataclass(frozen=True, slots=True)
class SubmissionsDoc:
    meta: CompanyMeta
    filings: tuple[RawFiling, ...]
    pages: tuple[PageRef, ...]


@dataclass(frozen=True, slots=True)
class CoverTags:
    fiscal_year: int | None
    fiscal_period: str | None
    document_type: str | None
    period_end_date: date | None
    filer_category: str | None
    amendment_flag: bool | None
    amendment_description: str | None
    error_correction_flag: bool | None
    current_reporting_status: str | None
    non_dei_fact_count: int


@dataclass(frozen=True, slots=True)
class IndexEntry:
    form: str
    company_name: str
    cik: int
    date_filed: date
    accession_number: str


@dataclass(frozen=True, slots=True)
class Label:
    fiscal_year: int | None
    fiscal_period: FiscalPeriod | None
    source: LabelSource
    confidence: Confidence | None


@dataclass(frozen=True, slots=True)
class FetchedResponse:
    url: str
    status: int
    body: bytes
    sha256: str
    fetched_at: datetime
    from_fixture: bool


@dataclass(frozen=True, slots=True)
class Version:
    accession_number: str
    filing_date: date
    acceptance_datetime: datetime | None
    is_amendment: bool
    amendment_scope: str | None  # None for originals


@dataclass(frozen=True, slots=True)
class CanonicalChoice:
    canonical_accession: str | None
    latest_filed_accession: str
    original_accession: str | None
    version_count: int


@dataclass(frozen=True, slots=True)
class ScopeSignals:
    has_financial_facts: bool | None
    in_financial_data_sets: bool | None
    size_ratio: float | None
    description_says_full: bool | None
    partial_only_text: bool | None = None  # descriptions name only exhibits, Part III, etc.
    primary_doc_bytes: int | None = None  # size of the amendment's primary document


@dataclass(frozen=True, slots=True)
class DueDates:
    due: date
    due_with_extension: date
    basis: str


@dataclass(frozen=True, slots=True)
class CheckResult:
    check_id: str
    check_name: str
    tier: Literal["core", "extended"]
    status: CheckStatus
    message: str
    observed: str | None = None
    expected: str | None = None
    company_id: str | None = None


@dataclass
class RunResult:
    run_id: UUID
    mode: str
    status: str
    started_at: datetime
    finished_at: datetime | None
    http_requests: int
    rows_inserted: int
    rows_updated: int
    rows_unchanged: int
    companies_ok: list[str]
    companies_failed: list[str]
    error_summary: str | None


@dataclass
class CheckReport:
    run_id: UUID
    results: list[CheckResult]
    exit_code: int
    markdown: str
