"""SEC ticker file parsing."""

from __future__ import annotations

import json

from sec_filings.errors import ParseError

TICKERS_URL = "https://www.sec.gov/files/company_tickers.json"


def parse_company_tickers(body: bytes) -> dict[str, tuple[int, str]]:
    """Parse company_tickers.json into {'AAPL': (320193, 'Apple Inc.')}.

    A ticker listed twice keeps its first entry (the file is ordered by market cap)."""
    try:
        data = json.loads(body)
        rows = data.values() if isinstance(data, dict) else data
        out: dict[str, tuple[int, str]] = {}
        for row in rows:
            ticker = str(row["ticker"]).strip()
            if ticker and ticker not in out:
                out[ticker] = (int(row["cik_str"]), str(row.get("title", "")))
        return out
    except (ValueError, KeyError, TypeError, AttributeError) as exc:
        raise ParseError(f"cannot parse company_tickers.json: {exc}") from exc
