"""Submissions JSON URL builders and parsers."""

from __future__ import annotations

import json
from datetime import UTC, date, datetime
from typing import Any

from sec_filings.errors import ParseError
from sec_filings.models import (
    CompanyMeta,
    FormerName,
    PageRef,
    RawFiling,
    SubmissionsDoc,
)

_BASE = "https://data.sec.gov/submissions"


def submissions_url(cik: int) -> str:
    """https://data.sec.gov/submissions/CIK0000320193.json"""
    return f"{_BASE}/CIK{int(cik):010d}.json"


def history_page_url(name: str) -> str:
    """https://data.sec.gov/submissions/<name>"""
    return f"{_BASE}/{name}"


def _none_if_empty(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, str) and value.strip() == "":
        return None
    return value


def _date(value: Any) -> date | None:
    value = _none_if_empty(value)
    if value is None:
        return None
    return date.fromisoformat(str(value)[:10])


def _datetime_utc(value: Any) -> datetime | None:
    value = _none_if_empty(value)
    if value is None:
        return None
    dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt.astimezone(UTC)


def _int(value: Any) -> int | None:
    value = _none_if_empty(value)
    return None if value is None else int(value)


def _str(value: Any) -> str | None:
    value = _none_if_empty(value)
    return None if value is None else str(value)


def _items(value: Any) -> tuple[str, ...]:
    value = _none_if_empty(value)
    if value is None:
        return ()
    return tuple(p.strip() for p in str(value).split(",") if p.strip())


def _rows(arrays: dict[str, Any], cik: int) -> tuple[RawFiling, ...]:
    """Turn the columnar arrays into rows; every array must be as long as accessionNumber."""
    accessions = arrays.get("accessionNumber")
    if accessions is None:
        raise ParseError("submissions arrays have no accessionNumber")
    n = len(accessions)
    cols: dict[str, list[Any]] = {}
    for key in (
        "filingDate",
        "reportDate",
        "acceptanceDateTime",
        "form",
        "items",
        "size",
        "isXBRL",
        "isInlineXBRL",
        "primaryDocument",
        "primaryDocDescription",
        "fileNumber",
        "filmNumber",
    ):
        col = arrays.get(key)
        if col is None:
            col = [None] * n
        if len(col) != n:
            raise ParseError(f"column {key} has {len(col)} values, expected {n}")
        cols[key] = col
    rows = []
    for i in range(n):
        filing_date = _date(cols["filingDate"][i])
        form = _str(cols["form"][i])
        if filing_date is None or form is None:
            raise ParseError(f"row {i} ({accessions[i]}) lacks form or filingDate")
        rows.append(
            RawFiling(
                accession_number=str(accessions[i]),
                cik=cik,
                form=form,
                filing_date=filing_date,
                acceptance_datetime=_datetime_utc(cols["acceptanceDateTime"][i]),
                period_of_report=_date(cols["reportDate"][i]),
                items=_items(cols["items"][i]),
                primary_document=_str(cols["primaryDocument"][i]),
                primary_doc_description=_str(cols["primaryDocDescription"][i]),
                is_xbrl=bool(_int(cols["isXBRL"][i]) or 0),
                is_inline_xbrl=bool(_int(cols["isInlineXBRL"][i]) or 0),
                size_bytes=_int(cols["size"][i]),
                file_number=_str(cols["fileNumber"][i]),
                film_number=_str(cols["filmNumber"][i]),
            )
        )
    return tuple(rows)


def _load(body: bytes) -> dict[str, Any]:
    try:
        data = json.loads(body)
    except ValueError as exc:
        raise ParseError(f"submissions payload is not JSON: {exc}") from exc
    if not isinstance(data, dict):
        raise ParseError("submissions payload is not a JSON object")
    return data


def parse_submissions(body: bytes) -> SubmissionsDoc:
    """Parse the columnar arrays. Empty strings become None; 'items' is split on ','.
    acceptanceDateTime like '2026-11-03T18:01:36.000Z' is parsed as UTC-aware."""
    data = _load(body)
    try:
        cik = int(data["cik"])
        filings = data["filings"]
        meta = CompanyMeta(
            cik=cik,
            name=str(data.get("name") or ""),
            tickers=tuple(str(t) for t in (data.get("tickers") or ())),
            fiscal_year_end_mmdd=_str(data.get("fiscalYearEnd")),
            filer_category=_str(data.get("category")),
            former_names=tuple(
                FormerName(
                    name=str(fn["name"]),
                    valid_from=_date(fn.get("from")),
                    valid_to=_date(fn.get("to")),
                )
                for fn in (data.get("formerNames") or ())
            ),
        )
        pages = tuple(
            PageRef(
                name=str(p["name"]),
                filing_count=int(p["filingCount"]),
                filing_from=_date(p.get("filingFrom")),
                filing_to=_date(p.get("filingTo")),
            )
            for p in (filings.get("files") or ())
        )
        rows = _rows(filings["recent"], cik)
    except (KeyError, TypeError, ValueError) as exc:
        raise ParseError(f"cannot parse submissions JSON: {exc!r}") from exc
    return SubmissionsDoc(meta=meta, filings=rows, pages=pages)


def parse_history_page(body: bytes, cik: int) -> tuple[RawFiling, ...]:
    """Parse a history page (same columnar layout) into RawFiling rows for `cik`."""
    data = _load(body)
    try:
        return _rows(data, cik)
    except (KeyError, TypeError, ValueError) as exc:
        raise ParseError(f"cannot parse history page: {exc!r}") from exc
