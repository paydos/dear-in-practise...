"""Map a URL to its recorded fixture path (docs/contracts.md section 7)."""

from __future__ import annotations

from pathlib import PurePosixPath
from urllib.parse import urlsplit


def url_to_fixture_path(url: str) -> PurePosixPath:
    """'https://data.sec.gov/submissions/CIK0000320193.json' ->
    'data.sec.gov/submissions/CIK0000320193.json'. Host, then path; no query strings."""
    parts = urlsplit(url)
    host = parts.netloc
    path = parts.path.lstrip("/")
    return PurePosixPath(host) / PurePosixPath(path)
