"""HTTP client for EDGAR: rate limited, budgeted, retrying; serves recorded fixtures offline."""

from __future__ import annotations

import gzip
import hashlib
import logging
import random
import time
from collections.abc import Callable
from datetime import UTC, datetime
from email.utils import parsedate_to_datetime
from pathlib import Path

import httpx

from sec_filings.edgar.fixtures import url_to_fixture_path
from sec_filings.errors import EdgarHTTPError, RequestBudgetExceeded, SecAccessDenied
from sec_filings.models import FetchedResponse

BACKOFF_BASE_SECONDS = 0.5
BACKOFF_CAP_SECONDS = 30.0
RETRY_AFTER_CAP_SECONDS = 60.0
PROGRESS_EVERY_SECONDS = 15.0

log = logging.getLogger(__name__)


def _parse_retry_after(value: str) -> float | None:
    """Seconds to wait from a Retry-After header: delta-seconds or an HTTP date. None when
    unreadable. Never negative; the caller caps it."""
    try:
        return max(0.0, float(value))
    except ValueError:
        pass
    try:
        when = parsedate_to_datetime(value)
    except (TypeError, ValueError, IndexError):
        return None
    if when.tzinfo is None:
        when = when.replace(tzinfo=UTC)
    return max(0.0, (when - datetime.now(UTC)).total_seconds())


class EdgarClient:
    """Rate-limited, budgeted EDGAR client; also serves recorded fixtures offline."""

    requests_made: int  # counts network requests and fixture reads alike

    def __init__(
        self,
        user_agent: str,
        *,
        requests_per_second: float = 4.0,
        request_budget: int = 200,
        fixtures_dir: Path | None = None,
        max_retries: int = 3,
        timeout: float = 30.0,
        on_response: Callable[[FetchedResponse], None] | None = None,
        sleep: Callable[[float], None] = time.sleep,
        clock: Callable[[], float] = time.monotonic,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        if requests_per_second <= 0:
            raise ValueError("requests_per_second must be positive")
        self.user_agent = user_agent
        self.requests_made = 0
        self._rate = float(requests_per_second)
        self._budget = request_budget
        self._fixtures_dir = Path(fixtures_dir) if fixtures_dir is not None else None
        self._max_retries = max_retries
        self._on_response = on_response
        self._sleep = sleep
        self._clock = clock
        # Token bucket: capacity of one token keeps requests evenly spaced.
        self._capacity = 1.0
        self._tokens = 1.0
        self._last_refill: float | None = None
        self._last_note = time.monotonic()  # wall clock for progress lines, never the test clock
        self._http: httpx.Client | None = None
        if self._fixtures_dir is None:
            self._http = httpx.Client(
                headers={"User-Agent": user_agent, "Accept-Encoding": "gzip, deflate"},
                timeout=timeout,
                transport=transport,
                follow_redirects=True,
            )
            # Send exactly the two headers the fair-access policy asks for.
            for name in ("accept", "connection"):
                if name in self._http.headers:
                    del self._http.headers[name]

    # ------------------------------------------------------------------ public

    def get(self, url: str) -> FetchedResponse:
        """GET a URL. Headers: User-Agent, Accept-Encoding 'gzip, deflate'. Token bucket
        shared by all calls. 200 -> response. 404 -> response with status 404.
        403 -> SecAccessDenied immediately. 429, 5xx, connect/read errors -> retries with
        exponential backoff + jitter, then EdgarHTTPError. Budget exceeded ->
        RequestBudgetExceeded before sending. on_response is called for every 200 and 404."""
        if self._fixtures_dir is not None:
            return self._get_fixture(url)
        return self._get_network(url)

    def close(self) -> None:
        """Release resources. The client is also a context manager."""
        if self._http is not None:
            self._http.close()

    def __enter__(self) -> EdgarClient:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    # ---------------------------------------------------------------- internals

    def _spend_budget(self, url: str) -> None:
        if self.requests_made >= self._budget:
            raise RequestBudgetExceeded(
                f"request budget of {self._budget} exhausted before fetching {url}"
            )
        self.requests_made += 1

    def _acquire_token(self) -> None:
        """Block until a token is available. Shared by every call on this client."""
        now = self._clock()
        if self._last_refill is not None:
            elapsed = max(0.0, now - self._last_refill)
            self._tokens = min(self._capacity, self._tokens + elapsed * self._rate)
        self._last_refill = now
        if self._tokens < 1.0:
            wait = (1.0 - self._tokens) / self._rate
            self._sleep(wait)
            self._last_refill = self._clock()
            self._tokens = 1.0
        self._tokens -= 1.0

    def _finish(self, resp: FetchedResponse) -> FetchedResponse:
        if self._on_response is not None and resp.status in (200, 404):
            self._on_response(resp)
        # A large filer can take minutes: say it is still moving, at most every 15 seconds.
        now = time.monotonic()
        if now - self._last_note >= PROGRESS_EVERY_SECONDS:
            self._last_note = now
            log.info("  still fetching: %d requests so far, last %s", self.requests_made, resp.url)
        return resp

    @staticmethod
    def _make_response(url: str, status: int, body: bytes, from_fixture: bool) -> FetchedResponse:
        return FetchedResponse(
            url=url,
            status=status,
            body=body,
            sha256=hashlib.sha256(body).hexdigest(),
            fetched_at=datetime.now(UTC),
            from_fixture=from_fixture,
        )

    def _get_fixture(self, url: str) -> FetchedResponse:
        self._spend_budget(url)
        assert self._fixtures_dir is not None
        path = self._fixtures_dir / url_to_fixture_path(url)
        gz_path = path.with_name(path.name + ".gz")
        if path.is_file():
            resp = self._make_response(url, 200, path.read_bytes(), True)
        elif gz_path.is_file():
            resp = self._make_response(url, 200, gzip.decompress(gz_path.read_bytes()), True)
        else:
            resp = self._make_response(url, 404, b"", True)
        return self._finish(resp)

    def _backoff(self, attempt: int, retry_after: float | None) -> float:
        delay = min(BACKOFF_CAP_SECONDS, BACKOFF_BASE_SECONDS * (2**attempt))
        delay += random.uniform(0, delay / 2)
        if retry_after is not None:
            delay = max(delay, min(retry_after, RETRY_AFTER_CAP_SECONDS))
        return delay

    def _get_network(self, url: str) -> FetchedResponse:
        assert self._http is not None
        last_problem = "no attempt made"
        for attempt in range(self._max_retries + 1):
            self._spend_budget(url)  # checked before sending, retries included
            self._acquire_token()
            retry_after: float | None = None
            try:
                r = self._http.get(url)
            except httpx.TransportError as exc:
                last_problem = f"{type(exc).__name__}: {exc}"
            else:
                status = r.status_code
                if status == 403:
                    raise SecAccessDenied(f"HTTP 403 from {url}; stopping")
                if status == 404:
                    return self._finish(self._make_response(url, 404, r.content, False))
                if 200 <= status < 300:
                    return self._finish(self._make_response(url, status, r.content, False))
                if status == 429 or status >= 500:
                    last_problem = f"HTTP {status}"
                    ra = r.headers.get("Retry-After")
                    if ra is not None:
                        retry_after = _parse_retry_after(ra)
                else:
                    raise EdgarHTTPError(f"HTTP {status} from {url}")
            if attempt < self._max_retries:
                wait = self._backoff(attempt, retry_after)
                log.warning("%s from %s; retrying in %.1fs", last_problem, url, wait)
                self._sleep(wait)
        raise EdgarHTTPError(f"{last_problem} from {url} after {self._max_retries + 1} attempts")
