"""EDGAR access layer."""
