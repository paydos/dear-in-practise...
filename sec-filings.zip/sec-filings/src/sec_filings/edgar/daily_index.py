"""Daily and full index URL builders and parsers."""

from __future__ import annotations

import re
from datetime import date

from sec_filings.errors import ParseError
from sec_filings.models import IndexEntry

_ARCHIVES = "https://www.sec.gov/Archives/edgar"
_ACCESSION = re.compile(r"(\d{10}-\d{2}-\d{6})\.txt\s*$")
# Right-anchored tail of a form.idx row: CIK, YYYYMMDD, file name.
_FORM_TAIL = re.compile(r"\s(\d+)\s+(\d{8})\s+(\S+)\s*$")


def _quarter(d: date) -> int:
    return (d.month - 1) // 3 + 1


def daily_index_url(d: date) -> str:
    """.../daily-index/2026/QTR4/form.20261102.idx"""
    return f"{_ARCHIVES}/daily-index/{d.year}/QTR{_quarter(d)}/form.{d:%Y%m%d}.idx"


def full_index_url(year: int, quarter: int) -> str:
    """.../full-index/2026/QTR4/master.idx"""
    if quarter not in (1, 2, 3, 4):
        raise ValueError(f"quarter must be 1..4, got {quarter}")
    return f"{_ARCHIVES}/full-index/{year}/QTR{quarter}/master.idx"


def _decode(body: bytes) -> list[str]:
    try:
        text = body.decode("utf-8")
    except UnicodeDecodeError:
        text = body.decode("latin-1")
    return text.splitlines()


def _data_lines(lines: list[str]) -> list[tuple[int, str]]:
    """Lines after the dashed separator that closes the header."""
    for i, line in enumerate(lines):
        if len(line) >= 20 and set(line.strip()) == {"-"}:
            return [(n + 1, ln) for n, ln in enumerate(lines[i + 1 :], start=i + 1) if ln.strip()]
    raise ParseError("index file has no dashed header separator")


def _accession(filename: str, lineno: int) -> str:
    m = _ACCESSION.search(filename)
    if not m:
        raise ParseError(f"line {lineno}: no accession number in file name {filename!r}")
    return m.group(1)


def parse_form_index(body: bytes) -> tuple[IndexEntry, ...]:
    """Parse a fixed-width form.*.idx file. Rows whose date differs from the file date
    are kept (the SEC puts older filing dates in daily files)."""
    out = []
    for lineno, line in _data_lines(_decode(body)):
        m = _FORM_TAIL.search(line)
        if not m:
            raise ParseError(f"line {lineno}: cannot parse form index row {line!r}")
        left = line[: m.start()].strip()
        parts = re.split(r"\s{2,}", left, maxsplit=1)
        form = parts[0].strip()
        name = parts[1].strip() if len(parts) > 1 else ""
        if not form:
            raise ParseError(f"line {lineno}: empty form type")
        try:
            filed = date(int(m.group(2)[:4]), int(m.group(2)[4:6]), int(m.group(2)[6:]))
        except ValueError as exc:
            raise ParseError(f"line {lineno}: bad date {m.group(2)!r}") from exc
        out.append(
            IndexEntry(
                form=form,
                company_name=name,
                cik=int(m.group(1)),
                date_filed=filed,
                accession_number=_accession(m.group(3), lineno),
            )
        )
    return tuple(out)


def parse_master_index(body: bytes) -> tuple[IndexEntry, ...]:
    """Parse a pipe-delimited master.idx. The accession number comes from the file name,
    e.g. 'edgar/data/2115436/0002115436-26-000020.txt'."""
    out = []
    for lineno, line in _data_lines(_decode(body)):
        parts = line.split("|")
        if len(parts) < 5:
            raise ParseError(f"line {lineno}: expected 5 pipe-delimited fields: {line!r}")
        # A company name may itself contain '|', so take the last three fields from the right.
        cik, name = parts[0], "|".join(parts[1:-3])
        form, filed, filename = parts[-3], parts[-2], parts[-1]
        try:
            entry = IndexEntry(
                form=form.strip(),
                company_name=name.strip(),
                cik=int(cik),
                date_filed=date.fromisoformat(filed.strip()),
                accession_number=_accession(filename.strip(), lineno),
            )
        except ValueError as exc:
            raise ParseError(f"line {lineno}: {exc}") from exc
        out.append(entry)
    return tuple(out)
