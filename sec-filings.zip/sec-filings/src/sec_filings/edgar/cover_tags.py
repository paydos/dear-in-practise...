"""XBRL cover-page (dei) facts: instance parsing, rendered R1.htm parsing, filing index."""

from __future__ import annotations

import json
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from datetime import date
from html.parser import HTMLParser
from io import BytesIO

from sec_filings.errors import ParseError
from sec_filings.models import CoverTags

_ARCHIVES = "https://www.sec.gov/Archives/edgar/data"
# SEC-era namespaces are http://xbrl.sec.gov/dei/<year>; the first 2009 instances (EDGAR Online)
# used http://xbrl.us/dei/<date>. Not dei-ent, dei-std (different prefixes).
DEI_NS_PREFIXES = ("http://xbrl.sec.gov/dei/", "http://xbrl.us/dei/")


def _folder(cik: int, accession_number: str) -> str:
    return f"{_ARCHIVES}/{int(cik)}/{accession_number.replace('-', '')}"


def filing_index_url(cik: int, accession_number: str) -> str:
    """URL of the filing's index.json."""
    return f"{_folder(cik, accession_number)}/index.json"


def instance_url(cik: int, accession_number: str, filename: str) -> str:
    """URL of an instance document inside a filing folder."""
    return f"{_folder(cik, accession_number)}/{filename}"


def cover_page_url(cik: int, accession_number: str) -> str:
    """URL of the rendered cover page (report R1) of the filing."""
    return f"{_folder(cik, accession_number)}/R1.htm"


# --------------------------------------------------------------------- filing index


@dataclass(frozen=True)
class FilingIndex:
    files: tuple[tuple[str, int | None], ...]  # (name, size in bytes or None)
    report_file_count: int  # rendered reports: R<n>.htm or R<n>.xml


_REPORT_FILE = re.compile(r"R\d+\.(htm|xml)", re.IGNORECASE)


def parse_filing_index(body: bytes) -> FilingIndex:
    try:
        items = json.loads(body)["directory"]["item"]
        files = []
        for item in items:
            size = item.get("size")
            files.append((str(item["name"]), int(size) if str(size or "").strip() else None))
    except (ValueError, KeyError, TypeError, AttributeError) as exc:
        raise ParseError(f"cannot parse filing index.json: {exc!r}") from exc
    count = sum(1 for name, _ in files if _REPORT_FILE.fullmatch(name))
    return FilingIndex(files=tuple(files), report_file_count=count)


_NOT_INSTANCE = re.compile(
    r"(R\d+\.xml|defnref\.xml|FilingSummary\.xml|.+_(cal|def|lab|pre)\.xml)", re.IGNORECASE
)


def pick_instance(index_body: bytes) -> str | None:
    """Spike B1. (1) Inline XBRL: the '*_htm.xml' file. (2) Older XBRL: the '.xml' whose stem
    equals the stem of the single '.xsd'. Never R<n>.xml, defnref.xml, FilingSummary.xml or
    the _cal/_def/_lab/_pre linkbases. None if there is no XBRL instance."""
    names = [name for name, _ in parse_filing_index(index_body).files]
    candidates = [n for n in names if n.lower().endswith(".xml") and not _NOT_INSTANCE.fullmatch(n)]
    inline = sorted(n for n in candidates if n.lower().endswith("_htm.xml"))
    if inline:
        return inline[0]
    xsd_stems = {n[:-4].lower() for n in names if n.lower().endswith(".xsd")}
    matches = sorted(n for n in candidates if n[:-4].lower() in xsd_stems)
    return matches[0] if len(matches) == 1 else None


# ----------------------------------------------------------------- instance document


def _local(tag: str) -> tuple[str, str]:
    if tag.startswith("{"):
        ns, _, local = tag[1:].partition("}")
        return ns, local
    return "", tag


def _bool(text: str | None) -> bool | None:
    if text is None:
        return None
    t = text.strip().lower()
    if t == "true":
        return True
    if t == "false":
        return False
    return None


def _iso_date(text: str | None) -> date | None:
    if not text or not text.strip():
        return None
    try:
        return date.fromisoformat(text.strip()[:10])
    except ValueError:
        return None


def parse_cover_tags(xml_body: bytes) -> CoverTags:
    """Match any dei namespace starting with 'http://xbrl.sec.gov/dei/' (or the 2009-era
    'http://xbrl.us/dei/', see contract note). Booleans
    'true'/'false'. Integer DocumentFiscalYearFocus. non_dei_fact_count: elements carrying
    a contextRef attribute whose namespace is not dei."""
    dei: dict[str, str] = {}
    non_dei = 0
    try:
        for _event, el in ET.iterparse(BytesIO(xml_body), events=("end",)):
            ns, local = _local(el.tag)
            if ns.startswith(DEI_NS_PREFIXES):
                if local not in dei:
                    dei[local] = (el.text or "").strip()
            elif "contextRef" in el.attrib:
                non_dei += 1
            if "contextRef" in el.attrib:
                el.clear()  # facts can be huge in number; keep memory flat
    except ET.ParseError as exc:
        raise ParseError(f"instance document is not well-formed XML: {exc}") from exc

    fy_text = dei.get("DocumentFiscalYearFocus")
    try:
        fiscal_year = int(fy_text) if fy_text else None
    except ValueError:
        fiscal_year = None
    return CoverTags(
        fiscal_year=fiscal_year,
        fiscal_period=dei.get("DocumentFiscalPeriodFocus") or None,
        document_type=dei.get("DocumentType") or None,
        period_end_date=_iso_date(dei.get("DocumentPeriodEndDate")),
        filer_category=dei.get("EntityFilerCategory") or None,
        amendment_flag=_bool(dei.get("AmendmentFlag")),
        amendment_description=dei.get("AmendmentDescription") or None,
        error_correction_flag=_bool(dei.get("DocumentFinStmtErrorCorrectionFlag")),
        current_reporting_status=dei.get("EntityCurrentReportingStatus") or None,
        non_dei_fact_count=non_dei,
    )


# ------------------------------------------------------------------- rendered cover


class _RowCollector(HTMLParser):
    """Collects table rows as lists of cell texts."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.rows: list[list[str]] = []
        self._row: list[str] | None = None
        self._cell: list[str] | None = None
        self._hidden = 0  # depth inside <script>/<style>

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in ("script", "style"):
            self._hidden += 1
        elif tag == "tr":
            self._row = []
        elif tag in ("td", "th") and self._row is not None:
            self._cell = []

    def handle_endtag(self, tag: str) -> None:
        if tag in ("script", "style"):
            self._hidden = max(0, self._hidden - 1)
        elif tag in ("td", "th") and self._row is not None and self._cell is not None:
            self._row.append(_clean(" ".join(self._cell)))
            self._cell = None
        elif tag == "tr" and self._row is not None:
            self.rows.append(self._row)
            self._row = None

    def handle_data(self, data: str) -> None:
        if self._cell is not None and not self._hidden:
            self._cell.append(data)


def _clean(text: str) -> str:
    return re.sub(r"\s+", " ", text.replace("\xa0", " ")).strip()


_MONTHS = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1
)}  # fmt: skip
_RENDERED_DATE = re.compile(r"([A-Za-z]{3})[A-Za-z]*\.?\s+(\d{1,2})\s*,\s*(\d{4})")


def _rendered_date(text: str) -> date | None:
    m = _RENDERED_DATE.search(text)
    if m and m.group(1).lower() in _MONTHS:
        try:
            return date(int(m.group(3)), _MONTHS[m.group(1).lower()], int(m.group(2)))
        except ValueError:
            return None
    return _iso_date(text)


def _normalise_label(label: str) -> str:
    label = re.sub(r"\[[^\]]*\]", "", label)  # 'Amendment Flag [true,false]' -> 'Amendment Flag'
    return _clean(label).lower()


_ERROR_CORRECTION = "document financial statement error correction"


def _rendered_bool(text: str) -> bool | None:
    t = text.strip().lower()
    return {"true": True, "false": False}.get(t)


def parse_cover_page(html: bytes) -> CoverTags:
    """Read the rendered cover table by row label (case-insensitive, bracketed suffixes
    ignored). The first non-empty value column of a row is used. non_dei_fact_count is -1:
    this source cannot know it."""
    collector = _RowCollector()
    collector.feed(html.decode("utf-8", errors="replace"))
    values: dict[str, str] = {}
    for row in collector.rows:
        if len(row) < 2:
            continue
        label = _normalise_label(row[0])
        value = next((c for c in row[1:] if c), "")
        if label.startswith(_ERROR_CORRECTION):  # "... Error Correction Flag" or "... [Flag]"
            label = _ERROR_CORRECTION
        if label and value and label not in values:
            values[label] = value
    known = (
        "document fiscal year focus", "document fiscal period focus", "document type",
        "document period end date", "entity filer category", "amendment flag",
        "amendment description", _ERROR_CORRECTION, "entity current reporting status",
    )  # fmt: skip
    if not any(k in values for k in known):
        raise ParseError("no cover page rows found in R1.htm")

    fy_text = values.get("document fiscal year focus")
    try:
        fiscal_year = int(fy_text) if fy_text else None
    except ValueError:
        fiscal_year = None
    period_end = values.get("document period end date")
    err = values.get(_ERROR_CORRECTION)
    amend = values.get("amendment flag")
    return CoverTags(
        fiscal_year=fiscal_year,
        fiscal_period=values.get("document fiscal period focus"),
        document_type=values.get("document type"),
        period_end_date=_rendered_date(period_end) if period_end else None,
        filer_category=values.get("entity filer category"),
        amendment_flag=_rendered_bool(amend) if amend else None,
        amendment_description=values.get("amendment description"),
        error_correction_flag=_rendered_bool(err) if err else None,
        current_reporting_status=values.get("entity current reporting status"),
        non_dei_fact_count=-1,
    )
