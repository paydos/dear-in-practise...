"""Company-concept API (dei cover facts per accession)."""

from __future__ import annotations

import json
from collections import Counter
from dataclasses import dataclass
from datetime import date
from typing import Any

from sec_filings.errors import ParseError


def company_concept_url(cik: int, concept: str, taxonomy: str = "dei") -> str:
    """https://data.sec.gov/api/xbrl/companyconcept/CIK0000320193/dei/EntityPublicFloat.json"""
    return (
        f"https://data.sec.gov/api/xbrl/companyconcept/CIK{int(cik):010d}/{taxonomy}/{concept}.json"
    )


@dataclass(frozen=True)
class ConceptLabel:
    accession_number: str
    fiscal_year: int | None
    fiscal_period: str | None
    form: str
    filed: date
    consistent: bool  # False if the facts of one accession disagree on fiscal year or period


def _facts(body: bytes, only_usd: bool = False) -> list[dict[str, Any]]:
    try:
        data = json.loads(body)
        units = data["units"]
        facts: list[dict[str, Any]] = []
        for unit, rows in units.items():
            if only_usd and unit != "USD":
                continue
            facts.extend(rows)
        return facts
    except (ValueError, KeyError, TypeError, AttributeError) as exc:
        raise ParseError(f"cannot parse company concept JSON: {exc!r}") from exc


def _mode(values: list[Any]) -> Any:
    """Most common value; ties go to the one seen first."""
    counts = Counter(values)
    best = max(counts.values())
    return next(v for v in values if counts[v] == best)


def parse_concept_labels(body: bytes) -> dict[str, ConceptLabel]:
    """accession -> label, the mode of the (fy, fp) of its facts."""
    by_accn: dict[str, list[dict[str, Any]]] = {}
    for fact in _facts(body):
        try:
            by_accn.setdefault(str(fact["accn"]), []).append(fact)
        except KeyError as exc:
            raise ParseError("concept fact without accn") from exc
    out: dict[str, ConceptLabel] = {}
    for accn, facts in by_accn.items():
        pairs = [(f.get("fy"), f.get("fp")) for f in facts]
        fy, fp = _mode(pairs)
        try:
            filed = date.fromisoformat(str(_mode([f["filed"] for f in facts])))
        except (KeyError, ValueError) as exc:
            raise ParseError(f"concept fact for {accn} has no valid 'filed'") from exc
        out[accn] = ConceptLabel(
            accession_number=accn,
            fiscal_year=int(fy) if fy is not None else None,
            fiscal_period=str(fp) if fp else None,
            form=str(_mode([f.get("form") or "" for f in facts])),
            filed=filed,
            consistent=len(set(pairs)) == 1,
        )
    return out


def parse_public_float(body: bytes) -> dict[str, tuple[float, date]]:
    """accession -> (USD value, as-of date). USD units only. If one accession carries several
    facts, the one with the latest as-of date wins (ties: the last listed)."""
    best: dict[str, tuple[float, date]] = {}
    for fact in _facts(body, only_usd=True):
        try:
            accn = str(fact["accn"])
            as_of = date.fromisoformat(str(fact["end"]))
            value = float(fact["val"])
        except (KeyError, ValueError, TypeError) as exc:
            raise ParseError(f"bad public float fact: {fact!r}") from exc
        if accn not in best or as_of >= best[accn][1]:
            best[accn] = (value, as_of)
    return best
