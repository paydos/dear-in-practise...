# Review guide

A ten-minute tour. Start with [README.md](README.md) for the one command, and
[docs/how-it-was-built.md](docs/how-it-was-built.md) for how the agents were organised.

![How it was built: director, planning, orchestrator, builders, reviewers](docs/diagrams/agentic-development.svg)

## Where each deliverable is

| Deliverable | File | Look at first |
|---|---|---|
| 1. The job | [src/sec_filings/flows.py](src/sec_filings/flows.py), [README.md](README.md) | `sync` and `check`: plain functions, no Prefect. Then `show AAPL 2009` in the README. |
| 2. The morning check | [src/sec_filings/checks/core.py](src/sec_filings/checks/core.py), [reports/sample_red_report.md](reports/sample_red_report.md) | The sample red report, then C1 and C3 in `core.py`. |
| 3. The handover kit | [AGENTS.md](AGENTS.md), [DECISIONS.md](DECISIONS.md), [docs/runbooks/](docs/runbooks/) | The "Definition of done" section of AGENTS.md: the `verify` block an agent must paste. |
| 4. What I didn't trust | [docs/what-i-didnt-trust.md](docs/what-i-didnt-trust.md), [docs/trust-log.md](docs/trust-log.md) | The half page first; the trust log holds all 19 entries. T-6 and T-11 are the clearest. |
| 5. An analyst's question | [docs/analyst-answer.md](docs/analyst-answer.md), [docs/analyst-answer.sql](docs/analyst-answer.sql) | The "How sure I am" list. The SQL reproduces every figure. |
| Evidence the answers are right | [docs/reconciliation.md](docs/reconciliation.md) | Summary table: 0 mismatches against EDGAR's separate company browse. |
| My role | [docs/my-role.md](docs/my-role.md) | What I decided and asked for, as distinct from what the agents did. |
| Agent work log | [docs/agent-log.md](docs/agent-log.md) | Who did what, and what the orchestrator rejected. |
| Handover test on fresh agents | [docs/handover/results.md](docs/handover/results.md) | Trial S3 (diagnose a red check) passed; both add-company trials found a real defect, fixed as T-14. |
| Query server (MCP) | [src/sec_filings/mcp_server.py](src/sec_filings/mcp_server.py), [.mcp.json](.mcp.json) | Five read-only tools; ask an agent the analyst's question through it. |
| How it was built | [docs/how-it-was-built.md](docs/how-it-was-built.md), [docs/agent-usage.md](docs/agent-usage.md) | The diagram of who did what, then tokens per model. |

## If you run one command, run this

```
DATABASE_URL=postgresql://USER:PASSWORD@HOST:5432/DBNAME uv run sec-filings sync
```

Then `uv run sec-filings show AAPL 2009`. It takes about three minutes on an empty database
(507 requests, measured). Exit code 0 or 1 is a pass (4 means another run held the lock). Run it a second time: it should change no filing rows.

No database to hand? See "Getting a database" in [AGENTS.md](AGENTS.md). No network? Set
`SEC_FIXTURES_DIR=tests/fixtures/edgar` and use `uv run pytest -q -m "not live"` (628 tests; the database tests start an embedded Postgres).

## Brief traceability

| The brief says | Where it is met |
|---|---|
| Use AI agents as you normally would | [docs/agent-log.md](docs/agent-log.md): orchestrator, builders, reviewer, and the work I did not delegate |
| Every 10-K and 10-Q the 20 companies filed | Full history from 1994 ([D-05](DECISIONS.md)); amendments and old form variants kept; foreign filers' 20-F as annual ([D-01](DECISIONS.md)). Code: [src/sec_filings/domain/forms.py](src/sec_filings/domain/forms.py) |
| Record which fiscal year or quarter it covers | [src/sec_filings/domain/labels.py](src/sec_filings/domain/labels.py); label source and confidence on every row ([D-04](DECISIONS.md)) |
| "What do we have for Apple's 2009 annual report?" gets one answer | `show AAPL 2009` in [README.md](README.md); canonical rule [D-03](DECISIONS.md); check C7 and golden queries |
| The 20 tickers | [companies.csv](companies.csv) is the list of record; [companies.yml](companies.yml) holds reviewed details ([D-08](DECISIONS.md)) |
| Source is EDGAR, start at data.sec.gov/submissions | [src/sec_filings/edgar/submissions.py](src/sec_filings/edgar/submissions.py) |
| Follow the fair-access rules | "SEC fair access" in [README.md](README.md); [src/sec_filings/edgar/client.py](src/sec_filings/edgar/client.py) |
| Python with local Postgres, `DATABASE_URL` | [src/sec_filings/config.py](src/sec_filings/config.py); [docker-compose.yml](docker-compose.yml) |
| A README with the one command | [README.md](README.md), first block |
| Safe to run every morning | Upsert by accession number, advisory lock, run ledger ([src/sec_filings/flows.py](src/sec_filings/flows.py)), request budgets |
| Shaped for Prefect, not installed | "Scheduling with Prefect" in [README.md](README.md); [CI check](.github/workflows/ci.yml) fails if `prefect` appears |
| If tomorrow's 06:00 run is wrong, what tells us? | Checks C1 to C12 in [src/sec_filings/checks/core.py](src/sec_filings/checks/core.py); heartbeat; daily-index reconciliation; [sample red report](reports/sample_red_report.md); [D-16](DECISIONS.md) |
| Let an AI agent run, extend or fix the job | [AGENTS.md](AGENTS.md), [CLAUDE.md](CLAUDE.md), [docs/runbooks/](docs/runbooks/), [.claude/](.claude/) |
| For example, add five companies | [docs/runbooks/add-companies.md](docs/runbooks/add-companies.md); `sec-filings resolve-companies`; check C4 stays amber until reviewed |
| Tell the agent what decisions you made | [DECISIONS.md](DECISIONS.md), linked from AGENTS.md |
| And what it must check before it's done | `sec-filings verify` ([src/sec_filings/cli.py](src/sec_filings/cli.py)); [Stop hook](scripts/stop_hook.py) |
| We'll test it with a fresh agent | [docs/handover/results.md](docs/handover/results.md): three fresh-agent trials, scored |
| What you didn't trust: wrong, found how, checked against, decisions | [docs/what-i-didnt-trust.md](docs/what-i-didnt-trust.md), [docs/trust-log.md](docs/trust-log.md), [DECISIONS.md](DECISIONS.md) |
| Analyst's question: late or corrected annual reports, 10 years | [docs/analyst-answer.md](docs/analyst-answer.md); deadlines [src/sec_filings/domain/deadlines.py](src/sec_filings/domain/deadlines.py); correction events [src/sec_filings/domain/corrections.py](src/sec_filings/domain/corrections.py) |
| Say how sure you are, and what is missing | Confidence per claim and "What's missing" in [docs/analyst-answer.md](docs/analyst-answer.md) |
| Send agent session logs | Not shared; the written record is ([D-15](DECISIONS.md)): [docs/agent-log.md](docs/agent-log.md), [docs/how-it-was-built.md](docs/how-it-was-built.md) |
| Make the call yourself and write down why | [DECISIONS.md](DECISIONS.md), D-01 to D-24 |
| Link to a Git repository | This repository, with full history ([D-17](DECISIONS.md)) |
| A 60-minute call | The repository is laid out so any file can be opened live during the call |

## Known gaps

- The handover evaluation is three single trials, not a repeated matrix, and the two add-company trials
  were stopped before their final evidence block (see [docs/handover/results.md](docs/handover/results.md)).
- Amendments filed before 2009-06-15 are stored but not classified, because no rendered reports exist
  to judge them ([D-20](DECISIONS.md)).

## What I'd do next

1. A ground-truth restatement list, such as Audit Analytics, to measure how many quiet restatements the table misses.
2. Parse the text of each item 4.02 8-K, to name the periods affected.
3. Parse 6-K interim results for the five foreign filers, so a quarterly question gets a real answer.
4. Auditor-change 8-Ks (item 4.01) and material-weakness disclosures.
5. Predecessor CIK lineage beyond the hand-reviewed cases (Exxon, AT&T, Lucid).
6. Historical filer category before XBRL, so more old deadlines can be called late with confidence.
7. Repeat each handover trial several times per model and report pass rates.
