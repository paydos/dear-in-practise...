# AGENTS.md: SEC filings tracker

A Python job keeps a Postgres table of every 10-K and 10-Q (plus 20-F for foreign filers) that the
companies in `companies.csv` filed with SEC EDGAR, each labelled with its fiscal year or quarter.
`sec-filings check` writes a morning report that says whether today's run can be trusted.
Prefect is never installed: `flows.sync()` and `flows.check()` are plain functions a scheduler calls.

## The one command

`uv run sec-filings sync` (equivalent: `uv run python -m sec_filings sync`). Needs only `DATABASE_URL`.
Migrations apply themselves; an empty database is loaded as a backfill.

## Getting a database

- Any Postgres: `DATABASE_URL=postgresql://USER:PASSWORD@HOST:5432/sec_filings`.
- Docker: `docker compose up -d db`, then
  `DATABASE_URL=postgresql://sec:sec@localhost:5432/sec_filings`.
- Embedded, no install: set `PGSERVER_DATA` to a folder outside the repo, then
  bash `export DATABASE_URL=$(uv run python scripts/dev_db.py)` or PowerShell
  `$env:DATABASE_URL = (uv run python scripts/dev_db.py)`. It keeps running after the script exits.

Other env vars: `SEC_USER_AGENT` (a personal "Name contact" string, see the never list),
`SEC_FIXTURES_DIR=tests/fixtures/edgar` (serve recorded files, zero network),
`SEC_REQUESTS_PER_SECOND` (default 4, capped at 9), `HEARTBEAT_URL`, `TEST_DATABASE_URL` (tests).

## Non-negotiables (PLAN.md section 1)

1. Python, Postgres, connection from `DATABASE_URL` only.
2. Safe every morning: idempotent (upsert by accession number), re-runnable, overlap-safe
   (advisory lock), every run recorded in the `run` ledger.
3. Scheduler-shaped: `flows.sync()` returns a result; `flows.check()` raises `ChecksRed` on any red.
4. SEC fair access: declared User-Agent, gzip, at most 10 requests per second (we use 4),
   download only what is needed, stop on HTTP 403 (`docs/runbooks/sec-403.md`).
5. Every data decision is written down in `DECISIONS.md`.
6. Nothing is "done" without evidence: the `verify` block (next section).

## Definition of done

Run `uv run sec-filings verify` and paste its whole evidence block in your final message. It must end
`RESULT: OK` with zero red checks, golden queries all passing, unit tests passing. Amber is allowed
only if you explain each amber. "It ran without crashing" is not evidence. When you changed or
added a company, also paste `uv run sec-filings show TICKER YEAR` for one filing per new company.
A diagnosis-only task (for example "why is the check red?") still ends with the current `check` or
`verify` output, so the person can see what is still red after your work.

## Decisions

`DECISIONS.md` holds D-01 to D-24 (foreign filers, CIK history, canonical answer, fiscal labels, the
never-delete rule, lateness, amendment review, check exit codes and acknowledgements). Read it before touching data rules. `docs/trust-log.md` lists real
past mistakes and the data traps. **If a data decision is unclear, add a `DECISIONS.md` entry
describing the question and your proposed answer, and stop. Do not guess.**

## Map of the code (`src/sec_filings/`)

- `cli.py`: typer commands. `flows.py`: `sync`, `backfill`, `check`; the whole pipeline.
- `config.py`: env settings. `companies.py`: reads `companies.csv` + `companies.yml`.
- `models.py`, `errors.py`: dataclasses and exceptions (`ChecksRed`, `SecAccessDenied`).
- `edgar/`: `client.py` (rate-limited, budgeted, fixtures offline), `submissions.py`, `tickers.py`,
  `daily_index.py`, `cover_tags.py`, `xbrl_concepts.py`.
- `domain/`: pure rules, no I/O: `forms.py`, `labels.py`, `amendments.py`, `corrections.py`,
  `deadlines.py`, `expected.py`.
- `db/`: `connection.py`, `migrate.py`, `repo.py`, `migrations/*.sql` (tables, views, fetch log).
- `checks/`: `core.py` (C1 to C12), `report.py` (markdown, exit codes).
- `scripts/`: `dev_db.py`, `record_fixtures.py`, `sql.py`, `stop_hook.py`, `agent_usage.py`. Tests: `tests/unit`, `tests/integration`
  (marker `db`), `tests/golden` (hand-checked facts), `tests/fixtures` (recorded SEC files).

## Commands

| Command | Does |
|---|---|
| `sec-filings sync [--today YYYY-MM-DD]` | Daily incremental run, then the checks. |
| `sec-filings backfill [-t TICKER ...]` | Full history; only the named tickers if given. |
| `sec-filings check [--expect-run-by HH:MM]` | Morning checks on stored data. Exit 0 green, 1 amber, 2 red, 3 run failed, 4 skipped (another run held the lock). C1 deadline defaults to 06:30 London. |
| `sec-filings ack C3 YYYY-MM-DD --reason "..."` | Accept an explained C3 gap: that day turns amber and the report shows the reason (D-23). Only after you have explained it. |
| `sec-filings show TICKER YEAR [-q 1..3]` | The canonical filing for one period, plus other versions. |
| `sec-filings resolve-companies` | CIKs, foreign-filer and predecessor hints per ticker (reads the SEC). |
| `sec-filings verify [--if-db]` | The evidence block. Exit 1 if red. |
| `uv run pytest -q -m "not db and not live"` | Unit tests only: no database, no network. |
| `uv run pytest -q -m "not live"` | All tests; starts an embedded Postgres, or set `TEST_DATABASE_URL`. |
| `uv run python scripts/sql.py "SELECT ..."` | Run a query without `psql` (read-only unless `--write`). |
| `uv run ruff check src tests scripts` | Lint. |
| `uv run python scripts/record_fixtures.py --out tests/fixtures/edgar URL...` | Record SEC files. |
| `uv run --extra mcp sec-filings mcp` | Read-only query server for agents (optional). |

## Runbooks and skills

Two skills (Claude Code) in `.claude/skills/`, mirrored for any agent in `docs/runbooks/`:
`add-companies` and `investigate-red-check` (C1 to C12). Three more runbooks, in `docs/runbooks/` only:
`cik-changed`, `sec-403`, `backfill`.

## Never

- Never call the SEC from tests. Tests use `SEC_FIXTURES_DIR`; `live` tests are not run by agents.
- Never install Prefect (not `pip install`, not `uv add`); CI fails if it appears in dependencies.
- Never delete filing rows; upstream disappearances are flagged `is_stale` (D-07).
- Never follow a changed ticker-to-CIK mapping silently; C4 goes red and a person reviews (D-08).
- Never put an employer email in the User-Agent; use a personal contact (D-09).
- Never retry a 403 in a loop; never raise the request rate above the cap.
- Never edit `brief.md`. Never make a red check green by loosening the check or editing data.
- Never write absolute local paths or personal emails into committed files. The one exception is the
  default User-Agent contact in `config.py` (D-09): it is deliberate, so the one command works with only
  `DATABASE_URL` set. Do not remove or change it.
