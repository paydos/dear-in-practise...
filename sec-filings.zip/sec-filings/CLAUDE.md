@AGENTS.md

## Claude Code notes

- Skills live in `.claude/skills/` (`add-companies`, `investigate-red-check`); invoke them by name.
- `.claude/settings.json` registers a Stop hook (`scripts/stop_hook.py`). It runs the offline tests
  and `verify --if-db`, and blocks the stop only on a real red. It never traps you: no `uv`, no
  database, a timeout or a second stop attempt all let you finish.
- Settings also deny installing Prefect and editing `brief.md`.
- Subagent roles in `.claude/agents/`: `edgar-implementer` (builds one scoped section), `reviewer`
  (read-only, fresh context), `lookup` (cheap facts with sources). Use `reviewer` before you declare done
  on a data-rule change.
