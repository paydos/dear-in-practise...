---
name: investigate-red-check
description: Use when sec-filings check, sync or verify reports a red or amber check (C1 to C12) and you must diagnose it, fix the cause and show evidence. One section per check id.
---

# Runbook: investigate a red (or amber) check

Use when `sec-filings check`, `sync` or `verify` reports red or amber. Source of truth:
`src/sec_filings/checks/core.py`. Never edit data or loosen a check to make it green: diagnose, fix
the cause (config, code, or a documented decision), re-run, show the evidence.

## Start here

```
uv run sec-filings check   # exit 0 green, 1 amber, 2 red, 3 run failed, 4 skipped (lock held)
uv run python scripts/sql.py "SELECT check_id, status, message FROM check_result
  WHERE run_id = (SELECT run_id FROM check_result ORDER BY created_at DESC LIMIT 1)
  AND status <> 'green' ORDER BY check_id"
```

`scripts/sql.py` is read-only and needs no `psql`; any SQL below can be run the same way. The full
report is in `reports/morning_check_<date>.md`. Then go to the section for the check id.

## C1 Heartbeat
Meaning: it is past the deadline (`check --expect-run-by`, default 06:30 Europe/London) and no
whole-job sync or backfill (`scope = 'all'`, not a `-t TICKER` run) finished with status `success`
today, London date. A `partial` run does not count. Before the deadline C1 is green. First look:
`SELECT run_id, mode, scope, status, started_at, finished_at, error_summary FROM run ORDER BY
started_at DESC LIMIT 5;`. Causes: the scheduler did not fire, the run failed or was partial (see C2),
only a subset run happened, the run finished after the deadline, the clock or timezone is wrong.
Do not: insert a fake run row, or move the deadline.

## C2 Run status
Meaning: judges the latest whole-job (`scope = 'all'`) sync or backfill. Red if it failed or was
partial, if it is still `running` more than 2 hours after it started (the process died), if it
started more than 26 hours ago (the daily job has stopped), or if the SEC answered 403
(`run.sec_denied`). Amber if it was skipped because another run held the lock. A subset run that
failed is reported too, next to the whole-job verdict. First look: the `run` query under C1, plus
`SELECT companies_failed, error_summary, sec_denied FROM run ORDER BY started_at DESC LIMIT 1;`.
Causes: network error, request budget exceeded, SEC 403 (read `sec-403.md`), one company's data
unparseable, the host or scheduler is down. Do not: loop-retry on a 403, raise the request rate, or
mark a dead run as finished by hand.

## C3 Daily index reconcile
Meaning: red if the SEC daily index listed a filing for one of our CIKs that is not in `filing`, on
any day, until that day is reconciled again or acknowledged (a gap does not age out). Amber for a day
acknowledged with a reason, and for business days in the last 30 that have no reconciled index yet
("not published" or "never checked"; retried on the next run). First look:
`SELECT index_date, status, missing FROM daily_index_reconciliation ORDER BY index_date DESC LIMIT 10;`.
Causes: the submissions API lagged behind the daily index (re-run `sync` later), a company's CIK is
missing from `company_cik`, a gap in runs (read `backfill.md`), the SEC withdrew a filing. When you
have shown the filing cannot be loaded and why, accept it with
`uv run sec-filings ack C3 YYYY-MM-DD --reason "..."`; the day turns amber and the report prints the
reason (D-23). Do not: delete reconciliation rows, or acknowledge a day you have not explained.

## C4 Company mapping
Meaning: red if the SEC ticker file now maps a ticker to a CIK we do not know; amber if a ticker is in
`companies.csv` but not synced, has no reviewed entry in `companies.yml`, failed this run, or the ticker
file was not fetched. First look: `uv run sec-filings resolve-companies`, then
`SELECT company_id, cik, valid_from, valid_to FROM company_cik WHERE company_id = 'XOM';`. Causes:
a redomiciliation or merger (read `cik-changed.md`), a new unreviewed ticker (read `add-companies.md`).
Do not: edit `company_cik` rows, or point the ticker at the new CIK without reading the 8-K.

## C5 Coverage drift
Meaning: the number of filings the SEC says a history page holds differs from what we parsed or
stored. First look: `SELECT cik, page_name, filing_count, rows_in_payload FROM history_page WHERE
rows_in_payload IS DISTINCT FROM filing_count;`. Causes: a parser bug on an unusual form, a truncated
download, SEC changed the JSON shape, a stale stored page. Re-run `backfill --ticker T` for that company
once; if it persists, fix the parser with a fixture test. Do not: edit `history_page`.

## C6 Row count never falls
Meaning: a (company, form family) count of non-stale filings is lower than at the previous run. First
look: the message lists `KEY old -> new`; compare with `SELECT company_id, form_family, count(*) FROM
filing WHERE NOT is_stale GROUP BY 1,2 ORDER BY 1,2;`. Causes: filings flagged `is_stale` (they vanished
from upstream or a CIK span changed), a form family reclassified. Do not: delete or un-stale rows to
restore the count, and do not delete the previous check_result baseline.

## C7 One canonical per period
Meaning: a labelled period has no canonical filing, several canonical ones, several original filings
under one label, or `report_period` points at a non-canonical filing. First look: the message names
`COMPANY kind FYyyyy period`; run `uv run sec-filings show TICKER YEAR` and
`SELECT accession_number, form, filing_date, period_of_report, fiscal_year, is_canonical FROM filing
WHERE company_id = 'T' AND fiscal_year = 2020 ORDER BY filing_date;`. Causes: wrong fiscal label (the
usual one: a convention flip such as Walmart or Toyota), an amendment scope misjudged. Do not: flip
`is_canonical` by hand; fix the label rule or add an override with a reason in `companies.yml`.

## C8 Labels present and plausible
Meaning: red when a filing since 2011 has no label (`label_source = 'none'`) or its fiscal year is more
than one year from its period end. A green line starting `info:`, one per company, says how many
filings declare a fiscal year that differs from our convention label; it is expected for Walmart,
Toyota and GE (D-04, D-24) and needs no action. First look: `SELECT accession_number, form,
period_of_report, fiscal_year, declared_fiscal_year, label_source FROM filing WHERE company_id = 'T'
ORDER BY filing_date DESC LIMIT 20;`. Causes of a red: a missing cover page, a wrong period end, an
unusual fiscal year end (set `fiscal_year_end` in `companies.yml`). Do not: relabel by hand.

## C9 Expected but overdue
Meaning: `expected_filing` has a period past its due date with extension and no filing. First look:
`SELECT company_id, report_kind, fiscal_year, fiscal_period, due_date_with_extension FROM
expected_filing WHERE status = 'overdue';`. Causes: the company really is late (a genuine finding, check
for an NT 10-K), a wrong filer category, a wrong fiscal year end, a filing we mislabelled so the period
looks empty, or a CIK missing. Do not: mark the row filed by hand.

## C10 Amendments resolved
Meaning (amber): an amendment is not linked to an original, or its scope or kind is unknown. First look:
`SELECT accession_number, company_id, amends_accession, amendment_scope, amendment_kind FROM filing WHERE
form_family IN ('annual_amendment','quarterly_amendment') AND (amends_accession IS NULL OR
amendment_scope IS NULL OR amendment_scope = 'unknown' OR amendment_kind IS NULL OR amendment_kind =
'unknown');`. Causes: the filing index was not fetched (common offline), the original predates our
history, a genuinely ambiguous amendment. Resolve with a reasoned `overrides` entry in `companies.yml`
(accession, scope, kind, reason). Do not: guess a kind without reading the filing.

## C11 Golden queries
Meaning: a hand-checked canonical accession in `src/sec_filings/golden_queries.yml` no longer matches
`report_period`, or the period is missing, or the file is unreadable (amber). First look: `uv run
sec-filings show TICKER YEAR` and compare with the filing on EDGAR. Causes: a rule change that moved
the canonical answer (find out which and why), a lost or relabelled filing. Do not: edit the expected
accession to match our output unless you proved the old value wrong against EDGAR and logged a
DECISIONS.md entry.

## C12 Unknown periodic form
Meaning (amber): the sync saw a form that looks periodic (10-K, 10-Q, 20-F, 40-F, 6-K, NT 10-) but has
no family in `domain/forms.py`. First look: `SELECT message FROM check_result WHERE check_id =
'C12-input' ORDER BY created_at DESC LIMIT 10;`. Causes: a new SEC form variant (for example a new
10-K suffix). Decide its family in `domain/forms.py` with a unit test and a DECISIONS.md entry. Do not:
ignore it; an unmapped form is a filing the table silently lacks.

## Evidence the agent must show

The check id, the first query's output, the cause in one sentence, the fix, and the `verify` block
ending `RESULT: OK` (or the remaining ambers with a reason each). If the fix touched a data rule, the
DECISIONS.md entry.
