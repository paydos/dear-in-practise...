"""Total tokens per model, and per agent, from Claude Code session logs (.jsonl).

Usage:
    python scripts/agent_usage.py <log-dir> [--out docs/agent-usage.md]

<log-dir> is a folder of session logs, e.g. a project folder under ~/.claude/projects/
(gzipped .jsonl.gz files are read too). Only token counts and the first words of each agent's
brief are read out. Each assistant message is counted once (streamed chunks share a message id).
Standard library only.

Prices change and differ by plan, so this reports tokens, not money.
"""

from __future__ import annotations

import argparse
import gzip
import json
from collections import defaultdict
from pathlib import Path

FIELDS = ("input_tokens", "cache_creation_input_tokens", "cache_read_input_tokens", "output_tokens")


def _open(path: Path):
    return (
        gzip.open(path, "rt", encoding="utf-8")
        if path.suffix == ".gz"
        else path.open(encoding="utf-8")
    )


def _first_prompt(path: Path) -> str:
    with _open(path) as fh:
        for line in fh:
            try:
                rec = json.loads(line)
            except ValueError:
                continue
            msg = rec.get("message") or {}
            if rec.get("type") == "user" and msg.get("role") == "user":
                content = msg.get("content")
                text = (
                    content
                    if isinstance(content, str)
                    else " ".join(c.get("text", "") for c in content or [] if isinstance(c, dict))
                )
                text = " ".join(text.split())
                if text:
                    return text[:70]
    return ""


def scan(log_dir: Path):
    by_model: dict[str, dict[str, int]] = defaultdict(lambda: dict.fromkeys(FIELDS, 0))
    by_file: list[tuple[str, str, str, dict[str, int]]] = []
    files = sorted(p for p in log_dir.rglob("*") if p.name.endswith((".jsonl", ".jsonl.gz")))
    # A resumed or forked session copies earlier messages and subagent logs into a new folder,
    # so a message id is counted once across ALL files, not once per file.
    seen: set[str] = set()
    for path in files:
        totals: dict[str, dict[str, int]] = defaultdict(lambda: dict.fromkeys(FIELDS, 0))
        with _open(path) as fh:
            for line in fh:
                try:
                    rec = json.loads(line)
                except ValueError:
                    continue
                msg = rec.get("message") or {}
                model, usage, mid = msg.get("model"), msg.get("usage"), msg.get("id")
                if not model or not usage or model.startswith("<") or mid in seen:
                    continue
                seen.add(mid)
                for f in FIELDS:
                    totals[model][f] += int(usage.get(f) or 0)
        kind = "subagent" if "subagents" in path.parts else "session"
        for model, t in totals.items():
            by_file.append((kind, path.name.split(".")[0], model, t))
            for f in FIELDS:
                by_model[model][f] += t[f]
    prompts = {p.name.split(".")[0]: _first_prompt(p) for p in files if "subagents" in p.parts}
    return by_model, by_file, prompts


def _fmt(n: int) -> str:
    return f"{n:,}"


def render(by_model, by_file, prompts) -> str:
    lines = [
        "# Agent usage",
        "",
        "Tokens per model, from the session logs (`scripts/agent_usage.py`). Each assistant",
        "message is counted once. Cache reads are tokens re-read from the prompt cache.",
        "",
        "## By model",
        "",
        "| Model | Input | Cache write | Cache read | Output |",
        "|---|---:|---:|---:|---:|",
    ]
    for model, t in sorted(by_model.items(), key=lambda kv: -kv[1]["output_tokens"]):
        lines.append(
            f"| `{model}` | {_fmt(t['input_tokens'])} | {_fmt(t['cache_creation_input_tokens'])} | "
            f"{_fmt(t['cache_read_input_tokens'])} | {_fmt(t['output_tokens'])} |"
        )
    lines += [
        "",
        "## By agent",
        "",
        "| Kind | Model | Output tokens | First instruction |",
        "|---|---|---:|---|",
    ]
    for kind, name, model, t in sorted(
        by_file, key=lambda r: (r[0] != "session", -r[3]["output_tokens"])
    ):
        first = prompts.get(name, "(main conversation)" if kind == "session" else "")
        first = first.replace("|", "/")
        lines.append(f"| {kind} | `{model}` | {_fmt(t['output_tokens'])} | {first} |")
    return "\n".join(lines) + "\n"


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("log_dir", type=Path)
    ap.add_argument("--out", type=Path)
    args = ap.parse_args(argv)
    md = render(*scan(args.log_dir))
    if args.out:
        args.out.write_text(md, encoding="utf-8")
        print(f"wrote {args.out}")
    else:
        print(md)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
