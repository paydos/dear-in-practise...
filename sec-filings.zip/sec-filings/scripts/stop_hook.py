"""Claude Code Stop hook (PLAN.md section 10.3). It must never trap the agent.

Exit 2 (block the stop, stderr shown to the agent) only when:
  - the offline unit tests fail, or
  - `sec-filings verify --if-db` reports RED against a reachable database.
Every other situation (uv missing, a timeout, no database, any surprise) prints a one-line hint
to stderr and exits 0. If the hook input says `stop_hook_active`, it exits 0 at once.
"""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TEST_CMD = ["uv", "run", "pytest", "-q", "-m", "not db and not live", "-x"]
VERIFY_CMD = ["uv", "run", "python", "-m", "sec_filings", "verify", "--if-db"]
TEST_TIMEOUT = 60
VERIFY_TIMEOUT = 180
TAIL_LINES = 40


def _hint(message: str) -> int:
    print(f"stop hook: {message}", file=sys.stderr)
    return 0


def _tail(text: str) -> str:
    return "\n".join(text.strip().splitlines()[-TAIL_LINES:])


def _stop_hook_active(raw: str) -> bool:
    try:
        data = json.loads(raw) if raw.strip() else {}
    except ValueError:
        return False
    return isinstance(data, dict) and bool(data.get("stop_hook_active"))


def _run(cmd: list[str], timeout: int) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        cmd, cwd=ROOT, capture_output=True, text=True, timeout=timeout, check=False
    )


def main(raw_stdin: str = "") -> int:
    if _stop_hook_active(raw_stdin):
        return 0
    if shutil.which("uv") is None:
        return _hint("uv is not on PATH, checks skipped. Install uv, run `sec-filings verify`.")

    try:
        tests = _run(TEST_CMD, TEST_TIMEOUT)
    except subprocess.TimeoutExpired:
        return _hint(f"unit tests took over {TEST_TIMEOUT}s, skipped. Run them before finishing.")
    except Exception as exc:  # noqa: BLE001 - the hook must never trap the agent
        return _hint(f"could not run the unit tests ({exc}); allowing the stop.")
    if tests.returncode in (1, 2):  # 1 test failure, 2 interrupted or collection error
        print("Offline unit tests failed. Fix them before finishing:", file=sys.stderr)
        print(_tail(tests.stdout + "\n" + tests.stderr), file=sys.stderr)
        return 2
    if tests.returncode not in (0, 5):  # 5: nothing collected
        return _hint(f"pytest exited {tests.returncode} (not a test failure); allowing the stop.")

    try:
        verify = _run(VERIFY_CMD, VERIFY_TIMEOUT)
    except subprocess.TimeoutExpired:
        return _hint("verify timed out, skipped. Run `uv run sec-filings verify` yourself.")
    except Exception as exc:  # noqa: BLE001
        return _hint(f"could not run verify ({exc}); allowing the stop.")
    if verify.returncode == 1 and "RESULT: RED" in verify.stdout:
        print("sec-filings verify reports RED. Fix it or explain it:", file=sys.stderr)
        print(_tail(verify.stdout), file=sys.stderr)
        return 2
    if "not reachable" in verify.stdout:
        return _hint("no database reachable, verify skipped. Set DATABASE_URL (see AGENTS.md).")
    return 0


if __name__ == "__main__":
    try:
        code = main(sys.stdin.read() if not sys.stdin.isatty() else "")
    except Exception as exc:  # noqa: BLE001
        code = _hint(f"unexpected error ({exc}); allowing the stop.")
    raise SystemExit(code)
