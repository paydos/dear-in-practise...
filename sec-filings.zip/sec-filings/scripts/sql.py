"""Run one SQL statement against DATABASE_URL and print the rows. For machines without psql.

Usage:
    uv run python scripts/sql.py "SELECT company_id, fiscal_year FROM v_annual_reports LIMIT 5"
    uv run python scripts/sql.py --file docs/analyst-answer.sql      # runs each statement in turn

Read-only by default (the session is set read-only); pass --write to allow changes.
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

import psycopg


def _print(cur: psycopg.Cursor) -> None:
    if cur.description is None:
        print(f"({cur.rowcount} rows affected)")
        return
    cols = [d.name for d in cur.description]
    rows = cur.fetchall()
    widths = [
        max(len(c), *(len(str(r[i])) for r in rows)) if rows else len(c) for i, c in enumerate(cols)
    ]
    print("  ".join(c.ljust(w) for c, w in zip(cols, widths, strict=True)))
    print("  ".join("-" * w for w in widths))
    for r in rows:
        print("  ".join(str(v).ljust(w) for v, w in zip(r, widths, strict=True)))
    print(f"({len(rows)} rows)\n")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("sql", nargs="?")
    ap.add_argument("--file", type=Path)
    ap.add_argument("--write", action="store_true")
    args = ap.parse_args(argv)
    url = os.environ.get("DATABASE_URL")
    if not url:
        print("Set DATABASE_URL first.", file=sys.stderr)
        return 2
    if args.file:
        text = args.file.read_text(encoding="utf-8")
        lines = [ln for ln in text.splitlines() if not ln.strip().startswith("--")]
        statements = [s.strip() for s in "\n".join(lines).split(";") if s.strip()]
    elif args.sql:
        statements = [args.sql]
    else:
        ap.error("give a SQL statement or --file")
    with psycopg.connect(url) as conn:
        if not args.write:
            conn.execute("SET default_transaction_read_only = on")
            conn.commit()
        for stmt in statements:
            with conn.cursor() as cur:
                cur.execute(stmt)
                _print(cur)
        conn.commit()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
