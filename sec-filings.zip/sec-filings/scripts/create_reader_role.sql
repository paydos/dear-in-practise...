-- create_reader_role.sql: a read-only Postgres role for the MCP server (production use).
-- Run once as a superuser or the database owner, connected to the sec_filings database:
--   psql "$DATABASE_URL" -v reader_password="'choose-a-password'" -f scripts/create_reader_role.sql
-- Then point the server at it:
--   MCP_DATABASE_URL=postgresql://sec_reader:PASSWORD@HOST:5432/DBNAME

DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'sec_reader') THEN
    CREATE ROLE sec_reader LOGIN;
  END IF;
END $$;

ALTER ROLE sec_reader PASSWORD :reader_password;
ALTER ROLE sec_reader SET default_transaction_read_only = on;
ALTER ROLE sec_reader SET statement_timeout = '5s';

GRANT USAGE ON SCHEMA public TO sec_reader;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO sec_reader;   -- includes views
-- Tables and views created by later migrations (run by the owner role) stay readable:
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON TABLES TO sec_reader;
