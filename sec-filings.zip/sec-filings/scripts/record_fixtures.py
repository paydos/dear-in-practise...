"""Record SEC responses byte-exact into the fixture layout (docs/contracts.md section 7).

Usage:
    python scripts/record_fixtures.py --out tests/fixtures/edgar URL [URL ...]
    python scripts/record_fixtures.py --out tests/fixtures/edgar \
        --manifest tests/fixtures/manifest.txt

Each URL is saved under <out>/<host>/<path>, decompressed, exactly as the SEC sent it.
Requires SEC_USER_AGENT ("Name email@example.com"), per the SEC fair-access rules.
Stays at 4 requests per second. Stops on HTTP 403. Skips files that already exist
unless --force is given. Uses only httpx and the standard library, so it does not
depend on the package being importable.
"""

from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path
from urllib.parse import urlsplit

import httpx

MIN_INTERVAL = 0.25  # seconds between requests: 4 per second, limit is 10


def fixture_path(out: Path, url: str) -> Path:
    parts = urlsplit(url)
    if parts.query:
        raise SystemExit(f"query strings are not supported: {url}")
    return out / parts.netloc / parts.path.lstrip("/")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--out", required=True, type=Path)
    ap.add_argument(
        "--manifest", type=Path, help="file with one URL per line; '#' starts a comment"
    )
    ap.add_argument("--force", action="store_true", help="re-download files that already exist")
    ap.add_argument("urls", nargs="*")
    args = ap.parse_args(argv)

    ua = os.environ.get("SEC_USER_AGENT", "").strip()
    if "@" not in ua:
        print("SEC_USER_AGENT must be set to 'Name email@example.com'", file=sys.stderr)
        return 2

    urls = list(args.urls)
    if args.manifest:
        for line in args.manifest.read_text(encoding="utf-8").splitlines():
            line = line.split("#", 1)[0].strip()
            if line:
                urls.append(line)

    headers = {"User-Agent": ua, "Accept-Encoding": "gzip, deflate"}
    last = 0.0
    saved = skipped = missing = 0
    with httpx.Client(headers=headers, timeout=60.0, follow_redirects=False) as client:
        for url in urls:
            target = fixture_path(args.out, url)
            if target.exists() and not args.force:
                skipped += 1
                continue
            wait = MIN_INTERVAL - (time.monotonic() - last)
            if wait > 0:
                time.sleep(wait)
            last = time.monotonic()
            resp = client.get(url)
            if resp.status_code == 403:
                print(f"403 from SEC on {url}; stopping (check SEC_USER_AGENT)", file=sys.stderr)
                return 3
            if resp.status_code == 404:
                print(f"404  {url}")
                missing += 1
                continue
            resp.raise_for_status()
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(resp.content)  # httpx has already decompressed gzip/deflate
            print(f"{resp.status_code}  {len(resp.content):>10,} B  {url}")
            saved += 1
    print(f"saved {saved}, skipped {skipped} existing, {missing} not found")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
