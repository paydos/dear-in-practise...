"""Start (or reuse) an embedded Postgres for manual runs and print its DATABASE_URL.

    $env:PGSERVER_DATA = "<a folder outside the repo>"
    $env:DATABASE_URL = (uv run python scripts/dev_db.py)

The server keeps running after this script exits, so the next command can use the URL.
Data lives under PGSERVER_DATA/dev; nothing is ever written into the repository.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

import psycopg
from psycopg import sql

DATABASE = "sec_filings"


def main() -> int:
    base = os.environ.get("PGSERVER_DATA")
    if not base:
        print("PGSERVER_DATA is not set: point it at a folder outside the repo", file=sys.stderr)
        return 2
    root = Path(base).expanduser()
    root.mkdir(parents=True, exist_ok=True)

    import pgserver

    server = pgserver.get_server(root / "dev", cleanup_mode=None)  # None: leave it running
    admin_uri = server.get_uri()
    with psycopg.connect(admin_uri, autocommit=True) as admin:
        exists = admin.execute(
            "SELECT 1 FROM pg_database WHERE datname = %s", (DATABASE,)
        ).fetchone()
        if not exists:
            admin.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(DATABASE)))
    print(server.get_uri(database=DATABASE))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
