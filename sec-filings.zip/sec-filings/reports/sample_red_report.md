<!-- Sample of a RED morning report. Produced 2026-11-12 with the final code by injecting two faults into a copy of the live database: Apple's 2006 NT 10-K row deleted (C6) and a daily-index day listing a filing that is absent (C3). The same two faults were used in docs/handover/results.md, scenario S3. Exit code 2. -->

# Morning check 2026-11-12: RED

2 red, 0 amber, 13 green. Run 0c6bad78-9c54-4642-81bb-82ed8e8763a8 (check): success.

## Red

- C3 Daily index reconcile: 1 filing(s) in the SEC daily index but not in our table (days 2026-11-10): 0000320193-26-099999
- C6 Row count never falls: 1 company/family count(s) fell: AAPL/late_notice 2 -> 1

## All checks

| Check | Name | Status | Message |
|-------|------|--------|---------|
| C1 | Heartbeat | green | run finished 20:51 today (Europe/London) |
| C2 | Run status | green | last run succeeded |
| C3 | Daily index reconcile | red | 1 filing(s) in the SEC daily index but not in our table (days 2026-11-10): 0000320193-26-099999 |
| C4 | Company mapping | green | 20 ticker(s) mapped and reviewed |
| C5 | Coverage drift | green | 97 history page(s) match their stated filing count |
| C6 | Row count never falls | red | 1 company/family count(s) fell: AAPL/late_notice 2 -> 1 |
| C7 | One canonical per period | green | every labelled period has exactly one canonical filing |
| C8 | Labels present and plausible [GE] | green | info: GE: 1 filing(s) declare a different fiscal year than the convention label (deliberate, D-04): 0000040545-20-000... |
| C8 | Labels present and plausible [TM] | green | info: TM: 7 filing(s) declare a different fiscal year than the convention label (deliberate, D-04): 0001193125-10-163... |
| C8 | Labels present and plausible [WMT] | green | info: WMT: 19 filing(s) declare a different fiscal year than the convention label (deliberate, D-04): 0001193125-09-1... |
| C9 | Expected but overdue | green | no overdue filings |
| C10 | Amendments resolved | green | every amendment is linked with a known scope and kind |
| C11 | Golden queries | green | 17 golden queries match |
| C12 | Unknown periodic form | green | no unknown periodic forms |
| X1 | Stale rows | green | no rows newly flagged stale |
