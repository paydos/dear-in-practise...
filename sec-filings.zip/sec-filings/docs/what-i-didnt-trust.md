# What I didn't trust

I directed the work: an orchestrating model (Opus) wrote the plan and contracts, builder models (Sonnet) wrote the code. [`trust-log.md`](trust-log.md) has all 19 errors with evidence.

**Where the agent was wrong.** The four that mattered most:
- **T-6.** The plan built its restatement rule on Plug Power's 2022 10-K/A. The restated numbers are in the original 10-K (`0001558370-21-007147`); the amendment changes nothing.
- **T-8.** "A filing's declared fiscal year is the best label." Walmart and Toyota switched how they declare it, so two Walmart reports were both "fiscal 2009".
- **T-11.** "More than six rendered reports means a complete amendment." Ten exhibit-only amendments became the answer for their period.
- **T-12.** Old reports were judged late with today's filer category: 12 of 16 "late" flags were wrong.

**How I found out.** Not from summaries. T-6 from reading the filing itself; T-8 when the first end-to-end run turned check C9 red; T-11 and T-12 only on live data. Every test case had been clean, so the rules had never met a messy one.

**What I checked against.** Sources the code did not produce: the filings' own text and cover pages; EDGAR's separate company index (0 mismatches over 453 filings); deadlines recomputed by hand; a fresh-context reviewer told to break the job.

**Data decisions** (all 24 in [`DECISIONS.md`](../DECISIONS.md)):
- Foreign filers count, with the 20-F as their annual report (D-01).
- One answer per period: the latest complete version (D-03).
- Fiscal labels follow each company's majority convention (D-04).
- Corrections are events, separate from amendments (D-10).
- Rows are never deleted (D-07).

The pattern: "verified" without evidence, and rules tested only on clean cases.
