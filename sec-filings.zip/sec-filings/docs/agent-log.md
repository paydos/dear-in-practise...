# Agent log

What was delegated, to whom, what came back, what was wrong, and what was done about it. Includes the times work was deliberately not delegated. Entries are written as work happens.

Orchestrator: Claude Opus 5.5 (main session). Builders: Claude Sonnet 5.5 subagents. Reviewer: Opus, fresh context, read-only.

## R-0. Research and planning (2026-11-09, main session)

- **Not delegated:** brief reading, EDGAR spot checks and planning stayed in the main session, because each finding changed the next question.
- **Outcome:** `PLAN.md` (revisions 1 to 2.1) and a written plan review (not included; its findings are listed in the next bullet). Five agent errors caught and recorded as T-1 to T-5 in `trust-log.md`.
- **Second opinion:** an independent reviewer pass on the plan found a wrong canonical rule ("latest filed wins"), a morning check that could not see a missing run, a permanently red pagination check, and the employer email about to ship as the default User-Agent. All fixed before any code.

## P0. Environment and repository seed (2026-11-10, main session)

- **Not delegated:** environment setup, because every builder depends on it and the failures were specific to this machine.
- **Found:**
  - No Docker, no Postgres, no uv on the machine. The shell tool for POSIX commands did not work; PowerShell did.
  - uv's managed Python install failed with "Missing expected target directory". Cause: the desktop app runs in a Windows package sandbox that redirects `AppData`, so uv's version junction pointed at a path that did not exist. The Python itself installed fine and is used by absolute path.
  - The global git identity was a placeholder (`Example User`). Commits need a real, non-employer author.
  - An embedded Postgres 16 (`pgserver`, pip-installable) runs without admin rights. It is used for local development and tests only. Graders use their own Postgres through `DATABASE_URL`.
- **Decision:** the virtual environment and database data live outside OneDrive, so sync cannot corrupt them.
- **Also caught:** the first commit message carried a byte-order mark from PowerShell's UTF-8 writer. Fixed with a BOM-free commit helper.

## P1. Spike, part A (2026-11-10, main session)

- **Not delegated:** the full-history scan, because its results change the contract every builder works from.
- **Found** (details in `docs/spike-findings.md`): `reportDate` is the filing date on several older annual reports, which would mislabel them by a year; Alibaba has no fiscal year end in its metadata; "NT 11-K" would trip the unknown-form check forever; Novo Nordisk tagged nothing before 2022; acceptance times are real UTC.
- **Contract amendment 1:** `effective_period_end`, `infer_fiscal_year_end`, narrower unknown-form prefixes, gzipped large fixtures. Made before builder B started, so no builder had to absorb a moving target.

## P2. Scaffold (Sonnet 5.5 subagent, background)

- **Delegated:** package skeleton, models, errors, config, migrations, stubs with frozen signatures, test harness on embedded Postgres, CI workflow.

- **Came back (model reported `claude-sonnet-5-5`):** 26 tests green, lint clean. It could not run the `sec-filings` launcher ("Access is denied") and said so rather than working around it. It ran the same app through Python and listed four contract ambiguities.
- **Orchestrator check:** re-ran the tests and lint; spot-checked the schema, the default User-Agent and the absence of Prefect. Added a `python -m sec_filings` entry point, because this machine blocks new launchers.

## P1, part B. Fixtures and document reading (Sonnet 5.5 subagent, background)

- **Delegated:** recording the golden fixtures and reading specific amendments, because it is mechanical and verbose. The orchestrator reviews the classifications against the filings before they become golden tests.
- **Came back (`claude-sonnet-5-5`):** 92 byte-exact fixtures (13 MB), 28 golden facts with sources, spike findings B1 to B9. Two findings overturned the plan: Plug Power's restated numbers are in the original FY2020 10-K, not the 2022 amendment (T-6), and the cover-tag design would download about 4 GB (T-7).
- **Orchestrator check:** fetched Plug's original FY2020 10-K and confirmed the restatement tagging (482 mentions). Rewrote the contract (amendment 2) before builder A started.
- **Not accepted as-is:** the subagent's suggestion to link Plug's 2022 amendment as a secondary correction. The amendment restates nothing, so it is not linked at all.

## P3. Parallel build (three Sonnet 5.5 builders, disjoint files)

- **Builder B, domain rules (`claude-sonnet-5-5`):** 250 tests. Listed eight interpretations. Two exposed contract problems that amendment 2 fixed: `effective_period_end` would have "corrected" a 10-K/A filed within a week of its period end, and the non-reliance fallback had no time window.
- **Builder C, repository and checks (`claude-sonnet-5-5`):** 47 tests. Found that `now()` is frozen inside a Postgres transaction, so run ordering tied; switched to `clock_timestamp()`. Found that the embedded Postgres lacks time-zone data; the heartbeat uses Python's `zoneinfo`. Flagged the C12 side channel as weak coupling. Accepted for now, because the contract has no other place to carry unknown forms.
- **Orchestrator check:** ran all 323 tests together to catch collisions between builders; all pass. Committed as one phase.
- **Builder A, SEC client and parsers (`claude-sonnet-5-5`):** 100 tests, every golden fact matched. Caught an error in the orchestrator's contract: 2009 filings use the `http://xbrl.us/dei/` namespace, so the specified prefix rule would have returned nothing for Apple's FY2009 cover. It accepts both. Also found that history pages' `filingFrom`/`filingTo` are not exact bounds (GameStop), so only counts are compared.
- **Orchestrator check:** full suite of 431 tests green across all builders. One interpretation not accepted silently: the daily-index parser raises on a malformed row, which would let one bad line fail a whole morning's reconciliation. The integration brief now catches it per day and records it.
- **Fixtures follow-up (`claude-sonnet-5-5`):** 44 small concept files and cover pages. Found that Novo Nordisk has no concept files, so its labels depend on cover pages, and that "more than 6 report files" separates complete amendments from add-ons on every golden case.

## P4. Integration (Sonnet 5.5 builder, background)

- **Delegated:** companies loader, flows, CLI, analyst views, dev database script, golden queries and end-to-end offline tests, from a written brief that names every rule and the expected golden outcomes.
- **Came back (`claude-sonnet-5-5`):** 463 tests, `show AAPL 2009` correct. The builder did not paper over the end-to-end run. It listed every red and amber with a cause and a file and line, and left frozen modules untouched as instructed. Checks C7, C8 and C9 went red on real defects. The worst: Walmart had two reports labelled fiscal 2009, which show WMT 2009 answered wrongly until C9's red was traced to it.
- **Orchestrator triage:**
  - Verified the most surprising claim directly: Walmart's and Toyota's declared fiscal years really do switch convention mid-history (T-8). Rejected the easy fix of trusting declared labels per filing, and chose a majority convention applied consistently.
  - Accepted the builder's diagnosis of the period-correction bug, and reinstated a rule I had removed in amendment 2 (T-10).
  - Accepted the storage flaw in my own schema (T-9).
  - Made three reviewed classifications in `companies.yml` from the recorded evidence. Plug's 2022 amendment is administrative. Shell's two 2025 amendments are partial and administrative, being reissued audit opinions, so the original 20-Fs stay canonical.
  - Ruled that the 63 amber amendments in the offline run are a fixture gap (their indexes were never recorded), not a defect. The live run will judge them.
- **Contract amendment 3** written, then two Sonnet fixers launched in parallel on disjoint files.

## Fix round 1, after the first end-to-end run (two Sonnet 5.5 fixers)

- **Fixer D, labels and periods (`claude-sonnet-5-5`):** majority convention, the 14-day period rule for every family, year-end distance by month and day, expected filings from 2009-06-15. 280 domain tests.
- **Fixer F, storage, checks, flows (`claude-sonnet-5-5`):** `raw_fetch` log, declared-label columns, C2/C3/C4/C7/C8 changes, two new golden queries (Walmart FY2014, Toyota FY2017). 501 tests overall.
- **Accepted deviation:** fixer F learns the convention from original annual reports only. With Toyota's 17 amendments counted, the majority fell to 53 % and the convention became "unknown", which left fiscal 2017 with no answer. Originals give 60 %. Sound, because amendments repeat their original's declaration.
- **Corrected the orchestrator's brief:** Walmart's FY2009 10-K has raw period 2009-04-01 (its filing date), not 2009-01-31 as the brief said. The labelling corrects it; the test asserts the accession.
- **Orchestrator check:** 501 tests and lint re-run and green. Offline golden backfill: no red. The remaining ambers were the deliberate declared-label notes and amendments whose indexes were not recorded offline.
- **Paused here** at the user's request, before the live run.

## P6. Live backfill (2026-11-10, main session)

- **Not delegated:** the first live run, because it is the one moment the job talks to the SEC for real and the orchestrator wanted to see the result directly.
- **Result:** all 20 companies loaded, 507 requests in 186 seconds, 6,419 filings, run status success. Morning check: 0 red, 4 amber, exit code 1 (amber only, by design).
- **Checked directly:** Apple FY2009 answers with the 10-K/A (accounting change); Exxon has an unbroken 1993 to 2025 annual series across both CIKs; Walmart FY2014 and Toyota FY2021 are right; no company has a gap in its annual series; in the analyst window the only late annual report is Plug Power FY2020 (due 2021-03-16 with its NT 10-K, filed 2021-05-14).
- **New signal:** a cover-page error-correction flag on SAP's FY2024 20-F. Not taken at face value; sent to reconciliation.
- **Ambers judged:** C8 is the deliberate declared-label disagreement. C10 lists 55 unresolved amendments, 35 of them from 1994 to 2009, before rendered reports existed. Decision pending: assess amendment scope only from 2009-06-15, matching contract 12.3.
- **Delegated in parallel:** independent Opus review (read-only, fresh context), reconciliation against EDGAR's separate company-browse system (Sonnet), handover kit (Sonnet).

## P5. Independent review (Opus 5.5, fresh context, read-only, run after the live backfill)

- **Came back (`claude-opus-5-5`):** 14 findings. It ran its own scratch database and tried to break the job. Two blockers: the shipped User-Agent was still the placeholder, and there was no README. Six majors: a dropped row was red once, then became the baseline; SEC-side deletions never surfaced day to day; a skipped duplicate run hid a failed one; one missing filing kept C3 red forever; the heartbeat missed a run that never happened when the check ran early; unreviewed tickers silently followed a CIK change.
- **Orchestrator response:** accepted all 14. Replaced the User-Agent default with the contact the user approved and added the release guard. Everything else went into fix round 2. Kept the reviewer's "no Prefect, exit codes as specified" confirmation as evidence.

## P6, continued. Reconciliation against EDGAR (Sonnet 5.5)

- **Came back (`claude-sonnet-5-5`):** 96 SEC requests. Zero mismatches against EDGAR's separate company-browse system for Apple, Exxon (both CIKs), Toyota, GameStop, Plug and SAP. 12 of 12 random labels match the filings' covers. SAP's error flag is real (a €0.7 billion prior-year disclosure correction). Two defects found: exhibit-only amendments answering as the report (T-11), and 12 of 16 "late" rows wrong because they used today's filer category (T-12).
- **Deviation reported by the subagent:** one 12 MB download despite a 5 MB rule (T-13).
- **Orchestrator response:** both defects went into fix round 2, with the reconciliation's tables as the acceptance test.

## P8, part 1. Handover kit (Sonnet 5.5)

- **Came back (`claude-sonnet-5-5`):** AGENTS.md, CLAUDE.md, two skills mirrored as runbooks, three more runbooks, a safe Stop hook with tests. It self-checked every documented command against the CLI and listed three it could not verify.
- **Orchestrator review:** read the hook and settings line by line before keeping them, because a hook in the repo also runs on the orchestrator's own session. Shortened the verify timeout, added the PowerShell form of the dev-database line, and added the Docker Compose file the kit referred to.

## Fix round 2 (Sonnet 5.5 fixer)

- **Delegated:** all 14 review findings plus the two reconciliation defects, with the reconciliation's tables as acceptance tests.
- **Came back (`claude-sonnet-5-5`):** all fixes in, 547 tests. It said plainly that five amendments could not be separated by any rule and that the CI step had not been run.
- **Orchestrator response:** wrote 11 reviewed overrides in `companies.yml` from the reconciliation's evidence, ran the CI step locally on a fresh database, and re-ran the live sync: 22 requests, 0 red, no add-on amendment left as an answer.

## P7. The two half-pages

- **What I didn't trust:** drafted by a Sonnet subagent from the trust log; the orchestrator corrected the attribution and one claim about the daily index before keeping it.
- **Analyst answer:** written by the orchestrator from the corrected live data. Its own check removed two overclaims ("each was checked against EDGAR's index", "Plug's amendment re-files unchanged").

## P8, part 2. Fresh-agent trials (Sonnet 5.5 and Haiku 5.5, isolated worktrees)

- **S3, diagnose a red check (Sonnet):** passed. Found both injected faults, restored the deleted row with a scoped backfill, refused to edit data to make the check green, and escalated.
- **S1, add five companies (Sonnet and Haiku):** stopped by the orchestrator to save budget before their final evidence block. Both had independently found Oracle's predecessor CIK, Rio Tinto's two registrants and a real labelling defect (T-14).
- **Orchestrator response:** ported the Haiku agent's fix, which was the more principled of the two (D-21), and wrote `docs/handover/results.md`.

## P9 and P10. MCP server and reviewer pack (Sonnet 5.5)

- **MCP server:** 28 tests. The builder pinned the `mcp` extra below 2.x, because 2.x dropped the API it uses. The orchestrator ran the full suite before committing, because the builder's own run was unconfirmed.
- **Reviewer pack:** README, REVIEW.md and first drafts; the writer listed five stale statements itself, all fixed.

## P12 and P13. Usage, logs and the grader path (orchestrator)

- **Not delegated:** anything touching privacy.
- **Grader path:** `git clone` fails inside this machine's sandbox, so the committed tree was exported with `git archive` and run with only `DATABASE_URL` set: 20 companies, 496 requests, 148 seconds, 0 red.

## Final review round (three Opus 5.5 reviewers, fresh context, read-only)

- **Asked for by me:** a critical assessment "as the employer would grade it", knowing other candidates also use AI.
- **Grader simulation:** scores of 3 to 4 out of 5 per deliverable. Hardest points: my own judgement was not visible, the half-pages were twice too long, numbers in the docs disagreed.
- **Resilience review:** no blockers; six majors, all in the morning check: a run days old, a narrow manual run after a failed sync, a crash while writing the report, a missing filing that went green after 30 days, a false "403" alarm, and a ticker-file outage that aborted the run (T-17).
- **Consistency and privacy review:** found that the exported logs still named the employer's clients through the tool's system prompt (T-15), and that the usage table counted every agent twice (T-16).
- **Orchestrator response:** confirmed the leak (2,111 matches) and the doubled table before acting, then planned fix round 3.

## Fix round 3 (two Sonnet 5.5 fixers on disjoint files, plus the orchestrator)

- **Fixer X, the morning check:** runs older than 26 hours are red; only whole runs count for C1 and C2; a crash while reporting can no longer hide a red; missing filings stay red until found or acknowledged (`sec-filings ack C3 ...`, D-23); unreconciled days are amber; a structured "SEC denied" flag replaces text matching; a ticker-file outage degrades instead of failing; exit code 4 for a skipped run and informational C8 notes (D-24); a last-chance handler marks a dying run failed; the heartbeat pings `/fail` when anything is red; empty or vanished tickers are flagged; `Retry-After` dates are honoured; pre-2009 amendments stay unclassified; `flows.sync(..., raise_on_red=True)` for schedulers. Its final test run hung because the local test database had been shut down underneath it; the orchestrator traced that, added 10-second connection timeouts everywhere, and re-ran the suite itself.
- **Fixer Y, answers and kit:** `show` and the MCP server display the corrected period end with the SEC's raw value as a note; SEC COVID-19 relief is modelled (D-22); lateness judged with today's category is marked unconfirmed; the Stop hook path and `Write(brief.md)` deny were fixed. It also ran a formatter across the other fixer's files mid-run, which it reported.
- **Orchestrator:** usage table de-duplicated across sessions; both half-pages cut to under 300 words; `docs/my-role.md`; private preparation files removed from the repository; a historical banner on `PLAN.md`; AGENTS.md and runbook fixes; the diagrams in `docs/how-it-was-built.md`; and, my decision, the session logs are not shared (D-15).
## Final run (orchestrator)

- **Asked for by me:** "run it from scratch", and progress lines in the terminal, in colour, because a silent run looked stuck.
- **Progress output:** `sync` and `backfill` now print a time-stamped line per company on stderr (green done, yellow retry or warning, red failure) and one line per non-green check; `--quiet` and `NO_COLOR` turn it off. Three CLI tests; the report on stdout is unchanged.
- **Local hang explained:** the development database had died while the test suite started its own embedded Postgres alongside it (Windows error 0xC0000142, a process-start failure). Heavy jobs now run one at a time.
- **Live run from scratch:** a new empty database, real SEC traffic, no fixtures: 20 of 20 companies, 6,419 filings, 500 requests in 758 seconds (the SEC was slow that evening and answered some requests with 503; the retries showed up as yellow lines instead of silence), all checks green. A second sync used 22 requests and changed no rows.
- **Caught on that run:** `show AAPL 2009` claimed Apple's year end had been corrected to 2009-09-30; the real date is 2009-09-26. A display bug from fix round 3, fixed with a test (T-18).
- **Clean-copy check:** the committed tree, installed into a new environment, failed on the first command: Typer 0.29 no longer installs click, which the CLI imported and the development environment still had. Fixed, with a test, and the development environment re-synced to match a fresh install (T-19). The check was then repeated: the sync was green from the clean copy, and `verify` caught one help-text test that failed when `FORCE_COLOR` was set in the shell; the test now compares plain text.