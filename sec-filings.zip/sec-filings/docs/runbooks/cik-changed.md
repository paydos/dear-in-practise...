# Runbook: a ticker's CIK changed (check C4 red)

C4 is red when the SEC ticker file maps a ticker to a CIK that is not in `company_cik`. The job never
follows this silently (D-08). A person decides whether it is a real successor.

1. **Read the message.** `uv run sec-filings check` shows `T now maps to CIK N, not in company_cik
   (known: [...])`. Run `uv run sec-filings resolve-companies` for the company's name, earliest filing and
   former names under the new CIK.
2. **Confirm it is a successor, not a mistake.** On EDGAR, open the new CIK's filing list. A genuine
   successor shows an 8-K12B (successor-issuer notice) or an 8-K announcing the reorganisation, and the old CIK
   usually shows a Form 25 (delisting) or Form 15 (deregistration) around the same date. Record the
   accession number and date. If you find neither, or the new CIK is an unrelated company (ticker
   reuse), do NOT add it: write a DECISIONS.md entry and stop.
3. **Edit `companies.yml`.** Keep the old CIK and close it, add the new one with dates, as Exxon does:
   old `{cik: OLD, valid_to: <day before>, source: manual}`, new `{cik: NEW, valid_from: <effective day>,
   source: successor_8k, note: "<8-K12B accession and date>"}`. Dates are inclusive. Add a `notes`
   line and refresh `reviewed_by` and `reviewed_on`. Never remove the old CIK: its filings are the history.
4. **Record a decision** in `DECISIONS.md` (one short entry: what changed, evidence accession, date).
5. **Backfill that company only:** `uv run sec-filings backfill --ticker T`. A joint filing listed under
   both CIKs is stored once (D-02).
6. **Verify.** `uv run sec-filings verify` ends `RESULT: OK`; C4 is green; `uv run sec-filings show T
   <year>` answers for periods on both sides of the change; filing row count for T did not fall (C6).

Do not: delete filing rows, rewrite `company_cik` in SQL, or edit the stored ticker map to make C4 green.
