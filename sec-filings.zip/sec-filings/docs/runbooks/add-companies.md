# Runbook: add companies

Use when asked to track new tickers (for example "add NFLX, ORCL, BP, RIO and SONY"). Read
`AGENTS.md` and `DECISIONS.md` first. Needs `DATABASE_URL`, and `SEC_USER_AGENT` set to a personal
"Name contact" string (never an employer address). Commands: `uv run sec-filings ...`.

## Steps

1. **Append tickers** to `companies.csv`, one per line under the `ticker` header, upper case.
   Do not touch existing rows.
2. **Resolve.** `uv run sec-filings resolve-companies`. For each ticker it prints the CIK from the SEC
   ticker file, `UNREVIEWED` or `reviewed`, the company name, fiscal year end, earliest filing,
   whether it looks like a foreign filer, former names, and a yml snippet to paste after review.
   "not in the SEC ticker file" means you must find the CIK yourself and add it by hand.
3. **Foreign filers (D-01).** If the hint says "foreign filer ... yes" (20-F or 40-F, no 10-K), set
   `foreign_filer: true`. Such a company has an annual 20-F and no quarterly report; `show` says so.
   Confirm on EDGAR's filing list; a company that moved from 20-F to 10-K is not foreign today.
4. **Predecessor and successor CIKs.** Compare "earliest filing" with the listing date. An earliest
   filing years after the listing, or a former name in the hints, means an older CIK exists (AT&T's
   history sits under the SBC CIK, D-12; Lucid was a SPAC shell until 2021, D-11, `pre_merger_until`).
   A ticker file CIK that differs from where the history lives means a successor (Exxon: old CIK 34088,
   new CIK 2115436 from 2026-07-01, D-02). Joint filings appear under several registrants and are stored
   once, for example Rio Tinto plc 863064 and Rio Tinto Ltd 887028 filing one 20-F under both: list both
   CIKs and write a DECISIONS.md entry for which registrant the ticker belongs to.
5. **Write the reviewed entry** in `companies.yml` (field list in that file's header): `ciks` with
   `valid_from`/`valid_to` (inclusive, null if open), `source` one of `ticker_file`, `manual`,
   `successor_8k`; `foreign_filer`; `fiscal_year_end` only if the SEC metadata lacks it; `pre_merger_until`
   if applicable; `notes`; `reviewed_by` and `reviewed_on`. An unreviewed ticker still loads but stays
   amber on C4.
6. **Record fixtures** so an offline golden test exists. Add to `tests/fixtures/manifest.txt` every URL
   the job reads for the new company: the ticker file;
   `https://data.sec.gov/submissions/CIK##########.json` and each `-submissions-NNN.json` page named in
   the main JSON's `filings.files`; the two concept files
   `https://data.sec.gov/api/xbrl/companyconcept/CIK##########/dei/EntityCommonStockSharesOutstanding.json`
   and `.../dei/EntityPublicFloat.json` (a 404 is normal for some foreign filers); and, for the filing
   behind your golden query and any amendment of it, `.../Archives/edgar/data/<cik>/<accession without
   dashes>/index.json` and `.../R1.htm`. Add the ticker to `tests/fixtures/companies_golden.csv` too,
   so the offline golden test loads it. Then
   `uv run python scripts/record_fixtures.py --out tests/fixtures/edgar --manifest tests/fixtures/manifest.txt`.
   It skips files already recorded, runs at 4 requests per second and stops on 403. Files over 1 MB are
   stored as `.gz`.
7. **Backfill the new tickers only:** `uv run sec-filings backfill --ticker NFLX --ticker ORCL`.
   Cost: a few hundred small requests for 10 to 15 companies, budget 6000 (see `backfill.md`). Never run a
   plain `sync` as a stand-in; it would also onboard the new tickers but is not limited to them.
8. **Golden queries.** For each new company pick one annual period, look at the filing itself on EDGAR,
   and add to `src/sec_filings/golden_queries.yml`: `id`, `company_id`, `report_kind`, `fiscal_year`,
   `fiscal_period`, `expected_canonical_accession` (copy the style of existing entries). Take the
   accession from the filing, not from our table, otherwise the test proves nothing. Add the fact to
   `tests/golden/filings.yml` as well when the entry is non-trivial.
9. **Decisions.** Add a `DECISIONS.md` entry for anything new: a joint registrant, a shell history, a
   fiscal-year convention that is odd, a foreign filer with a 10-K history. If you are unsure, add the entry
   with your proposed answer and stop.
10. **Verify.** `uv run sec-filings verify` and `uv run sec-filings check`.

## Evidence the agent must show

- The `verify` block ending `RESULT: OK`, zero red.
- `uv run sec-filings show TICKER YEAR` for one period of each new company (for a foreign filer, a
  `-q 1` call showing the "no quarterly report" answer too).
- The diff of `companies.csv`, `companies.yml`, the golden entries, and any DECISIONS.md entry.
- A list of new ambers and why each is expected (unreviewed company, C8 declared-year disagreement).
