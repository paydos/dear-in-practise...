# Runbook: backfill

`backfill` loads full history (every history page, every concept file); `sync` is the cheap daily
incremental. Backfill is idempotent: rows are upserted by accession number, nothing is deleted.

## When

- First load of an empty database (`sync` does this by itself).
- New tickers: `sync` also loads any ticker not yet in the database with the backfill budget, but
  use `backfill --ticker` so you control the scope.
- A gap: C3 red with "no daily index reconciled in the last 30 days", or runs missed for weeks.
- C5 coverage drift on one company, after a parser fix.

## Cost

A company costs one submissions request, one per extra history page, plus ticker file, concept
files and cover pages for recent annual reports. The 20-company load is a few hundred small requests
at 4 per second (minutes). Budget: `backfill_request_budget` 6000 requests per run, sync budget 200;
exceeding it stops the run cleanly (the C2 message says so). JPMorgan has the largest history.

## How to limit

```
uv run sec-filings backfill --ticker NFLX --ticker ORCL    # only these; -t is the short form
uv run sec-filings backfill                                # everything in companies.csv
```

Tickers must exist in `companies.csv`. Offline, with recorded files: set
`SEC_FIXTURES_DIR=tests/fixtures/edgar` first (no network).

## After

Run `uv run sec-filings verify`. Row counts for the backfilled tickers must not fall (C6), and the
summary line shows new, updated and unchanged counts. A concurrent run is skipped by the advisory lock
(`skipped_locked`, exit 1); wait for it rather than forcing.
