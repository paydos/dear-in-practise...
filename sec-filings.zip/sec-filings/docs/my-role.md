# My role

I did not write the code; the brief asks to use agents as at work, and I did. My job was to set direction, demand evidence before trusting anything, and make the calls the agents could not. These are the interventions that changed the outcome, in order.

1. **Research before planning.** I asked for the brief, the company and current agentic practice to be researched before any plan. That surfaced the traps in the ticker list (Exxon's new CIK, five foreign filers, Apple 2009) before a line of code.
2. **Two reviews of the plan before building.** I asked for the plan to be validated, then traced line by line against the brief. The first review replaced "latest filed wins" with "latest complete version" and added an external heartbeat. The second found that `companies.csv`, the brief's own file, had been made read-only, so the obvious way to add companies would not have worked.
4. **How agents were used.** Opus to plan, contract and review; Sonnet subagents to build from written briefs; a fresh, read-only reviewer to try to break it; fresh agents to test the handover kit. I asked side questions about the process with `/btw` as the work ran, so I understood each step without stopping it.
5. **The live run only after the offline build.** No live SEC traffic until the offline build and its tests were complete and I had approved going live.
6. **Independent review after the build.** I asked for a critical assessment against the brief, as a grader would make it. Three fresh reviewers found, among other things, morning-check situations that showed green when something was wrong, half-pages twice too long, and a confidentiality leak in the logs. All were fixed before submission.
7. **What I share.** The written record of the work rather than the raw session logs, which mix in unrelated material (D-15). The diagrams in `how-it-was-built.md` show the setup.

Where the trust log credits an agent with a catch, that is accurate: my contribution was the process that made those catches happen, and the decision on each one.
