# Handover evaluation (PLAN.md 10.4)

Each trial is a fresh agent given only its one-line task, a copy of the repository in its own git worktree, its own database, and machine notes (how to reach uv and Python on this computer). No agent was told the handover kit exists. Each was scored by the orchestrator from what it changed, what it ran, and its final message.

Scope note: the plan called for three runs per scenario on two models. To control cost, three trials were run once each. The two S1 trials were stopped by the orchestrator before they wrote their final report, so they are scored on the work they left behind.

| Trial | Model | Task | Result |
|-------|-------|------|--------|
| S3 | Sonnet 5.5 | "This morning's check is red. Find out why and tell me what to do." Two faults injected: a deleted Apple NT 10-K row (C6) and a daily-index day listing a filing that does not exist (C3). | **Pass.** |
| S1 | Sonnet 5.5 | "Add NFLX, ORCL, BP, RIO and SONY to the tracker, then prove it worked." Empty database, live SEC. | **Pass on behaviour, unfinished.** Stopped before the final evidence block. |
| S1 | Haiku 5.5 | Same task. | **Pass on behaviour, unfinished.** Stopped before the final evidence block. |

## S3, diagnose a red check (Sonnet): pass

- Found and used the `investigate-red-check` skill and the backfill runbook without being told they exist.
- C6: identified the missing row as `0001104659-06-081617` and noted it was deleted outside the pipeline, which the rules forbid. Restored it with a scoped `backfill -t AAPL` (1 new, 137 unchanged). C6 turned green.
- C3: traced the reconciliation row to something outside any sync (no run id, written between two checks). Established that the accession appears in no SEC source. Refused to edit data to make the check green and escalated to a person.
- **Gap:** it did not paste the `verify` or `check` output at the end. Kit fixed: diagnosis tasks now end with the current `check` or `verify` output (AGENTS.md, definition of done).

## S1, add five companies (Sonnet and Haiku): strong behaviour, unfinished

Both agents, independently:
- Added the five tickers to `companies.csv`, wrote reviewed entries in `companies.yml`, recorded fixtures, and added golden queries.
- **Found Oracle's predecessor CIK.** Oracle's history before 2006 sits under CIK 777676; the ticker file knows only 1341439. Both wrote it up as a proposed decision. The Haiku agent loaded only the new CIK and stopped for a person on the boundary date, as the runbook says to do.
- **Found Rio Tinto's two registrants**, and a pair of separate paper-era 20-F stubs from 2002 (`9999999997-02-024574` and `-024578`) that turned C7 red. The Sonnet agent proposed a reviewed override. The Haiku agent laid out two options and left the choice to a person.
- **Found a real defect in the job.** Oracle files its 10-Qs 10 to 13 days after quarter end. The 14-day period rule (contract 12.2) moved those periods back a quarter, so C7 and C9 went red. Both agents traced the cause and fixed it in `domain/labels.py` with tests. The two fixes differed. The orchestrator ported the Haiku agent's fix, because it is the more principled one: a quarterly period that is a real fiscal quarter end before the filing date is kept (trust log T-14, decision D-21).

**Not completed:** neither trial reached its final `verify` evidence block before being stopped. The Oracle and Rio Tinto decisions remain proposals; the five companies were not merged into the main repository, which keeps the brief's 20.

## What the trials changed in the kit

1. Definition of done: diagnosis tasks end with `check`/`verify` output (from S3).
2. The period rule for quarterly reports (D-21, T-14), from S1.
3. The add-companies runbook already told agents to stop for a person on predecessor CIKs; both S1 agents did. No change needed.
