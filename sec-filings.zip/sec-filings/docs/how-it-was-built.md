# How it was built

I directed the work; agents did it. The brief asks to "use agents, exactly as you would at work", so this page shows the setup I used, who did what, and where the work came back to me. It is the map for [`agent-log.md`](agent-log.md) (every delegation and what came back) and [`trust-log.md`](trust-log.md) (every error that was caught).

![Agentic development: who did what](diagrams/agentic-development.svg)

## Roles

| Role | Who | What it did |
|------|-----|-------------|
| **Director** | Me | Set the goal and the standard; studied the domain; made the scope and data calls (D-01, D-09); approved the plan, the live run and every fix round; asked for the independent reviews. Asked side questions about the process with `/btw` while agents kept working, so learning never stopped the build. |
| **Research and planning** | Claude Fable, then Opus 5.5 | Researched In Practise, SEC EDGAR and current agentic practice; wrote `PLAN.md`; then two critiques of the plan at my request: a validation review and a line-by-line trace against the brief. |
| **Orchestrator** | Claude Opus 5.5 (main session) | Wrote the frozen contracts and every brief; ran the spike; delegated; re-ran tests and checked surprising claims against the SEC itself after every hand-back; wrote the reviewed overrides; kept the logs. |
| **Advisor** | A stronger reviewer model | Consulted by the orchestrator before committing to an approach and before declaring a phase done. It caught, among others, the default User-Agent about to ship an employer address, and the Stop hook that would have trapped a grader's agent. |
| **Builders** | Claude Sonnet 5.5 subagents | Scaffold; three parallel builders on disjoint files (SEC client, domain rules, repository and checks); integration; fixtures; reconciliation against EDGAR; three fix rounds; handover kit; MCP server; first drafts of the reviewer pack. Each reported its model ID and pasted its test output. |
| **Independent reviewers** | Claude Opus 5.5, fresh context, read-only | Never saw the conversation. One review after the live run (14 findings) and a final round of three: a grader simulation, a resilience review told to break the job, and a consistency and privacy review. |
| **Fresh-agent trials** | Sonnet 5.5 and Haiku 5.5, in isolated git worktrees | Given only the repository and one task, to test the handover kit. They found a real defect (Oracle, T-14). |

## The loop

![The back-and-forth, phase by phase](diagrams/agentic-loop.svg)

Every delegation followed the same loop:
1. **Brief:** the orchestrator wrote a complete brief: goal, files allowed and forbidden, environment, the command that proves the work, what to return.
2. **Build:** a Sonnet subagent built against the frozen contracts in `docs/contracts.md`.
3. **Hand-back:** the subagent returned its model ID, its test output, and the places it had to interpret the contract.
4. **Verify:** the orchestrator re-ran the tests and checked every surprising claim against the source, for example Walmart's declared fiscal years and Plug Power's restated 10-K.
5. **Record:** findings went into the trust log; design changes into a numbered contract amendment or a decision, never silently into code.
6. **Decide:** anything that was a judgement call came back to me.

Alongside the loop, I asked side questions with `/btw` (how a check worked, why a rule was chosen, what an agent was doing) without interrupting the work in progress.

## Guardrails in the repository

These are the same things a fresh agent gets, so the way the build was run is also the way the job is handed over.
- `AGENTS.md` and `CLAUDE.md`: instructions, non-negotiables, definition of done.
- `.claude/agents/`: the three roles used in the build (implementer on Sonnet, reviewer on Opus, lookup on Haiku).
- `.claude/skills/`: two skills the agents wrote for whoever runs the job next: `add-companies` and `investigate-red-check`.
- A Stop hook (`scripts/stop_hook.py`) that will not let an agent finish while tests fail or a check is red, but never traps it when no database is available.
- `DECISIONS.md`: every open question decided, with the reason. Agents are told to add an entry and stop rather than guess.

## What it cost

Output tokens by model across the whole project (each message counted once): see [`agent-usage.md`](agent-usage.md). Sonnet did most of the writing; Opus did less writing and more reading, checking and deciding.

```mermaid
flowchart TB
  D["Director: me<br/>goals, decisions, approvals"]
  P["Research and planning<br/>Fable, then Opus<br/>PLAN.md + two plan reviews"]
  O["Orchestrator: Opus 5.5<br/>contracts, briefs, verification"]
  A["Advisor<br/>stronger reviewer model"]
  subgraph B["Builders: Sonnet 5.5 subagents"]
    B1["SEC client"]
    B2["Domain rules"]
    B3["Repository + checks"]
    B4["Integration, fixtures,<br/>fix rounds, kit, MCP"]
  end
  R["Independent reviewers<br/>Opus 5.5, fresh, read-only"]
  T["Fresh-agent trials<br/>Sonnet + Haiku, git worktrees"]
  L[("Trust log, agent log,<br/>DECISIONS.md")]
  D -- "goal, brief, scope calls" --> P
  P -- "plan for approval" --> D
  D -- "approved plan" --> O
  O <-- "before committing, before done" --> A
  O -- "written briefs" --> B
  B -- "code + test output" --> O
  O -- "build to review" --> R
  R -- "findings" --> O
  O -- "kit to test" --> T
  T -- "results, defects" --> O
  O -- "judgement calls, status" --> D
  D -. "/btw side questions,<br/>work keeps running" .-> O
  O --> L
```

(The Mermaid block above is the same structure as the first image, for viewers that render Mermaid.)
