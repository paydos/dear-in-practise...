-- Reproduces every figure in docs/analyst-answer.md.
-- Window: fiscal years ending 2016-11-01 to 2026-10-31 (decision D-13).
-- Run against the job's database, e.g.  psql "$DATABASE_URL" -f docs/analyst-answer.sql

-- 1. Annual reports in the window, and where each deadline's filer category came from.
SELECT category_source, count(*) AS annual_reports
FROM expected_filing
WHERE report_kind = 'annual'
  AND period_end_estimate BETWEEN DATE '2016-11-01' AND DATE '2026-10-31'
GROUP BY category_source;

-- 2. Annual reports filed late (lateness measured on the original filing, D-18 and D-19).
SELECT company_id, fiscal_year, original_accession, original_filing_date,
       due_date, due_date_with_extension, nt_filed, filer_category_used, category_source
FROM v_annual_reports
WHERE filed_late
  AND period_of_report BETWEEN DATE '2016-11-01' AND DATE '2026-10-31'
ORDER BY company_id, fiscal_year;

-- 3. Correction events: non-reliance 8-Ks (item 4.02) and cover-page error-correction flags.
SELECT company_id, event_type, source_accession, event_date,
       corrected_in_accessions, link_confidence, pre_merger_shell
FROM correction_event
WHERE event_date BETWEEN DATE '2016-11-01' AND DATE '2026-12-31'
ORDER BY event_date;

-- 4. Every amendment to an annual report in the window, with its scope and kind.
SELECT company_id, form, filing_date, accession_number, fiscal_year,
       amendment_scope, amendment_kind, kind_evidence
FROM filing
WHERE form_family = 'annual_amendment'
  AND period_of_report BETWEEN DATE '2016-11-01' AND DATE '2026-10-31'
ORDER BY company_id, filing_date;

-- 5. Late notices (NT 10-K, NT 20-F) filed in the window.
SELECT company_id, form, filing_date, accession_number, period_of_report
FROM filing
WHERE form_family = 'late_notice'
  AND (form LIKE 'NT 10-K%' OR form LIKE 'NT 20-F%')
  AND filing_date >= DATE '2016-11-01'
ORDER BY filing_date;

-- 6. Quarterly reports flagged late (outside the question, for context).
SELECT e.company_id, e.fiscal_year, e.fiscal_period, e.category_source,
       e.due_date_with_extension, f.filing_date
FROM expected_filing e
LEFT JOIN filing f ON f.accession_number = e.matched_accession
WHERE e.report_kind = 'quarterly' AND e.status = 'received_late'
  AND e.period_end_estimate >= DATE '2016-11-01'
  AND e.category_source <> 'current'
ORDER BY e.company_id, e.fiscal_year, e.fiscal_period;
