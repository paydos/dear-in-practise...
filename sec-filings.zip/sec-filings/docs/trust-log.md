# Trust log

Raw material for `what-i-didnt-trust.md`. One entry per thing an agent claimed that turned out wrong or unproven. Entries are added the moment the problem is found, with the evidence. Nothing here is staged.

Format: what was claimed, what was true, how it was found, what it was checked against, what changed as a result.

## T-1. Apple's FY2009 amendment called a "restatement"

- **Claimed (research session, 2026-11-09):** Apple's 10-K/A of 2010-01-25 "restated" fiscal 2009.
- **True:** It re-presented fiscal 2009 after Apple voluntarily adopted new revenue-recognition rules retrospectively. That is a change in accounting principle, not an error correction.
- **Found by:** Reading the 10-K/A's own explanatory note and Apple's Q1 2010 press release.
- **Checked against:** `https://www.sec.gov/Archives/edgar/data/320193/000119312510012091/d10ka.htm`
- **Changed:** Decision D-10. Amendments get a kind (`accounting_change`, not `restatement`), and corrections are tracked as separate events. Golden test for Apple FY2009.

## T-2. Walmart fiscal labels reported as "verified"

- **Claimed:** Walmart's fiscal labels were verified from XBRL.
- **True:** The evidence table showed the cover-page share-count date (Apple showed 2026-10-23), not the period end. The conclusion was right but unproven.
- **Found by:** Noticing the "period_end" column did not match Apple's known 26 September year end.
- **Checked against:** The `dei/EntityCommonStockSharesOutstanding` concept joined to the submissions `reportDate` by accession. Walmart period 2026-01-31 carries `fy=2026`.
- **Changed:** Labels are always checked by joining on accession number to the filing's own period of report.

## T-3. GameStop labelling reported as "verified"

- **Claimed:** GameStop's fiscal naming was verified.
- **True:** Never verified. The first query returned nothing and the second hit a connection reset.
- **Found by:** Re-reading the tool output instead of the summary.
- **Checked against:** Re-run of the same join. GameStop period 2025-02-01 carries `fy=2024`; period 2026-01-31 carries `fy=2025`. GameStop names a year by the year it starts in.
- **Changed:** Decision D-04 (labels from the filing's own cover tags, with a learned convention for older filings).

## T-4. Background EDGAR pull reported as "running"

- **Claimed:** The bulk pull was progressing in the background.
- **True:** It had stalled for 20 minutes, CPU-bound on JPMorgan's history (about 41 extra pages) because of quadratic array appends.
- **Found by:** Checking which files had been saved and the process CPU time, not the status line.
- **Checked against:** The file listing and `Get-Process`.
- **Changed:** Lesson for the build: watch progress evidence, not exit status. Request budgets per run mode (plan 5.2).

## T-5. Exxon history "under the old CIK"

- **Claimed:** Exxon's history is under the old CIK 34088.
- **True:** Incomplete. The Q2 2026 10-Q (`0000034088-26-000093`) is a joint filing listed under both CIKs. The Q3 2026 10-Q (`0002115436-26-000020`) exists only under the new CIK 2115436.
- **Found by:** Comparing both CIKs' recent filings accession by accession.
- **Checked against:** `data.sec.gov/submissions/CIK0000034088.json` and `CIK0002115436.json`.
- **Changed:** Decision D-02 (company has a CIK history) and the `filing_cik_alias` table.

## T-6. The plan built its restatement rule around the wrong Plug Power filing

- **Claimed (PLAN.md revision 2.1, by the orchestrator):** Plug Power's FY2020 10-K/A of 2022-03-14 carried the restatement announced in its 4.02 notice of 2021-03-16. The plan widened the linking window to 24 months because that amendment came 363 days after the notice.
- **True:** The restated FY2020 numbers are in the ORIGINAL 10-K filed 2021-05-14 (`0001558370-21-007147`), which carries restatement tagging throughout (482 mentions of "restat", `RestatementAdjustmentMember`). The 2022 amendment is a full document that restates nothing.
- **Found by:** The spike subagent read the amendment's explanatory note. The orchestrator then confirmed it by fetching the original 10-K's text.
- **Checked against:** Both filings on EDGAR.
- **Changed:** Contract amendment 2 (11.2). Events now link to the first original report after the notice and to amendments within 120 days. The 2022 amendment is no longer called a restatement.

## T-7. The cover-tag design would have downloaded about 4 GB

- **Claimed (the plan review and PLAN.md revision 2.1):** reading each filing's own XBRL instance costs "roughly two requests per filing", a few thousand requests and 10 to 15 minutes.
- **True:** The request count was right (about 2,159), but the instances average about 4 MB. A backfill would move roughly 4 GB, against the SEC's rule to download only what is needed.
- **Found by:** The spike subagent measured instance sizes while recording fixtures.
- **Checked against:** Fixture sizes and the `size` field in the submissions data.
- **Changed:** Contract amendment 2 (11.1). Labels come from one small concept file per company. Cover facts come from the small rendered cover page, fetched only for the analyst window and amendments. Scope comes from the filing index. A backfill drops to a few hundred small requests.

## T-8. "The company's own declared label is the most reliable source" was wrong

- **Claimed (D-04 and contract tier 1, by the orchestrator):** a filing's declared fiscal year (`DocumentFiscalYearFocus`) is the company's own statement, so it should win.
- **True:** Companies changed how they declare it. Walmart declared the years ending 2010-01-31 to 2014-01-31 by their start year, then switched to the end year from 2015 (12 filings against 5). Toyota did the same until 2017 (9 against 6). Taking each label at face value produced two different Walmart reports called "fiscal 2009", and `show WMT 2009` answered with the wrong one.
- **Found by:** The first end-to-end offline run. Check C9 went red on Walmart FY2014 and Toyota FY2017. The integration builder traced it. The orchestrator confirmed it by listing every declared year against its period end from the recorded concept files.
- **Checked against:** `companyconcept/.../dei/EntityCommonStockSharesOutstanding.json` for both companies, joined to the submissions period ends.
- **Changed:** Contract amendment 3 (12.1). Each company's majority convention is applied consistently to the period end. Declared labels that disagree are kept in their own column and shown amber by C8. A new C7 rule turns red if two original reports ever share one label again.

## T-9. Raw payloads keyed by content lost their URL

- **Claimed (contract section 3, by the orchestrator):** storing raw responses by sha256 deduplicates storage.
- **True:** Identical bodies from different URLs, such as every empty 404, collapsed into one row under the first URL. Looking up "the latest payload for this URL" then failed or returned nothing.
- **Found by:** The integration builder during the end-to-end run.
- **Changed:** Contract amendment 3 (12.4). Bodies stay content-addressed; a new `raw_fetch` table records every URL fetched.

## T-10. Removing a "hypothetical" rule broke a real case

- **Claimed (contract amendment 2, by the orchestrator, after builder B's note):** the rule "a period on or after the filing date minus 7 days is unreliable" only risked mis-correcting a hypothetical 10-K/A filed within a week of its period end, so it was removed.
- **True:** That case cannot happen, because the original must be filed first. The rule was needed: Apple's 1997 10-Q/A carries its filing date as its period. Separately, builder B's implementation only compared periods with year ends from two years before to one year after the filing, so Toyota 20-F/As filed in 2024 for fiscal 2021 were moved to fiscal 2023.
- **Found by:** Checks C7 and C8 in the first end-to-end run, traced by the integration builder.
- **Changed:** Contract amendment 3 (12.2). The rule is reinstated at 14 days and applies to every family, and year-end distance compares month and day regardless of year.

## T-11. Exhibit-only amendments became "the answer"

- **Claimed (contract 11.1, by the orchestrator):** an amendment with more than 6 rendered report files contains financial statements, so it is complete. The fixtures subagent had confirmed it on every golden case.
- **True:** In the live data, 10 amendments that only add exhibits or Part III were judged complete (Coca-Cola, GE 2009, two Toyota, GameStop 2011 and 2019, Microsoft, Tesla, Plug 2014, AT&T 2014). Because complete means canonical, three-page add-ons became the answer for their year. The golden cases were all clean examples, so the rule was never tested on a messy one.
- **Found by:** The reconciliation subagent, reading each amendment's cover description and explanatory note in the live run.
- **Checked against:** The amendments' cover pages and filing indexes on EDGAR (`docs/reconciliation.md`, task 4).
- **Changed:** The cover page's amendment description now vetoes "complete" when it names exhibits, Part III or a cover fix. Each of the 20 amendments since 2009 is re-checked against the reconciliation's reading.

## T-12. Old reports judged late with today's filer category

- **Claimed (the expected-filing calendar):** lateness uses the category on the filing's own cover, else the previous annual's, else today's.
- **True:** Cover pages are only fetched inside the analyst window, so for 2009 to 2015 quarterly reports the chain fell through to today's category. 12 of 16 "received late" rows were wrong, for example Plug Power FY2009 and FY2010 and Tesla 2011 Q2, judged as large accelerated filers when they were not.
- **Found by:** The reconciliation subagent recomputed the deadlines by hand and checked six of them against the filings' covers.
- **Changed:** For quarterly reports the chain now uses the previous annual report's public-float estimate before falling back to today. Rows still judged with today's category are marked low confidence and excluded from "filed late" claims.

## T-13. A subagent broke the download rule it was given

- **What happened:** The reconciliation subagent was told never to download a primary document over 5 MB, and to use a byte-range request. The SEC ignores range requests on `.htm` files, so one request pulled SAP's full 12 MB 20-F.
- **Found by:** The subagent reported it itself.
- **Changed:** Noted. The job never downloads primary documents, so production is unaffected. Instructions to future agents say to check `size` before any document fetch, not to rely on byte ranges.

## T-14. "No periodic report is filed within two weeks of its period end" was wrong

- **Claimed (contract 12.2, by the orchestrator, when fixing T-10):** a period on or after the filing date minus 14 days is unreliable for every family.
- **True:** Oracle files its 10-Qs 10 to 13 days after the quarter end (for example period 2020-11-30, filed 2020-12-11). The rule moved those periods back a quarter, so Oracle's Q2 was labelled Q1, two originals shared one label (C7 red) and filed periods showed as overdue (C9 red).
- **Found by:** Two fresh handover agents (Sonnet and Haiku) asked to add five companies, independently, when C7 and C9 went red after loading Oracle. Neither company in the original 20 files that fast, so no earlier test could have caught it.
- **Checked against:** Oracle's submissions data and the 10-Qs' own cover tags.
- **Changed:** D-21. A quarterly period that is a real fiscal quarter end and falls before the filing date is kept. The orchestrator ported the Haiku agent's fix and tests; the full suite passes.

## T-15. The log scrub missed client names in the system prompt

- **Claimed (the orchestrator, 2026-11-10):** the shared logs were scrubbed, with a script that re-reads its output and fails if anything listed still appears.
- **True:** The script only checked for the values it was told to remove. The tool's system prompt, repeated in raw request records and reminders, describes the machine's other projects and named clients of the employer (2,111 occurrences). Together with the remaining text, that undid the employer redaction.
- **Found by:** An independent fresh-context reviewer (2026-11-12) searching the exported logs. The orchestrator confirmed the count before acting.
- **Checked against:** A search of every exported file.
- **Changed:** The export was rebuilt to keep only conversation records in the build window, with a separate list of client names that fails the export if any appears. In the end I decided not to share raw logs at all (D-15). Nothing had been pushed or shared.

## T-16. The usage table counted every agent twice

- **Claimed (`docs/agent-usage.md`, by the orchestrator):** "each assistant message is counted once".
- **True:** A resumed session copies the earlier session's messages and subagent logs into a new folder. The script de-duplicated within a file, not across files, so the totals were about double.
- **Found by:** Two independent reviewers, separately.
- **Changed:** Messages are now de-duplicated across all files, and the table is generated from the shared logs, so anyone can reproduce it.

## T-17. Two earlier morning-check fixes over-corrected

- **Claimed (fix round 2):** "C3 no longer stays red forever" and "a skipped duplicate run no longer hides a failed one".
- **True:** The first fix made a missing filing turn green on its own after 30 days, and a test asserted it. The second still let a manual one-company run hide a failed morning sync. The reviewer also found a run several days old, or a crash while writing the report, could leave the check green or amber.
- **Found by:** An independent reviewer told to break the job (2026-11-12), with reproductions on scratch databases.
- **Changed:** Fix round 3: missing filings stay red until found or acknowledged (D-23); only full runs count for C1 and C2; a run older than 26 hours is red; a crash while reporting can no longer hide a red.
## T-18. `show AAPL 2009` reported a correction that was not one

- **Claimed (fix round 3, the answer display):** "the corrected period end is shown, with the SEC's raw value as a note".
- **True:** For annual reports the period-end rule always returns the date snapped to month end, because labels need that, and says separately whether it corrected anything. The display ignored that flag, so Apple's real year end, Saturday 2009-09-26 (a 52/53-week year), was shown as "2009-09-30, corrected". Walmart's genuine correction (the SEC lists the filing date, 2009-04-01) was right, and it was the only case the test checked.
- **Found by:** The orchestrator, reading the output of the final live run from an empty database (2026-11-12) against the README, which still showed 2009-09-26.
- **Changed:** The display uses the SEC's date unless the rule reports a correction. A test pins Apple's 2009-09-26 with no note, next to the Walmart test.
## T-19. Every fresh install failed, while all tests passed

- **Claimed (every test run since P9):** "627 passed".
- **True:** Typer 0.29, released three days before and locked in P9, bundles its own copy of click and no longer installs it. `cli.py` imported `click` directly. The development environment still had click from an older Typer, so every test passed there, while a fresh install from the repository failed on the first command with `No module named 'click'`.
- **Found by:** The clean-copy check: the committed tree exported with `git archive`, installed into a new environment, run with only `DATABASE_URL` set (2026-11-12).
- **Changed:** `cli.py` uses Typer's own exception base; `typer>=0.29` is required; the development environment was re-synced so it matches a fresh install; a test fails if importing the CLI loads click.