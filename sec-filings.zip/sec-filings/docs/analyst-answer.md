# An analyst's question

> "Which of these companies have filed an annual report late, or had to correct one, in the last 10 years?"

**Yes, the table answers it.** "Last 10 years" means fiscal years ending 2016-11-01 to 2026-10-31: 194 annual reports. Every figure comes from [`analyst-answer.sql`](analyst-answer.sql).

**Filed late: one company.** Plug Power, FY2020. Its NT 10-K moved the deadline to 2021-03-16; the 10-K arrived 2021-05-14, 59 days later.

**Had to correct one: two companies, plus a shell.**
- **Plug Power, FY2020.** A non-reliance 8-K (item 4.02) on 2021-03-16. The restated numbers are in that late 10-K.
- **SAP, FY2024.** The 20-F's cover flags an error correction: a prior-year disclosure figure raised by €0.7 billion. No restatement was announced.
- **Lucid's pre-merger shell** (Churchill Capital Corp IV) restated its FY2020 report in May 2021, before the July merger. Lucid itself has corrected nothing. Whether that counts is the analyst's call.

**Not corrections.** Of the window's 29 annual amendments, only the Lucid shell's restates. Plug's 2022 amendment re-files the whole report with no figure changed; the other 27 only add Part III, exhibits, a required disclosure or (Shell, 2025) reissued audit opinions.

**How sure I am.**
- **Lateness: high.** 187 deadlines use the filer category printed on that year's cover; the other 7 are 20-Fs, whose deadline does not depend on it.
- **Restatements: high.** Every 8-K's item codes are read, so no 4.02 notice is missed.
- **Quiet revisions: medium.** Before the cover-page error flag (2023 to 2024), a correction with no 4.02 notice leaves no machine-readable trace.

**What I'd add.** A ground-truth restatement dataset to size that gap, the text of each 4.02 notice, and auditor-change 8-Ks.
