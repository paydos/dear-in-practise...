# Reconciliation of the live backfill against SEC sources

Run date 2026-11-10. Database `sec_live` (read only). Reconciler model: claude-sonnet-5-5.
SEC requests made: **96** (all HTTP 200/206, no 403, at most 4 per second, one process).
One process deviation, disclosed: `sec.gov` ignores `Range` headers on `.htm` primary documents (it returned 200 with the whole body). One request (SAP 20-F `sap-20241224x20f.htm`, 12 MB) therefore downloaded a document above the 5 MB limit. All other primary documents fetched were under 5 MB by `index.json` size (the pre-2009 SAP 20-F is 4.0 MB). `.txt` full-submission files did honour Range (206).

## Summary

| Task | Result |
|---|---|
| 1 Completeness vs EDGAR browse | 0 mismatches in either direction across 9 company/form-type queries (453 accessions). |
| 2 Labels vs covers | 12 of 12 agree. One convention note: Toyota FY2013 (cover DEI says 2012; the database applies its `ends_in` convention and keeps `declared_fiscal_year` = 2012). |
| 3 SAP flag | Confirmed. Cover box ticked and DEI `Error Correction [Flag]` true. The correction is a prior-year remaining-performance-obligation figure. |
| 4 Unresolved amendments | 20 rows. All 20 are administrative. Scope: the database says `full` on 17, 10 of which are wrong (exhibit-only or Part III-only amendments). |
| 5 Late filings | 16 rows. 12 are false positives or doubtful, because the job applied today's filer category to old periods. Verified correct: PLUG FY2020 and PLUG 2021 Q1. AMC unverified (COVID order), PLUG FY2014 borderline. |
| 6 Analyst question | In the window: PLUG, LCID, SAP. |

## 1. Completeness against EDGAR company browse

Source: `https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=<cik>&type=<type>&dateb=&owner=include&count=100&output=atom` (paged with `start=` where 100 rows came back). Database side: `filing` rows with annual, annual_amendment, transition_annual (or the quarterly equivalents) for the company, joined with `filing_cik_alias`. Accession, form and filing date compared.

| Company (CIK) | Type | EDGAR rows | Database rows | Only in EDGAR | Only in database | Form or date differs |
|---|---|---|---|---|---|---|
| Apple (320193) | 10-K | 35 | 35 | 0 | 0 | 0 |
| Apple (320193) | 10-Q | 100 | 100 | 0 | 0 | 0 |
| Exxon (34088 + 2115436) | 10-K | 34 (34088: 34; 2115436: 0) | 34 | 0 | 0 | 0 |
| Toyota (1094517) | 20-F | 43 | 43 | 0 | 0 | 0 |
| GameStop (1326380) | 10-K | 23 | 23 | 0 | 0 | 0 |
| GameStop (1326380) | 10-Q | 67 | 67 | 0 | 0 | 0 |
| Plug Power (1093691) | 10-K | 35 | 35 | 0 | 0 | 0 |
| Plug Power (1093691) | 10-Q | 83 | 83 | 0 | 0 | 0 |
| SAP (1000184) | 20-F | 30 | 30 | 0 | 0 | 0 |

Notes: the new Exxon Holdings CIK 2115436 has no 10-K filings yet on EDGAR, which matches the database. Browse is a prefix match so these counts include 10-K/A, 10-K405, 10-KT and similar; the database covers all of them. Evidence: e.g. https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=320193&type=10-K&dateb=&owner=include&count=100&output=atom

## 2. Labels against cover pages

Seed: `random.Random(20261110)`, stratified draw of 3 post-2009 annual, 3 post-2009 quarterly, 3 pre-2009 annual, 3 pre-2009 quarterly, each from a distinct company not yet drawn (12 companies).

| Company | Accession | Form / filed | Stored FY / period / period of report | Evidence | Verdict |
|---|---|---|---|---|---|
| GE | [0000040545-21-000011](https://www.sec.gov/Archives/edgar/data/40545/000004054521000011/R1.htm) | 10-K 2021-02-12 | 2020 / FY / 2020-12-31 | R1: Dec. 31, 2020, FYFocus 2020, FY | agree |
| GME | [0001326380-21-000032](https://www.sec.gov/Archives/edgar/data/1326380/000132638021000032/R1.htm) | 10-K 2021-03-23 | 2020 / FY / 2021-01-30 | R1: Jan. 30, 2021, FYFocus 2020, FY | agree |
| TM | [0001193125-13-268044](https://www.sec.gov/Archives/edgar/data/1094517/000119312513268044/R1.htm) | 20-F 2013-06-24 | 2013 / FY / 2013-03-31 | R1: Mar. 31, 2013, FYFocus **2012**, FY | period agrees; FY differs from DEI by design (label_source convention, `ends_in`, declared_fiscal_year 2012 retained) |
| CVNA | [0001690820-26-000067](https://www.sec.gov/Archives/edgar/data/1690820/000169082026000067/R1.htm) | 10-Q 2026-10-28 | 2026 / Q3 / 2026-09-30 | R1: Sep. 30, 2026, FYFocus 2026, Q3 | agree |
| WMT | [0000104169-21-000072](https://www.sec.gov/Archives/edgar/data/104169/000010416921000072/R1.htm) | 10-Q 2021-12-01 | 2022 / Q3 / 2021-10-31 | R1: Oct. 31, 2021, FYFocus 2022, Q3 | agree |
| KO | [0000021344-19-000042](https://www.sec.gov/Archives/edgar/data/21344/000002134419000042/R1.htm) | 10-Q 2019-10-24 | 2019 / Q3 / 2019-09-27 | R1: Sep. 27, 2019, FYFocus 2019, Q3 | agree |
| F (pre-2009) | [0000950124-95-000729](https://www.sec.gov/Archives/edgar/data/37996/0000950124-95-000729.txt) | 10-K 1995-03-16 | 1994 / FY / 1994-12-31 | header "CONFORMED PERIOD OF REPORT: 19941231"; cover "fiscal year ended December 31, 1994" | agree |
| SAP (pre-2009) | [0001326932-08-000133](https://www.sec.gov/Archives/edgar/data/1000184/000132693208000133/f01936e20vf.htm) | 20-F 2008-04-02 | 2007 / FY / 2007-12-31 | cover "For the fiscal year ended December 31, 2007" | agree |
| MSFT (pre-2009) | [0001032210-98-001067](https://www.sec.gov/Archives/edgar/data/789019/0001032210-98-001067.txt) | 10-K 1998-09-25 | 1998 / FY / 1998-06-30 | header period 19980630; "FISCAL YEAR ENDED JUNE 30, 1998" | agree |
| XOM (pre-2009) | [0000034088-96-000006](https://www.sec.gov/Archives/edgar/data/34088/0000034088-96-000006.txt) | 10-Q 1996-11-13 | 1996 / Q3 / 1996-09-30 | header period 19960930; "quarterly period ended September 30, 1996" | agree |
| T (pre-2009) | [0000732717-05-000279](https://www.sec.gov/Archives/edgar/data/732717/000073271705000279/q105.htm) | 10-Q 2005-05-06 | 2005 / Q1 / 2005-03-31 | "quarterly period ended March 31, 2005" | agree |
| JPM (pre-2009) | [0000950123-06-013738](https://www.sec.gov/Archives/edgar/data/19617/000095012306013738/y26732e10vq.htm) | 10-Q 2006-11-08 | 2006 / Q3 / 2006-09-30 | "Quarterly Period Ended September 30, 2006" | agree |

Mix: 6 annual (GE, GME, TM, F, SAP, MSFT) and 6 quarterly (CVNA, WMT, KO, XOM, T, JPM); 6 filings dated before 2009-06-15 (F, SAP, MSFT, XOM, T, JPM); 12 distinct companies.
Observation (not an error): for Ford, Microsoft and Exxon the SEC's own header date (1995-06-15, 1998-09-28, 1996-12-10) differs from the stored filing date because the `.txt` header is a reprocessing stamp; the stored dates match the `FILED AS OF DATE` lines (19950316, 19980925, 19961113).

## 3. SAP error-correction flag

Accession [0001104659-25-017815](https://www.sec.gov/Archives/edgar/data/1000184/000110465925017815/0001104659-25-017815-index.htm), 20-F filed 2025-02-27, period 2024-12-31. Database: `correction_event` 10, `cover_error_flag`, link_confidence high, corrected_in = itself; `dei_error_correction_flag` true.

- R1.htm ([link](https://www.sec.gov/Archives/edgar/data/1000184/000110465925017815/R1.htm)): "Error Correction [Flag] true"; "Document Financial Statement Restatement Recovery Analysis [Flag] false"; Amendment Flag false; FYFocus 2024. Confirmed.
- Main document cover (https://www.sec.gov/Archives/edgar/data/1000184/000110465925017815/sap-20241224x20f.htm): the "correction of an error to previously issued financial statements" box is ticked; the clawback-recovery-analysis box is not. So it is an error correction, not a restatement requiring recovery analysis.
- What was corrected: the remaining performance obligations note (transaction price allocated to unsatisfied obligations). Quote: "The prior-year's figure was corrected to reflect an increase of € 0.7 billion". The reason given is premium engagement contracts previously classified as having a termination-for-convenience right. The accounting-policies R page (R50) and the Basis for Preparation page (R8) contain no error-correction wording. The numbers on the income statement, balance sheet, equity and cash flow pages (R2, R4, R5, R6) carry no "restated" wording.
- Assessment: the flag is genuine but the correction is a small prior-year disclosure figure. `v_correction_events` lists it as a correction event, so an analyst should read it as low severity.

## 4. Unresolved amendments since 2009-06-15

Query: `filing` with form_family in (annual_amendment, quarterly_amendment), filing_date >= 2009-06-15, and amendment_scope or amendment_kind null or `unknown`. 20 rows (all have kind `unknown`; 3 also have scope `unknown`). "Size ratio" is the database `size_bytes` of the amendment over its original; note this is the whole submission size, not the document size. "Primary doc" is the amendment's primary document size from `index.json`. "R files" counts `R<n>.htm` pages in `index.json` (0 for pre-2011 filings whose XBRL pre-dates R pages, with `Financial_Report.xls` instead).

The classification columns are mine, from the amendment's own explanatory note. Overrides are not written.

| Company | Form | Filed | Period | Accession | Size ratio | Primary doc (bytes) | R files | Cover amendment description | DB scope/kind | Proposed scope / kind | Confidence | Evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| KO | 10-Q/A | 2009-10-29 | 2009-10-02 | [0001047469-09-009321](https://www.sec.gov/Archives/edgar/data/21344/000104746909009321/0001047469-09-009321-index.htm) | 2.18 | 39,991 | 0 (of 33 files) | none (R1 has no description) | full/unknown | partial / administrative | high | "sole purpose of furnishing the Interactive Data File as Exhibit 101" |
| GE | 10-Q/A | 2009-11-06 | 2009-09-30 | [0000040545-09-000074](https://www.sec.gov/Archives/edgar/data/40545/000004054509000074/0000040545-09-000074-index.htm) | 0.55 | 43,835 | 0 (of 37 files) | none (R1 has no description) | full/unknown | partial / administrative | high | "sole purpose of furnishing an amended Interactive Data File" |
| TM | 20-F/A | 2010-07-22 | 2010-03-31 | [0001193125-10-163251](https://www.sec.gov/Archives/edgar/data/1094517/000119312510163251/0001193125-10-163251-index.htm) | 2.44 | 30,990 | 0 (of 46 files) | none (R1 has no description) | full/unknown | partial / administrative | high | "sole purpose ... to provide Interactive Data File disclosure as Exhibit 101" |
| XOM | 10-K/A | 2011-02-28 | 2010-12-31 | [0001193125-11-050134](https://www.sec.gov/Archives/edgar/data/34088/000119312511050134/0001193125-11-050134-index.htm) | 1.00 | 4,517,327 | 0 (of 139 files) | none (R1 has no description) | full/unknown | full / administrative | high | "inserting the conformed signature of independent auditors"; whole 10-K re-filed |
| TM | 20-F/A | 2011-03-18 | 2010-03-31 | [0000947871-11-000311](https://www.sec.gov/Archives/edgar/data/1094517/000094787111000311/0000947871-11-000311-index.htm) | 0.38 | 1,299,125 | 0 (of 6 files) | n/a (no XBRL cover) | unknown/unknown | partial / administrative | medium | Amendment No. 2: "filed in response to a comment letter"; one MD&A section expanded |
| TM | 20-F/A | 2011-07-20 | 2011-03-31 | [0001193125-11-191732](https://www.sec.gov/Archives/edgar/data/1094517/000119312511191732/0001193125-11-191732-index.htm) | 5.39 | 29,914 | 137 (of 152 files) | none (R1 has no description) | full/unknown | partial / administrative | high | "sole purpose ... Interactive Data File disclosure as Exhibit 101" |
| GME | 10-Q/A | 2011-10-04 | 2011-07-30 | [0001193125-11-263719](https://www.sec.gov/Archives/edgar/data/1326380/000119312511263719/0001193125-11-263719-index.htm) | 5.50 | 75,566 | 44 (of 59 files) | none (R1 has no description) | full/unknown | partial / administrative | high | "solely to furnish Exhibit 101" |
| MSFT | 10-Q/A | 2012-01-27 | 2011-12-31 | [0001193125-12-026864](https://www.sec.gov/Archives/edgar/data/789019/000119312512026864/0001193125-12-026864-index.htm) | 7.64 | 20,584 | 78 (of 93 files) | none (R1 has no description) | full/unknown | partial / administrative | high | "sole purpose of filing the Interactive Data File as Exhibit 101" |
| NVO | 20-F/A | 2012-02-08 | 2011-12-31 | [0001208646-12-000037](https://www.sec.gov/Archives/edgar/data/353278/000120864612000037/0001208646-12-000037-index.htm) | 1.00 | 283,212 | 0 (of 10 files) | n/a (no XBRL cover) | unknown/unknown | full / administrative | high | "filed ... due to an administrative error"; replaces original "in its entirety" |
| TSLA | 10-K/A | 2012-03-28 | 2011-12-31 | [0001193125-12-137560](https://www.sec.gov/Archives/edgar/data/1318605/000119312512137560/0001193125-12-137560-index.htm) | 1.66 | 231,387 | 83 (of 98 files) | The purpose of this Amendment No. 1 to the Annual Report on Form 10-K of Tesla Motors, Inc. for the period end... | full/unknown | partial / administrative | high | "to furnish detail-tagged footnotes in Exhibit 101" |
| NVO | 20-F/A | 2013-06-28 | 2012-12-31 | [0000950103-13-004004](https://www.sec.gov/Archives/edgar/data/353278/000095010313004004/0000950103-13-004004-index.htm) | 5.10 | 2,488,451 | 0 (of 8 files) | n/a (no XBRL cover) | unknown/unknown | partial / administrative | medium | Items 8 and 18 only: adds 2010 equity statement, expands tax note; says it does not restate |
| WMT | 10-Q/A | 2013-10-21 | 2013-07-31 | [0000104169-13-000039](https://www.sec.gov/Archives/edgar/data/104169/000010416913000039/0000104169-13-000039-index.htm) | 0.74 | 1,257,546 | 39 (of 61 files) | The sole purpose of this Amendment No. 1 is to furnish the correct versions of Exhibits 32.1 and 32.2, include... | full/unknown | full / administrative | high | "furnish the correct versions of Exhibit 32.1"; complete 10-Q re-filed |
| PLUG | 10-K/A | 2014-04-22 | 2013-12-31 | [0001193125-14-152721](https://www.sec.gov/Archives/edgar/data/1093691/000119312514152721/0001193125-14-152721-index.htm) | 0.89 | 785,066 | 72 (of 94 files) | none (R1 has no description) | full/unknown | partial / administrative | high | "include all of the Part III information" (Item 15 amended) |
| T | 10-Q/A | 2014-11-10 | 2014-09-30 | [0000732717-14-000134](https://www.sec.gov/Archives/edgar/data/732717/000073271714000134/0000732717-14-000134-index.htm) | 0.84 | 24,222 | 42 (of 61 files) | none (R1 has no description) | full/unknown | partial / administrative | high | "furnishing corrected XBRL Interactive Data Files" |
| GME | 10-K/A | 2016-03-29 | 2016-01-30 | [0001326380-16-000323](https://www.sec.gov/Archives/edgar/data/1326380/000132638016000323/0001326380-16-000323-index.htm) | 0.99 | 2,799,830 | 84 (of 106 files) | none (R1 has no description) | full/unknown | full / administrative | high | "conformed signature of Deloitte"; complete 10-K re-filed |
| GE | 10-Q/A | 2016-11-09 | 2016-09-30 | [0000040545-16-000198](https://www.sec.gov/Archives/edgar/data/40545/000004054516000198/0000040545-16-000198-index.htm) | 1.00 | 3,822,460 | 108 (of 237 files) | none (R1 has no description) | full/unknown | full / administrative | medium-high | table in Note 18 "inadvertently omitted"; "entire Form 10-Q ... re-filed" |
| T | 10-Q/A | 2019-05-07 | 2019-03-31 | [0000732717-19-000021](https://www.sec.gov/Archives/edgar/data/732717/000073271719000021/0000732717-19-000021-index.htm) | 1.02 | 1,881,160 | 61 (of 79 files) | none (R1 has no description) | full/unknown | full / administrative | high | "correct the signature dates and hyperlinks"; no financial changes; full 10-Q re-filed |
| GME | 10-Q/A | 2019-06-12 | 2019-05-04 | [0001326380-19-000110](https://www.sec.gov/Archives/edgar/data/1326380/000132638019000110/0001326380-19-000110-index.htm) | 3.89 | 65,764 | 51 (of 69 files) | The sole purpose of this Amendment No. 1 GameStop Corp’s Quarterly Report on Form 10-Q for the quarterly perio... | full/unknown | partial / administrative | high | "sole purpose ... is to file Exhibit 101" |
| GME | 10-Q/A | 2024-10-25 | 2024-08-03 | [0001326380-24-000160](https://www.sec.gov/Archives/edgar/data/1326380/000132638024000160/0001326380-24-000160-index.htm) | 1.00 | 879,236 | 39 (of 60 files) | none (R1 has no description) | full/unknown | full / administrative | high | "amending the certifications ... correct signatory"; full 10-Q re-filed |
| GME | 10-Q/A | 2024-10-25 | 2024-05-04 | [0001326380-24-000159](https://www.sec.gov/Archives/edgar/data/1326380/000132638024000159/0001326380-24-000159-index.htm) | 1.18 | 723,089 | 37 (of 63 files) | none (R1 has no description) | full/unknown | full / administrative | high | "amending the certifications ... correct signatory"; full 10-Q re-filed |

Findings:
- Every one of the 20 is administrative on the evidence (exhibit 101 XBRL furnishing: 9; certifications, signatures or omitted table: 7; SEC comment-letter or Part III or disclosure expansion: 3; administrative refile: 1). None restates numbers.
- The database scope heuristic is wrong on 10 rows. It labels `full` any amendment whose submission is larger than the original, which happens when the amendment adds XBRL files to an exhibit-only filing: KO 2009-10-29, GE 2009-11-06, TM 2010-07-22, TM 2011-07-20, GME 2011-10-04, MSFT 2012-01-27, TSLA 2012-03-28, PLUG 2014-04-22, T 2014-11-10, GME 2019-06-12 should all be `partial`. (PLUG 2014 is a Part III amendment, a 198 KB text with a 786 KB primary doc.)
- The remaining 7 `full` rows (XOM, WMT, GE-2016, GME-2016, T-2019, GME-2024 x2) and the three `unknown` scopes were fine or resolved above: NVO 2012 full, TM 2011-03 and NVO 2013 partial.
- Side effect to check: 17 of the 20 rows are flagged `is_canonical`, including exhibit-only amendments (for example KO Q3 2009, TSLA FY2011), so the canonical row for that period is a 40 KB exhibit stub rather than the original filing. Only TM 2011-03 and the two NVO rows are not canonical.

## 5. Late filings (`expected_filing.status = 'received_late'`)

16 rows (all years). "Cat source" is the job's `category_source`. "Cover" is the filer category printed on the filing's own cover, where I checked it.

| Company | Period | Kind | Cat used (source) | Job due / with ext. | Matched filing (filed) | NT | Cover category (checked) | My verdict |
|---|---|---|---|---|---|---|---|---|
| AMC | 2020 Q1 | 10-Q | accelerated (previous_cover) | 2020-05-11 / 05-15 | [0001411579-20-000058](https://www.sec.gov/Archives/edgar/data/1411579/000141157920000058/R1.htm) (2020-06-09) | none | Accelerated Filer | late by the plain calendar rule; unverified whether the COVID relief order (Release 34-88318, 45 extra days with an 8-K) applied, which would make it timely |
| CVNA | 2017 Q1 | 10-Q | large_accel (current) | 2017-05-10 / 05-15 | [0001690820-17-000007](https://www.sec.gov/Archives/edgar/data/1690820/000169082017000007/R1.htm) (2017-06-06) | none | Non-accelerated Filer | **job wrong** |
| LCID | 2021 Q2 | 10-Q | large_accel (current) | 2021-08-09 / 08-16 | [0001104659-21-106466](https://www.sec.gov/Archives/edgar/data/1811210/000110465921106466/R1.htm) (2021-08-16) | none | Non-accelerated Filer | **job wrong** (45 days from 06-30 is 08-14, a Saturday, so 08-16) |
| LCID | 2021 Q3 | 10-Q | large_accel (current) | 2021-11-09 / 11-15 | [0001628280-21-023384](https://www.sec.gov/Archives/edgar/data/1811210/000162828021023384/0001628280-21-023384-index.htm) (2021-11-15) | none | not fetched; same registrant, same category expected | probably wrong (45 days is 11-14, a Sunday, so 11-15) |
| PLUG | 2009 FY | 10-K | large_accel (current) | 2010-03-01 / 03-16 | [0001003297-10-000066](https://www.sec.gov/Archives/edgar/data/1093691/000100329710000066/0001003297-10-000066-index.htm) (2010-03-16) | none | Accelerated filer (float $73.3M on the cover) | **job wrong** (75 days is 2010-03-16, the filing date) |
| PLUG | 2010 FY | 10-K | large_accel (current) | 2011-03-01 / 03-16 | [0001003297-11-000114](https://www.sec.gov/Archives/edgar/data/1093691/000100329711000114/0001003297-11-000114-index.htm) (2011-03-31) | none | Non-accelerated (float $38.6M) | **job wrong** (90 days is 2011-03-31, the filing date) |
| PLUG | 2011 Q1 | 10-Q | large_accel (current) | 2011-05-10 / 05-16 | [0001003297-11-000176](https://www.sec.gov/Archives/edgar/data/1093691/000100329711000176/0001003297-11-000176-index.htm) (2011-05-13) | none | not fetched; non-accelerated in the Q2 cover | probably wrong (45 days is 05-15, a Sunday, so 05-16) |
| PLUG | 2011 Q2 | 10-Q | large_accel (current) | 2011-08-09 / 08-15 | [0001003297-11-000292](https://www.sec.gov/Archives/edgar/data/1093691/000100329711000292/R1.htm) (2011-08-11) | none | Non-accelerated Filer | **job wrong** |
| PLUG | 2014 FY | 10-K | large_accel (public_float) | 2015-03-02 / 03-16 | [0001047469-15-002340](https://www.sec.gov/Archives/edgar/data/1093691/000104746915002340/R1.htm) (2015-03-17) | NT 10-K 2015-03-03 | Large Accelerated (float $777M) | borderline: due date 60 days is Sunday 2015-03-01, moved to 03-02; the extension is 15 calendar days after the prescribed date: 03-16 counting from 03-01, 03-17 counting from 03-02. The job picked 03-16; filed 03-17. |
| PLUG | 2020 FY | 10-K | large_accel (cover) | 2021-03-01 / 03-16 | [0001558370-21-007147](https://www.sec.gov/Archives/edgar/data/1093691/000155837021007147/0001558370-21-007147-index.htm) (2021-05-14) | NT 10-K 2021-03-02 | Large Accelerated (DB dei) | **correct** |
| PLUG | 2021 Q1 | 10-Q | large_accel (previous_cover) | 2021-05-10 / 05-17 | [0001558370-21-008486](https://www.sec.gov/Archives/edgar/data/1093691/000155837021008486/0001558370-21-008486-index.htm) (2021-06-22) | NT 10-Q 2021-05-10 | Large Accelerated (previous) | correct |
| TSLA | 2010 Q2 | 10-Q | large_accel (current) | 2010-08-09 / 08-16 | [0001193125-10-188792](https://www.sec.gov/Archives/edgar/data/1318605/000119312510188792/0001193125-10-188792-index.htm) (2010-08-13) | none | not fetched; IPO June 2010 so a first-time filer | wrong (a new registrant's first 10-Q is due the later of 45 days after effectiveness and the normal date) |
| TSLA | 2010 Q3 | 10-Q | large_accel (current) | 2010-11-09 / 11-15 | [0001193125-10-259068](https://www.sec.gov/Archives/edgar/data/1318605/000119312510259068/0001193125-10-259068-index.htm) (2010-11-12) | none | not fetched; non-accelerated | wrong (45 days is 11-14, a Sunday, so 11-15) |
| TSLA | 2011 Q1 | 10-Q | large_accel (current) | 2011-05-10 / 05-16 | [0001193125-11-139677](https://www.sec.gov/Archives/edgar/data/1318605/000119312511139677/0001193125-11-139677-index.htm) (2011-05-13) | none | not fetched; non-accelerated | wrong (45 days is 05-15, a Sunday, so 05-16) |
| TSLA | 2011 Q2 | 10-Q | large_accel (current) | 2011-08-09 / 08-15 | [0001193125-11-221497](https://www.sec.gov/Archives/edgar/data/1318605/000119312511221497/R1.htm) (2011-08-12) | none | Non-accelerated Filer | **job wrong** |
| TSLA | 2011 Q3 | 10-Q | large_accel (current) | 2011-11-09 / 11-14 | [0001193125-11-308489](https://www.sec.gov/Archives/edgar/data/1318605/000119312511308489/0001193125-11-308489-index.htm) (2011-11-14) | none | not fetched; non-accelerated | wrong or at best a same-day filing (45 days is 2011-11-14, a Monday) |

Hand recomputation (three required):

1. **PLUG FY2020 10-K** (period end 2020-12-31, large accelerated, 60 days). 31 January + 28 February = 59, so day 60 is Monday 2021-03-01. The NT 10-K was filed 2021-03-02, one business day after the due date, so Rule 12b-25 gave 15 calendar days: 2021-03-16. The 10-K was filed 2021-05-14, 59 days after the extended deadline. **Job right.**
2. **TSLA 2011 Q2 10-Q** (period end 2011-06-30). The cover (R1) says Non-accelerated Filer, so 45 days: 31 July + 14 August, day 45 is Sunday 2011-08-14, moved to Monday 2011-08-15. Filed Friday 2011-08-12, so on time. The job used a 40-day large accelerated date (08-09) taken from the company's current category. **Job wrong.**
3. **CVNA 2017 Q1 10-Q** (period end 2017-03-31). The cover says Non-accelerated Filer, so 45 days gives 2017-05-15. Carvana's IPO became effective in late April 2017 (from memory, not checked), and Form 10-Q General Instruction A.1 gives a new registrant the later of 45 days after the effective date (about 2017-06-12) and the normal date, so a 2017-06-06 filing was on time. The job used 05-10. **Job wrong.**
Extra: PLUG FY2009 and FY2010 were checked against the 10-K covers (accelerated, then non-accelerated). Both were filed exactly on the true deadline.

Root cause: for 12 of the 16 rows `category_source = current`, i.e. the company's present category was applied to a period when it was a smaller or new filer. Rows with `previous_cover` or `cover` sources hold up (PLUG 2020, 2021, AMC, apart from the AMC COVID caveat). Because `v_annual_reports.filed_late` reads this status, the false PLUG FY2009 and FY2010 flags are visible to analysts. A caveat on the PLUG FY2020 view row: `v_annual_reports` shows the canonical accession as the 10-K/A of 2022-03-14 (0001558370-22-003577) with `filed_late` true, while the late filing is the original 10-K 0001558370-21-007147 (the view judges the original, as its comment says, but the accession column shows the amendment).

## 6. Analyst question (database only)

Window: fiscal years ending 2016-11-01 to 2026-10-31. Sources: `v_annual_reports` (filed_late), `correction_event` (matched to the corrected filings' period), and `filing` with amendment_kind = restatement.

| Company | Reason | Accessions |
|---|---|---|
| PLUG | Annual late (FY2020, 10-K filed 2021-05-14, after NT 10-K) | 10-K [0001558370-21-007147](https://www.sec.gov/Archives/edgar/data/1093691/000155837021007147/0001558370-21-007147-index.htm); NT 10-K 0001104659-21-030324; view canonical 10-K/A 0001558370-22-003577 (administrative) |
| PLUG | Correction event (non-reliance 8-K 2021-03-16, medium link) | 8-K [0001104659-21-037184](https://www.sec.gov/Archives/edgar/data/1093691/000110465921037184/0001104659-21-037184-index.htm), corrected in 10-K 0001558370-21-007147 |
| LCID | Correction event (non-reliance 8-K 2021-05-14, high link; the filer was the Churchill Capital Corp IV shell, `pre_merger_shell` true) | 8-K 0001104659-21-066993; corrected in 10-K/A 0001104659-21-067004 and 10-Q 0001104659-21-074484 |
| LCID | Restatement amendment (10-K/A FY2020, full, restatement; shell period) | 10-K/A [0001104659-21-067004](https://www.sec.gov/Archives/edgar/data/1811210/000110465921067004/0001104659-21-067004-index.htm), amends 0001104659-21-036537 |
| SAP | Correction event (cover error-correction flag, FY2024) | 20-F [0001104659-25-017815](https://www.sec.gov/Archives/edgar/data/1000184/000110465925017815/0001104659-25-017815-index.htm) |

Outside the window (not listed above): late annuals PLUG FY2009, FY2010, FY2014 (the first two are false positives per section 5); correction events at AAPL, F, GE x2, JPM x2, TSLA (2005 to 2013); JPM 10-Q/A restatement 0000019617-12-000262. Two caveats: the LCID entries concern the pre-merger shell, so an analyst may want to exclude them; and if the three false late-flags from section 5 were corrected nothing in the window would change, because all of them lie before 2016.
