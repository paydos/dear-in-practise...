# Contracts (frozen for the build)

Written by the orchestrator before any parallel build. Builders implement against this file exactly. If something here is wrong or ambiguous, a builder stops and reports it; it does not change the contract. Changes are made only by the orchestrator, and logged in `docs/agent-log.md`.

Plan references are to `PLAN.md` revision 2.1.

---

## 1. Package and tooling

- Package `sec_filings` under `src/`. Python `>=3.12`. Build backend `hatchling`.
- Runtime dependencies: `httpx>=0.27`, `psycopg[binary]>=3.2`, `typer>=0.12`, `pyyaml>=6`.
- Optional extra `mcp`: `mcp>=1.2`.
- Dependency group `dev`: `pytest>=8`, `pgserver>=0.1.4`, `ruff>=0.6`.
- Console script: `sec-filings = "sec_filings.cli:app"`.
- Pytest markers: `db` (needs Postgres), `live` (touches the network; never run in CI or by builders).
- No `prefect` anywhere.

## 2. Module map and ownership

| Module | Purpose | Owner |
|--------|---------|-------|
| `config.py` | settings from environment | scaffold |
| `models.py` | shared dataclasses (section 4) | scaffold, then frozen |
| `errors.py` | exception classes (section 5) | scaffold, then frozen |
| `db/migrations/001_init.sql` | schema (section 3) | scaffold, then frozen |
| `db/connection.py`, `db/migrate.py` | connect, apply migrations | scaffold |
| `edgar/fixtures.py` | URL to fixture path | scaffold |
| `edgar/client.py` | HTTP client | builder A |
| `edgar/tickers.py`, `edgar/submissions.py`, `edgar/cover_tags.py`, `edgar/daily_index.py` | parsers and URL builders | builder A |
| `domain/forms.py`, `domain/labels.py`, `domain/amendments.py`, `domain/deadlines.py`, `domain/expected.py`, `domain/corrections.py` | pure rules, no I/O | builder B |
| `db/repo.py` | reads and writes | builder C |
| `checks/core.py`, `checks/report.py` | morning check | builder C |
| `companies.py` | read `companies.csv` and `companies.yml` | integration |
| `flows.py`, `cli.py` | entry points | integration |
| `mcp_server.py` | read-only server | later phase |

Builders A, B and C only create or edit files they own, plus tests under `tests/unit/<their area>/` and `tests/integration/<their area>/`.

## 3. Database schema (DDL is authoritative)

```sql
-- 001_init.sql
CREATE TABLE IF NOT EXISTS schema_migrations (
  version     text PRIMARY KEY,
  applied_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE company (
  company_id                 text PRIMARY KEY,            -- ticker as given in companies.csv
  name                       text,
  is_foreign_private_issuer  boolean NOT NULL DEFAULT false,
  fiscal_year_end_mmdd       text,                        -- e.g. '0926', from the latest submissions JSON
  filer_category_current     text,                        -- raw text from submissions JSON 'category'
  fy_naming_convention       text NOT NULL DEFAULT 'unknown'
                             CHECK (fy_naming_convention IN ('ends_in','starts_in','unknown')),
  pre_merger_until           date,
  reviewed                   boolean NOT NULL DEFAULT false,   -- true when companies.yml has an entry
  notes                      text,
  updated_at                 timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE company_cik (
  company_id  text NOT NULL REFERENCES company(company_id),
  cik         bigint NOT NULL UNIQUE,
  valid_from  date,
  valid_to    date,
  source      text NOT NULL CHECK (source IN ('ticker_file','manual','successor_8k')),
  note        text,
  PRIMARY KEY (company_id, cik)
);

CREATE TABLE company_name_history (
  cik         bigint NOT NULL,
  name        text NOT NULL,
  valid_from  date,
  valid_to    date,
  PRIMARY KEY (cik, name)
);

CREATE TABLE run (
  run_id         uuid PRIMARY KEY,
  started_at     timestamptz NOT NULL,
  finished_at    timestamptz,
  mode           text NOT NULL CHECK (mode IN ('sync','backfill','check')),
  status         text NOT NULL CHECK (status IN ('running','success','partial','failed','skipped_locked')),
  http_requests  integer NOT NULL DEFAULT 0,
  http_errors    integer NOT NULL DEFAULT 0,
  rows_inserted  integer NOT NULL DEFAULT 0,
  rows_updated   integer NOT NULL DEFAULT 0,
  rows_unchanged integer NOT NULL DEFAULT 0,
  companies_ok     text[] NOT NULL DEFAULT '{}',
  companies_failed text[] NOT NULL DEFAULT '{}',
  error_summary  text,
  git_sha        text
);

CREATE TABLE raw_payload (
  sha256      text PRIMARY KEY,
  url         text NOT NULL,
  first_fetched_at timestamptz NOT NULL,
  last_fetched_at  timestamptz NOT NULL,
  run_id      uuid REFERENCES run(run_id),
  http_status integer NOT NULL,
  body_gzip   bytea NOT NULL
);
CREATE INDEX raw_payload_url ON raw_payload(url, last_fetched_at DESC);

CREATE TABLE filing (
  accession_number        text PRIMARY KEY,               -- '0000320193-25-000079'
  cik                     bigint NOT NULL,                -- CIK it was first seen under
  company_id              text NOT NULL REFERENCES company(company_id),
  form                    text NOT NULL,
  form_family             text NOT NULL CHECK (form_family IN (
                            'annual','annual_amendment','quarterly','quarterly_amendment',
                            'transition_annual','transition_quarterly',
                            'foreign_current_report','late_notice','non_reliance_8k')),
  filing_date             date NOT NULL,
  acceptance_datetime     timestamptz,
  period_of_report        date,
  fiscal_year             integer,
  fiscal_period           text CHECK (fiscal_period IN ('FY','Q1','Q2','Q3','Q4','H1','H2','OTHER')),
  label_source            text NOT NULL DEFAULT 'none'
                          CHECK (label_source IN ('filing_dei','convention','rule','manual','none')),
  label_confidence        text CHECK (label_confidence IN ('high','medium','low')),
  dei_filer_category      text,
  dei_amendment_flag      boolean,
  dei_amendment_description text,
  dei_error_correction_flag boolean,
  dei_current_reporting_status text,
  dei_non_dei_fact_count  integer,
  cover_tags_fetched      boolean NOT NULL DEFAULT false,
  amends_accession        text REFERENCES filing(accession_number),
  amendment_scope         text CHECK (amendment_scope IN ('full','partial','unknown')),
  amendment_kind          text CHECK (amendment_kind IN ('restatement','accounting_change','administrative','unknown')),
  kind_evidence           text,
  is_canonical            boolean NOT NULL DEFAULT false,
  is_xbrl                 boolean NOT NULL DEFAULT false,
  is_inline_xbrl          boolean NOT NULL DEFAULT false,
  primary_document        text,
  primary_doc_description text,
  size_bytes              bigint,
  items                   text[] NOT NULL DEFAULT '{}',
  file_number             text,
  film_number             text,
  pre_merger_shell        boolean NOT NULL DEFAULT false,
  first_seen_run_id       uuid REFERENCES run(run_id),
  last_seen_run_id        uuid REFERENCES run(run_id),
  last_seen_at            timestamptz,
  is_stale                boolean NOT NULL DEFAULT false,
  CHECK (label_source <> 'none' OR fiscal_year IS NULL)
);
CREATE INDEX filing_company_family ON filing(company_id, form_family, fiscal_year, fiscal_period);
CREATE INDEX filing_cik ON filing(cik);

CREATE TABLE filing_cik_alias (
  accession_number text NOT NULL REFERENCES filing(accession_number),
  cik              bigint NOT NULL,
  PRIMARY KEY (accession_number, cik)
);

-- Raw row counts per history page, for the coverage check (plan C5).
CREATE TABLE history_page (
  cik              bigint NOT NULL,
  page_name        text NOT NULL,
  filing_count     integer NOT NULL,     -- as stated by the SEC in filings.files
  rows_in_payload  integer,              -- rows parsed from the stored raw copy, all forms
  filing_from      date,
  filing_to        date,
  payload_sha256   text REFERENCES raw_payload(sha256),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (cik, page_name)
);

CREATE TABLE report_period (
  company_id             text NOT NULL REFERENCES company(company_id),
  report_kind            text NOT NULL CHECK (report_kind IN ('annual','quarterly')),
  fiscal_year            integer NOT NULL,
  fiscal_period          text NOT NULL,          -- 'FY' for annual
  canonical_accession    text REFERENCES filing(accession_number),
  latest_filed_accession text REFERENCES filing(accession_number),
  original_accession     text REFERENCES filing(accession_number),
  version_count          integer NOT NULL,
  PRIMARY KEY (company_id, report_kind, fiscal_year, fiscal_period)
);

CREATE TABLE correction_event (
  event_id               bigserial PRIMARY KEY,
  company_id             text NOT NULL REFERENCES company(company_id),
  event_type             text NOT NULL CHECK (event_type IN ('non_reliance_8k','cover_error_flag')),
  source_accession       text NOT NULL REFERENCES filing(accession_number),
  event_date             date NOT NULL,
  corrected_in_accessions text[] NOT NULL DEFAULT '{}',
  link_confidence        text NOT NULL CHECK (link_confidence IN ('high','medium','low','none')),
  pre_merger_shell       boolean NOT NULL DEFAULT false,
  UNIQUE (event_type, source_accession)
);

CREATE TABLE expected_filing (
  company_id              text NOT NULL REFERENCES company(company_id),
  report_kind             text NOT NULL CHECK (report_kind IN ('annual','quarterly')),
  fiscal_year             integer NOT NULL,
  fiscal_period           text NOT NULL,
  period_end_estimate     date NOT NULL,
  filer_category_used     text,
  category_source         text CHECK (category_source IN ('cover','previous_cover','current','none')),
  due_date                date NOT NULL,
  due_date_with_extension date NOT NULL,
  status                  text NOT NULL CHECK (status IN ('received','received_late','nt_filed','due_soon','overdue','pending','not_applicable')),
  matched_accession       text REFERENCES filing(accession_number),
  nt_accession            text REFERENCES filing(accession_number),
  PRIMARY KEY (company_id, report_kind, fiscal_year, fiscal_period)
);

CREATE TABLE daily_index_reconciliation (
  index_date     date PRIMARY KEY,
  status         text NOT NULL CHECK (status IN ('ok','missing_filings','not_published')),
  entries_for_us integer NOT NULL DEFAULT 0,
  missing        text[] NOT NULL DEFAULT '{}',    -- accession numbers listed by the SEC but absent here
  run_id         uuid REFERENCES run(run_id),
  checked_at     timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE check_result (
  run_id      uuid NOT NULL REFERENCES run(run_id),
  check_id    text NOT NULL,                       -- 'C1'..'C12' or 'X..' for extended
  check_name  text NOT NULL,
  tier        text NOT NULL CHECK (tier IN ('core','extended')),
  status      text NOT NULL CHECK (status IN ('green','amber','red')),
  message     text NOT NULL,
  observed    text,
  expected    text,
  company_id  text,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX check_result_run ON check_result(run_id);

-- Unique canonical row per report period, enforced at the filing level too.
CREATE UNIQUE INDEX one_canonical_per_period ON filing(company_id,
  (CASE WHEN form_family IN ('annual','annual_amendment') THEN 'annual' ELSE 'quarterly' END),
  fiscal_year, fiscal_period)
  WHERE is_canonical;
```

Analyst views (`v_annual_reports`, `v_quarterly_reports`, `v_correction_events`, `v_amendments`, `v_morning_check`, `v_company_coverage`) go in `002_views.sql`, written in the integration phase.

## 4. Shared dataclasses (`models.py`)

All `@dataclass(frozen=True, slots=True)` unless noted. Dates are `datetime.date`; datetimes are timezone-aware `datetime.datetime`.

```python
FormFamily = Literal["annual","annual_amendment","quarterly","quarterly_amendment",
                     "transition_annual","transition_quarterly",
                     "foreign_current_report","late_notice","non_reliance_8k"]
ReportKind = Literal["annual","quarterly"]
FiscalPeriod = Literal["FY","Q1","Q2","Q3","Q4","H1","H2","OTHER"]
LabelSource = Literal["filing_dei","convention","rule","manual","none"]
Confidence = Literal["high","medium","low"]
Convention = Literal["ends_in","starts_in","unknown"]
FilerCategory = Literal["large_accelerated","accelerated","non_accelerated"]
CheckStatus = Literal["green","amber","red"]

class FormerName:        name: str; valid_from: date | None; valid_to: date | None
class PageRef:           name: str; filing_count: int; filing_from: date | None; filing_to: date | None
class CompanyMeta:       cik: int; name: str; tickers: tuple[str, ...]; fiscal_year_end_mmdd: str | None
                         filer_category: str | None; former_names: tuple[FormerName, ...]
class RawFiling:         # one row of the submissions arrays; every form, not only periodic ones
                         accession_number: str; cik: int; form: str; filing_date: date
                         acceptance_datetime: datetime | None; period_of_report: date | None
                         items: tuple[str, ...]; primary_document: str | None
                         primary_doc_description: str | None; is_xbrl: bool; is_inline_xbrl: bool
                         size_bytes: int | None; file_number: str | None; film_number: str | None
class SubmissionsDoc:    meta: CompanyMeta; filings: tuple[RawFiling, ...]; pages: tuple[PageRef, ...]
class CoverTags:         fiscal_year: int | None; fiscal_period: str | None; document_type: str | None
                         period_end_date: date | None; filer_category: str | None
                         amendment_flag: bool | None; amendment_description: str | None
                         error_correction_flag: bool | None; current_reporting_status: str | None
                         non_dei_fact_count: int
class IndexEntry:        form: str; company_name: str; cik: int; date_filed: date; accession_number: str
class Label:             fiscal_year: int | None; fiscal_period: FiscalPeriod | None
                         source: LabelSource; confidence: Confidence | None
class FetchedResponse:   url: str; status: int; body: bytes; sha256: str; fetched_at: datetime; from_fixture: bool
class Version:           accession_number: str; filing_date: date; acceptance_datetime: datetime | None
                         is_amendment: bool; amendment_scope: str | None     # None for originals
class CanonicalChoice:   canonical_accession: str | None; latest_filed_accession: str
                         original_accession: str | None; version_count: int
class ScopeSignals:      has_financial_facts: bool | None; in_financial_data_sets: bool | None
                         size_ratio: float | None; description_says_full: bool | None
class DueDates:          due: date; due_with_extension: date; basis: str
class CheckResult:       check_id: str; check_name: str; tier: Literal["core","extended"]
                         status: CheckStatus; message: str
                         observed: str | None = None; expected: str | None = None
                         company_id: str | None = None
```

Not frozen (mutable result objects):

```python
@dataclass
class RunResult:   run_id: UUID; mode: str; status: str; started_at: datetime; finished_at: datetime | None
                   http_requests: int; rows_inserted: int; rows_updated: int; rows_unchanged: int
                   companies_ok: list[str]; companies_failed: list[str]; error_summary: str | None
@dataclass
class CheckReport: run_id: UUID; results: list[CheckResult]; exit_code: int; markdown: str
```

## 5. Errors (`errors.py`)

```python
class SecFilingsError(Exception): ...
class ConfigError(SecFilingsError): ...
class SecAccessDenied(SecFilingsError): ...        # HTTP 403. Stops the run. Never retried.
class RequestBudgetExceeded(SecFilingsError): ...
class EdgarHTTPError(SecFilingsError): ...         # non-2xx other than 404, after retries
class ParseError(SecFilingsError): ...
class RunFailed(SecFilingsError): ...              # raised by flows.sync when the job itself fails
class ChecksRed(SecFilingsError):                  # raised by flows.check when any check is red
    def __init__(self, report: "CheckReport"): ...
```

## 6. Configuration (`config.py`)

```python
DEFAULT_USER_AGENT = "<author personal contact>"   # was a placeholder during the build; replaced 2026-11-10 (D-09)

@dataclass(frozen=True)
class Settings:
    database_url: str
    user_agent: str = DEFAULT_USER_AGENT
    requests_per_second: float = 4.0
    sync_request_budget: int = 200
    backfill_request_budget: int = 6000
    fixtures_dir: Path | None = None       # SEC_FIXTURES_DIR; when set, no network at all
    heartbeat_url: str | None = None       # HEARTBEAT_URL
    companies_csv: Path = Path("companies.csv")
    companies_yml: Path = Path("companies.yml")
    reports_dir: Path = Path("reports")

def load_settings(env: Mapping[str, str] | None = None) -> Settings
    # reads DATABASE_URL (required -> ConfigError with a clear message), SEC_USER_AGENT,
    # SEC_FIXTURES_DIR, HEARTBEAT_URL, SEC_REQUESTS_PER_SECOND (capped at 9)
```

## 7. Fixture layout (frozen)

Recorded SEC responses live under `tests/fixtures/edgar/`, mirroring the URL: host, then path. Bodies are byte-exact and decompressed. No query strings are used anywhere.

```
https://data.sec.gov/submissions/CIK0000320193.json
  -> tests/fixtures/edgar/data.sec.gov/submissions/CIK0000320193.json
https://www.sec.gov/Archives/edgar/data/320193/000119312510012091/index.json
  -> tests/fixtures/edgar/www.sec.gov/Archives/edgar/data/320193/000119312510012091/index.json
```

`edgar/fixtures.py`:
```python
def url_to_fixture_path(url: str) -> PurePosixPath   # 'data.sec.gov/submissions/CIK0000320193.json'
```
A URL with no fixture behaves as HTTP 404 in offline mode.

**Amendment 1 (2026-11-10, orchestrator):** a fixture larger than 1 MB may be stored gzipped as `<path>.gz`, containing the gzip of the exact bytes. The offline client reads `<path>` if present, otherwise `<path>.gz` decompressed. `url_to_fixture_path` is unchanged.

## 8. EDGAR layer (builder A)

```python
# edgar/client.py
class EdgarClient:
    def __init__(self, user_agent: str, *, requests_per_second: float = 4.0, request_budget: int = 200,
                 fixtures_dir: Path | None = None, max_retries: int = 3, timeout: float = 30.0,
                 on_response: Callable[[FetchedResponse], None] | None = None,
                 sleep: Callable[[float], None] = time.sleep, clock: Callable[[], float] = time.monotonic,
                 transport: httpx.BaseTransport | None = None): ...
    requests_made: int            # counts network requests and fixture reads alike
    def get(self, url: str) -> FetchedResponse
        # Headers: User-Agent, Accept-Encoding 'gzip, deflate'. Token bucket shared by all calls.
        # 200 -> response. 404 -> response with status 404 (caller decides).
        # 403 -> SecAccessDenied immediately, no retry.
        # 429, 5xx, connect/read errors -> up to max_retries with exponential backoff + jitter, then EdgarHTTPError.
        # budget exceeded -> RequestBudgetExceeded before sending.
        # on_response called for every 200 and 404 (used to store raw payloads).
    def close(self) -> None   # also a context manager

# edgar/tickers.py
TICKERS_URL = "https://www.sec.gov/files/company_tickers.json"
def parse_company_tickers(body: bytes) -> dict[str, tuple[int, str]]   # 'AAPL' -> (320193, 'Apple Inc.')

# edgar/submissions.py
def submissions_url(cik: int) -> str          # https://data.sec.gov/submissions/CIK0000320193.json
def history_page_url(name: str) -> str        # https://data.sec.gov/submissions/<name>
def parse_submissions(body: bytes) -> SubmissionsDoc
def parse_history_page(body: bytes, cik: int) -> tuple[RawFiling, ...]
    # Both parse the columnar arrays. Empty strings become None. 'items' is split on ','.
    # acceptanceDateTime like '2026-11-03T18:01:36.000Z' is parsed as UTC-aware (exact meaning: spike item).

# edgar/cover_tags.py
def filing_index_url(cik: int, accession_number: str) -> str
def pick_instance(index_body: bytes) -> str | None
    # inline XBRL: the '*_htm.xml' file. Older XBRL: the single '.xml' that is not
    # *_cal.xml, *_def.xml, *_lab.xml, *_pre.xml, FilingSummary.xml or an exhibit schema. None if no XBRL.
def instance_url(cik: int, accession_number: str, filename: str) -> str
def parse_cover_tags(xml_body: bytes) -> CoverTags
    # dei namespace varies by year (http://xbrl.sec.gov/dei/2009 ... /2025): match any namespace
    # starting with 'http://xbrl.sec.gov/dei/'. Booleans 'true'/'false'. Integers for DocumentFiscalYearFocus.
    # non_dei_fact_count: elements carrying a contextRef attribute whose namespace is not dei.

# edgar/daily_index.py
def daily_index_url(d: date) -> str           # .../daily-index/2026/QTR4/form.20261102.idx
def full_index_url(year: int, quarter: int) -> str   # .../full-index/2026/QTR4/master.idx
def parse_form_index(body: bytes) -> tuple[IndexEntry, ...]     # fixed-width form.*.idx
def parse_master_index(body: bytes) -> tuple[IndexEntry, ...]   # pipe-delimited master.idx
    # accession number comes from the file name: 'edgar/data/2115436/0002115436-26-000020.txt'
```

## 9. Domain layer (builder B): pure functions, no I/O

```python
# domain/forms.py
def form_family(form: str, items: Sequence[str] = ()) -> FormFamily | None    # plan 6.1 table
def report_kind(family: FormFamily) -> ReportKind | None      # annual*/transition_annual -> 'annual'; quarterly* -> 'quarterly'
def is_amendment(family: FormFamily) -> bool
def original_family(family: FormFamily) -> FormFamily | None  # annual_amendment -> annual, ...
def is_unknown_periodic_form(form: str) -> bool
    # Amendment 1: prefixes '10-K', '10-Q', '20-F', '40-F', '6-K', 'NT 10-', 'NT 20-F', 'NT 40-F'
    # and form_family(form) is None. 'NT 11-K' (employee plans, seen for KO and T) is NOT flagged.

# domain/labels.py
def snap_to_month_end(d: date, tolerance_days: int = 7) -> date
def infer_fiscal_year_end(annual_period_ends: Iterable[date]) -> str | None
    # Amendment 1. Most common month of the snapped period ends, as 'MMDD' using that month's
    # last day ('0331'). Used when the submissions JSON has no fiscalYearEnd (Alibaba).
def effective_period_end(*, family: FormFamily, period_of_report: date | None, filing_date: date,
                         fiscal_year_end_mmdd: str | None) -> tuple[date | None, bool]
    # Amendment 1. Returns (period end to label with, corrected?). Some older annual reports carry the
    # filing date as reportDate (GE 2015-02-27, WMT 2009-04-01, T 2008/2010, NVO 2012, SAP 2004).
    # For annual and annual_amendment families with a known fiscal year end: if period_of_report is
    # None, or on/after filing_date - 7 days, or more than 31 days from every fiscal-year-end date,
    # replace it with the latest fiscal-year-end date (FYE month end) at least 20 days before
    # filing_date, and return corrected=True. Otherwise return (snap_to_month_end(period), False)...
    # NOTE: callers keep the raw period_of_report in the filing table; only labelling uses this.
    # Quarterly families: return (period_of_report, False) unchanged.
def learn_convention(observations: Iterable[tuple[int, date]]) -> Convention
    # (declared fiscal year, period of report) for annual filings. Offset = fy - snapped period year.
    # >= 3 observations, all offset 0 -> 'ends_in'; all -1 -> 'starts_in'; else 'unknown'.
def normalize_fiscal_period(raw: str | None) -> FiscalPeriod | None
def label_filing(*, family: FormFamily, period_of_report: date | None, cover: CoverTags | None,
                 convention: Convention, fiscal_year_end_mmdd: str | None,
                 manual: Label | None = None) -> Label
    # Amendment 1: period_of_report passed in is the EFFECTIVE period end (effective_period_end).
    # A corrected period caps confidence at 'medium' for tiers 2 and 3.
    # Order: manual -> tier 1 filing_dei (plausible: |fy - period.year| <= 1) -> tier 2 convention
    # -> tier 3 rule (assume ends_in) -> none.
    # Families foreign_current_report, late_notice, non_reliance_8k -> source 'none' unless manual.
    # Transition families -> fiscal_period 'OTHER'.
    # Quarter from fiscal year end month: quarter = ((m_period - m_fye - 1) % 12) // 3 + 1,
    # using snapped dates; fiscal-year-end year = period.year if m_period <= m_fye else period.year + 1;
    # label year = fye year + (0 if ends_in else -1).

# domain/amendments.py
def link_amendment(amendment: RawFiling, amendment_label: Label,
                   originals: Sequence[tuple[RawFiling, Label]]) -> str | None
    # same period_of_report -> latest such original filed on or before the amendment;
    # else same (fiscal_year, fiscal_period); else nearest earlier original within 400 days.
def decide_scope(signals: ScopeSignals) -> Literal["full","partial","unknown"]
    # positives: has_financial_facts True, in_financial_data_sets True, size_ratio >= 0.5,
    # description_says_full True. >= 2 positives -> 'full'.
    # has_financial_facts False and size_ratio < 0.25 -> 'partial'. else 'unknown'.
def description_says_full(text: str | None) -> bool | None
def decide_kind(*, scope: str, linked_to_correction_event: bool, cover_error_flag: bool | None,
                manual_kind: str | None) -> tuple[str, str]      # (kind, evidence text)
def select_canonical(versions: Sequence[Version]) -> CanonicalChoice
    # complete = original, or amendment with scope 'full'. Canonical = latest complete by
    # (filing_date, acceptance_datetime). Latest filed = latest of all. Original = earliest original.

# domain/deadlines.py
def normalize_filer_category(raw: str | None) -> FilerCategory | None
def us_federal_holidays(year: int) -> frozenset[date]    # observed dates, rule-based, Juneteenth from 2021
def roll_forward(d: date) -> date                        # to the next business day
def due_dates(*, report_kind: ReportKind, is_foreign: bool, category: FilerCategory | None,
              period_end: date, first_annual_after_listing: bool = False) -> DueDates
    # 10-K 60/75/90, 10-Q 40/40/45, 20-F 4 months (6 if period_end < 2011-12-15).
    # Unknown category -> non_accelerated. Extension +15 annual, +5 quarterly, then rolled.
def timeliness(*, dates: DueDates, filed: date | None, nt_filed: bool, today: date) -> str
    # 'received' | 'received_late' | 'nt_filed' | 'due_soon' (<= 7 days to due) | 'overdue' | 'pending'

# domain/expected.py
@dataclass(frozen=True) class ExpectedFiling: company_id; report_kind; fiscal_year; fiscal_period;
    period_end_estimate; filer_category_used; category_source; due_date; due_date_with_extension;
    status; matched_accession; nt_accession
def build_expected(*, company_id: str, is_foreign: bool, fiscal_year_end_mmdd: str | None,
                   convention: Convention, filings: Sequence[tuple[RawFiling, FormFamily, Label, CoverTags | None]],
                   current_filer_category: str | None, pre_merger_until: date | None, today: date) -> list[ExpectedFiling]
    # One annual per fiscal year and three quarterlies (US only) from the first periodic filing
    # (after pre_merger_until) up to the latest period whose due date is <= today + 7 days.
    # Category: matched filing's cover -> previous annual cover -> current -> none.

# domain/corrections.py
@dataclass(frozen=True) class CorrectionEventDraft: company_id; event_type; source_accession; event_date;
    corrected_in_accessions: tuple[str, ...]; link_confidence; pre_merger_shell: bool
def build_correction_events(*, company_id: str, filings: Sequence[tuple[RawFiling, FormFamily, Label, CoverTags | None]],
                            amendment_scopes: Mapping[str, str], pre_merger_until: date | None) -> list[CorrectionEventDraft]
    # non_reliance_8k: link full-scope amendments filed within 730 days after the event (confidence 'medium');
    # if none, the first original annual filed after the event ('low'); if none, 'none'.
    # cover_error_flag: any periodic filing whose cover flag is True; corrected_in = itself ('high').
```

## 10. Repository and checks (builder C)

`db/repo.py` exposes plain functions taking a `psycopg.Connection`. Signatures are listed in the builder C brief. Checks:

```python
# checks/core.py
@dataclass(frozen=True)
class CheckContext:
    run_id: UUID; today: date; now: datetime
    ticker_map: Mapping[str, int] | None      # current SEC ticker -> CIK, None if not fetched
    tickers_in_csv: Sequence[str]
    golden_queries_path: Path
CORE_CHECKS: tuple[Callable[[psycopg.Connection, CheckContext], list[CheckResult]], ...]   # C2..C12
def run_core_checks(conn, ctx) -> list[CheckResult]
def heartbeat_check(conn, *, now: datetime, deadline_local: time = time(7, 0), tz: str = "Europe/London") -> CheckResult   # C1, run separately

# checks/report.py
def exit_code(results: Sequence[CheckResult], run_failed: bool) -> int   # 3 run failed, 2 red, 1 amber, 0 green
def render_markdown(results: Sequence[CheckResult], run: RunResult | None, today: date) -> str
def ping_heartbeat(url: str, *, timeout: float = 10.0) -> bool
```

---

## 11. Amendment 2 (2026-11-10, orchestrator, after spike part B)

Two spike findings change the design. Both are logged as T-6 and T-7 in `docs/trust-log.md`.

### 11.1 Where cover facts come from (replaces fetching XBRL instances)

Fetching each filing's XBRL instance would download about 4 GB (1,021 instances averaging 4 MB; spike B8). That breaks the fair-access rule "download only what you need". New sources, all small:

| Fact | Source | Request cost |
|------|--------|--------------|
| Fiscal year and period per filing (tier 1 labels) | `https://data.sec.gov/api/xbrl/companyconcept/CIK##########/dei/EntityCommonStockSharesOutstanding.json`: every cover fact carries `accn`, `fy`, `fp`, `form`, `filed` | 1 per CIK |
| Public float per annual filing (filer category estimate) | same endpoint, concept `dei/EntityPublicFloat` | 1 per CIK |
| Filer category as stated, amendment flag and description, error-correction flag | the filing's rendered cover page `.../Archives/edgar/data/<cik>/<acc no dashes>/R1.htm`, only for XBRL annual reports and amendments with fiscal years ending on or after 2016-11-01 (the analyst window), and for every XBRL amendment | about 250 in a backfill |
| Amendment scope signal | the filing's `index.json`: number of rendered report files `R<n>.htm` and file sizes | 1 per amendment |

New and changed functions, builder A:
```python
# edgar/xbrl_concepts.py
def company_concept_url(cik: int, concept: str, taxonomy: str = "dei") -> str
@dataclass(frozen=True) class ConceptLabel: accession_number: str; fiscal_year: int | None
    fiscal_period: str | None; form: str; filed: date; consistent: bool   # False if facts in one accession disagree
def parse_concept_labels(body: bytes) -> dict[str, ConceptLabel]           # accession -> label (mode of its facts)
def parse_public_float(body: bytes) -> dict[str, tuple[float, date]]      # accession -> (USD value, as-of date); USD units only

# edgar/cover_tags.py (additions; pick_instance and parse_cover_tags stay, as a fallback)
def cover_page_url(cik: int, accession_number: str) -> str               # .../R1.htm
def parse_cover_page(html: bytes) -> CoverTags
    # Reads the rendered cover table by row label, case-insensitive, ignoring bracketed suffixes:
    # 'Document Fiscal Year Focus', 'Document Fiscal Period Focus', 'Document Type',
    # 'Document Period End Date', 'Entity Filer Category', 'Amendment Flag', 'Amendment Description',
    # 'Document Financial Statement Error Correction' (flag), 'Entity Current Reporting Status'.
    # non_dei_fact_count = -1 (unknown from this source).
@dataclass(frozen=True) class FilingIndex: files: tuple[tuple[str, int | None], ...]; report_file_count: int
def parse_filing_index(body: bytes) -> FilingIndex                       # report files: R<n>.htm or R<n>.xml
```

Integration rules:
- `ScopeSignals.has_financial_facts = index.report_file_count > 6` (a cover-only amendment renders one to a few reports); `size_ratio` from the submissions `size` of amendment and original; `description_says_full` from the cover page's amendment description; `in_financial_data_sets = None`.
- Filer category for deadlines, in order: the cover page (`cover`), the public float estimate (`public_float`: at least USD 700 million large accelerated, at least 75 million accelerated, else non-accelerated; confidence medium), the previous annual's category (`previous_cover`), today's category (`current`). Migration `002` widens the `category_source` check and adds `filing.cover_source` (`cover_page`, `concept`, `instance`, null).

### 11.2 Correction events link to where the corrected numbers are (replaces section 9 rule)

Plug Power's restated FY2020 numbers are in its ORIGINAL 10-K filed 2021-05-14, two months after its 4.02 notice. Its full-scope 10-K/A of 2022-03-14 restates nothing. The old rule would have linked the amendment and called it a restatement.

- `build_correction_events`, non-reliance 8-K: `corrected_in_accessions` = full-scope amendments filed within 120 days after the event, then the first original annual or quarterly report filed after the event within 730 days. `link_confidence` is `high` when an amendment within 120 days exists, `medium` when only the original is found, `none` otherwise.
- `decide_kind(linked_to_correction_event=...)` is True only when the amendment is in an event's `corrected_in_accessions`.

### 11.3 Smaller domain changes

- `effective_period_end`: correct the period only when it is None or more than 31 days from every fiscal-year-end date. Drop the "on or after filing date minus 7 days" condition: it would wrongly correct a 10-K/A filed within a week of its period end.
- Annual families always get `fiscal_period = 'FY'` (GE's FY2014 cover says `Q4`). Quarterly families keep Q1 to Q3.
- `build_expected` sets `first_annual_after_listing=True` for the company's first expected annual report.

## 12. Amendment 3 (2026-11-10, orchestrator, after the first end-to-end run)

The first offline run of the whole pipeline turned four checks red. Each traced to a design or code defect. Logged as T-8 to T-10 in `docs/trust-log.md`.

### 12.1 Labels: apply the company's convention consistently (domain)

Declared fiscal years change convention mid-history. Walmart declared the year ending 2010-01-31 to 2014-01-31 as the START year (offset -1), then the END year from 2015 (offset 0). Toyota did the same until 2017. Taking each declared label at face value gave two Walmart reports called "fiscal 2009".
- `learn_convention`: majority rule. With at least 3 observations, the offset shared by at least 60 % of them wins (`0` -> `ends_in`, `-1` -> `starts_in`). Otherwise `unknown`.
- `label_filing`, when the convention is known: the fiscal year is always derived from the effective period end with that convention. If the declared fiscal year agrees, source `filing_dei`, confidence `high`. If it disagrees, source `convention`, confidence `medium`. For quarterly filings, the quarter number from the period end wins over a disagreeing declared period. When the convention is `unknown`, use the declared label as before.
- Flows store the declared values in new columns `filing.declared_fiscal_year` and `filing.declared_fiscal_period`, so the disagreement stays visible (check C8, amber).

### 12.2 Period sanity for every family (domain)

- `effective_period_end` treats a period as unreliable when it is None, or on or after `filing_date - 14 days` (no periodic report is filed within two weeks of its period end; Apple's 1997 10-Q/A carries its filing date), or, for annual families, more than 31 days from the fiscal-year-end month-end of ANY year (compare month and day, not a window of years; Toyota's 20-F/A filed 2024 for FY2021 must stay 2021-03-31), or, for quarterly families, more than 31 days from every fiscal quarter end.
- Replacement: annual families get the latest fiscal-year-end at least 20 days before the filing date; quarterly families get the latest Q1 to Q3 quarter end (never the fiscal-year-end quarter) at least 20 days before the filing date.

### 12.3 Expected filings start with tagged data (domain)

`build_expected` only generates fiscal periods ending on or after 2009-06-15. Before that, the filer category cannot be read from filings, so lateness would be judged with today's category (pre-2003 "received late" artifacts), and some early 1990s reports were never on EDGAR. Earlier filings are still stored and labelled. They are just not assessed for lateness.

### 12.4 Storage and checks (db, checks, flows)

- `raw_payload` stays content-addressed by sha256. New table `raw_fetch(url, sha256, fetched_at, run_id, http_status)` records every fetch, so identical bodies from different URLs (every empty 404 body) no longer lose their URL. `latest_raw_payload(url)` reads through `raw_fetch`. Migration `003`.
- C2 judges the latest run of mode `sync` OR `backfill`.
- C3: a latest day that is only `not_published` is amber, not red.
- C4: companies that failed in the judged run are reported amber ("not resolved: company failed this run"), not red.
- C7: also red when a report period contains more than one ORIGINAL (non-amendment) filing. Two originals with one label means the labelling is wrong (E-31).
- C8: additionally amber, one result per company, when `declared_fiscal_year` differs from `fiscal_year` on any row (count and up to 5 examples). Not red: the convention rule chose deliberately.
