# Agent usage

Tokens per model, from the session logs (`scripts/agent_usage.py`). Each assistant
message is counted once. Cache reads are tokens re-read from the prompt cache.

Computed from the full local session logs of the whole project, research to submission, with each message counted once across sessions. The raw logs are not shared (D-15). Claude Fable did the early research and planning; Opus 5.5 orchestrated and reviewed; Sonnet 5.5 subagents built; Haiku 5.5 ran one handover trial.

## By model

| Model | Input | Cache write | Cache read | Output |
|---|---:|---:|---:|---:|
| `claude-sonnet-5-5` | 1,340 | 3,370,914 | 104,555,829 | 812,793 |
| `claude-opus-5-5` | 932 | 5,489,839 | 197,793,915 | 615,003 |
| `claude-fable-5-2` | 14 | 360,730 | 1,257,485 | 70,969 |
| `claude-haiku-5-5` | 116 | 236,633 | 6,730,160 | 59,927 |
| `claude-fable-5-1` | 712 | 160,688 | 2,827,304 | 53,561 |

## By agent

| Kind | Model | Output tokens | First instruction |
|---|---|---:|---|
| session | `claude-opus-5-5` | 300,270 | (main conversation) |
| session | `claude-opus-5-5` | 182,517 | (main conversation) |
| session | `claude-fable-5-2` | 70,969 | (main conversation) |
| session | `claude-fable-5-1` | 53,561 | (main conversation) |
| session | `claude-sonnet-5-5` | 2,034 | (main conversation) |
| session | `claude-opus-5-5` | 1,027 | (main conversation) |
| session | `claude-opus-5-5` | 619 | (main conversation) |
| subagent | `claude-sonnet-5-5` | 163,597 | You are the P4 integration builder for a Python take-home that tracks  |
| subagent | `claude-sonnet-5-5` | 89,746 | You are the fixer for round 2 of a Python take-home that tracks SEC 10 |
| subagent | `claude-sonnet-5-5` | 73,284 | You are fixer X for a Python + Postgres job that tracks SEC filings an |
| subagent | `claude-sonnet-5-5` | 61,047 | You are builder B for a Python take-home that tracks SEC 10-K/10-Q fil |
| subagent | `claude-opus-5-5` | 59,506 | You are an independent senior engineer reviewing a Python + Postgres j |
| subagent | `claude-haiku-5-5` | 58,321 | Add NFLX, ORCL, BP, RIO and SONY to the tracker, then prove it worked. |
| subagent | `claude-sonnet-5-5` | 57,774 | You are builder A for a Python take-home that tracks SEC 10-K/10-Q fil |
| subagent | `claude-sonnet-5-5` | 51,213 | You are the fixture-and-spike subagent for a Python take-home that tra |
| subagent | `claude-sonnet-5-5` | 49,596 | You are builder C for a Python take-home that tracks SEC 10-K/10-Q fil |
| subagent | `claude-sonnet-5-5` | 46,660 | You are the reconciliation subagent for a Python take-home that tracks |
| subagent | `claude-sonnet-5-5` | 40,501 | Add NFLX, ORCL, BP, RIO and SONY to the tracker, then prove it worked. |
| subagent | `claude-sonnet-5-5` | 32,420 | You are a fixer for the storage, checks and flows of a Python take-hom |
| subagent | `claude-sonnet-5-5` | 28,029 | Build a small read-only MCP server for a Python take-home that tracks  |
| subagent | `claude-opus-5-5` | 26,910 | You are an independent reviewer checking the documentation, handover k |
| subagent | `claude-opus-5-5` | 26,504 | You are an independent reviewer of a Python take-home project. You did |
| subagent | `claude-sonnet-5-5` | 24,513 | You are a fixer for the domain rules of a Python take-home that tracks |
| subagent | `claude-sonnet-5-5` | 22,887 | You are building the handover kit for a Python take-home that tracks S |
| subagent | `claude-sonnet-5-5` | 22,257 | You are the P2 scaffold builder for a Python take-home project. You im |
| subagent | `claude-opus-5-5` | 17,650 | You are a senior member of In Practise's data team grading a take-home |
| subagent | `claude-sonnet-5-5` | 17,337 | You are fixer Y for a Python + Postgres job that tracks SEC filings. A |
| subagent | `claude-sonnet-5-5` | 15,259 | Write the reviewer pack for a take-home submission: `README.md`, `REVI |
| subagent | `claude-sonnet-5-5` | 9,192 | This morning's check is red. Find out why and tell me what to do. Mach |
| subagent | `claude-sonnet-5-5` | 5,447 | Draft deliverable 4 of a take-home assignment: `docs/what-i-didnt-trus |
| subagent | `claude-haiku-5-5` | 1,606 | Run PowerShell: `Wait-Process -Id (Get-Process python -ErrorAction Sil |
