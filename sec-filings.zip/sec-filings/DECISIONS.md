# Decisions

Every open question in the brief, decided and written down. Each entry is short: the decision, then why. Agents: if a data decision is unclear, add an entry here and stop. Do not guess.

**D-01. Foreign private issuers are in scope.** SAP, SHEL, BABA, NVO and TM file a 20-F as their annual report and no 10-K or 10-Q. The 20-F counts as the annual report. Their 6-Ks are stored as `foreign_current_report`, because most are press releases and notices (Toyota has 603 in its recent window). A 6-K never answers a quarterly question. For these five the quarterly answer is "no periodic quarterly report is filed with the SEC".
*Why:* the analyst needs an answer for all 20 names. The brief's "10-K/10-Q" is read as "annual and quarterly reports".

**D-02. A company is an entity with a history of CIKs.** Exxon's ticker moved to CIK 2115436 on 2026-07-01. Its history sits under CIK 34088. The Q2 2026 10-Q appears under both and is stored once, with both CIKs recorded as aliases.
*Why:* following the ticker alone loses 30 years of Exxon history.

**D-03. Every filing is a row. The answer for a period is the latest complete version.** The latest filed version is recorded separately.
*Why:* most 10-K/As add only Part III or an exhibit. "Latest filed wins" would answer with a stub.

**D-04. Fiscal labels follow each company's own naming convention, applied consistently.** The convention is learned from the company's declared fiscal years (majority rule) and applied to every report's period end. A declared label that disagrees is kept in its own column and shown amber. Every label stores its source and confidence.
*Why:* Walmart names a year by the year it ends in; GameStop by the year it starts in. And companies changed how they declared it: Walmart's filings for 2010 to 2014 used the other convention. Taking each declared label literally produced two "fiscal 2009" Walmart reports (trust log T-8).

**D-05. Full history from 1994.**
*Why:* it costs little, and the brief's own example is 2009.

**D-06. Raw SEC responses are stored, hashed, before parsing.**
*Why:* any answer can be replayed and traced to what the SEC said on a given day, and tests run offline.

**D-07. The job never deletes rows.** Filings that disappear upstream are flagged stale.
*Why:* a silent delete would hide an SEC-side change.

**D-08. `companies.csv` is the list of record. `companies.yml` holds reviewed details.** A ticker in the CSV without a reviewed entry is resolved automatically, loaded, and flagged amber until a person reviews it. Any change in a ticker's CIK is red. The job never silently follows it.
*Why:* adding companies must work the obvious way, and the next Exxon-style change must be noticed.

**D-09. One command, with a default SEC User-Agent.** The default carries the author's personal contact address, overridable with `SEC_USER_AGENT`. Never an employer address.
*Why:* a grader with only `DATABASE_URL` set must succeed first time.

**D-10. Corrections are events, separate from amendments.** An event is a non-reliance 8-K (item 4.02) or a cover-page error-correction flag. Amendments separately get a kind: `restatement`, `accounting_change`, `administrative` or `unknown`.
*Why:* a restatement can arrive in the next ordinary 10-K with no amendment. Apple's FY2009 10-K/A came from a voluntary accounting change and is not a correction.

**D-11. Lucid's pre-merger shell history is kept and flagged.** CIK 1811210 was Churchill Capital Corp IV until the July 2021 merger.
*Why:* the shell's May 2021 restatement is real, but it belongs to the shell. The analyst sees it separately.

**D-12. AT&T's history includes SBC Communications.** CIK 732717 was SBC until 2005. The old AT&T Corp is a different CIK and out of scope.
*Why:* same legal entity; stated so nobody is surprised.

**D-13. Lateness uses the filer category on that filing's own cover page, EDGAR's filing date, and Rule 12b-25 grace.** "Last 10 years" means fiscal years ending 2016-11-01 to 2026-10-31.
*Why:* deadlines depend on the category the company had that year, not today.

**D-14. Deployment is optional. The heartbeat that detects a missing run is external to the job.**
*Why:* a job cannot report that it did not run.

**D-15. The raw session logs are not shared; the record of the work is.** The brief invites the logs "if you're comfortable". They mix the build with my planning conversation and personal interview preparation, and they repeat the tool's system prompt, which describes unrelated client work on this machine. Instead the repository carries the record: every delegation and what came back (`docs/agent-log.md`), every caught error (`docs/trust-log.md`), how the agents were organised (`docs/how-it-was-built.md`) and token use by model (`docs/agent-usage.md`). A scrubbed export of the build phase exists and can be shared on request.
*Why:* a first scrubbed export still leaked client names through the system prompt (trust log T-15). Not sharing raw logs removes that risk entirely; the written record is what a reviewer would read anyway.

**D-16. "06:00" means 06:00 Europe/London.** That is 01:00 or 02:00 US Eastern, after EDGAR publishes the previous business day's index at about 22:00 Eastern.
*Why:* the brief gives no time zone, and the choice decides whether yesterday's data is complete.

**D-17. Submission is a Git repository with full history.** A zip, if used, includes `.git`.
*Why:* the commit history shows the process.

**D-18. The Rule 12b-25 extension is counted from the business-day due date.** When a deadline falls on a weekend or holiday, it moves to the next business day. The 15-day (annual) or 5-day (quarterly) extension is counted from that date, then moved again if needed.
*Why:* the rule is ambiguous on this point, and the lenient reading never calls a filing late that a reasonable reading calls timely. Plug Power's FY2014 10-K, filed 2015-03-17, is timely under this reading and late under the strict one.

**D-19. Lateness is only claimed when the filer category is known for that year.** The category comes from the filing's own cover page, its public float, or the previous annual report's. When only today's category is available, the deadline is still computed but the report is not called late.
*Why:* applying today's category to old years produced 12 false "late" findings (trust log T-12).

**D-20. Amendments are classified only from 2009-06-15, and unclear ones are reviewed by a person.** Before that date no rendered reports exist to judge scope. After it, a rule decides scope and kind, and any amendment the rule cannot separate gets a reviewed entry in `companies.yml` with its evidence.
*Why:* an add-on amendment must never become the answer for its year (trust log T-11).

**D-21. A quarterly period that is a real quarter end is trusted even when filed soon after.** A period is normally treated as unreliable when it falls within 14 days of the filing date. That exception does not apply to a quarterly report whose period is a fiscal quarter end before the filing date.
*Why:* Oracle files its 10-Qs 10 to 13 days after quarter end, and the 14-day rule moved them back a quarter (trust log T-14). Apple's 1997 10-Q/A, whose period is its filing date, is still corrected.

**D-22. Reports due during the SEC's March to July 2020 COVID-19 relief get 45 extra days, marked "relief assumed (not verified)".** The relief required a current report explaining the delay, which the job does not check.
*Why:* without it, AMC's Q1 2020 10-Q would be called late when it was most likely covered.

**D-23. A missing filing keeps check C3 red until it is found or a person acknowledges it** with `sec-filings ack C3 <date> --reason "..."`. Acknowledged items show amber with the reason.
*Why:* a problem must never turn green on its own because time passed (independent review, 2026-11-12).

**D-24. Exit codes: 0 green, 1 amber, 2 red, 3 run failed, 4 skipped because another run holds the lock.** Deliberate, reviewed differences between a company's declared fiscal year and its convention label (D-04) are reported as information, not amber.
*Why:* a normal morning should exit 0, so that amber and red keep their meaning for whoever is on call.